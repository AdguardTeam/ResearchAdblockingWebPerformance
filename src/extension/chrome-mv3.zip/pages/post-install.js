/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/.pnpm/nanobar@0.4.2/node_modules/nanobar/nanobar.js":
/*!**************************************************************************!*\
  !*** ./node_modules/.pnpm/nanobar@0.4.2/node_modules/nanobar/nanobar.js ***!
  \**************************************************************************/
/***/ (function(module) {

/* http://nanobar.micronube.com/  ||  https://github.com/jacoborus/nanobar/    MIT LICENSE */
(function (root) {
  'use strict'
  // container styles
  var css = '.nanobar{width:100%;height:4px;z-index:9999;top:0}.bar{width:0;height:100%;transition:height .3s;background:#000}'

  // add required css in head div
  function addCss () {
    var s = document.getElementById('nanobarcss')

    // check whether style tag is already inserted
    if (s === null) {
      s = document.createElement('style')
      s.type = 'text/css'
      s.id = 'nanobarcss'
      document.head.insertBefore(s, document.head.firstChild)
      // the world
      if (!s.styleSheet) return s.appendChild(document.createTextNode(css))
      // IE
      s.styleSheet.cssText = css
    }
  }

  function addClass (el, cls) {
    if (el.classList) el.classList.add(cls)
    else el.className += ' ' + cls
  }

  // create a progress bar
  // this will be destroyed after reaching 100% progress
  function createBar (rm) {
    // create progress element
    var el = document.createElement('div'),
        width = 0,
        here = 0,
        on = 0,
        bar = {
          el: el,
          go: go
        }

    addClass(el, 'bar')

    // animation loop
    function move () {
      var dist = width - here

      if (dist < 0.1 && dist > -0.1) {
        place(here)
        on = 0
        if (width === 100) {
          el.style.height = 0
          setTimeout(function () {
            rm(el)
          }, 300)
        }
      } else {
        place(width - dist / 4)
        setTimeout(go, 16)
      }
    }

    // set bar width
    function place (num) {
      width = num
      el.style.width = width + '%'
    }

    function go (num) {
      if (num >= 0) {
        here = num
        if (!on) {
          on = 1
          move()
        }
      } else if (on) {
        move()
      }
    }
    return bar
  }

  function Nanobar (opts) {
    opts = opts || {}
    // set options
    var el = document.createElement('div'),
        applyGo,
        nanobar = {
          el: el,
          go: function (p) {
            // expand bar
            applyGo(p)
            // create new bar when progress reaches 100%
            if (p === 100) {
              init()
            }
          }
        }

    // remove element from nanobar container
    function rm (child) {
      el.removeChild(child)
    }

    // create and insert progress var in nanobar container
    function init () {
      var bar = createBar(rm)
      el.appendChild(bar.el)
      applyGo = bar.go
    }

    addCss()

    addClass(el, 'nanobar')
    if (opts.id) el.id = opts.id
    if (opts.classname) addClass(el, opts.classname)

    // insert container
    if (opts.target) {
      // inside a div
      el.style.position = 'relative'
      opts.target.insertBefore(el, opts.target.firstChild)
    } else {
      // on top of the page
      el.style.position = 'fixed'
      document.getElementsByTagName('body')[0].appendChild(el)
    }

    init()
    return nanobar
  }

  if (true) {
    // CommonJS
    module.exports = Nanobar
  } else {}
}(this))


/***/ }),

/***/ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.12.0 - Tue May 14 2024 18:01:29 */
  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
  /* vim: set sts=2 sw=2 et tw=80: */
  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
    throw new Error("This script should only be loaded in a browser extension.");
  }
  if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";

    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }

      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }

      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };

      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);

                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };

      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },
          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }
            if (!(prop in target)) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.

              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };

        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };

      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */
        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {} /* wrappers */, {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);

          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }

          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };

          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }

          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "./Extension/src/common/i18n.ts":
/*!**************************************!*\
  !*** ./Extension/src/common/i18n.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I18n: () => (/* binding */ I18n)
/* harmony export */ });
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/**
 * @file
 * I18n file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 
/**
 * Injects translations to DOM elements with i18n attributes
 */ class I18n {
    /**
     * Initializes injector.
     */ static init() {
        document.addEventListener('DOMContentLoaded', I18n.translate);
    }
    /**
     * Processes i18n injections
     */ static translate() {
        I18n.translateElements('i18n');
        I18n.translateAttributes('i18n-plhr', 'placeholder');
        I18n.translateAttributes('i18n-href', 'href');
        I18n.translateAttributes('i18n-title', 'title');
    }
    /**
     * Translates elements with specified {@link i18nAttributeName}
     *
     * @param i18nAttributeName - i18n attribute
     */ static translateElements(i18nAttributeName) {
        document.querySelectorAll(`[${i18nAttributeName}]`).forEach((el)=>{
            const message = I18n.getI18nMessage(el, i18nAttributeName);
            if (!message) {
                return;
            }
            I18n.translateElement(el, message);
        });
    }
    /**
     * Replaces content of {@link element} to translation
     *
     * @param element - target element
     * @param message - element text
     */ static translateElement(element, message) {
        try {
            // remove original content
            while(element.lastChild){
                element.removeChild(element.lastChild);
            }
            // append translated content
            I18n.processString(message, element);
        } catch (ex) {
        // Ignore exceptions
        }
    }
    /**
     * Creates translated {@link element} child nodes and appends it to parent
     *
     * @param html - html string
     * @param element - target element
     */ static processString(html, element) {
        let el;
        const match1 = /^([^]*?)<(a|strong|span|i)([^>]*)>(.*?)<\/\2>([^]*)$/m.exec(html);
        const match2 = /^([^]*?)<(br|input)([^>]*)\/?>([^]*)$/m.exec(html);
        if (match1) {
            // TODO: safe types
            /* eslint-disable @typescript-eslint/no-non-null-assertion */ I18n.processString(match1[1], element);
            el = I18n.createElement(match1[2], match1[3]);
            I18n.processString(match1[4], el);
            element.appendChild(el);
            I18n.processString(match1[5], element);
        } else if (match2) {
            I18n.processString(match2[1], element);
            el = I18n.createElement(match2[2], match2[3]);
            element.appendChild(el);
            I18n.processString(match2[4], element);
        /* eslint-enable @typescript-eslint/no-non-null-assertion */ } else {
            element.appendChild(document.createTextNode(html.replace(/&nbsp;/g, '\u00A0')));
        }
    }
    /**
     * Creates elements with specified attributes.
     *
     * @param tagName - element tag
     * @param attributes - attributes string value
     *
     * @returns created element
     */ static createElement(tagName, attributes) {
        const el = document.createElement(tagName);
        if (!attributes) {
            return el;
        }
        attributes.split(/([a-z]+='[^']+')/).forEach((attr)=>{
            if (!attr) {
                return;
            }
            const index = attr.indexOf('=');
            let attrName;
            let attrValue;
            if (index > 0) {
                attrName = attr.substring(0, index);
                attrValue = attr.substring(index + 2, attr.length - 1);
            }
            if (attrName && attrValue) {
                el.setAttribute(attrName, attrValue);
            }
        });
        return el;
    }
    /**
     * Finds all elements with specified {@link i18nAttributeName},
     * translates attributes and sets to elements {@link attributeName}
     *
     * @param i18nAttributeName -  name of i18n attribute
     * @param attributeName  - name of translated attribute
     */ static translateAttributes(i18nAttributeName, attributeName) {
        document.querySelectorAll(`[${i18nAttributeName}]`).forEach((element)=>{
            const message = I18n.getI18nMessage(element, i18nAttributeName);
            if (!message) {
                return;
            }
            element.setAttribute(attributeName, message);
        });
    }
    /**
     * Returns element attribute value and translate it.
     *
     * @param element - page element
     * @param attributeName - name of element attribute
     *
     * @returns translated attribute value
     */ static getI18nMessage(element, attributeName) {
        const attribute = element.getAttribute(attributeName);
        if (!attribute) {
            return null;
        }
        return webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().i18n.getMessage(attribute);
    }
}


/***/ }),

/***/ "./Extension/src/common/logger.ts":
/*!****************************************!*\
  !*** ./Extension/src/common/logger.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   logger: () => (/* binding */ logger)
/* harmony export */ });
/* harmony import */ var core_js_modules_web_self_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/web.self.js */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/web.self.js");
/* harmony import */ var core_js_modules_web_self_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_self_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _adguard_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @adguard/logger */ "./node_modules/.pnpm/@adguard+logger@1.1.1/node_modules/@adguard/logger/dist/es/index.mjs");
/**
 * @file
 *
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

class ExtendedLogger extends _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.Logger {
    isVerbose() {
        return this.currentLevel === _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.LogLevel.Debug || this.currentLevel === _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.LogLevel.Trace;
    }
}
const logger = new ExtendedLogger();
logger.currentLevel =  false ? 0 : _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.LogLevel.Trace;
// Expose logger to the window object,
// to have possibility to switch log level from the console.
// Example: adguard.logger.currentLevel = 'debug'
// eslint-disable-next-line no-restricted-globals
Object.assign(self, {
    adguard: {
        ...self.adguard,
        logger
    }
});



/***/ }),

/***/ "./Extension/src/common/messages/constants.ts":
/*!****************************************************!*\
  !*** ./Extension/src/common/messages/constants.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   APP_MESSAGE_HANDLER_NAME: () => (/* binding */ APP_MESSAGE_HANDLER_NAME),
/* harmony export */   MessageType: () => (/* binding */ MessageType)
/* harmony export */ });
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Important: do not use z.inferOf, because it brings a lot of side effects with
 * many dependencies to the bundle.
 *
 * Also please try, if possible, to not import here external modules
 * other that types.
 */ const APP_MESSAGE_HANDLER_NAME = 'app';
/**
 * Message types used for message passing between extension contexts
 * (popup, filtering log, content scripts, background)
 */ var MessageType = /*#__PURE__*/ function(MessageType) {
    MessageType["CreateEventListener"] = "createEventListener";
    MessageType["RemoveListener"] = "removeListener";
    MessageType["OpenExtensionStore"] = "openExtensionStore";
    MessageType["AddAndEnableFilter"] = "addAndEnableFilter";
    MessageType["ApplySettingsJson"] = "applySettingsJson";
    MessageType["OpenFilteringLog"] = "openFilteringLog";
    MessageType["OpenFullscreenUserRules"] = "openFullscreenUserRules";
    MessageType["UpdateFullscreenUserRulesTheme"] = "updateFullscreenUserRulesTheme";
    MessageType["ResetBlockedAdsCount"] = "resetBlockedAdsCount";
    MessageType["ResetSettings"] = "resetSettings";
    MessageType["GetUserRules"] = "getUserRules";
    MessageType["SaveUserRules"] = "saveUserRules";
    MessageType["GetAllowlistDomains"] = "getAllowlistDomains";
    MessageType["SaveAllowlistDomains"] = "saveAllowlistDomains";
    MessageType["CheckFiltersUpdate"] = "checkFiltersUpdate";
    MessageType["DisableFiltersGroup"] = "disableFiltersGroup";
    MessageType["DisableFilter"] = "disableFilter";
    MessageType["LoadCustomFilterInfo"] = "loadCustomFilterInfo";
    MessageType["SubscribeToCustomFilter"] = "subscribeToCustomFilter";
    MessageType["RemoveAntiBannerFilter"] = "removeAntiBannerFilter";
    MessageType["GetIsEngineStarted"] = "getIsEngineStarted";
    MessageType["GetTabInfoForPopup"] = "getTabInfoForPopup";
    MessageType["ChangeApplicationFilteringPaused"] = "changeApplicationFilteringPaused";
    MessageType["OpenRulesLimitsTab"] = "openRulesLimitsTab";
    MessageType["OpenSettingsTab"] = "openSettingsTab";
    MessageType["OpenAssistant"] = "openAssistant";
    MessageType["OpenAbuseTab"] = "openAbuseTab";
    MessageType["OpenSiteReportTab"] = "openSiteReportTab";
    MessageType["OpenComparePage"] = "openComparePage";
    MessageType["ResetUserRulesForPage"] = "resetUserRulesForPage";
    MessageType["RemoveAllowlistDomain"] = "removeAllowlistDomain";
    MessageType["AddAllowlistDomain"] = "addAllowlistDomain";
    MessageType["OnOpenFilteringLogPage"] = "onOpenFilteringLogPage";
    MessageType["GetFilteringLogData"] = "getFilteringLogData";
    MessageType["InitializeFrameScript"] = "initializeFrameScript";
    MessageType["OnCloseFilteringLogPage"] = "onCloseFilteringLogPage";
    MessageType["GetFilteringInfoByTabId"] = "getFilteringInfoByTabId";
    MessageType["SynchronizeOpenTabs"] = "synchronizeOpenTabs";
    MessageType["ClearEventsByTabId"] = "clearEventsByTabId";
    MessageType["RefreshPage"] = "refreshPage";
    MessageType["AddUserRule"] = "addUserRule";
    MessageType["RemoveUserRule"] = "removeUserRule";
    MessageType["EnableFiltersGroup"] = "enableFiltersGroup";
    MessageType["NotifyListeners"] = "notifyListeners";
    MessageType["AddLongLivedConnection"] = "addLongLivedConnection";
    MessageType["GetOptionsData"] = "getOptionsData";
    MessageType["ChangeUserSettings"] = "changeUserSetting";
    MessageType["CheckRequestFilterReady"] = "checkRequestFilterReady";
    MessageType["OpenThankyouPage"] = "openThankYouPage";
    MessageType["OpenSafebrowsingTrusted"] = "openSafebrowsingTrusted";
    MessageType["GetSelectorsAndScripts"] = "getSelectorsAndScripts";
    MessageType["CheckPageScriptWrapperRequest"] = "checkPageScriptWrapperRequest";
    MessageType["ProcessShouldCollapse"] = "processShouldCollapse";
    MessageType["ProcessShouldCollapseMany"] = "processShouldCollapseMany";
    MessageType["AddFilteringSubscription"] = "addFilterSubscription";
    MessageType["SetNotificationViewed"] = "setNotificationViewed";
    MessageType["SaveCssHitsStats"] = "saveCssHitStats";
    MessageType["GetCookieRules"] = "getCookieRules";
    MessageType["SaveCookieLogEvent"] = "saveCookieRuleEvent";
    MessageType["LoadSettingsJson"] = "loadSettingsJson";
    MessageType["AddUrlToTrusted"] = "addUrlToTrusted";
    MessageType["SetPreserveLogState"] = "setPreserveLogState";
    MessageType["GetUserRulesEditorData"] = "getUserRulesEditorData";
    MessageType["GetEditorStorageContent"] = "getEditorStorageContent";
    MessageType["SetEditorStorageContent"] = "setEditorStorageContent";
    MessageType["SetFilteringLogWindowState"] = "setFilteringLogWindowState";
    MessageType["AppInitialized"] = "appInitialized";
    MessageType["UpdateTotalBlocked"] = "updateTotalBlocked";
    MessageType["ScriptletCloseWindow"] = "scriptletCloseWindow";
    MessageType["ShowRuleLimitsAlert"] = "showRuleLimitsAlert";
    MessageType["ShowAlertPopup"] = "showAlertPopup";
    MessageType["ShowVersionUpdatedPopup"] = "showVersionUpdatedPopup";
    MessageType["UpdateListeners"] = "updateListeners";
    MessageType["SetConsentedFilters"] = "setConsentedFilters";
    MessageType["GetIsConsentedFilter"] = "getIsConsentedFilter";
    MessageType["GetRulesLimitsCountersMv3"] = "getRulesLimitsCountersMv3";
    MessageType["CanEnableStaticFilterMv3"] = "canEnableStaticFilterMv3";
    MessageType["CanEnableStaticGroupMv3"] = "canEnableStaticGroupMv3";
    MessageType["ClearRulesLimitsWarningMv3"] = "clearRulesLimitsWarningMv3";
    MessageType["RestoreFiltersMv3"] = "restoreFiltersMv3";
    MessageType["CurrentLimitsMv3"] = "currentLimitsMv3";
    return MessageType;
}({});


/***/ }),

/***/ "./Extension/src/common/messages/index.ts":
/*!************************************************!*\
  !*** ./Extension/src/common/messages/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   APP_MESSAGE_HANDLER_NAME: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.APP_MESSAGE_HANDLER_NAME),
/* harmony export */   MessageType: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.MessageType),
/* harmony export */   messageHasTypeAndDataFields: () => (/* reexport safe */ _message_handler__WEBPACK_IMPORTED_MODULE_2__.messageHasTypeAndDataFields),
/* harmony export */   messageHasTypeField: () => (/* reexport safe */ _message_handler__WEBPACK_IMPORTED_MODULE_2__.messageHasTypeField)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./Extension/src/common/messages/constants.ts");
/* harmony import */ var _send_message__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./send-message */ "./Extension/src/common/messages/send-message.ts");
/* harmony import */ var _message_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./message-handler */ "./Extension/src/common/messages/message-handler.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 




/***/ }),

/***/ "./Extension/src/common/messages/message-handler.ts":
/*!**********************************************************!*\
  !*** ./Extension/src/common/messages/message-handler.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   messageHasTypeAndDataFields: () => (/* binding */ messageHasTypeAndDataFields),
/* harmony export */   messageHasTypeField: () => (/* binding */ messageHasTypeField)
/* harmony export */ });
/* unused harmony export MessageHandler */
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.error.cause.js");
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./Extension/src/common/messages/constants.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}



/**
 * Type guard for messages that have a 'type' field with possible {@link MessageType}.
 *
 * @note Added to no bring here huge zod library.
 *
 * @param message Unknown message.
 *
 * @returns True if message has 'type' field with possible {@link MessageType}.
 */ const messageHasTypeField = (message)=>{
    return typeof message === 'object' && message !== null && 'type' in message;
};
/**
 * Type guard for messages that have a 'type' field and 'data' field and looks like {@link Message}.
 *
 * @note Added to no bring here huge zod library.
 *
 * @param message Unknown message.
 *
 * @returns True if message has 'type' and 'data' fields and looks like {@link Message}.
 */ const messageHasTypeAndDataFields = (message)=>{
    return messageHasTypeField(message) && 'data' in message;
};
/**
 * API for handling Messages via {@link browser.runtime.onMessage}
 */ class MessageHandler {
    init() {
        webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.onMessage.addListener(this.handleMessage);
    }
    /**
     * Add message listener.
     * Listeners limited to 1 per message type to prevent race
     * condition while response processing.
     *
     * TODO: implement listeners priority execution strategy
     *
     * @param type - {@link ValidMessageTypes}
     * @param listener - {@link MessageListener}
     *
     * @throws error, if message listener already added
     */ addListener(type, listener) {
        if (this.listeners.has(type)) {
            throw new Error(`Message handler: ${type} listener has already been registered`);
        }
        // Cast through unknown to help TS understand that the listener is of
        // the correct type. It will check types at compile time.
        this.listeners.set(type, listener);
    }
    /**
     * Removes message listener.
     *
     * @param type - {@link ValidMessageTypes}
     */ removeListener(type) {
        this.listeners.delete(type);
    }
    /**
     * Removes all listeners
     */ removeListeners() {
        this.listeners.clear();
    }
    /**
     * Check if the message is of type {@link Message}.
     *
     * @param message Message of basic type {@link Message} or {@link EngineMessage}.
     *
     * @returns True if the message is of type {@link Message}.
     */ static isValidMessageType(message) {
        return message.handlerName === _constants__WEBPACK_IMPORTED_MODULE_2__.APP_MESSAGE_HANDLER_NAME && 'type' in message;
    }
    constructor(){
        _define_property(this, "listeners", new Map());
        this.handleMessage = this.handleMessage.bind(this);
    }
}


/***/ }),

/***/ "./Extension/src/common/messages/send-message.ts":
/*!*******************************************************!*\
  !*** ./Extension/src/common/messages/send-message.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports sendMessage, sendTabMessage */
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./Extension/src/common/messages/constants.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

/**
 * TODO: Consider moving this file to the background folder, because all messages
 * from the UI should be send via methods of Messenger class instead of using
 * directly sendMessage to proper types checking.
 *
 * {@link sendMessage} sends app message via {@link browser.runtime.sendMessage} and
 * gets response from another extension page message handler
 *
 * @param message - partial {@link Message} record without {@link Message.handlerName} field
 *
 * @returns message handler response
 */ async function sendMessage(message) {
    try {
        return await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime.sendMessage({
            handlerName: _constants__WEBPACK_IMPORTED_MODULE_1__.APP_MESSAGE_HANDLER_NAME,
            ...message
        });
    } catch (e) {
    // do nothing
    }
}
/**
 * {@link sendTabMessage} sends message to specified tab via {@link browser.tabs.sendMessage} and
 * gets response from it
 *
 * @param tabId - tab id
 * @param message - partial {@link Message} record without {@link Message.handlerName} field
 *
 * @returns tab message handler response
 */ async function sendTabMessage(tabId, message) {
    return webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.sendMessage(tabId, {
        handlerName: _constants__WEBPACK_IMPORTED_MODULE_1__.APP_MESSAGE_HANDLER_NAME,
        ...message
    });
}


/***/ }),

/***/ "./Extension/src/pages/post-install.ts":
/*!*********************************************!*\
  !*** ./Extension/src/pages/post-install.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PostInstall: () => (/* binding */ PostInstall)
/* harmony export */ });
/* harmony import */ var nanobar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! nanobar */ "./node_modules/.pnpm/nanobar@0.4.2/node_modules/nanobar/nanobar.js");
/* harmony import */ var nanobar__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nanobar__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/logger */ "./Extension/src/common/logger.ts");
/* harmony import */ var _services_messenger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/messenger */ "./Extension/src/pages/services/messenger.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ // @ts-ignore
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}



class PostInstall {
    static init() {
        document.addEventListener('DOMContentLoaded', PostInstall.onDOMContentLoaded);
    }
    static onDOMContentLoaded() {
        PostInstall.nanobar.go(15);
        PostInstall.checkRequestFilterReady();
    }
    static async checkRequestFilterReady() {
        try {
            const ready = await _services_messenger__WEBPACK_IMPORTED_MODULE_2__.messenger.checkRequestFilterReady();
            if (ready) {
                PostInstall.onEngineLoaded();
            } else {
                setTimeout(PostInstall.checkRequestFilterReady, PostInstall.checkRequestTimeoutMs);
            }
        } catch (e) {
            _common_logger__WEBPACK_IMPORTED_MODULE_1__.logger.error(e);
            // retry request, if message handler is not ready
            setTimeout(PostInstall.checkRequestFilterReady, PostInstall.checkRequestTimeoutMs);
        }
    }
    static onEngineLoaded() {
        PostInstall.nanobar.go(100);
        setTimeout(()=>{
            if (window) {
                _services_messenger__WEBPACK_IMPORTED_MODULE_2__.messenger.openThankyouPage();
            }
        }, PostInstall.openThankyouPageTimeoutMs);
    }
}
_define_property(PostInstall, "nanobar", new (nanobar__WEBPACK_IMPORTED_MODULE_0___default())({
    classname: 'adg-progress-bar'
}));
_define_property(PostInstall, "checkRequestTimeoutMs", 500);
_define_property(PostInstall, "openThankyouPageTimeoutMs", 1000);


/***/ }),

/***/ "./Extension/src/pages/services/messenger.ts":
/*!***************************************************!*\
  !*** ./Extension/src/pages/services/messenger.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   messenger: () => (/* binding */ messenger)
/* harmony export */ });
/* unused harmony exports Page, Messenger */
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! nanoid */ "./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js");
/* harmony import */ var _common_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/logger */ "./Extension/src/common/logger.ts");
/* harmony import */ var _common_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/messages */ "./Extension/src/common/messages/index.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}





var Page = /*#__PURE__*/ function(Page) {
    Page["FullscreenUserRules"] = "fullscreen-user-rules";
    Page["FilteringLog"] = "filtering-log";
    return Page;
}({});
/**
 * Messenger class, used to communicate with the background page from the UI.
 * Actually, it's a wrapper around the browser.runtime.sendMessage method.
 */ class Messenger {
    /**
     * Sends a message to the background page.
     *
     * All messages described in the {@link MessageType} enum.
     * All answers described in the {@link MessageMap} type.
     *
     * @param type Message type.
     * @param data Message data. Optional because not all messages have data.
     *
     * @returns Promise that resolves with the response from the background page.
     * Type of the response depends on the message type. Go to {@link MessageMap}
     * to see all possible message types and their responses.
     */ // eslint-disable-next-line class-methods-use-this
    async sendMessage(type, data) {
        const response = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.sendMessage({
            handlerName: _common_messages__WEBPACK_IMPORTED_MODULE_3__.APP_MESSAGE_HANDLER_NAME,
            type,
            data
        });
        return response;
    }
    /**
     * Sends a message from background page to update listeners on the UI.
     *
     * @returns Promise that resolves when the message is sent.
     */ async updateListeners() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.UpdateListeners);
    }
    /**
     * Sends a message to the background page to get the settings data for
     * the options page with some additional info.
     *
     * @returns Promise that resolves with the settings data for
     * the options page with some additional info.
     */ async getOptionsData() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetOptionsData);
    }
    /**
     * Sends a message to the background page to change the user setting.
     *
     * @param settingId Setting identifier.
     * @param value Setting value.
     *
     * @returns Promise that resolves after the message is sent.
     */ async changeUserSetting(settingId, value) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ChangeUserSettings, {
            key: settingId,
            value
        });
    }
    /**
     * Sends a message to the background page to open the extension store.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openExtensionStore() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenExtensionStore);
    }
    /**
     * Sends a message to the background page to open the compare page.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openComparePage() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenComparePage);
    }
    /**
     * Sends a message to the background page to enable a filter by filter id.
     *
     * @param filterId Filter identifier.
     *
     * @returns Promise that resolves after the message is sent.
     */ async enableFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddAndEnableFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to disable a filter by filter id.
     *
     * @param filterId Filter identifier.
     *
     * @returns Promise that resolves after the message is sent.
     */ async disableFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.DisableFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to apply settings from a JSON object.
     *
     * @param json JSON object representing the settings to apply.
     *
     * @returns Promise that resolves after the message is sent.
     */ async applySettingsJson(json) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ApplySettingsJson, {
            json
        });
    }
    /**
     * Sends a message to the background page to open the filtering log.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openFilteringLog() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenFilteringLog);
    }
    /**
     * Sends a message to the background page to reset the blocked ads statistics.
     *
     * @returns Promise that resolves after the message is sent.
     */ async resetStatistics() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ResetBlockedAdsCount);
    }
    /**
     * Sends a message to the background page to set the filtering log window state.
     *
     * @param windowState State of the filtering log window.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setFilteringLogWindowState(windowState) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetFilteringLogWindowState, {
            windowState
        });
    }
    /**
     * Sends a message to the background page to reset the settings.
     *
     * @returns Promise that resolves after the message is sent.
     */ async resetSettings() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ResetSettings);
    }
    /**
     * Sends a message to the background page to get the user rules.
     *
     * @returns Promise that resolves with the user rules.
     */ async getUserRules() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetUserRules);
    }
    /**
     * Sends a message to the background page to save user rules.
     *
     * @param value User rules value to save.
     *
     * @returns Promise that resolves after the message is sent.
     */ async saveUserRules(value) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SaveUserRules, {
            value
        });
    }
    /**
     * Sends a message to the background page to open user rules editor in fullscreen.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openFullscreenUserRules() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenFullscreenUserRules);
    }
    /**
     * Sends a message to the background page to get the allowlist domains.
     *
     * @returns Promise that resolves with the list of allowlist domains.
     */ async getAllowlist() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetAllowlistDomains);
    }
    /**
     * Sends a message to the background page to save the allowlist domains.
     *
     * @param value Allowlist domains value to save.
     *
     * @returns Promise that resolves after the message is sent.
     */ async saveAllowlist(value) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SaveAllowlistDomains, {
            value
        });
    }
    /**
     * Sends a message to the background page to mark a notification as viewed.
     *
     * @param withDelay Whether the notification should be marked as viewed after a delay.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setNotificationViewed(withDelay) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetNotificationViewed, {
            withDelay
        });
    }
    /**
     * Sends a message to the background page to update filters.
     *
     * @returns Promise that resolves with the list of filters.
     */ async updateFilters() {
        if (true) {
            _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.debug('Filters update is not supported in MV3');
            return [];
        }
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CheckFiltersUpdate);
    }
    /**
     * Sends a message to the background page to update the status of a filter group.
     *
     * @param id Group identifier.
     * @param enabled Whether the group should be enabled or disabled.
     *
     * @returns Promise that resolves after the message is sent.
     */ async updateGroupStatus(id, enabled) {
        const type = enabled ? _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.EnableFiltersGroup : _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.DisableFiltersGroup;
        const groupId = Number.parseInt(id, 10);
        return this.sendMessage(type, {
            groupId
        });
    }
    /**
     * Sends a message to the background page to set consented filters.
     *
     * @param filterIds List of filter identifiers.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setConsentedFilters(filterIds) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetConsentedFilters, {
            filterIds
        });
    }
    /**
     * Sends a message to the background page to check if a filter is consented.
     *
     * @param filterId Filter identifier.
     *
     * @returns Promise that resolves with the result of the check.
     */ async getIsConsentedFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetIsConsentedFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to check a custom filter URL.
     *
     * @param url Custom filter URL.
     *
     * @returns Promise that resolves with the result of the check.
     */ async checkCustomUrl(url) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.LoadCustomFilterInfo, {
            url
        });
    }
    /**
     * Sends a message to the background page to add a custom filter.
     *
     * @param {CustomFilterSubscriptionData} filter Custom filter data.
     *
     * @returns {Promise<CustomFilterMetadata>} Custom filter metadata.
     */ async addCustomFilter(filter) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SubscribeToCustomFilter, {
            filter
        });
    }
    /**
     * Sends a message to the background page to remove a custom filter.
     *
     * @param filterId Custom filter ID.
     *
     * @returns Promise that resolves after the filter is removed.
     */ async removeCustomFilter(filterId) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveAntiBannerFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to check if the engine is started.
     *
     * @returns Promise that resolves to a boolean value:
     * true if the engine is started, false otherwise.
     */ async getIsEngineStarted() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetIsEngineStarted);
    }
    /**
     * Sends a message to the background to get the tab info for the popup.
     *
     * @param tabId Tab ID.
     *
     * @returns Promise that resolves with the tab info or undefined.
     */ async getTabInfoForPopup(tabId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetTabInfoForPopup, {
            tabId
        });
    }
    /**
     * Sends a message to the background page to change application filtering state.
     *
     * @param state Application filtering state.
     *
     * @returns Promise that resolves after the state is changed.
     */ async changeApplicationFilteringPaused(state) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ChangeApplicationFilteringPaused, {
            state
        });
    }
    /**
     * Sends a message to the background page to update the theme of the fullscreen user rules.
     *
     * @param theme Theme to set.
     *
     * @returns Promise that resolves after the theme is updated.
     */ async updateFullscreenUserRulesTheme(theme) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.UpdateFullscreenUserRulesTheme, {
            theme
        });
    }
    /**
     * Sends a message to the background page to open the rules limits tab.
     *
     * @returns Promise that resolves after the tab is opened.
     */ async openRulesLimitsTab() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenRulesLimitsTab);
    }
    /**
     * Sends a message to the background page to open the settings tab.
     *
     * @returns Promise that resolves after the tab is opened.
     */ async openSettingsTab() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenSettingsTab);
    }
    /**
     * Sends a message to the background page to open the assistant.
     *
     * @returns Promise that resolves after the assistant is opened.
     */ async openAssistant() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenAssistant);
    }
    /**
     * Sends a message to the background page to open the abuse reporting tab for a site.
     *
     * @param url The URL of the site to report abuse for.
     * @param from The source of the request.
     *
     * @returns Promise that resolves after the tab is opened.
     */ async openAbuseSite(url, from) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenAbuseTab, {
            url,
            from
        });
    }
    /**
     * Sends a message to the background page to check site security.
     *
     * @param url The URL of the site to check.
     * @param from The source of the request.
     *
     * @returns Promise that resolves with the site security info.
     */ async checkSiteSecurity(url, from) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenSiteReportTab, {
            url,
            from
        });
    }
    /**
     * Sends a message to the background page to reset user rules for a specific page.
     *
     * @param url The URL of the page.
     *
     * @returns Promise that resolves after the user rules are reset.
     */ async resetUserRulesForPage(url) {
        const [currentTab] = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().tabs.query({
            active: true,
            currentWindow: true
        });
        if (!(currentTab === null || currentTab === void 0 ? void 0 : currentTab.id)) {
            _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.debug('[resetUserRulesForPage]: cannot get current tab id');
            return;
        }
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ResetUserRulesForPage, {
            url,
            tabId: currentTab === null || currentTab === void 0 ? void 0 : currentTab.id
        });
    }
    /**
     * Sends a message to the background page to remove an allowlist domain.
     *
     * @param tabId The ID of the tab.
     * @param tabRefresh Whether the tab should be refreshed.
     *
     * @returns Promise that resolves after the domain is removed.
     */ async removeAllowlistDomain(tabId, tabRefresh) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveAllowlistDomain, {
            tabId,
            tabRefresh
        });
    }
    /**
     * Sends a message to the background page to add an allowlist domain.
     *
     * @param tabId The ID of the tab.
     *
     * @returns Promise that resolves after the domain is added.
     */ async addAllowlistDomain(tabId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddAllowlistDomain, {
            tabId
        });
    }
    /**
     * Works only in MV2, since MV3 doesn't support filtering log yet.
     *
     * @returns Promise that resolves after the filtering log page is opened.
     */ async onOpenFilteringLogPage() {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OnOpenFilteringLogPage);
    }
    /**
     * Sends a message to the background page to get filtering log data.
     *
     * @returns Promise that resolves with filtering log data.
     */ async getFilteringLogData() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetFilteringLogData);
    }
    /**
     * Sends a message to the background page to close the filtering log page.
     *
     * @returns Promise that resolves after the page is closed.
     */ async onCloseFilteringLogPage() {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OnCloseFilteringLogPage);
    }
    /**
     * Sends a message to the background page to get filtering info by tab ID.
     *
     * @param tabId The ID of the tab.
     *
     * @returns Promise that resolves with filtering info about the tab.
     */ async getFilteringInfoByTabId(tabId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetFilteringInfoByTabId, {
            tabId
        });
    }
    /**
     * Sends a message to the background page to synchronize the list of open tabs.
     *
     * @returns Promise that resolves with an array of filtering info about open tabs.
     */ async synchronizeOpenTabs() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SynchronizeOpenTabs);
    }
    /**
     * Sends a message to the background page to clear events by tab ID.
     *
     * @param tabId The ID of the tab.
     * @param ignorePreserveLog Optional flag to ignore the preserve log state.
     *
     * @returns Promise that resolves after the events are cleared.
     */ async clearEventsByTabId(tabId, ignorePreserveLog) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ClearEventsByTabId, {
            tabId,
            ignorePreserveLog
        });
    }
    /**
     * Sends a message to the background page to refresh the current page by tab ID.
     *
     * @param tabId The ID of the tab.
     *
     * @returns Promise that resolves after the page is refreshed.
     */ async refreshPage(tabId) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RefreshPage, {
            tabId
        });
    }
    /**
     * Sends a message to the background page to add a user rule.
     *
     * @param ruleText User rule text to be added.
     *
     * @returns Promise that resolves after the message is sent.
     */ async addUserRule(ruleText) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddUserRule, {
            ruleText
        });
    }
    /**
     * Sends a message to the background page to remove a user rule.
     *
     * @param ruleText User rule text to be removed.
     *
     * @returns Promise that resolves after the message is sent.
     */ async removeUserRule(ruleText) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveUserRule, {
            ruleText
        });
    }
    /**
     * Sends a message to the background page to set the preserve log state.
     *
     * @param state State indicating whether to preserve the log.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setPreserveLogState(state) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetPreserveLogState, {
            state
        });
    }
    /**
     * Sends a message to the background page to get the editor storage content.
     *
     * @returns Promise that resolves with the editor storage content.
     */ async getEditorStorageContent() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetEditorStorageContent);
    }
    /**
     * Sends a message to the background page to set the editor storage content.
     *
     * @param content Content to be stored in the editor.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setEditorStorageContent(content) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetEditorStorageContent, {
            content
        });
    }
    /**
     * Sends a message to the background page to get the rules limits counters for MV3.
     *
     * @returns Promise that resolves with the rules limits counters for MV3.
     */ async getRulesLimitsCounters() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetRulesLimitsCountersMv3);
    }
    /**
     * Sends a message to the background page to check if it is possible to enable a static filter.
     *
     * @param filterId Filter ID to check.
     *
     * @returns Promise that resolves with the result of the static filter check.
     *
     * @throws Error If the filter is not static.
     */ async canEnableStaticFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CanEnableStaticFilterMv3, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to check if all dynamic rules for a user rules' group can be enabled.
     *
     * @param groupId Group identifier to check.
     *
     * @returns Promise that resolves with the result of the static group check.
     */ async canEnableStaticGroup(groupId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CanEnableStaticGroupMv3, {
            groupId
        });
    }
    /**
     * Sends a message to the background page to get the current static filters limits.
     *
     * @returns Promise that resolves with the current static filters limits.
     */ async getCurrentLimits() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CurrentLimitsMv3);
    }
    /**
     * Sends a message to the background page to check if the request filter is ready.
     *
     * @returns Promise that resolves to a boolean indicating if the request filter is ready.
     */ async checkRequestFilterReady() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CheckRequestFilterReady);
    }
    /**
     * Sends a message to the background page to add a URL to the trusted list.
     *
     * @param url URL to be added to the trusted list.
     *
     * @returns Promise that resolves after the message is sent.
     */ async addUrlToTrusted(url) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddUrlToTrusted, {
            url
        });
    }
    /**
     * Sends a message to the background page to get user rules editor data.
     *
     * @returns Promise that resolves with the user rules editor data.
     */ async getUserRulesEditorData() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetUserRulesEditorData);
    }
    /**
     * Sends a message to the background page to restore filters in MV3.
     *
     * @returns Promise that resolves after the message is sent.
     */ async restoreFiltersMv3() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RestoreFiltersMv3);
    }
    /**
     * Sends a message to the background page to clear the rules limits warning in MV3.
     *
     * @returns Promise that resolves after the message is sent.
     */ async clearRulesLimitsWarningMv3() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ClearRulesLimitsWarningMv3);
    }
    /**
     * Sends a message to the background page to get the allowlist domains.
     *
     * @returns Promise that resolves with the allowlist domains.
     */ async getAllowlistDomains() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetAllowlistDomains);
    }
    /**
     * Sends a message to the background page to load the settings JSON.
     *
     * @returns Promise that resolves with the loaded settings JSON.
     */ async loadSettingsJson() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.LoadSettingsJson);
    }
    /**
     * Sends a message to the background page to open the thank you page.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openThankyouPage() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenThankyouPage);
    }
    /**
     * Sends a message to the background page to initialize the frame script.
     *
     * @returns Promise that resolves with the initialization data for the frame script.
     */ async initializeFrameScript() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.InitializeFrameScript);
    }
    /**
     * Sends a message to the background page to mark url as trusted and ignore
     * safebrowsing checks for it.
     *
     * @returns Promise that resolves with the initialization data for the frame script.
     */ async openSafebrowsingTrusted(url) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenSafebrowsingTrusted, {
            url
        });
    }
    /**
     * Creates an instance of the Messenger class.
     */ constructor(){
        _define_property(this, "onMessage", (webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime).onMessage);
        /**
     * Method subscribes to notifier module events.
     *
     * @param events List of events to which subscribe.
     * @param callback Callback called when event fires.
     * @param onUnloadCallback Callback used to remove listener on unload.
     *
     * @returns Function to remove listener on unload.
     */ _define_property(this, "createEventListener", async (events, callback, onUnloadCallback)=>{
            let listenerId;
            const response = await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CreateEventListener, {
                events
            });
            listenerId = response.listenerId;
            const onUpdateListeners = async ()=>{
                const updatedResponse = await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CreateEventListener, {
                    events
                });
                listenerId = updatedResponse.listenerId;
            };
            webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.onMessage.addListener((message)=>{
                if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeField)(message)) {
                    _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message in Messenger.createEventListener has no type field: ', message);
                    return undefined;
                }
                if (message.type === _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.NotifyListeners) {
                    if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeAndDataFields)(message)) {
                        _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message with type MessageType.NotifyListeners has no data: ', message);
                        return undefined;
                    }
                    const castedMessage = message;
                    const [type, ...data] = castedMessage.data;
                    if (events.includes(type)) {
                        callback({
                            type,
                            data
                        });
                    }
                }
                if (message.type === _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.UpdateListeners) {
                    onUpdateListeners();
                }
            });
            const onUnload = ()=>{
                if (!listenerId) {
                    return;
                }
                this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveListener, {
                    listenerId
                });
                listenerId = null;
                if (typeof onUnloadCallback === 'function') {
                    onUnloadCallback();
                }
            };
            window.addEventListener('beforeunload', onUnload);
            window.addEventListener('unload', onUnload);
            return onUnload;
        });
        this.resetUserRulesForPage = this.resetUserRulesForPage.bind(this);
        this.updateFilters = this.updateFilters.bind(this);
        this.removeAllowlistDomain = this.removeAllowlistDomain.bind(this);
        this.addAllowlistDomain = this.addAllowlistDomain.bind(this);
    }
}
/**
     * Creates long-lived connections between popup and background page.
     *
     * @param page Page name.
     * @param events List of events to which subscribe.
     * @param callback Callback called when event fires.
     *
     * @returns Function to remove listener on unload.
     */ _define_property(Messenger, "createLongLivedConnection", (page, events, callback)=>{
    let port;
    let forceDisconnected = false;
    const connect = ()=>{
        port = webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.connect({
            name: `${page}_${(0,nanoid__WEBPACK_IMPORTED_MODULE_4__.nanoid)()}`
        });
        port.postMessage({
            type: _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddLongLivedConnection,
            data: {
                events
            }
        });
        port.onMessage.addListener((message)=>{
            if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeField)(message)) {
                _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message in Messenger.createLongLivedConnection has no type field: ', message);
                return;
            }
            if (message.type === _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.NotifyListeners) {
                if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeAndDataFields)(message)) {
                    _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message with type MessageType.NotifyListeners has no data: ', message);
                    return;
                }
                const castedMessage = message;
                const [type, ...data] = castedMessage.data;
                callback({
                    type,
                    data
                });
            }
        });
        port.onDisconnect.addListener(()=>{
            if ((webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime).lastError) {
                _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error((webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime).lastError.message);
            }
            // we try to connect again if the background page was terminated
            if (!forceDisconnected) {
                connect();
            }
        });
    };
    connect();
    const onUnload = ()=>{
        if (port) {
            forceDisconnected = true;
            port.disconnect();
        }
    };
    window.addEventListener('beforeunload', onUnload);
    window.addEventListener('unload', onUnload);
    return onUnload;
});
const messenger = new Messenger();



/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/try-to-string.js");

var $TypeError = TypeError;

// `Assert: IsCallable(argument) is true`
module.exports = function (argument) {
  if (isCallable(argument)) return argument;
  throw new $TypeError(tryToString(argument) + ' is not a function');
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-possible-prototype.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-possible-prototype.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isPossiblePrototype = __webpack_require__(/*! ../internals/is-possible-prototype */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-possible-prototype.js");

var $String = String;
var $TypeError = TypeError;

module.exports = function (argument) {
  if (isPossiblePrototype(argument)) return argument;
  throw new $TypeError("Can't set " + $String(argument) + ' as a prototype');
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/add-to-unscopables.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/add-to-unscopables.js ***!
  \************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");
var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-create.js");
var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js").f);

var UNSCOPABLES = wellKnownSymbol('unscopables');
var ArrayPrototype = Array.prototype;

// Array.prototype[@@unscopables]
// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
if (ArrayPrototype[UNSCOPABLES] === undefined) {
  defineProperty(ArrayPrototype, UNSCOPABLES, {
    configurable: true,
    value: create(null)
  });
}

// add a key to Array.prototype[@@unscopables]
module.exports = function (key) {
  ArrayPrototype[UNSCOPABLES][key] = true;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

var $String = String;
var $TypeError = TypeError;

// `Assert: Type(argument) is Object`
module.exports = function (argument) {
  if (isObject(argument)) return argument;
  throw new $TypeError($String(argument) + ' is not an object');
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ../internals/to-absolute-index */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-absolute-index.js");
var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/length-of-array-like.js");

// `Array.prototype.{ indexOf, includes }` methods implementation
var createMethod = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIndexedObject($this);
    var length = lengthOfArrayLike(O);
    if (length === 0) return !IS_INCLUDES && -1;
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare -- NaN check
    if (IS_INCLUDES && el !== el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare -- NaN check
      if (value !== value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) {
      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};

module.exports = {
  // `Array.prototype.includes` method
  // https://tc39.es/ecma262/#sec-array.prototype.includes
  includes: createMethod(true),
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: createMethod(false)
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

var toString = uncurryThis({}.toString);
var stringSlice = uncurryThis(''.slice);

module.exports = function (it) {
  return stringSlice(toString(it), 8, -1);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof.js ***!
  \*************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var TO_STRING_TAG_SUPPORT = __webpack_require__(/*! ../internals/to-string-tag-support */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string-tag-support.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var classofRaw = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");

var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Object = Object;

// ES3 wrong here
var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) === 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (error) { /* empty */ }
};

// getting tag from ES6+ `Object.prototype.toString`
module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function (it) {
  var O, tag, result;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG)) == 'string' ? tag
    // builtinTag case
    : CORRECT_ARGUMENTS ? classofRaw(O)
    // ES3 arguments fallback
    : (result = classofRaw(O)) === 'Object' && isCallable(O.callee) ? 'Arguments' : result;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js ***!
  \*********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var ownKeys = __webpack_require__(/*! ../internals/own-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/own-keys.js");
var getOwnPropertyDescriptorModule = __webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");

module.exports = function (target, source, exceptions) {
  var keys = ownKeys(source);
  var defineProperty = definePropertyModule.f;
  var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (!hasOwn(target, key) && !(exceptions && hasOwn(exceptions, key))) {
      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
    }
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js":
/*!************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js ***!
  \************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");
var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js");

module.exports = DESCRIPTORS ? function (object, key, value) {
  return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js":
/*!********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in-accessor.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in-accessor.js ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var makeBuiltIn = __webpack_require__(/*! ../internals/make-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js");
var defineProperty = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");

module.exports = function (target, name, descriptor) {
  if (descriptor.get) makeBuiltIn(descriptor.get, name, { getter: true });
  if (descriptor.set) makeBuiltIn(descriptor.set, name, { setter: true });
  return defineProperty.f(target, name, descriptor);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in.js ***!
  \*********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");
var makeBuiltIn = __webpack_require__(/*! ../internals/make-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js");
var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js");

module.exports = function (O, key, value, options) {
  if (!options) options = {};
  var simple = options.enumerable;
  var name = options.name !== undefined ? options.name : key;
  if (isCallable(value)) makeBuiltIn(value, name, options);
  if (options.global) {
    if (simple) O[key] = value;
    else defineGlobalProperty(key, value);
  } else {
    try {
      if (!options.unsafe) delete O[key];
      else if (O[key]) simple = true;
    } catch (error) { /* empty */ }
    if (simple) O[key] = value;
    else definePropertyModule.f(O, key, {
      value: value,
      enumerable: false,
      configurable: !options.nonConfigurable,
      writable: !options.nonWritable
    });
  } return O;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");

// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;

module.exports = function (key, value) {
  try {
    defineProperty(globalThis, key, { value: value, configurable: true, writable: true });
  } catch (error) {
    globalThis[key] = value;
  } return value;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");

// Detect IE8's incomplete defineProperty implementation
module.exports = !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] !== 7;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

var document = globalThis.document;
// typeof document.createElement is 'object' in old IE
var EXISTS = isObject(document) && isObject(document.createElement);

module.exports = function (it) {
  return EXISTS ? document.createElement(it) : {};
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js ***!
  \*******************************************************************************************/
/***/ ((module) => {

"use strict";

// IE8- don't enum bug keys
module.exports = [
  'constructor',
  'hasOwnProperty',
  'isPrototypeOf',
  'propertyIsEnumerable',
  'toLocaleString',
  'toString',
  'valueOf'
];


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-user-agent.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-user-agent.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");

var navigator = globalThis.navigator;
var userAgent = navigator && navigator.userAgent;

module.exports = userAgent ? String(userAgent) : '';


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-v8-version.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-v8-version.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-user-agent.js");

var process = globalThis.process;
var Deno = globalThis.Deno;
var versions = process && process.versions || Deno && Deno.version;
var v8 = versions && versions.v8;
var match, version;

if (v8) {
  match = v8.split('.');
  // in old Chrome, versions of V8 isn't V8 = Chrome / 10
  // but their correct versions are not interesting for us
  version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
}

// BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
// so check `userAgent` even if `.v8` exists, but 0
if (!version && userAgent) {
  match = userAgent.match(/Edge\/(\d+)/);
  if (!match || match[1] >= 74) {
    match = userAgent.match(/Chrome\/(\d+)/);
    if (match) version = +match[1];
  }
}

module.exports = version;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-clear.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-clear.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

var $Error = Error;
var replace = uncurryThis(''.replace);

var TEST = (function (arg) { return String(new $Error(arg).stack); })('zxcasd');
// eslint-disable-next-line redos/no-vulnerable, sonarjs/slow-regex -- safe
var V8_OR_CHAKRA_STACK_ENTRY = /\n\s*at [^:]*:[^\n]*/;
var IS_V8_OR_CHAKRA_STACK = V8_OR_CHAKRA_STACK_ENTRY.test(TEST);

module.exports = function (stack, dropEntries) {
  if (IS_V8_OR_CHAKRA_STACK && typeof stack == 'string' && !$Error.prepareStackTrace) {
    while (dropEntries--) stack = replace(stack, V8_OR_CHAKRA_STACK_ENTRY, '');
  } return stack;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-install.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-install.js ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var clearErrorStack = __webpack_require__(/*! ../internals/error-stack-clear */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-clear.js");
var ERROR_STACK_INSTALLABLE = __webpack_require__(/*! ../internals/error-stack-installable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-installable.js");

// non-standard V8
var captureStackTrace = Error.captureStackTrace;

module.exports = function (error, C, stack, dropEntries) {
  if (ERROR_STACK_INSTALLABLE) {
    if (captureStackTrace) captureStackTrace(error, C);
    else createNonEnumerableProperty(error, 'stack', clearErrorStack(stack, dropEntries));
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-installable.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-installable.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js");

module.exports = !fails(function () {
  var error = new Error('a');
  if (!('stack' in error)) return true;
  // eslint-disable-next-line es/no-object-defineproperty -- safe
  Object.defineProperty(error, 'stack', createPropertyDescriptor(1, 7));
  return error.stack !== 7;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js":
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var getOwnPropertyDescriptor = (__webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js").f);
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in.js");
var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js");
var copyConstructorProperties = __webpack_require__(/*! ../internals/copy-constructor-properties */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js");
var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-forced.js");

/*
  options.target         - name of the target object
  options.global         - target is the global object
  options.stat           - export as static methods of target
  options.proto          - export as prototype methods of target
  options.real           - real prototype method for the `pure` version
  options.forced         - export even if the native feature is available
  options.bind           - bind methods to the target, required for the `pure` version
  options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
  options.unsafe         - use the simple assignment of property instead of delete + defineProperty
  options.sham           - add a flag to not completely full polyfills
  options.enumerable     - export as enumerable property
  options.dontCallGetSet - prevent calling a getter on target
  options.name           - the .name of the function if it does not match the key
*/
module.exports = function (options, source) {
  var TARGET = options.target;
  var GLOBAL = options.global;
  var STATIC = options.stat;
  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
  if (GLOBAL) {
    target = globalThis;
  } else if (STATIC) {
    target = globalThis[TARGET] || defineGlobalProperty(TARGET, {});
  } else {
    target = globalThis[TARGET] && globalThis[TARGET].prototype;
  }
  if (target) for (key in source) {
    sourceProperty = source[key];
    if (options.dontCallGetSet) {
      descriptor = getOwnPropertyDescriptor(target, key);
      targetProperty = descriptor && descriptor.value;
    } else targetProperty = target[key];
    FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
    // contained in target
    if (!FORCED && targetProperty !== undefined) {
      if (typeof sourceProperty == typeof targetProperty) continue;
      copyConstructorProperties(sourceProperty, targetProperty);
    }
    // add a flag to not completely full polyfills
    if (options.sham || (targetProperty && targetProperty.sham)) {
      createNonEnumerableProperty(sourceProperty, 'sham', true);
    }
    defineBuiltIn(target, key, sourceProperty, options);
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (error) {
    return true;
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-apply.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-apply.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js");

var FunctionPrototype = Function.prototype;
var apply = FunctionPrototype.apply;
var call = FunctionPrototype.call;

// eslint-disable-next-line es/no-function-prototype-bind, es/no-reflect -- safe
module.exports = typeof Reflect == 'object' && Reflect.apply || (NATIVE_BIND ? call.bind(apply) : function () {
  return call.apply(apply, arguments);
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");

module.exports = !fails(function () {
  // eslint-disable-next-line es/no-function-prototype-bind -- safe
  var test = (function () { /* empty */ }).bind();
  // eslint-disable-next-line no-prototype-builtins -- safe
  return typeof test != 'function' || test.hasOwnProperty('prototype');
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js");

var call = Function.prototype.call;
// eslint-disable-next-line es/no-function-prototype-bind -- safe
module.exports = NATIVE_BIND ? call.bind(call) : function () {
  return call.apply(call, arguments);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-name.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-name.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");

var FunctionPrototype = Function.prototype;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getDescriptor = DESCRIPTORS && Object.getOwnPropertyDescriptor;

var EXISTS = hasOwn(FunctionPrototype, 'name');
// additional protection from minified / mangled / dropped function names
var PROPER = EXISTS && (function something() { /* empty */ }).name === 'something';
var CONFIGURABLE = EXISTS && (!DESCRIPTORS || (DESCRIPTORS && getDescriptor(FunctionPrototype, 'name').configurable));

module.exports = {
  EXISTS: EXISTS,
  PROPER: PROPER,
  CONFIGURABLE: CONFIGURABLE
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this-accessor.js":
/*!************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this-accessor.js ***!
  \************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js");

module.exports = function (object, key, method) {
  try {
    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
    return uncurryThis(aCallable(Object.getOwnPropertyDescriptor(object, key)[method]));
  } catch (error) { /* empty */ }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js");

var FunctionPrototype = Function.prototype;
var call = FunctionPrototype.call;
// eslint-disable-next-line es/no-function-prototype-bind -- safe
var uncurryThisWithBind = NATIVE_BIND && FunctionPrototype.bind.bind(call, call);

module.exports = NATIVE_BIND ? uncurryThisWithBind : function (fn) {
  return function () {
    return call.apply(fn, arguments);
  };
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js ***!
  \******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

var aFunction = function (argument) {
  return isCallable(argument) ? argument : undefined;
};

module.exports = function (namespace, method) {
  return arguments.length < 2 ? aFunction(globalThis[namespace]) : globalThis[namespace] && globalThis[namespace][method];
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-method.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-method.js ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js");
var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js");

// `GetMethod` abstract operation
// https://tc39.es/ecma262/#sec-getmethod
module.exports = function (V, P) {
  var func = V[P];
  return isNullOrUndefined(func) ? undefined : aCallable(func);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js ***!
  \*****************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var check = function (it) {
  return it && it.Math === Math && it;
};

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
module.exports =
  // eslint-disable-next-line es/no-global-this -- safe
  check(typeof globalThis == 'object' && globalThis) ||
  check(typeof window == 'object' && window) ||
  // eslint-disable-next-line no-restricted-globals -- safe
  check(typeof self == 'object' && self) ||
  check(typeof __webpack_require__.g == 'object' && __webpack_require__.g) ||
  check(typeof this == 'object' && this) ||
  // eslint-disable-next-line no-new-func -- fallback
  (function () { return this; })() || Function('return this')();


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js":
/*!**********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js ***!
  \**********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-object.js");

var hasOwnProperty = uncurryThis({}.hasOwnProperty);

// `HasOwnProperty` abstract operation
// https://tc39.es/ecma262/#sec-hasownproperty
// eslint-disable-next-line es/no-object-hasown -- safe
module.exports = Object.hasOwn || function hasOwn(it, key) {
  return hasOwnProperty(toObject(it), key);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = {};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/html.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/html.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");

module.exports = getBuiltIn('document', 'documentElement');


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var createElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js");

// Thanks to IE8 for its funny defineProperty
module.exports = !DESCRIPTORS && !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(createElement('div'), 'a', {
    get: function () { return 7; }
  }).a !== 7;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/indexed-object.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/indexed-object.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js");

var $Object = Object;
var split = uncurryThis(''.split);

// fallback for non-array-like ES3 and non-enumerable old V8 strings
module.exports = fails(function () {
  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
  // eslint-disable-next-line no-prototype-builtins -- safe
  return !$Object('z').propertyIsEnumerable(0);
}) ? function (it) {
  return classof(it) === 'String' ? split(it, '') : $Object(it);
} : $Object;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inherit-if-required.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inherit-if-required.js ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js");

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
    // it can work only with native `setPrototypeOf`
    setPrototypeOf &&
    // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
    isCallable(NewTarget = dummy.constructor) &&
    NewTarget !== Wrapper &&
    isObject(NewTargetPrototype = NewTarget.prototype) &&
    NewTargetPrototype !== Wrapper.prototype
  ) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inspect-source.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inspect-source.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var store = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js");

var functionToString = uncurryThis(Function.toString);

// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
if (!isCallable(store.inspectSource)) {
  store.inspectSource = function (it) {
    return functionToString(it);
  };
}

module.exports = store.inspectSource;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/install-error-cause.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/install-error-cause.js ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");

// `InstallErrorCause` abstract operation
// https://tc39.es/proposal-error-cause/#sec-errorobjects-install-error-cause
module.exports = function (O, options) {
  if (isObject(options) && 'cause' in options) {
    createNonEnumerableProperty(O, 'cause', options.cause);
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/internal-state.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/internal-state.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_WEAK_MAP = __webpack_require__(/*! ../internals/weak-map-basic-detection */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/weak-map-basic-detection.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var shared = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js");
var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js");
var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js");

var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
var TypeError = globalThis.TypeError;
var WeakMap = globalThis.WeakMap;
var set, get, has;

var enforce = function (it) {
  return has(it) ? get(it) : set(it, {});
};

var getterFor = function (TYPE) {
  return function (it) {
    var state;
    if (!isObject(it) || (state = get(it)).type !== TYPE) {
      throw new TypeError('Incompatible receiver, ' + TYPE + ' required');
    } return state;
  };
};

if (NATIVE_WEAK_MAP || shared.state) {
  var store = shared.state || (shared.state = new WeakMap());
  /* eslint-disable no-self-assign -- prototype methods protection */
  store.get = store.get;
  store.has = store.has;
  store.set = store.set;
  /* eslint-enable no-self-assign -- prototype methods protection */
  set = function (it, metadata) {
    if (store.has(it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    store.set(it, metadata);
    return metadata;
  };
  get = function (it) {
    return store.get(it) || {};
  };
  has = function (it) {
    return store.has(it);
  };
} else {
  var STATE = sharedKey('state');
  hiddenKeys[STATE] = true;
  set = function (it, metadata) {
    if (hasOwn(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    createNonEnumerableProperty(it, STATE, metadata);
    return metadata;
  };
  get = function (it) {
    return hasOwn(it, STATE) ? it[STATE] : {};
  };
  has = function (it) {
    return hasOwn(it, STATE);
  };
}

module.exports = {
  set: set,
  get: get,
  has: has,
  enforce: enforce,
  getterFor: getterFor
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";

// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
var documentAll = typeof document == 'object' && document.all;

// `IsCallable` abstract operation
// https://tc39.es/ecma262/#sec-iscallable
// eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
module.exports = typeof documentAll == 'undefined' && documentAll !== undefined ? function (argument) {
  return typeof argument == 'function' || argument === documentAll;
} : function (argument) {
  return typeof argument == 'function';
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-forced.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-forced.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

var replacement = /#|\.prototype\./;

var isForced = function (feature, detection) {
  var value = data[normalize(feature)];
  return value === POLYFILL ? true
    : value === NATIVE ? false
    : isCallable(detection) ? fails(detection)
    : !!detection;
};

var normalize = isForced.normalize = function (string) {
  return String(string).replace(replacement, '.').toLowerCase();
};

var data = isForced.data = {};
var NATIVE = isForced.NATIVE = 'N';
var POLYFILL = isForced.POLYFILL = 'P';

module.exports = isForced;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";

// we can't use just `it == null` since of `document.all` special case
// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
module.exports = function (it) {
  return it === null || it === undefined;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

module.exports = function (it) {
  return typeof it == 'object' ? it !== null : isCallable(it);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-possible-prototype.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-possible-prototype.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

module.exports = function (argument) {
  return isObject(argument) || argument === null;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js ***!
  \*************************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = false;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js");
var USE_SYMBOL_AS_UID = __webpack_require__(/*! ../internals/use-symbol-as-uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js");

var $Object = Object;

module.exports = USE_SYMBOL_AS_UID ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  var $Symbol = getBuiltIn('Symbol');
  return isCallable($Symbol) && isPrototypeOf($Symbol.prototype, $Object(it));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/length-of-array-like.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/length-of-array-like.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-length.js");

// `LengthOfArrayLike` abstract operation
// https://tc39.es/ecma262/#sec-lengthofarraylike
module.exports = function (obj) {
  return toLength(obj.length);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var CONFIGURABLE_FUNCTION_NAME = (__webpack_require__(/*! ../internals/function-name */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-name.js").CONFIGURABLE);
var inspectSource = __webpack_require__(/*! ../internals/inspect-source */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inspect-source.js");
var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/internal-state.js");

var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var $String = String;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var stringSlice = uncurryThis(''.slice);
var replace = uncurryThis(''.replace);
var join = uncurryThis([].join);

var CONFIGURABLE_LENGTH = DESCRIPTORS && !fails(function () {
  return defineProperty(function () { /* empty */ }, 'length', { value: 8 }).length !== 8;
});

var TEMPLATE = String(String).split('String');

var makeBuiltIn = module.exports = function (value, name, options) {
  if (stringSlice($String(name), 0, 7) === 'Symbol(') {
    name = '[' + replace($String(name), /^Symbol\(([^)]*)\).*$/, '$1') + ']';
  }
  if (options && options.getter) name = 'get ' + name;
  if (options && options.setter) name = 'set ' + name;
  if (!hasOwn(value, 'name') || (CONFIGURABLE_FUNCTION_NAME && value.name !== name)) {
    if (DESCRIPTORS) defineProperty(value, 'name', { value: name, configurable: true });
    else value.name = name;
  }
  if (CONFIGURABLE_LENGTH && options && hasOwn(options, 'arity') && value.length !== options.arity) {
    defineProperty(value, 'length', { value: options.arity });
  }
  try {
    if (options && hasOwn(options, 'constructor') && options.constructor) {
      if (DESCRIPTORS) defineProperty(value, 'prototype', { writable: false });
    // in V8 ~ Chrome 53, prototypes of some methods, like `Array.prototype.values`, are non-writable
    } else if (value.prototype) value.prototype = undefined;
  } catch (error) { /* empty */ }
  var state = enforceInternalState(value);
  if (!hasOwn(state, 'source')) {
    state.source = join(TEMPLATE, typeof name == 'string' ? name : '');
  } return value;
};

// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
// eslint-disable-next-line no-extend-native -- required
Function.prototype.toString = makeBuiltIn(function toString() {
  return isCallable(this) && getInternalState(this).source || inspectSource(this);
}, 'toString');


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/math-trunc.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/math-trunc.js ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";

var ceil = Math.ceil;
var floor = Math.floor;

// `Math.trunc` method
// https://tc39.es/ecma262/#sec-math.trunc
// eslint-disable-next-line es/no-math-trunc -- safe
module.exports = Math.trunc || function trunc(x) {
  var n = +x;
  return (n > 0 ? floor : ceil)(n);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/normalize-string-argument.js":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/normalize-string-argument.js ***!
  \*******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string.js");

module.exports = function (argument, $default) {
  return argument === undefined ? arguments.length < 2 ? '' : $default : toString(argument);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-create.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-create.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* global ActiveXObject -- old IE, WSH */
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");
var definePropertiesModule = __webpack_require__(/*! ../internals/object-define-properties */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-properties.js");
var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js");
var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js");
var html = __webpack_require__(/*! ../internals/html */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/html.js");
var documentCreateElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js");
var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js");

var GT = '>';
var LT = '<';
var PROTOTYPE = 'prototype';
var SCRIPT = 'script';
var IE_PROTO = sharedKey('IE_PROTO');

var EmptyConstructor = function () { /* empty */ };

var scriptTag = function (content) {
  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
};

// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
var NullProtoObjectViaActiveX = function (activeXDocument) {
  activeXDocument.write(scriptTag(''));
  activeXDocument.close();
  var temp = activeXDocument.parentWindow.Object;
  // eslint-disable-next-line no-useless-assignment -- avoid memory leak
  activeXDocument = null;
  return temp;
};

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var NullProtoObjectViaIFrame = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = documentCreateElement('iframe');
  var JS = 'java' + SCRIPT + ':';
  var iframeDocument;
  iframe.style.display = 'none';
  html.appendChild(iframe);
  // https://github.com/zloirock/core-js/issues/475
  iframe.src = String(JS);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(scriptTag('document.F=Object'));
  iframeDocument.close();
  return iframeDocument.F;
};

// Check for document.domain and active x support
// No need to use active x approach when document.domain is not set
// see https://github.com/es-shims/es5-shim/issues/150
// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
// avoid IE GC bug
var activeXDocument;
var NullProtoObject = function () {
  try {
    activeXDocument = new ActiveXObject('htmlfile');
  } catch (error) { /* ignore */ }
  NullProtoObject = typeof document != 'undefined'
    ? document.domain && activeXDocument
      ? NullProtoObjectViaActiveX(activeXDocument) // old IE
      : NullProtoObjectViaIFrame()
    : NullProtoObjectViaActiveX(activeXDocument); // WSH
  var length = enumBugKeys.length;
  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
  return NullProtoObject();
};

hiddenKeys[IE_PROTO] = true;

// `Object.create` method
// https://tc39.es/ecma262/#sec-object.create
// eslint-disable-next-line es/no-object-create -- safe
module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    EmptyConstructor[PROTOTYPE] = anObject(O);
    result = new EmptyConstructor();
    EmptyConstructor[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = NullProtoObject();
  return Properties === undefined ? result : definePropertiesModule.f(result, Properties);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-properties.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-properties.js ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(/*! ../internals/v8-prototype-define-bug */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var objectKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys.js");

// `Object.defineProperties` method
// https://tc39.es/ecma262/#sec-object.defineproperties
// eslint-disable-next-line es/no-object-defineproperties -- safe
exports.f = DESCRIPTORS && !V8_PROTOTYPE_DEFINE_BUG ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var props = toIndexedObject(Properties);
  var keys = objectKeys(Properties);
  var length = keys.length;
  var index = 0;
  var key;
  while (length > index) definePropertyModule.f(O, key = keys[index++], props[key]);
  return O;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ../internals/ie8-dom-define */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js");
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(/*! ../internals/v8-prototype-define-bug */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");
var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js");

var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var $defineProperty = Object.defineProperty;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ENUMERABLE = 'enumerable';
var CONFIGURABLE = 'configurable';
var WRITABLE = 'writable';

// `Object.defineProperty` method
// https://tc39.es/ecma262/#sec-object.defineproperty
exports.f = DESCRIPTORS ? V8_PROTOTYPE_DEFINE_BUG ? function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (typeof O === 'function' && P === 'prototype' && 'value' in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
    var current = $getOwnPropertyDescriptor(O, P);
    if (current && current[WRITABLE]) {
      O[P] = Attributes.value;
      Attributes = {
        configurable: CONFIGURABLE in Attributes ? Attributes[CONFIGURABLE] : current[CONFIGURABLE],
        enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
        writable: false
      };
    }
  } return $defineProperty(O, P, Attributes);
} : $defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return $defineProperty(O, P, Attributes);
  } catch (error) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw new $TypeError('Accessors not supported');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js");
var propertyIsEnumerableModule = __webpack_require__(/*! ../internals/object-property-is-enumerable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-property-is-enumerable.js");
var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ../internals/ie8-dom-define */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js");

// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
  O = toIndexedObject(O);
  P = toPropertyKey(P);
  if (IE8_DOM_DEFINE) try {
    return $getOwnPropertyDescriptor(O, P);
  } catch (error) { /* empty */ }
  if (hasOwn(O, P)) return createPropertyDescriptor(!call(propertyIsEnumerableModule.f, O, P), O[P]);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-names.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-names.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var internalObjectKeys = __webpack_require__(/*! ../internals/object-keys-internal */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js");
var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js");

var hiddenKeys = enumBugKeys.concat('length', 'prototype');

// `Object.getOwnPropertyNames` method
// https://tc39.es/ecma262/#sec-object.getownpropertynames
// eslint-disable-next-line es/no-object-getownpropertynames -- safe
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return internalObjectKeys(O, hiddenKeys);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-symbols.js":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-symbols.js ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
exports.f = Object.getOwnPropertySymbols;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

module.exports = uncurryThis({}.isPrototypeOf);


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var indexOf = (__webpack_require__(/*! ../internals/array-includes */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js").indexOf);
var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js");

var push = uncurryThis([].push);

module.exports = function (object, names) {
  var O = toIndexedObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) !hasOwn(hiddenKeys, key) && hasOwn(O, key) && push(result, key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (hasOwn(O, key = names[i++])) {
    ~indexOf(result, key) || push(result, key);
  }
  return result;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys.js ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var internalObjectKeys = __webpack_require__(/*! ../internals/object-keys-internal */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js");
var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js");

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
// eslint-disable-next-line es/no-object-keys -- safe
module.exports = Object.keys || function keys(O) {
  return internalObjectKeys(O, enumBugKeys);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-property-is-enumerable.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-property-is-enumerable.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

var $propertyIsEnumerable = {}.propertyIsEnumerable;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Nashorn ~ JDK8 bug
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({ 1: 2 }, 1);

// `Object.prototype.propertyIsEnumerable` method implementation
// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
  var descriptor = getOwnPropertyDescriptor(this, V);
  return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable no-proto -- safe */
var uncurryThisAccessor = __webpack_require__(/*! ../internals/function-uncurry-this-accessor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this-accessor.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js");
var aPossiblePrototype = __webpack_require__(/*! ../internals/a-possible-prototype */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-possible-prototype.js");

// `Object.setPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.setprototypeof
// Works with __proto__ only. Old v8 can't work with null proto objects.
// eslint-disable-next-line es/no-object-setprototypeof -- safe
module.exports = Object.setPrototypeOf || ('__proto__' in {} ? function () {
  var CORRECT_SETTER = false;
  var test = {};
  var setter;
  try {
    setter = uncurryThisAccessor(Object.prototype, '__proto__', 'set');
    setter(test, []);
    CORRECT_SETTER = test instanceof Array;
  } catch (error) { /* empty */ }
  return function setPrototypeOf(O, proto) {
    requireObjectCoercible(O);
    aPossiblePrototype(proto);
    if (!isObject(O)) return O;
    if (CORRECT_SETTER) setter(O, proto);
    else O.__proto__ = proto;
    return O;
  };
}() : undefined);


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ordinary-to-primitive.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ordinary-to-primitive.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

var $TypeError = TypeError;

// `OrdinaryToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-ordinarytoprimitive
module.exports = function (input, pref) {
  var fn, val;
  if (pref === 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  if (isCallable(fn = input.valueOf) && !isObject(val = call(fn, input))) return val;
  if (pref !== 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  throw new $TypeError("Can't convert object to primitive value");
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/own-keys.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/own-keys.js ***!
  \**************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");
var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var getOwnPropertyNamesModule = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-names.js");
var getOwnPropertySymbolsModule = __webpack_require__(/*! ../internals/object-get-own-property-symbols */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-symbols.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");

var concat = uncurryThis([].concat);

// all object keys, includes non-enumerable and symbols
module.exports = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
  var keys = getOwnPropertyNamesModule.f(anObject(it));
  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
  return getOwnPropertySymbols ? concat(keys, getOwnPropertySymbols(it)) : keys;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/proxy-accessor.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/proxy-accessor.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js").f);

module.exports = function (Target, Source, key) {
  key in Target || defineProperty(Target, key, {
    configurable: true,
    get: function () { return Source[key]; },
    set: function (it) { Source[key] = it; }
  });
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js");

var $TypeError = TypeError;

// `RequireObjectCoercible` abstract operation
// https://tc39.es/ecma262/#sec-requireobjectcoercible
module.exports = function (it) {
  if (isNullOrUndefined(it)) throw new $TypeError("Can't call method on " + it);
  return it;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js");
var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js");

var keys = shared('keys');

module.exports = function (key) {
  return keys[key] || (keys[key] = uid(key));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js ***!
  \******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js");

var SHARED = '__core-js_shared__';
var store = module.exports = globalThis[SHARED] || defineGlobalProperty(SHARED, {});

(store.versions || (store.versions = [])).push({
  version: '3.40.0',
  mode: IS_PURE ? 'pure' : 'global',
  copyright: '© 2014-2025 Denis Pushkarev (zloirock.ru)',
  license: 'https://github.com/zloirock/core-js/blob/v3.40.0/LICENSE',
  source: 'https://github.com/zloirock/core-js'
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js":
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var store = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js");

module.exports = function (key, value) {
  return store[key] || (store[key] = value || {});
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js ***!
  \**********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable es/no-symbol -- required for testing */
var V8_VERSION = __webpack_require__(/*! ../internals/environment-v8-version */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-v8-version.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");

var $String = globalThis.String;

// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
module.exports = !!Object.getOwnPropertySymbols && !fails(function () {
  var symbol = Symbol('symbol detection');
  // Chrome 38 Symbol has incorrect toString conversion
  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
  // nb: Do not call `String` directly to avoid this being optimized out to `symbol+''` which will,
  // of course, fail.
  return !$String(symbol) || !(Object(symbol) instanceof Symbol) ||
    // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
    !Symbol.sham && V8_VERSION && V8_VERSION < 41;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-absolute-index.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-absolute-index.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js");

var max = Math.max;
var min = Math.min;

// Helper for a popular repeating case of the spec:
// Let integer be ? ToInteger(index).
// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
module.exports = function (index, length) {
  var integer = toIntegerOrInfinity(index);
  return integer < 0 ? max(integer + length, 0) : min(integer, length);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

// toObject with fallback for non-array-like ES3 strings
var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/indexed-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js");

module.exports = function (it) {
  return IndexedObject(requireObjectCoercible(it));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var trunc = __webpack_require__(/*! ../internals/math-trunc */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/math-trunc.js");

// `ToIntegerOrInfinity` abstract operation
// https://tc39.es/ecma262/#sec-tointegerorinfinity
module.exports = function (argument) {
  var number = +argument;
  // eslint-disable-next-line no-self-compare -- NaN check
  return number !== number || number === 0 ? 0 : trunc(number);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-length.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-length.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js");

var min = Math.min;

// `ToLength` abstract operation
// https://tc39.es/ecma262/#sec-tolength
module.exports = function (argument) {
  var len = toIntegerOrInfinity(argument);
  return len > 0 ? min(len, 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-object.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-object.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js");

var $Object = Object;

// `ToObject` abstract operation
// https://tc39.es/ecma262/#sec-toobject
module.exports = function (argument) {
  return $Object(requireObjectCoercible(argument));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-primitive.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-primitive.js ***!
  \******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js");
var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-method.js");
var ordinaryToPrimitive = __webpack_require__(/*! ../internals/ordinary-to-primitive */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ordinary-to-primitive.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");

var $TypeError = TypeError;
var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

// `ToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-toprimitive
module.exports = function (input, pref) {
  if (!isObject(input) || isSymbol(input)) return input;
  var exoticToPrim = getMethod(input, TO_PRIMITIVE);
  var result;
  if (exoticToPrim) {
    if (pref === undefined) pref = 'default';
    result = call(exoticToPrim, input, pref);
    if (!isObject(result) || isSymbol(result)) return result;
    throw new $TypeError("Can't convert object to primitive value");
  }
  if (pref === undefined) pref = 'number';
  return ordinaryToPrimitive(input, pref);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js ***!
  \*********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toPrimitive = __webpack_require__(/*! ../internals/to-primitive */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-primitive.js");
var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js");

// `ToPropertyKey` abstract operation
// https://tc39.es/ecma262/#sec-topropertykey
module.exports = function (argument) {
  var key = toPrimitive(argument, 'string');
  return isSymbol(key) ? key : key + '';
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string-tag-support.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string-tag-support.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");

var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var test = {};

test[TO_STRING_TAG] = 'z';

module.exports = String(test) === '[object z]';


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof.js");

var $String = String;

module.exports = function (argument) {
  if (classof(argument) === 'Symbol') throw new TypeError('Cannot convert a Symbol value to a string');
  return $String(argument);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/try-to-string.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/try-to-string.js ***!
  \*******************************************************************************************/
/***/ ((module) => {

"use strict";

var $String = String;

module.exports = function (argument) {
  try {
    return $String(argument);
  } catch (error) {
    return 'Object';
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js ***!
  \*********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

var id = 0;
var postfix = Math.random();
var toString = uncurryThis(1.0.toString);

module.exports = function (key) {
  return 'Symbol(' + (key === undefined ? '' : key) + ')_' + toString(++id + postfix, 36);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable es/no-symbol -- required for testing */
var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js");

module.exports = NATIVE_SYMBOL &&
  !Symbol.sham &&
  typeof Symbol.iterator == 'symbol';


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");

// V8 ~ Chrome 36-
// https://bugs.chromium.org/p/v8/issues/detail?id=3334
module.exports = DESCRIPTORS && fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(function () { /* empty */ }, 'prototype', {
    value: 42,
    writable: false
  }).prototype !== 42;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/weak-map-basic-detection.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/weak-map-basic-detection.js ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

var WeakMap = globalThis.WeakMap;

module.exports = isCallable(WeakMap) && /native code/.test(String(WeakMap));


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js");
var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js");
var USE_SYMBOL_AS_UID = __webpack_require__(/*! ../internals/use-symbol-as-uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js");

var Symbol = globalThis.Symbol;
var WellKnownSymbolsStore = shared('wks');
var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol['for'] || Symbol : Symbol && Symbol.withoutSetter || uid;

module.exports = function (name) {
  if (!hasOwn(WellKnownSymbolsStore, name)) {
    WellKnownSymbolsStore[name] = NATIVE_SYMBOL && hasOwn(Symbol, name)
      ? Symbol[name]
      : createWellKnownSymbol('Symbol.' + name);
  } return WellKnownSymbolsStore[name];
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/wrap-error-constructor-with-cause.js":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/wrap-error-constructor-with-cause.js ***!
  \***************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js");
var copyConstructorProperties = __webpack_require__(/*! ../internals/copy-constructor-properties */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js");
var proxyAccessor = __webpack_require__(/*! ../internals/proxy-accessor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/proxy-accessor.js");
var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inherit-if-required.js");
var normalizeStringArgument = __webpack_require__(/*! ../internals/normalize-string-argument */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/normalize-string-argument.js");
var installErrorCause = __webpack_require__(/*! ../internals/install-error-cause */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/install-error-cause.js");
var installErrorStack = __webpack_require__(/*! ../internals/error-stack-install */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-install.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js");

module.exports = function (FULL_NAME, wrapper, FORCED, IS_AGGREGATE_ERROR) {
  var STACK_TRACE_LIMIT = 'stackTraceLimit';
  var OPTIONS_POSITION = IS_AGGREGATE_ERROR ? 2 : 1;
  var path = FULL_NAME.split('.');
  var ERROR_NAME = path[path.length - 1];
  var OriginalError = getBuiltIn.apply(null, path);

  if (!OriginalError) return;

  var OriginalErrorPrototype = OriginalError.prototype;

  // V8 9.3- bug https://bugs.chromium.org/p/v8/issues/detail?id=12006
  if (!IS_PURE && hasOwn(OriginalErrorPrototype, 'cause')) delete OriginalErrorPrototype.cause;

  if (!FORCED) return OriginalError;

  var BaseError = getBuiltIn('Error');

  var WrappedError = wrapper(function (a, b) {
    var message = normalizeStringArgument(IS_AGGREGATE_ERROR ? b : a, undefined);
    var result = IS_AGGREGATE_ERROR ? new OriginalError(a) : new OriginalError();
    if (message !== undefined) createNonEnumerableProperty(result, 'message', message);
    installErrorStack(result, WrappedError, result.stack, 2);
    if (this && isPrototypeOf(OriginalErrorPrototype, this)) inheritIfRequired(result, this, WrappedError);
    if (arguments.length > OPTIONS_POSITION) installErrorCause(result, arguments[OPTIONS_POSITION]);
    return result;
  });

  WrappedError.prototype = OriginalErrorPrototype;

  if (ERROR_NAME !== 'Error') {
    if (setPrototypeOf) setPrototypeOf(WrappedError, BaseError);
    else copyConstructorProperties(WrappedError, BaseError, { name: true });
  } else if (DESCRIPTORS && STACK_TRACE_LIMIT in OriginalError) {
    proxyAccessor(WrappedError, OriginalError, STACK_TRACE_LIMIT);
    proxyAccessor(WrappedError, OriginalError, 'prepareStackTrace');
  }

  copyConstructorProperties(WrappedError, OriginalError);

  if (!IS_PURE) try {
    // Safari 13- bug: WebAssembly errors does not have a proper `.name`
    if (OriginalErrorPrototype.name !== ERROR_NAME) {
      createNonEnumerableProperty(OriginalErrorPrototype, 'name', ERROR_NAME);
    }
    OriginalErrorPrototype.constructor = WrappedError;
  } catch (error) { /* empty */ }

  return WrappedError;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.array.includes.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.array.includes.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js");
var $includes = (__webpack_require__(/*! ../internals/array-includes */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js").includes);
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var addToUnscopables = __webpack_require__(/*! ../internals/add-to-unscopables */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/add-to-unscopables.js");

// FF99+ bug
var BROKEN_ON_SPARSE = fails(function () {
  // eslint-disable-next-line es/no-array-prototype-includes -- detection
  return !Array(1).includes();
});

// `Array.prototype.includes` method
// https://tc39.es/ecma262/#sec-array.prototype.includes
$({ target: 'Array', proto: true, forced: BROKEN_ON_SPARSE }, {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables('includes');


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.error.cause.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.error.cause.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable no-unused-vars -- required for functions `.length` */
var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var apply = __webpack_require__(/*! ../internals/function-apply */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-apply.js");
var wrapErrorConstructorWithCause = __webpack_require__(/*! ../internals/wrap-error-constructor-with-cause */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/wrap-error-constructor-with-cause.js");

var WEB_ASSEMBLY = 'WebAssembly';
var WebAssembly = globalThis[WEB_ASSEMBLY];

// eslint-disable-next-line es/no-error-cause -- feature detection
var FORCED = new Error('e', { cause: 7 }).cause !== 7;

var exportGlobalErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  var O = {};
  O[ERROR_NAME] = wrapErrorConstructorWithCause(ERROR_NAME, wrapper, FORCED);
  $({ global: true, constructor: true, arity: 1, forced: FORCED }, O);
};

var exportWebAssemblyErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  if (WebAssembly && WebAssembly[ERROR_NAME]) {
    var O = {};
    O[ERROR_NAME] = wrapErrorConstructorWithCause(WEB_ASSEMBLY + '.' + ERROR_NAME, wrapper, FORCED);
    $({ target: WEB_ASSEMBLY, stat: true, constructor: true, arity: 1, forced: FORCED }, O);
  }
};

// https://tc39.es/ecma262/#sec-nativeerror
exportGlobalErrorCauseWrapper('Error', function (init) {
  return function Error(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('EvalError', function (init) {
  return function EvalError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('RangeError', function (init) {
  return function RangeError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('ReferenceError', function (init) {
  return function ReferenceError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('SyntaxError', function (init) {
  return function SyntaxError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('TypeError', function (init) {
  return function TypeError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('URIError', function (init) {
  return function URIError(message) { return apply(init, this, arguments); };
});
exportWebAssemblyErrorCauseWrapper('CompileError', function (init) {
  return function CompileError(message) { return apply(init, this, arguments); };
});
exportWebAssemblyErrorCauseWrapper('LinkError', function (init) {
  return function LinkError(message) { return apply(init, this, arguments); };
});
exportWebAssemblyErrorCauseWrapper('RuntimeError', function (init) {
  return function RuntimeError(message) { return apply(init, this, arguments); };
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/web.self.js":
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/web.self.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in-accessor.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");

var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var INCORRECT_VALUE = globalThis.self !== globalThis;

// `self` getter
// https://html.spec.whatwg.org/multipage/window-object.html#dom-self
try {
  if (DESCRIPTORS) {
    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
    var descriptor = Object.getOwnPropertyDescriptor(globalThis, 'self');
    // some engines have `self`, but with incorrect descriptor
    // https://github.com/denoland/deno/issues/15765
    if (INCORRECT_VALUE || !descriptor || !descriptor.get || !descriptor.enumerable) {
      defineBuiltInAccessor(globalThis, 'self', {
        get: function self() {
          return globalThis;
        },
        set: function self(value) {
          if (this !== globalThis) throw new $TypeError('Illegal invocation');
          defineProperty(globalThis, 'self', {
            value: value,
            writable: true,
            configurable: true,
            enumerable: true
          });
        },
        configurable: true,
        enumerable: true
      });
    }
  } else $({ global: true, simple: true, forced: INCORRECT_VALUE }, {
    self: globalThis
  });
} catch (error) { /* empty */ }


/***/ }),

/***/ "./node_modules/.pnpm/@adguard+logger@1.1.1/node_modules/@adguard/logger/dist/es/index.mjs":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@adguard+logger@1.1.1/node_modules/@adguard/logger/dist/es/index.mjs ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LogLevel: () => (/* binding */ LogLevel),
/* harmony export */   Logger: () => (/* binding */ Logger)
/* harmony export */ });
/**
 * Checks if error has message.
 *
 * @param error Error object.
 * @returns True if error has message.
 */
function isErrorWithMessage(error) {
    return (typeof error === 'object'
        && error !== null
        && 'message' in error
        && typeof error.message === 'string');
}
/**
 * Converts error to the error with a message.
 *
 * @param maybeError Possible error.
 * @returns Error with a message.
 */
function toErrorWithMessage(maybeError) {
    if (isErrorWithMessage(maybeError)) {
        return maybeError;
    }
    try {
        return new Error(JSON.stringify(maybeError));
    }
    catch {
        // fallback in case there's an error stringifying the maybeError
        // like with circular references, for example.
        return new Error(String(maybeError));
    }
}
/**
 * Converts an error object to an error with a message. This method might be helpful to handle thrown errors.
 *
 * @param error Error object.
 *
 * @returns Message of the error.
 */
function getErrorMessage(error) {
    return toErrorWithMessage(error).message;
}

/**
 * Pads a number with leading zeros.
 * @param num The number to pad.
 * @param size The number of digits to pad to.
 * @returns The padded number.
 */
const pad = (num, size = 2) => {
    return num.toString().padStart(size, '0');
};
/**
 * Formats a date into an ISO 8601-like string with milliseconds.
 *
 * @param {Date|number} date The date object or timestamp to format.
 * @returns {string} The formatted date string.
 */
const formatTime = (date) => {
    const d = (date instanceof Date) ? date : new Date(date);
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1); // Months are 0-based
    const day = pad(d.getDate());
    const hour = pad(d.getHours());
    const minute = pad(d.getMinutes());
    const second = pad(d.getSeconds());
    const millisecond = pad(d.getMilliseconds(), 3); // Milliseconds are 3 digits
    return `${year}-${month}-${day}T${hour}:${minute}:${second}:${millisecond}`;
};

/**
 * String presentation of log levels, for convenient users usage.
 */
var LogLevel;
(function (LogLevel) {
    LogLevel["Error"] = "error";
    LogLevel["Warn"] = "warn";
    LogLevel["Info"] = "info";
    LogLevel["Debug"] = "debug";
    LogLevel["Trace"] = "trace";
})(LogLevel || (LogLevel = {}));
/**
 * Log levels map, which maps number level to string level.
 */
const levelMapNumToString = {
    [1 /* LogLevelNumeric.Error */]: LogLevel.Error,
    [2 /* LogLevelNumeric.Warn */]: LogLevel.Warn,
    [3 /* LogLevelNumeric.Info */]: LogLevel.Info,
    [4 /* LogLevelNumeric.Debug */]: LogLevel.Debug,
    [5 /* LogLevelNumeric.Trace */]: LogLevel.Trace,
};
/**
 * Log levels map, which maps string level to number level.
 */
const levelMapStringToNum = Object.entries(levelMapNumToString)
    .reduce((acc, [key, value]) => {
    // Here, key is originally a string since Object.entries() returns [string, string][].
    // We need to cast the key to LogLevelNumeric correctly without causing type mismatches.
    const numericKey = Number(key);
    if (!Number.isNaN(numericKey)) {
        acc[value] = numericKey;
    }
    return acc;
}, {});
/**
 * Simple logger with log levels.
 */
class Logger {
    currentLevelValue = 3 /* LogLevelNumeric.Info */;
    writer;
    /**
     * Constructor.
     * @param writer Writer object.
     */
    constructor(writer = console) {
        this.writer = writer;
        // bind the logging methods to avoid losing context
        this.debug = this.debug.bind(this);
        this.info = this.info.bind(this);
        this.warn = this.warn.bind(this);
        this.error = this.error.bind(this);
    }
    /**
     * Print debug messages. Usually used for technical information.
     * Will be printed in 'log' channel.
     *
     * @param args Printed arguments.
     */
    debug(...args) {
        this.print(4 /* LogLevelNumeric.Debug */, "log" /* LogMethod.Log */, args);
    }
    /**
     * Print messages you want to disclose to users.
     *
     * @param args Printed arguments.
     */
    info(...args) {
        this.print(3 /* LogLevelNumeric.Info */, "info" /* LogMethod.Info */, args);
    }
    /**
     * Print warn messages.
     * NOTE: We do not use 'warn' channel, since in the extensions warn is
     * counted as error. Instead of this we use 'info' channel.
     *
     * @param args Printed arguments.
     */
    warn(...args) {
        this.print(2 /* LogLevelNumeric.Warn */, "info" /* LogMethod.Info */, args);
    }
    /**
     * Print error messages.
     *
     * @param args Printed arguments.
     */
    error(...args) {
        this.print(1 /* LogLevelNumeric.Error */, "error" /* LogMethod.Error */, args);
    }
    /**
     * Getter for log level.
     * @returns Logger level.
     */
    get currentLevel() {
        return levelMapNumToString[this.currentLevelValue];
    }
    /**
     * Setter for log level. With this method log level can be updated dynamically.
     *
     * @param logLevel Logger level.
     * @throws Error if log level is not supported.
     */
    set currentLevel(logLevel) {
        const level = levelMapStringToNum[logLevel];
        if (level === undefined) {
            throw new Error(`Logger supports only the following levels: ${[Object.values(LogLevel).join(', ')]}`);
        }
        this.currentLevelValue = level;
    }
    /**
     * Converts error to string, and adds stack trace.
     *
     * @param error Error to print.
     * @private
     * @returns Error message.
     */
    static errorToString(error) {
        const message = getErrorMessage(error);
        return `${message}\nStack trace:\n${error.stack}`;
    }
    /**
     * Wrapper over log methods.
     *
     * @param level Logger level.
     * @param method Logger method.
     * @param args Printed arguments.
     * @private
     */
    print(level, method, args) {
        // skip writing if the basic conditions are not met
        if (this.currentLevelValue < level) {
            return;
        }
        if (!args || args.length === 0 || !args[0]) {
            return;
        }
        const formattedArgs = args.map((value) => {
            if (value instanceof Error) {
                return Logger.errorToString(value);
            }
            if (value && typeof value.message === 'string') {
                return value.message;
            }
            if (typeof value === 'object' && value !== null) {
                return JSON.stringify(value);
            }
            return String(value);
        });
        const formattedTime = `${formatTime(new Date())}:`;
        /**
         * Conditions in which trace can happen:
         * 1. Method is not error (because console.error provides call stack trace)
         * 2. Log level is equal or higher that `LogLevel.Trace`.
         * 3. Writer has `trace` method.
         */
        if (method === "error" /* LogMethod.Error */
            || this.currentLevelValue < levelMapStringToNum[LogLevel.Trace]
            || !this.writer.trace) {
            // Print with regular method
            this.writer[method](formattedTime, ...formattedArgs);
            return;
        }
        if (!this.writer.groupCollapsed || !this.writer.groupEnd) {
            // Print expanded trace
            this.writer.trace(formattedTime, ...formattedArgs);
            return;
        }
        // Print collapsed trace
        this.writer.groupCollapsed(formattedTime, ...formattedArgs);
        this.writer.trace();
        this.writer.groupEnd();
    }
}




/***/ }),

/***/ "./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js":
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   nanoid: () => (/* binding */ nanoid)
/* harmony export */ });
/* unused harmony exports customAlphabet, customRandom, random */

let random = bytes => crypto.getRandomValues(new Uint8Array(bytes))
let customRandom = (alphabet, defaultSize, getRandom) => {
  let mask = (2 << (Math.log(alphabet.length - 1) / Math.LN2)) - 1
  let step = -~((1.6 * mask * defaultSize) / alphabet.length)
  return (size = defaultSize) => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      let j = step
      while (j--) {
        id += alphabet[bytes[j] & mask] || ''
        if (id.length === size) return id
      }
    }
  }
}
let customAlphabet = (alphabet, size = 21) =>
  customRandom(alphabet, size, random)
let nanoid = (size = 21) =>
  crypto.getRandomValues(new Uint8Array(size)).reduce((id, byte) => {
    byte &= 63
    if (byte < 36) {
      id += byte.toString(36)
    } else if (byte < 62) {
      id += (byte - 26).toString(36).toUpperCase()
    } else if (byte > 62) {
      id += '-'
    } else {
      id += '_'
    }
    return id
  }, '')



/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!***********************************************!*\
  !*** ./Extension/pages/post-install/index.js ***!
  \***********************************************/
/* harmony import */ var _src_common_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../src/common/i18n */ "./Extension/src/common/i18n.ts");
/* harmony import */ var _src_pages_post_install__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../src/pages/post-install */ "./Extension/src/pages/post-install.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

_src_common_i18n__WEBPACK_IMPORTED_MODULE_0__.I18n.init();
_src_pages_post_install__WEBPACK_IMPORTED_MODULE_1__.PostInstall.init();

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvcG9zdC1pbnN0YWxsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLFdBQVcsV0FBVyxhQUFhLE1BQU0sS0FBSyxRQUFRLFlBQVksc0JBQXNCLGdCQUFnQjs7QUFFOUg7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLE1BQU0sSUFBMkI7QUFDakM7QUFDQTtBQUNBLElBQUksS0FBSyxFQU1OO0FBQ0gsQ0FBQzs7Ozs7Ozs7Ozs7QUM5SUQ7QUFDQSxNQUFNLElBQTBDO0FBQ2hELElBQUksaUNBQWdDLENBQUMsTUFBUSxDQUFDLG9DQUFFLE9BQU87QUFBQTtBQUFBO0FBQUEsa0dBQUM7QUFDeEQsSUFBSSxLQUFLLFlBUU47QUFDSCxDQUFDO0FBQ0Q7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFVBQVU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsR0FBRztBQUNwQixtQkFBbUIsU0FBUztBQUM1QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTtBQUNBLGlCQUFpQixVQUFVO0FBQzNCO0FBQ0EsaUJBQWlCLFVBQVU7QUFDM0I7QUFDQSxpQkFBaUIsUUFBUTtBQUN6QjtBQUNBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixRQUFRO0FBQ3pCO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlELGtCQUFrQixFQUFFLHNDQUFzQyxNQUFNLEtBQUssVUFBVSxZQUFZO0FBQzVJO0FBQ0E7QUFDQSxnREFBZ0Qsa0JBQWtCLEVBQUUsc0NBQXNDLE1BQU0sS0FBSyxVQUFVLFlBQVk7QUFDM0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsZ0JBQWdCO0FBQ2hCLGdDQUFnQyxNQUFNO0FBQ3RDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBLFdBQVc7QUFDWDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixRQUFRO0FBQ3pCO0FBQ0EsaUJBQWlCLFVBQVU7QUFDM0I7QUFDQTtBQUNBLGlCQUFpQixVQUFVO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsUUFBUTtBQUN6QjtBQUNBO0FBQ0EsaUJBQWlCLFFBQVEsY0FBYztBQUN2QztBQUNBO0FBQ0E7QUFDQSw2REFBNkQsZ0JBQWdCO0FBQzdFO0FBQ0EsaUJBQWlCLFFBQVEsY0FBYztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0EsK0NBQStDLGVBQWU7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixvQ0FBb0M7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixRQUFRO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixHQUFHO0FBQ3RCO0FBQ0EsbUJBQW1CLFFBQVE7QUFDM0I7QUFDQSxtQkFBbUIsYUFBYTtBQUNoQztBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2YsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBK0Msa0JBQWtCLEVBQUUsc0NBQXNDLE1BQU0sS0FBSyxVQUFVLFlBQVk7QUFDMUk7QUFDQTtBQUNBLDhDQUE4QyxrQkFBa0IsRUFBRSxzQ0FBc0MsTUFBTSxLQUFLLFVBQVUsWUFBWTtBQUN6STtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWCxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsQ0FBQztBQUNEOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3hzQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FDMkM7QUFFNUM7O0NBRUMsR0FDTSxNQUFNQztJQUNUOztLQUVDLEdBQ0QsT0FBY0MsT0FBTztRQUNqQkMsU0FBU0MsZ0JBQWdCLENBQUMsb0JBQW9CSCxLQUFLSSxTQUFTO0lBQ2hFO0lBRUE7O0tBRUMsR0FDRCxPQUFlQSxZQUFZO1FBQ3ZCSixLQUFLSyxpQkFBaUIsQ0FBQztRQUN2QkwsS0FBS00sbUJBQW1CLENBQUMsYUFBYTtRQUN0Q04sS0FBS00sbUJBQW1CLENBQUMsYUFBYTtRQUN0Q04sS0FBS00sbUJBQW1CLENBQUMsY0FBYztJQUMzQztJQUVBOzs7O0tBSUMsR0FDRCxPQUFlRCxrQkFBa0JFLGlCQUF5QixFQUFFO1FBQ3hETCxTQUFTTSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBRUQsa0JBQWtCLENBQUMsQ0FBQyxFQUFFRSxPQUFPLENBQUMsQ0FBQ0M7WUFDekQsTUFBTUMsVUFBVVgsS0FBS1ksY0FBYyxDQUFDRixJQUFJSDtZQUV4QyxJQUFJLENBQUNJLFNBQVM7Z0JBQ1Y7WUFDSjtZQUVBWCxLQUFLYSxnQkFBZ0IsQ0FBQ0gsSUFBSUM7UUFDOUI7SUFDSjtJQUVBOzs7OztLQUtDLEdBQ0QsT0FBZUUsaUJBQWlCQyxPQUFnQixFQUFFSCxPQUFlLEVBQVE7UUFDckUsSUFBSTtZQUNBLDBCQUEwQjtZQUMxQixNQUFPRyxRQUFRQyxTQUFTLENBQUU7Z0JBQ3RCRCxRQUFRRSxXQUFXLENBQUNGLFFBQVFDLFNBQVM7WUFDekM7WUFDQSw0QkFBNEI7WUFDNUJmLEtBQUtpQixhQUFhLENBQUNOLFNBQVNHO1FBQ2hDLEVBQUUsT0FBT0ksSUFBSTtRQUNULG9CQUFvQjtRQUN4QjtJQUNKO0lBRUE7Ozs7O0tBS0MsR0FDRCxPQUFlRCxjQUFjRSxJQUFZLEVBQUVMLE9BQWdCLEVBQVE7UUFDL0QsSUFBSUo7UUFFSixNQUFNVSxTQUFTLHdEQUF3REMsSUFBSSxDQUFDRjtRQUM1RSxNQUFNRyxTQUFTLHlDQUF5Q0QsSUFBSSxDQUFDRjtRQUM3RCxJQUFJQyxRQUFRO1lBQ1IsbUJBQW1CO1lBQ25CLDJEQUEyRCxHQUMzRHBCLEtBQUtpQixhQUFhLENBQUNHLE1BQU0sQ0FBQyxFQUFFLEVBQUdOO1lBRS9CSixLQUFLVixLQUFLdUIsYUFBYSxDQUFDSCxNQUFNLENBQUMsRUFBRSxFQUFHQSxNQUFNLENBQUMsRUFBRTtZQUU3Q3BCLEtBQUtpQixhQUFhLENBQUNHLE1BQU0sQ0FBQyxFQUFFLEVBQUdWO1lBQy9CSSxRQUFRVSxXQUFXLENBQUNkO1lBRXBCVixLQUFLaUIsYUFBYSxDQUFDRyxNQUFNLENBQUMsRUFBRSxFQUFHTjtRQUNuQyxPQUFPLElBQUlRLFFBQVE7WUFDZnRCLEtBQUtpQixhQUFhLENBQUNLLE1BQU0sQ0FBQyxFQUFFLEVBQUdSO1lBRS9CSixLQUFLVixLQUFLdUIsYUFBYSxDQUFDRCxNQUFNLENBQUMsRUFBRSxFQUFHQSxNQUFNLENBQUMsRUFBRTtZQUM3Q1IsUUFBUVUsV0FBVyxDQUFDZDtZQUVwQlYsS0FBS2lCLGFBQWEsQ0FBQ0ssTUFBTSxDQUFDLEVBQUUsRUFBR1I7UUFDL0IsMERBQTBELEdBQzlELE9BQU87WUFDSEEsUUFBUVUsV0FBVyxDQUFDdEIsU0FBU3VCLGNBQWMsQ0FBQ04sS0FBS08sT0FBTyxDQUFDLFdBQVc7UUFDeEU7SUFDSjtJQUVBOzs7Ozs7O0tBT0MsR0FDRCxPQUFlSCxjQUFjSSxPQUFlLEVBQUVDLFVBQWtCLEVBQVc7UUFDdkUsTUFBTWxCLEtBQUtSLFNBQVNxQixhQUFhLENBQUNJO1FBQ2xDLElBQUksQ0FBQ0MsWUFBWTtZQUNiLE9BQU9sQjtRQUNYO1FBRUFrQixXQUNLQyxLQUFLLENBQUMsb0JBQ05wQixPQUFPLENBQUMsQ0FBQ3FCO1lBQ04sSUFBSSxDQUFDQSxNQUFNO2dCQUNQO1lBQ0o7WUFFQSxNQUFNQyxRQUFRRCxLQUFLRSxPQUFPLENBQUM7WUFDM0IsSUFBSUM7WUFDSixJQUFJQztZQUNKLElBQUlILFFBQVEsR0FBRztnQkFDWEUsV0FBV0gsS0FBS0ssU0FBUyxDQUFDLEdBQUdKO2dCQUM3QkcsWUFBWUosS0FBS0ssU0FBUyxDQUFDSixRQUFRLEdBQUdELEtBQUtNLE1BQU0sR0FBRztZQUN4RDtZQUNBLElBQUlILFlBQVlDLFdBQVc7Z0JBQ3ZCeEIsR0FBRzJCLFlBQVksQ0FBQ0osVUFBVUM7WUFDOUI7UUFDSjtRQUVKLE9BQU94QjtJQUNYO0lBRUE7Ozs7OztLQU1DLEdBQ0QsT0FBZUosb0JBQ1hDLGlCQUF5QixFQUN6QitCLGFBQXFCLEVBQ2pCO1FBQ0pwQyxTQUFTTSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBRUQsa0JBQWtCLENBQUMsQ0FBQyxFQUFFRSxPQUFPLENBQUMsQ0FBQ0s7WUFDekQsTUFBTUgsVUFBVVgsS0FBS1ksY0FBYyxDQUFDRSxTQUFTUDtZQUU3QyxJQUFJLENBQUNJLFNBQVM7Z0JBQ1Y7WUFDSjtZQUVBRyxRQUFRdUIsWUFBWSxDQUFDQyxlQUFlM0I7UUFDeEM7SUFDSjtJQUVBOzs7Ozs7O0tBT0MsR0FDRCxPQUFlQyxlQUFlRSxPQUFnQixFQUFFd0IsYUFBcUIsRUFBaUI7UUFDbEYsTUFBTUMsWUFBWXpCLFFBQVEwQixZQUFZLENBQUNGO1FBRXZDLElBQUksQ0FBQ0MsV0FBVztZQUNaLE9BQU87UUFDWDtRQUVBLE9BQU94QyxpRUFBWSxDQUFDMkMsVUFBVSxDQUFDSDtJQUNuQztBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxTEE7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJDLEdBd0IyQjtBQXRCdUI7QUFFbkQsTUFBTU0sdUJBQXVCRixtREFBTUE7SUFDL0JHLFlBQXFCO1FBQ2pCLE9BQU8sSUFBSSxDQUFDQyxZQUFZLEtBQUtILHFEQUFRQSxDQUFDSSxLQUFLLElBQ25DLElBQUksQ0FBQ0QsWUFBWSxLQUFLSCxxREFBUUEsQ0FBQ0ssS0FBSztJQUNoRDtBQUNKO0FBRUEsTUFBTUMsU0FBUyxJQUFJTDtBQUVuQkssT0FBT0gsWUFBWSxHQUFHSSxNQUFxQkMsR0FDckNSLENBQWEsR0FDYkEscURBQVFBLENBQUNLLEtBQUs7QUFFcEIsc0NBQXNDO0FBQ3RDLDREQUE0RDtBQUM1RCxpREFBaUQ7QUFFakQsaURBQWlEO0FBQ2pESyxPQUFPQyxNQUFNLENBQUNDLE1BQU07SUFBRUMsU0FBUztRQUFFLEdBQUdELEtBQUtDLE9BQU87UUFBRVA7SUFBTztBQUFFO0FBRS9COzs7Ozs7Ozs7Ozs7Ozs7O0FDekM1Qjs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUVEOzs7Ozs7Q0FNQyxHQTJCTSxNQUFNUSwyQkFBMkIsTUFBTTtBQU05Qzs7O0NBR0MsR0FDTSx5Q0FBS0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7V0FBQUE7TUFrRlg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9JRDs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUUyQjtBQUNHO0FBQ0c7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQmxDOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JDOzs7Ozs7Ozs7Ozs7O0FBeUhBO0FBeEh3RDtBQVdwQztBQU9yQjs7Ozs7Ozs7Q0FRQyxHQUNNLE1BQU1DLHNCQUFzQixDQUFDakQ7SUFDaEMsT0FBTyxPQUFPQSxZQUFZLFlBQVlBLFlBQVksUUFBUSxVQUFVQTtBQUN4RSxFQUFFO0FBRUY7Ozs7Ozs7O0NBUUMsR0FDTSxNQUFNa0QsOEJBQThCLENBQUNsRDtJQUN4QyxPQUFPaUQsb0JBQW9CakQsWUFBWSxVQUFVQTtBQUNyRCxFQUFFO0FBRUY7O0NBRUMsR0FDTSxNQUFlbUQ7SUFPWDdELE9BQWE7UUFDaEJGLG9FQUFlLENBQUNpRSxTQUFTLENBQUNDLFdBQVcsQ0FBQyxJQUFJLENBQUNDLGFBQWE7SUFDNUQ7SUFFQTs7Ozs7Ozs7Ozs7S0FXQyxHQUNELFlBQ0lDLElBQU8sRUFDUEMsUUFBNEIsRUFDeEI7UUFDSixJQUFJLElBQUksQ0FBQ0MsU0FBUyxDQUFDQyxHQUFHLENBQUNILE9BQU87WUFDMUIsTUFBTSxJQUFJSSxNQUFNLENBQUMsaUJBQWlCLEVBQUVKLEtBQUsscUNBQXFDLENBQUM7UUFDbkY7UUFFQSxxRUFBcUU7UUFDckUseURBQXlEO1FBQ3pELElBQUksQ0FBQ0UsU0FBUyxDQUFDRyxHQUFHLENBQUNMLE1BQU1DO0lBQzdCO0lBRUE7Ozs7S0FJQyxHQUNELGVBQW1ERCxJQUFPLEVBQVE7UUFDOUQsSUFBSSxDQUFDRSxTQUFTLENBQUNLLE1BQU0sQ0FBQ1A7SUFDMUI7SUFFQTs7S0FFQyxHQUNELGtCQUErQjtRQUMzQixJQUFJLENBQUNFLFNBQVMsQ0FBQ08sS0FBSztJQUN4QjtJQUVBOzs7Ozs7S0FNQyxHQUNELE9BQWlCQyxtQkFBbUJsRSxPQUFnQyxFQUFzQjtRQUN0RixPQUFPQSxRQUFRbUUsV0FBVyxLQUFLcEIsZ0VBQXdCQSxJQUFJLFVBQVUvQztJQUN6RTtJQTFEQW9FLGFBQWM7UUFGZCx1QkFBVVYsYUFBWSxJQUFJVztRQUd0QixJQUFJLENBQUNkLGFBQWEsR0FBRyxJQUFJLENBQUNBLGFBQWEsQ0FBQ2UsSUFBSSxDQUFDLElBQUk7SUFDckQ7QUFvRUo7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6SUE7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FFMkM7QUFNdkI7QUFFckI7Ozs7Ozs7Ozs7O0NBV0MsR0FDTSxlQUFlQyxZQUNsQnZFLE9BQXFDO0lBRXJDLElBQUk7UUFDQSxPQUFPLE1BQU1aLG9FQUFlLENBQUNtRixXQUFXLENBQUM7WUFDckNKLGFBQWFwQixnRUFBd0JBO1lBQ3JDLEdBQUcvQyxPQUFPO1FBQ2Q7SUFDSixFQUFFLE9BQU93RSxHQUFHO0lBQ1IsYUFBYTtJQUNqQjtBQUNKO0FBRUE7Ozs7Ozs7O0NBUUMsR0FDTSxlQUFlQyxlQUNsQkMsS0FBYSxFQUNiMUUsT0FBcUM7SUFFckMsT0FBT1osaUVBQVksQ0FBQ21GLFdBQVcsQ0FBQ0csT0FBTztRQUNuQ1AsYUFBYXBCLGdFQUF3QkE7UUFDckMsR0FBRy9DLE9BQU87SUFDZDtBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEVBOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JDLEdBRUQsYUFBYTs7Ozs7Ozs7Ozs7Ozs7QUFDaUI7QUFFWTtBQUVPO0FBRTFDLE1BQU04RTtJQVNULE9BQWN4RixPQUFhO1FBQ3ZCQyxTQUFTQyxnQkFBZ0IsQ0FBQyxvQkFBb0JzRixZQUFZQyxrQkFBa0I7SUFDaEY7SUFFQSxPQUFlQSxxQkFBMkI7UUFDdENELFlBQVlFLE9BQU8sQ0FBQ0MsRUFBRSxDQUFDO1FBRXZCSCxZQUFZSSx1QkFBdUI7SUFDdkM7SUFFQSxhQUFxQkEsMEJBQXlDO1FBQzFELElBQUk7WUFDQSxNQUFNQyxRQUFRLE1BQU1OLDBEQUFTQSxDQUFDSyx1QkFBdUI7WUFFckQsSUFBSUMsT0FBTztnQkFDUEwsWUFBWU0sY0FBYztZQUM5QixPQUFPO2dCQUNIQyxXQUFXUCxZQUFZSSx1QkFBdUIsRUFBRUosWUFBWVEscUJBQXFCO1lBQ3JGO1FBQ0osRUFBRSxPQUFPZCxHQUFHO1lBQ1JqQyxrREFBTUEsQ0FBQ2dELEtBQUssQ0FBQ2Y7WUFDYixpREFBaUQ7WUFDakRhLFdBQVdQLFlBQVlJLHVCQUF1QixFQUFFSixZQUFZUSxxQkFBcUI7UUFDckY7SUFDSjtJQUVBLE9BQWVGLGlCQUF1QjtRQUNsQ04sWUFBWUUsT0FBTyxDQUFDQyxFQUFFLENBQUM7UUFDdkJJLFdBQVc7WUFDUCxJQUFJRyxRQUFRO2dCQUNSWCwwREFBU0EsQ0FBQ1ksZ0JBQWdCO1lBQzlCO1FBQ0osR0FBR1gsWUFBWVkseUJBQXlCO0lBQzVDO0FBQ0o7QUExQ0ksaUJBRFNaLGFBQ01FLFdBQVUsSUFBSUosZ0RBQU9BLENBQUM7SUFDakNlLFdBQVc7QUFDZjtBQUVBLGlCQUxTYixhQUtNUSx5QkFBd0I7QUFFdkMsaUJBUFNSLGFBT01ZLDZCQUE0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQy9DOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JDOzs7Ozs7Ozs7Ozs7O0FBZy9CK0I7QUE5K0JZO0FBQ1o7QUFFYTtBQU1kO0FBNER4QixrQ0FBV0c7OztXQUFBQTtNQUdqQjtBQUlEOzs7Q0FHQyxHQUNELE1BQU1DO0lBYUY7Ozs7Ozs7Ozs7OztLQVlDLEdBQ0Qsa0RBQWtEO0lBQ2xELE1BQWN2QixZQUNWZixJQUEwQyxFQUMxQ3VDLElBQTJHLEVBQ3pFO1FBQ2xDLE1BQU1DLFdBQVcsTUFBTTVHLG9FQUFlLENBQUNtRixXQUFXLENBQUM7WUFDL0NKLGFBQWFwQixzRUFBd0JBO1lBQ3JDUztZQUNBdUM7UUFDSjtRQUVBLE9BQU9DO0lBQ1g7SUFvSkE7Ozs7S0FJQyxHQUNELE1BQU1DLGtCQUFnRjtRQUNsRixPQUFPLElBQUksQ0FBQzFCLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDa0QsZUFBZTtJQUN2RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGlCQUE4RTtRQUNoRixPQUFPLElBQUksQ0FBQzVCLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDb0QsY0FBYztJQUN0RDtJQUVBOzs7Ozs7O0tBT0MsR0FDRCxNQUFNQyxrQkFDRkMsU0FBa0QsRUFDbERDLEtBQWdELEVBQ2U7UUFDL0QsTUFBTSxJQUFJLENBQUNoQyxXQUFXLENBQ2xCdkIseURBQVdBLENBQUN3RCxrQkFBa0IsRUFDOUI7WUFDSUMsS0FBS0g7WUFDTEM7UUFDSjtJQUVSO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1HLHFCQUFzRjtRQUN4RixPQUFPLElBQUksQ0FBQ25DLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDMkQsa0JBQWtCO0lBQzFEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLGtCQUFnRjtRQUNsRixPQUFPLElBQUksQ0FBQ3JDLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDNkQsZUFBZTtJQUN2RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGFBQ0ZDLFFBQXVELEVBQ1E7UUFDL0QsT0FBTyxJQUFJLENBQUN4QyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ2dFLGtCQUFrQixFQUFFO1lBQUVEO1FBQVM7SUFDdkU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNRSxjQUNGRixRQUFrRCxFQUNRO1FBQzFELE9BQU8sSUFBSSxDQUFDeEMsV0FBVyxDQUFDdkIseURBQVdBLENBQUNrRSxhQUFhLEVBQUU7WUFBRUg7UUFBUztJQUNsRTtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1JLGtCQUNGQyxJQUE4QyxFQUNnQjtRQUM5RCxPQUFPLElBQUksQ0FBQzdDLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDcUUsaUJBQWlCLEVBQUU7WUFBRUQ7UUFBSztJQUNsRTtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNRSxtQkFBa0Y7UUFDcEYsT0FBTyxJQUFJLENBQUMvQyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3VFLGdCQUFnQjtJQUN4RDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxrQkFBcUY7UUFDdkYsT0FBTyxJQUFJLENBQUNqRCxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3lFLG9CQUFvQjtJQUM1RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLDJCQUNGQyxXQUFxRSxFQUNFO1FBQ3ZFLE9BQU8sSUFBSSxDQUFDcEQsV0FBVyxDQUFDdkIseURBQVdBLENBQUM0RSwwQkFBMEIsRUFBRTtZQUFFRDtRQUFZO0lBQ2xGO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1FLGdCQUE0RTtRQUM5RSxPQUFPLElBQUksQ0FBQ3RELFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDOEUsYUFBYTtJQUNyRDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxlQUEwRTtRQUM1RSxPQUFPLElBQUksQ0FBQ3hELFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDZ0YsWUFBWTtJQUNwRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGNBQ0YxQixLQUE0QyxFQUNjO1FBQzFELE1BQU0sSUFBSSxDQUFDaEMsV0FBVyxDQUFDdkIseURBQVdBLENBQUNrRixhQUFhLEVBQUU7WUFBRTNCO1FBQU07SUFDOUQ7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTTRCLDBCQUFnRztRQUNsRyxPQUFPLElBQUksQ0FBQzVELFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDb0YsdUJBQXVCO0lBQy9EO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLGVBQWlGO1FBQ25GLE9BQU8sSUFBSSxDQUFDOUQsV0FBVyxDQUFDdkIseURBQVdBLENBQUNzRixtQkFBbUI7SUFDM0Q7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNQyxjQUNGaEMsS0FBNEMsRUFDcUI7UUFDakUsTUFBTSxJQUFJLENBQUNoQyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3dGLG9CQUFvQixFQUFFO1lBQUVqQztRQUFNO0lBQ3JFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTWtDLHNCQUNGQyxTQUE0RCxFQUNNO1FBQ2xFLE1BQU0sSUFBSSxDQUFDbkUsV0FBVyxDQUFDdkIseURBQVdBLENBQUMyRixxQkFBcUIsRUFBRTtZQUFFRDtRQUFVO0lBQzFFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1FLGdCQUFpRjtRQUNuRixJQUFJQyxJQUFVQSxFQUFFO1lBQ1p0RyxrREFBTUEsQ0FBQ3VHLEtBQUssQ0FBQztZQUNiLE9BQU8sRUFBRTtRQUNiO1FBRUEsT0FBTyxJQUFJLENBQUN2RSxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQytGLGtCQUFrQjtJQUMxRDtJQUVBOzs7Ozs7O0tBT0MsR0FDRCxNQUFNQyxrQkFDRkMsRUFBVSxFQUNWQyxPQUFnQixFQUNpRjtRQUNqRyxNQUFNMUYsT0FBTzBGLFVBQVVsRyx5REFBV0EsQ0FBQ21HLGtCQUFrQixHQUFHbkcseURBQVdBLENBQUNvRyxtQkFBbUI7UUFDdkYsTUFBTUMsVUFBVUMsT0FBT0MsUUFBUSxDQUFDTixJQUFJO1FBRXBDLE9BQU8sSUFBSSxDQUFDMUUsV0FBVyxDQUFDZixNQUFNO1lBQUU2RjtRQUFRO0lBQzVDO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUcsb0JBQ0ZDLFNBQTBELEVBQ007UUFDaEUsT0FBTyxJQUFJLENBQUNsRixXQUFXLENBQUN2Qix5REFBV0EsQ0FBQzBHLG1CQUFtQixFQUFFO1lBQUVEO1FBQVU7SUFDekU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNRSxxQkFDRjVDLFFBQXlELEVBQ1E7UUFDakUsT0FBTyxJQUFJLENBQUN4QyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQzRHLG9CQUFvQixFQUFFO1lBQUU3QztRQUFTO0lBQ3pFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTThDLGVBQ0ZDLEdBQStDLEVBQ2tCO1FBQ2pFLE9BQU8sSUFBSSxDQUFDdkYsV0FBVyxDQUFDdkIseURBQVdBLENBQUMrRyxvQkFBb0IsRUFBRTtZQUFFRDtRQUFJO0lBQ3BFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUUsZ0JBQ0ZDLE1BQXdELEVBQ1k7UUFDcEUsT0FBTyxJQUFJLENBQUMxRixXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ2tILHVCQUF1QixFQUFFO1lBQUVEO1FBQU87SUFDMUU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNRSxtQkFDRnBELFFBQTJELEVBQ1E7UUFDbkUsTUFBTSxJQUFJLENBQUN4QyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ29ILHNCQUFzQixFQUFFO1lBQUVyRDtRQUFTO0lBQzFFO0lBRUE7Ozs7O0tBS0MsR0FDRCxNQUFNc0QscUJBQXNGO1FBQ3hGLE9BQU8sSUFBSSxDQUFDOUYsV0FBVyxDQUFDdkIseURBQVdBLENBQUNzSCxrQkFBa0I7SUFDMUQ7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNQyxtQkFDRjdGLEtBQWlELEVBQ2M7UUFDL0QsT0FBTyxJQUFJLENBQUNILFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDd0gsa0JBQWtCLEVBQUU7WUFBRTlGO1FBQU07SUFDcEU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNK0YsaUNBQ0ZDLEtBQStELEVBQ2M7UUFDN0UsT0FBTyxJQUFJLENBQUNuRyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQzJILGdDQUFnQyxFQUFFO1lBQUVEO1FBQU07SUFDbEY7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNRSwrQkFDRkMsS0FBNkQsRUFDYztRQUMzRSxPQUFPLElBQUksQ0FBQ3RHLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDOEgsOEJBQThCLEVBQUU7WUFBRUQ7UUFBTTtJQUNoRjtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNRSxxQkFBc0Y7UUFDeEYsT0FBTyxJQUFJLENBQUN4RyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ2dJLGtCQUFrQjtJQUMxRDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxrQkFBZ0Y7UUFDbEYsT0FBTyxJQUFJLENBQUMxRyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ2tJLGVBQWU7SUFDdkQ7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsZ0JBQTRFO1FBQzlFLE9BQU8sSUFBSSxDQUFDNUcsV0FBVyxDQUFDdkIseURBQVdBLENBQUNvSSxhQUFhO0lBQ3JEO0lBRUE7Ozs7Ozs7S0FPQyxHQUNELE1BQU1DLGNBQ0Z2QixHQUF1QyxFQUN2Q3dCLElBQXlDLEVBQ2dCO1FBQ3pELE9BQU8sSUFBSSxDQUFDL0csV0FBVyxDQUFDdkIseURBQVdBLENBQUN1SSxZQUFZLEVBQUU7WUFBRXpCO1lBQUt3QjtRQUFLO0lBQ2xFO0lBRUE7Ozs7Ozs7S0FPQyxHQUNELE1BQU1FLGtCQUNGMUIsR0FBNEMsRUFDNUN3QixJQUE4QyxFQUNnQjtRQUM5RCxPQUFPLElBQUksQ0FBQy9HLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDeUksaUJBQWlCLEVBQUU7WUFBRTNCO1lBQUt3QjtRQUFLO0lBQ3ZFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUksc0JBQ0Y1QixHQUFnRCxFQUNrQjtRQUNsRSxNQUFNLENBQUM2QixXQUFXLEdBQUcsTUFBTXZNLGlFQUFZLENBQUN3TSxLQUFLLENBQUM7WUFBRUMsUUFBUTtZQUFNQyxlQUFlO1FBQUs7UUFFbEYsSUFBSSxFQUFDSCx1QkFBQUEsaUNBQUFBLFdBQVkxQyxFQUFFLEdBQUU7WUFDakIxRyxrREFBTUEsQ0FBQ3VHLEtBQUssQ0FBQztZQUNiO1FBQ0o7UUFFQSxPQUFPLElBQUksQ0FBQ3ZFLFdBQVcsQ0FDbkJ2Qix5REFBV0EsQ0FBQytJLHFCQUFxQixFQUNqQztZQUFFakM7WUFBS3BGLEtBQUssRUFBRWlILHVCQUFBQSxpQ0FBQUEsV0FBWTFDLEVBQUU7UUFBQztJQUVyQztJQUVBOzs7Ozs7O0tBT0MsR0FDRCxNQUFNK0Msc0JBQ0Z0SCxLQUFvRCxFQUNwRHVILFVBQThELEVBQ0k7UUFDbEUsT0FBTyxJQUFJLENBQUMxSCxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ2tKLHFCQUFxQixFQUFFO1lBQUV4SDtZQUFPdUg7UUFBVztJQUNuRjtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1FLG1CQUNGekgsS0FBaUQsRUFDYztRQUMvRCxPQUFPLElBQUksQ0FBQ0gsV0FBVyxDQUFDdkIseURBQVdBLENBQUNvSixrQkFBa0IsRUFBRTtZQUFFMUg7UUFBTTtJQUNwRTtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNMkgseUJBQThGO1FBQ2hHLE1BQU0sSUFBSSxDQUFDOUgsV0FBVyxDQUFDdkIseURBQVdBLENBQUNzSixzQkFBc0I7SUFDN0Q7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsc0JBQXdGO1FBQzFGLE9BQU8sSUFBSSxDQUFDaEksV0FBVyxDQUFDdkIseURBQVdBLENBQUN3SixtQkFBbUI7SUFDM0Q7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsMEJBQWdHO1FBQ2xHLE1BQU0sSUFBSSxDQUFDbEksV0FBVyxDQUFDdkIseURBQVdBLENBQUMwSix1QkFBdUI7SUFDOUQ7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNQyx3QkFDRmpJLEtBQXNELEVBQ2M7UUFDcEUsT0FBTyxJQUFJLENBQUNILFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDNEosdUJBQXVCLEVBQUU7WUFBRWxJO1FBQU07SUFDekU7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTW1JLHNCQUF3RjtRQUMxRixPQUFPLElBQUksQ0FBQ3RJLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDOEosbUJBQW1CO0lBQzNEO0lBRUE7Ozs7Ozs7S0FPQyxHQUNELE1BQU1DLG1CQUNGckksS0FBaUQsRUFDakRzSSxpQkFBMEUsRUFDWDtRQUMvRCxPQUFPLElBQUksQ0FBQ3pJLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDaUssa0JBQWtCLEVBQUU7WUFBRXZJO1lBQU9zSTtRQUFrQjtJQUN2RjtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1FLFlBQ0Z4SSxLQUEwQyxFQUNjO1FBQ3hELE1BQU0sSUFBSSxDQUFDSCxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ21LLFdBQVcsRUFBRTtZQUFFekk7UUFBTTtJQUM1RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU0wSSxZQUNGQyxRQUFnRCxFQUNRO1FBQ3hELE1BQU0sSUFBSSxDQUFDOUksV0FBVyxDQUFDdkIseURBQVdBLENBQUNzSyxXQUFXLEVBQUU7WUFBRUQ7UUFBUztJQUMvRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1FLGVBQ0ZGLFFBQW1ELEVBQ1E7UUFDM0QsTUFBTSxJQUFJLENBQUM5SSxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3dLLGNBQWMsRUFBRTtZQUFFSDtRQUFTO0lBQ2xFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUksb0JBQ0YvQyxLQUFrRCxFQUNjO1FBQ2hFLE9BQU8sSUFBSSxDQUFDbkcsV0FBVyxDQUFDdkIseURBQVdBLENBQUMwSyxtQkFBbUIsRUFBRTtZQUFFaEQ7UUFBTTtJQUNyRTtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNaUQsMEJBQWdHO1FBQ2xHLE9BQU8sSUFBSSxDQUFDcEosV0FBVyxDQUFDdkIseURBQVdBLENBQUM0Syx1QkFBdUI7SUFDL0Q7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNQyx3QkFDRkMsT0FBMEQsRUFDVTtRQUNwRSxPQUFPLElBQUksQ0FBQ3ZKLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDK0ssdUJBQXVCLEVBQUU7WUFBRUQ7UUFBUTtJQUMzRTtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNRSx5QkFBaUc7UUFDbkcsT0FBTyxJQUFJLENBQUN6SixXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ2lMLHlCQUF5QjtJQUNqRTtJQUVBOzs7Ozs7OztLQVFDLEdBQ0QsTUFBTUMsc0JBQ0ZuSCxRQUE2RCxFQUNRO1FBQ3JFLE9BQU8sSUFBSSxDQUFDeEMsV0FBVyxDQUFDdkIseURBQVdBLENBQUNtTCx3QkFBd0IsRUFBRTtZQUFFcEg7UUFBUztJQUM3RTtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1xSCxxQkFDRi9FLE9BQTBELEVBQ1U7UUFDcEUsT0FBTyxJQUFJLENBQUM5RSxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3FMLHVCQUF1QixFQUFFO1lBQUVoRjtRQUFRO0lBQzNFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1pRixtQkFBa0Y7UUFDcEYsT0FBTyxJQUFJLENBQUMvSixXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3VMLGdCQUFnQjtJQUN4RDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNckosMEJBQWdHO1FBQ2xHLE9BQU8sSUFBSSxDQUFDWCxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3dMLHVCQUF1QjtJQUMvRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGdCQUFnQjNFLEdBQTBDLEVBQWdFO1FBQzVILE9BQU8sSUFBSSxDQUFDdkYsV0FBVyxDQUFDdkIseURBQVdBLENBQUMwTCxlQUFlLEVBQUU7WUFBRTVFO1FBQUk7SUFDL0Q7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTTZFLHlCQUE4RjtRQUNoRyxPQUFPLElBQUksQ0FBQ3BLLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDNEwsc0JBQXNCO0lBQzlEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLG9CQUFvRjtRQUN0RixPQUFPLElBQUksQ0FBQ3RLLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDOEwsaUJBQWlCO0lBQ3pEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLDZCQUFzRztRQUN4RyxPQUFPLElBQUksQ0FBQ3hLLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDZ00sMEJBQTBCO0lBQ2xFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLHNCQUF3RjtRQUMxRixPQUFPLElBQUksQ0FBQzFLLFdBQVcsQ0FBQ3ZCLHlEQUFXQSxDQUFDc0YsbUJBQW1CO0lBQzNEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU00RyxtQkFBa0Y7UUFDcEYsT0FBTyxJQUFJLENBQUMzSyxXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ21NLGdCQUFnQjtJQUN4RDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNMUosbUJBQWtGO1FBQ3BGLE9BQU8sSUFBSSxDQUFDbEIsV0FBVyxDQUFDdkIseURBQVdBLENBQUNvTSxnQkFBZ0I7SUFDeEQ7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsd0JBQTRGO1FBQzlGLE9BQU8sSUFBSSxDQUFDOUssV0FBVyxDQUFDdkIseURBQVdBLENBQUNzTSxxQkFBcUI7SUFDN0Q7SUFFQTs7Ozs7S0FLQyxHQUNELE1BQU1DLHdCQUNGekYsR0FBa0QsRUFDa0I7UUFDcEUsT0FBTyxJQUFJLENBQUN2RixXQUFXLENBQUN2Qix5REFBV0EsQ0FBQ3dNLHVCQUF1QixFQUFFO1lBQUUxRjtRQUFJO0lBQ3ZFO0lBdDVCQTs7S0FFQyxHQUNEMUYsYUFBYztRQUxkZix1QkFBQUEsYUFBWWpFLHNFQUFlLENBQUNpRSxTQUFTO1FBeUdyQzs7Ozs7Ozs7S0FRQyxHQUNEb00sdUJBQUFBLHVCQUFzQixPQUNsQkMsUUFDQUMsVUFDQUM7WUFFQSxJQUFJQztZQUVKLE1BQU03SixXQUF3QyxNQUFNLElBQUksQ0FBQ3pCLFdBQVcsQ0FDaEV2Qix5REFBV0EsQ0FBQzhNLG1CQUFtQixFQUMvQjtnQkFBRUo7WUFBTztZQUdiRyxhQUFhN0osU0FBUzZKLFVBQVU7WUFFaEMsTUFBTUUsb0JBQW9CO2dCQUN0QixNQUFNQyxrQkFBK0MsTUFBTSxJQUFJLENBQUN6TCxXQUFXLENBQ3ZFdkIseURBQVdBLENBQUM4TSxtQkFBbUIsRUFDL0I7b0JBQUVKO2dCQUFPO2dCQUdiRyxhQUFhRyxnQkFBZ0JILFVBQVU7WUFDM0M7WUFFQXpRLG9FQUFlLENBQUNpRSxTQUFTLENBQUNDLFdBQVcsQ0FBQyxDQUFDdEQ7Z0JBQ25DLElBQUksQ0FBQ2lELHFFQUFtQkEsQ0FBQ2pELFVBQVU7b0JBQy9CdUMsa0RBQU1BLENBQUNnRCxLQUFLLENBQUMseUVBQXlFdkY7b0JBQ3RGLE9BQU9pUTtnQkFDWDtnQkFFQSxJQUFJalEsUUFBUXdELElBQUksS0FBS1IseURBQVdBLENBQUNrTixlQUFlLEVBQUU7b0JBQzlDLElBQUksQ0FBQ2hOLDZFQUEyQkEsQ0FBQ2xELFVBQVU7d0JBQ3ZDdUMsa0RBQU1BLENBQUNnRCxLQUFLLENBQUMsd0VBQXdFdkY7d0JBQ3JGLE9BQU9pUTtvQkFDWDtvQkFFQSxNQUFNRSxnQkFBZ0JuUTtvQkFFdEIsTUFBTSxDQUFDd0QsTUFBTSxHQUFHdUMsS0FBSyxHQUFHb0ssY0FBY3BLLElBQUk7b0JBRTFDLElBQUkySixPQUFPVSxRQUFRLENBQUM1TSxPQUFPO3dCQUN2Qm1NLFNBQVM7NEJBQUVuTTs0QkFBTXVDO3dCQUFLO29CQUMxQjtnQkFDSjtnQkFDQSxJQUFJL0YsUUFBUXdELElBQUksS0FBS1IseURBQVdBLENBQUNrRCxlQUFlLEVBQUU7b0JBQzlDNko7Z0JBQ0o7WUFDSjtZQUVBLE1BQU1NLFdBQVc7Z0JBQ2IsSUFBSSxDQUFDUixZQUFZO29CQUNiO2dCQUNKO2dCQUVBLElBQUksQ0FBQ3RMLFdBQVcsQ0FDWnZCLHlEQUFXQSxDQUFDc04sY0FBYyxFQUMxQjtvQkFBRVQ7Z0JBQVc7Z0JBR2pCQSxhQUFhO2dCQUViLElBQUksT0FBT0QscUJBQXFCLFlBQVk7b0JBQ3hDQTtnQkFDSjtZQUNKO1lBRUFwSyxPQUFPaEcsZ0JBQWdCLENBQUMsZ0JBQWdCNlE7WUFDeEM3SyxPQUFPaEcsZ0JBQWdCLENBQUMsVUFBVTZRO1lBRWxDLE9BQU9BO1FBQ1g7UUFqTEksSUFBSSxDQUFDM0UscUJBQXFCLEdBQUcsSUFBSSxDQUFDQSxxQkFBcUIsQ0FBQ3BILElBQUksQ0FBQyxJQUFJO1FBQ2pFLElBQUksQ0FBQ3NFLGFBQWEsR0FBRyxJQUFJLENBQUNBLGFBQWEsQ0FBQ3RFLElBQUksQ0FBQyxJQUFJO1FBQ2pELElBQUksQ0FBQzBILHFCQUFxQixHQUFHLElBQUksQ0FBQ0EscUJBQXFCLENBQUMxSCxJQUFJLENBQUMsSUFBSTtRQUNqRSxJQUFJLENBQUM2SCxrQkFBa0IsR0FBRyxJQUFJLENBQUNBLGtCQUFrQixDQUFDN0gsSUFBSSxDQUFDLElBQUk7SUFDL0Q7QUErNEJKO0FBbDNCSTs7Ozs7Ozs7S0FRQyxHQUNELGlCQWpERXdCLFdBaURLeUssNkJBQTRCLENBQy9CQyxNQUNBZCxRQUNBQztJQUVBLElBQUljO0lBQ0osSUFBSUMsb0JBQW9CO0lBRXhCLE1BQU1DLFVBQVU7UUFDWkYsT0FBT3JSLG9FQUFlLENBQUN1UixPQUFPLENBQUM7WUFBRUMsTUFBTSxHQUFHSixLQUFLLENBQUMsRUFBRTVLLDhDQUFNQSxJQUFJO1FBQUM7UUFDN0Q2SyxLQUFLSSxXQUFXLENBQUM7WUFBRXJOLE1BQU1SLHlEQUFXQSxDQUFDOE4sc0JBQXNCO1lBQUUvSyxNQUFNO2dCQUFFMko7WUFBTztRQUFFO1FBRTlFZSxLQUFLcE4sU0FBUyxDQUFDQyxXQUFXLENBQUMsQ0FBQ3REO1lBQ3hCLElBQUksQ0FBQ2lELHFFQUFtQkEsQ0FBQ2pELFVBQVU7Z0JBQy9CdUMsa0RBQU1BLENBQUNnRCxLQUFLLENBQUMsK0VBQStFdkY7Z0JBQzVGO1lBQ0o7WUFFQSxJQUFJQSxRQUFRd0QsSUFBSSxLQUFLUix5REFBV0EsQ0FBQ2tOLGVBQWUsRUFBRTtnQkFDOUMsSUFBSSxDQUFDaE4sNkVBQTJCQSxDQUFDbEQsVUFBVTtvQkFDdkN1QyxrREFBTUEsQ0FBQ2dELEtBQUssQ0FBQyx3RUFBd0V2RjtvQkFDckY7Z0JBQ0o7Z0JBRUEsTUFBTW1RLGdCQUFnQm5RO2dCQUV0QixNQUFNLENBQUN3RCxNQUFNLEdBQUd1QyxLQUFLLEdBQUdvSyxjQUFjcEssSUFBSTtnQkFDMUM0SixTQUFTO29CQUFFbk07b0JBQU11QztnQkFBSztZQUMxQjtRQUNKO1FBRUEwSyxLQUFLTSxZQUFZLENBQUN6TixXQUFXLENBQUM7WUFDMUIsSUFBSWxFLHNFQUFlLENBQUM0UixTQUFTLEVBQUU7Z0JBQzNCek8sa0RBQU1BLENBQUNnRCxLQUFLLENBQUNuRyxzRUFBZSxDQUFDNFIsU0FBUyxDQUFDaFIsT0FBTztZQUNsRDtZQUNBLGdFQUFnRTtZQUNoRSxJQUFJLENBQUMwUSxtQkFBbUI7Z0JBQ3BCQztZQUNKO1FBQ0o7SUFDSjtJQUVBQTtJQUVBLE1BQU1OLFdBQVc7UUFDYixJQUFJSSxNQUFNO1lBQ05DLG9CQUFvQjtZQUNwQkQsS0FBS1EsVUFBVTtRQUNuQjtJQUNKO0lBRUF6TCxPQUFPaEcsZ0JBQWdCLENBQUMsZ0JBQWdCNlE7SUFDeEM3SyxPQUFPaEcsZ0JBQWdCLENBQUMsVUFBVTZRO0lBRWxDLE9BQU9BO0FBQ1g7QUFvekJKLE1BQU14TCxZQUFZLElBQUlpQjtBQUVVOzs7Ozs7Ozs7Ozs7QUNoZ0NuQjtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxrQkFBa0IsbUJBQU8sQ0FBQyx1SEFBNEI7O0FBRXREOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2IsMEJBQTBCLG1CQUFPLENBQUMsdUlBQW9DOztBQUV0RTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiLHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQztBQUM5RCxhQUFhLG1CQUFPLENBQUMsdUhBQTRCO0FBQ2pELHFCQUFxQixrS0FBZ0Q7O0FBRXJFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNwQmE7QUFDYixlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2Isc0JBQXNCLG1CQUFPLENBQUMsK0hBQWdDO0FBQzlELHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQztBQUM5RCx3QkFBd0IsbUJBQU8sQ0FBQyxxSUFBbUM7O0FBRW5FLHNCQUFzQixtQkFBbUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sV0FBVyxnQkFBZ0I7QUFDakM7QUFDQSxNQUFNO0FBQ047QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNqQ2E7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyx1SUFBb0M7O0FBRTlELDZCQUE2QjtBQUM3Qjs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1JhO0FBQ2IsNEJBQTRCLG1CQUFPLENBQUMsdUlBQW9DO0FBQ3hFLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsc0JBQXNCLG1CQUFPLENBQUMsK0hBQWdDOztBQUU5RDtBQUNBOztBQUVBO0FBQ0EsaURBQWlELG1CQUFtQjs7QUFFcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUM3QmE7QUFDYixhQUFhLG1CQUFPLENBQUMsNkhBQStCO0FBQ3BELGNBQWMsbUJBQU8sQ0FBQyw2R0FBdUI7QUFDN0MscUNBQXFDLG1CQUFPLENBQUMsaUtBQWlEO0FBQzlGLDJCQUEyQixtQkFBTyxDQUFDLHlJQUFxQzs7QUFFeEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsaUJBQWlCO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDaEJhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELDJCQUEyQixtQkFBTyxDQUFDLHlJQUFxQztBQUN4RSwrQkFBK0IsbUJBQU8sQ0FBQyxpSkFBeUM7O0FBRWhGO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1JhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUhBQTRCO0FBQ3RELHFCQUFxQixtQkFBTyxDQUFDLHlJQUFxQzs7QUFFbEU7QUFDQSwwREFBMEQsY0FBYztBQUN4RSwwREFBMEQsY0FBYztBQUN4RTtBQUNBOzs7Ozs7Ozs7Ozs7QUNSYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCwyQkFBMkIsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDeEUsa0JBQWtCLG1CQUFPLENBQUMsdUhBQTRCO0FBQ3RELDJCQUEyQixtQkFBTyxDQUFDLHlJQUFxQzs7QUFFeEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxNQUFNLGdCQUFnQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsSUFBSTtBQUNKOzs7Ozs7Ozs7Ozs7QUMzQmE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHNDQUFzQyxrREFBa0Q7QUFDeEYsSUFBSTtBQUNKO0FBQ0EsSUFBSTtBQUNKOzs7Ozs7Ozs7Ozs7QUNaYTtBQUNiLFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7O0FBRXhDO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxPQUFPLG1CQUFtQixhQUFhO0FBQ3hFLENBQUM7Ozs7Ozs7Ozs7OztBQ1BZO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7O0FBRS9DO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNOYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxnQkFBZ0IsbUJBQU8sQ0FBQyx5SUFBcUM7O0FBRTdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDM0JhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DOztBQUU5RDtBQUNBOztBQUVBLDZCQUE2Qix1Q0FBdUM7QUFDcEU7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjs7Ozs7Ozs7Ozs7O0FDZmE7QUFDYixrQ0FBa0MsbUJBQU8sQ0FBQyx5SkFBNkM7QUFDdkYsc0JBQXNCLG1CQUFPLENBQUMsK0hBQWdDO0FBQzlELDhCQUE4QixtQkFBTyxDQUFDLDJJQUFzQzs7QUFFNUU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2JhO0FBQ2IsWUFBWSxtQkFBTyxDQUFDLHVHQUFvQjtBQUN4QywrQkFBK0IsbUJBQU8sQ0FBQyxpSkFBeUM7O0FBRWhGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7OztBQ1ZZO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELCtCQUErQiwwTEFBNEQ7QUFDM0Ysa0NBQWtDLG1CQUFPLENBQUMseUpBQTZDO0FBQ3ZGLG9CQUFvQixtQkFBTyxDQUFDLDJIQUE4QjtBQUMxRCwyQkFBMkIsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDeEUsZ0NBQWdDLG1CQUFPLENBQUMsbUpBQTBDO0FBQ2xGLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7O0FBRS9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLGtFQUFrRTtBQUNsRSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3REYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1BhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMscUlBQW1DOztBQUU3RDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7O0FDVlk7QUFDYixZQUFZLG1CQUFPLENBQUMsdUdBQW9COztBQUV4QztBQUNBO0FBQ0EsNEJBQTRCLGFBQWE7QUFDekM7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7OztBQ1JZO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMscUlBQW1DOztBQUU3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNQYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxhQUFhLG1CQUFPLENBQUMsNkhBQStCOztBQUVwRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLCtDQUErQyxhQUFhO0FBQzVEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2pCYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQztBQUM5RCxnQkFBZ0IsbUJBQU8sQ0FBQyxpSEFBeUI7O0FBRWpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEI7Ozs7Ozs7Ozs7OztBQ1RhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMscUlBQW1DOztBQUU3RDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNaYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2IsZ0JBQWdCLG1CQUFPLENBQUMsaUhBQXlCO0FBQ2pELHdCQUF3QixtQkFBTyxDQUFDLHFJQUFtQzs7QUFFbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUscUJBQU0sZ0JBQWdCLHFCQUFNO0FBQzNDO0FBQ0E7QUFDQSxpQkFBaUIsY0FBYzs7Ozs7Ozs7Ozs7O0FDZmxCO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DO0FBQzlELGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7O0FBRS9DLG1DQUFtQzs7QUFFbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNYYTtBQUNiOzs7Ozs7Ozs7Ozs7QUNEYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLHFIQUEyQjs7QUFFcEQ7Ozs7Ozs7Ozs7OztBQ0hhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7QUFDeEMsb0JBQW9CLG1CQUFPLENBQUMsMklBQXNDOztBQUVsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QixHQUFHO0FBQ0gsQ0FBQzs7Ozs7Ozs7Ozs7O0FDWFk7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyx1SUFBb0M7QUFDOUQsWUFBWSxtQkFBTyxDQUFDLHVHQUFvQjtBQUN4QyxjQUFjLG1CQUFPLENBQUMsbUhBQTBCOztBQUVoRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQSxFQUFFOzs7Ozs7Ozs7Ozs7QUNmVztBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxlQUFlLG1CQUFPLENBQUMsK0dBQXdCO0FBQy9DLHFCQUFxQixtQkFBTyxDQUFDLDJJQUFzQzs7QUFFbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDbEJhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DO0FBQzlELGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxZQUFZLG1CQUFPLENBQUMscUhBQTJCOztBQUUvQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ2RhO0FBQ2IsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyxrQ0FBa0MsbUJBQU8sQ0FBQyx5SkFBNkM7O0FBRXZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLHNCQUFzQixtQkFBTyxDQUFDLDZJQUF1QztBQUNyRSxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyxrQ0FBa0MsbUJBQU8sQ0FBQyx5SkFBNkM7QUFDdkYsYUFBYSxtQkFBTyxDQUFDLDZIQUErQjtBQUNwRCxhQUFhLG1CQUFPLENBQUMscUhBQTJCO0FBQ2hELGdCQUFnQixtQkFBTyxDQUFDLGlIQUF5QjtBQUNqRCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsdUNBQXVDO0FBQ3ZDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3RFYTtBQUNiO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBOzs7Ozs7Ozs7Ozs7QUNYYTtBQUNiLFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7QUFDeEMsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUN0QmE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNMYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjs7QUFFbkQ7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNMYTtBQUNiLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7O0FBRS9DO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDTGE7QUFDYjs7Ozs7Ozs7Ozs7O0FDRGE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxxSEFBMkI7QUFDcEQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELG9CQUFvQixtQkFBTyxDQUFDLHlJQUFxQztBQUNqRSx3QkFBd0IsbUJBQU8sQ0FBQywrSEFBZ0M7O0FBRWhFOztBQUVBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNiYTtBQUNiLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7O0FBRS9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1BhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DO0FBQzlELFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7QUFDeEMsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELGFBQWEsbUJBQU8sQ0FBQyw2SEFBK0I7QUFDcEQsa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELGlDQUFpQywySkFBa0Q7QUFDbkYsb0JBQW9CLG1CQUFPLENBQUMseUhBQTZCO0FBQ3pELDBCQUEwQixtQkFBTyxDQUFDLHlIQUE2Qjs7QUFFL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHNDQUFzQyxhQUFhLGNBQWMsVUFBVTtBQUMzRSxDQUFDOztBQUVEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscURBQXFELGlDQUFpQztBQUN0RjtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0Msc0JBQXNCO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLDREQUE0RCxpQkFBaUI7QUFDN0U7QUFDQSxNQUFNO0FBQ04sSUFBSSxnQkFBZ0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7O0FDdERZO0FBQ2I7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVmE7QUFDYixlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ0xhO0FBQ2I7QUFDQSxlQUFlLG1CQUFPLENBQUMsK0dBQXdCO0FBQy9DLDZCQUE2QixtQkFBTyxDQUFDLDZJQUF1QztBQUM1RSxrQkFBa0IsbUJBQU8sQ0FBQyx1SEFBNEI7QUFDdEQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELFdBQVcsbUJBQU8sQ0FBQyxxR0FBbUI7QUFDdEMsNEJBQTRCLG1CQUFPLENBQUMsMklBQXNDO0FBQzFFLGdCQUFnQixtQkFBTyxDQUFDLGlIQUF5Qjs7QUFFakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxxQ0FBcUM7O0FBRXJDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0Q7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBOzs7Ozs7Ozs7Ozs7QUNwRmE7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDcEQsOEJBQThCLG1CQUFPLENBQUMsMklBQXNDO0FBQzVFLDJCQUEyQixtQkFBTyxDQUFDLHlJQUFxQztBQUN4RSxlQUFlLG1CQUFPLENBQUMsK0dBQXdCO0FBQy9DLHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQztBQUM5RCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3BCYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxxQkFBcUIsbUJBQU8sQ0FBQyx5SEFBNkI7QUFDMUQsOEJBQThCLG1CQUFPLENBQUMsMklBQXNDO0FBQzVFLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7QUFDL0Msb0JBQW9CLG1CQUFPLENBQUMsMkhBQThCOztBQUUxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDM0NhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELFdBQVcsbUJBQU8sQ0FBQyx1SEFBNEI7QUFDL0MsaUNBQWlDLG1CQUFPLENBQUMsdUpBQTRDO0FBQ3JGLCtCQUErQixtQkFBTyxDQUFDLGlKQUF5QztBQUNoRixzQkFBc0IsbUJBQU8sQ0FBQywrSEFBZ0M7QUFDOUQsb0JBQW9CLG1CQUFPLENBQUMsMkhBQThCO0FBQzFELGFBQWEsbUJBQU8sQ0FBQyw2SEFBK0I7QUFDcEQscUJBQXFCLG1CQUFPLENBQUMseUhBQTZCOztBQUUxRDtBQUNBOztBQUVBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQjtBQUNBOzs7Ozs7Ozs7Ozs7QUN0QmE7QUFDYix5QkFBeUIsbUJBQU8sQ0FBQyxxSUFBbUM7QUFDcEUsa0JBQWtCLG1CQUFPLENBQUMsdUhBQTRCOztBQUV0RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7Ozs7Ozs7Ozs7O0FDWGE7QUFDYjtBQUNBLFNBQVM7Ozs7Ozs7Ozs7OztBQ0ZJO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DOztBQUU5RCwrQkFBK0I7Ozs7Ozs7Ozs7OztBQ0hsQjtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQztBQUM5RCxhQUFhLG1CQUFPLENBQUMsNkhBQStCO0FBQ3BELHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQztBQUM5RCxjQUFjLHdKQUE4QztBQUM1RCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDcEJhO0FBQ2IseUJBQXlCLG1CQUFPLENBQUMscUlBQW1DO0FBQ3BFLGtCQUFrQixtQkFBTyxDQUFDLHVIQUE0Qjs7QUFFdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiLDhCQUE4QjtBQUM5QjtBQUNBOztBQUVBO0FBQ0EsNEVBQTRFLE1BQU07O0FBRWxGO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEVBQUU7Ozs7Ozs7Ozs7OztBQ2JXO0FBQ2I7QUFDQSwwQkFBMEIsbUJBQU8sQ0FBQyx5SkFBNkM7QUFDL0UsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyw2QkFBNkIsbUJBQU8sQ0FBQyw2SUFBdUM7QUFDNUUseUJBQXlCLG1CQUFPLENBQUMscUlBQW1DOztBQUVwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RDtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0JBQWdCO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7QUM1Qlk7QUFDYixXQUFXLG1CQUFPLENBQUMsdUhBQTRCO0FBQy9DLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2ZhO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMscUhBQTJCO0FBQ3BELGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQztBQUM5RCxnQ0FBZ0MsbUJBQU8sQ0FBQyx1SkFBNEM7QUFDcEYsa0NBQWtDLG1CQUFPLENBQUMsMkpBQThDO0FBQ3hGLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7O0FBRS9DOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDZGE7QUFDYixxQkFBcUIsa0tBQWdEOztBQUVyRTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIscUJBQXFCO0FBQzVDLHlCQUF5QjtBQUN6QixHQUFHO0FBQ0g7Ozs7Ozs7Ozs7OztBQ1RhO0FBQ2Isd0JBQXdCLG1CQUFPLENBQUMscUlBQW1DOztBQUVuRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2IsYUFBYSxtQkFBTyxDQUFDLHlHQUFxQjtBQUMxQyxVQUFVLG1CQUFPLENBQUMsbUdBQWtCOztBQUVwQzs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1JhO0FBQ2IsY0FBYyxtQkFBTyxDQUFDLDJHQUFzQjtBQUM1QyxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsMkJBQTJCLG1CQUFPLENBQUMseUlBQXFDOztBQUV4RTtBQUNBLGtGQUFrRjs7QUFFbEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7O0FDZFk7QUFDYixZQUFZLG1CQUFPLENBQUMscUhBQTJCOztBQUUvQztBQUNBLGdEQUFnRDtBQUNoRDs7Ozs7Ozs7Ozs7O0FDTGE7QUFDYjtBQUNBLGlCQUFpQixtQkFBTyxDQUFDLHlJQUFxQztBQUM5RCxZQUFZLG1CQUFPLENBQUMsdUdBQW9CO0FBQ3hDLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjs7QUFFbkQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7QUNsQlk7QUFDYiwwQkFBMEIsbUJBQU8sQ0FBQyx5SUFBcUM7O0FBRXZFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDZEQUE2RDtBQUM3RDtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDWmE7QUFDYjtBQUNBLG9CQUFvQixtQkFBTyxDQUFDLHlIQUE2QjtBQUN6RCw2QkFBNkIsbUJBQU8sQ0FBQyw2SUFBdUM7O0FBRTVFO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDUGE7QUFDYixZQUFZLG1CQUFPLENBQUMsaUhBQXlCOztBQUU3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVGE7QUFDYiwwQkFBMEIsbUJBQU8sQ0FBQyx5SUFBcUM7O0FBRXZFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1EO0FBQ25EOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLDZCQUE2QixtQkFBTyxDQUFDLDZJQUF1Qzs7QUFFNUU7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVGE7QUFDYixXQUFXLG1CQUFPLENBQUMsdUhBQTRCO0FBQy9DLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7QUFDL0MsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyxnQkFBZ0IsbUJBQU8sQ0FBQyxpSEFBeUI7QUFDakQsMEJBQTBCLG1CQUFPLENBQUMsdUlBQW9DO0FBQ3RFLHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQzs7QUFFOUQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3pCYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHFIQUEyQjtBQUNyRCxlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1RhO0FBQ2Isc0JBQXNCLG1CQUFPLENBQUMsK0hBQWdDOztBQUU5RDtBQUNBOztBQUVBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNSYTtBQUNiLGNBQWMsbUJBQU8sQ0FBQywyR0FBc0I7O0FBRTVDOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNSYTtBQUNiOztBQUVBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1RhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DOztBQUU5RDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiO0FBQ0Esb0JBQW9CLG1CQUFPLENBQUMscUpBQTJDOztBQUV2RTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ05hO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7O0FBRXhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLGFBQWE7QUFDMUQ7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDOzs7Ozs7Ozs7Ozs7QUNaWTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EOztBQUVBOzs7Ozs7Ozs7Ozs7QUNOYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxhQUFhLG1CQUFPLENBQUMseUdBQXFCO0FBQzFDLGFBQWEsbUJBQU8sQ0FBQyw2SEFBK0I7QUFDcEQsVUFBVSxtQkFBTyxDQUFDLG1HQUFrQjtBQUNwQyxvQkFBb0IsbUJBQU8sQ0FBQyxxSkFBMkM7QUFDdkUsd0JBQXdCLG1CQUFPLENBQUMsK0hBQWdDOztBQUVoRTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjs7Ozs7Ozs7Ozs7O0FDbEJhO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMscUhBQTJCO0FBQ3BELGFBQWEsbUJBQU8sQ0FBQyw2SEFBK0I7QUFDcEQsa0NBQWtDLG1CQUFPLENBQUMseUpBQTZDO0FBQ3ZGLG9CQUFvQixtQkFBTyxDQUFDLHlJQUFxQztBQUNqRSxxQkFBcUIsbUJBQU8sQ0FBQywySUFBc0M7QUFDbkUsZ0NBQWdDLG1CQUFPLENBQUMsbUpBQTBDO0FBQ2xGLG9CQUFvQixtQkFBTyxDQUFDLHlIQUE2QjtBQUN6RCx3QkFBd0IsbUJBQU8sQ0FBQyxtSUFBa0M7QUFDbEUsOEJBQThCLG1CQUFPLENBQUMsK0lBQXdDO0FBQzlFLHdCQUF3QixtQkFBTyxDQUFDLG1JQUFrQztBQUNsRSx3QkFBd0IsbUJBQU8sQ0FBQyxtSUFBa0M7QUFDbEUsa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELGNBQWMsbUJBQU8sQ0FBQywyR0FBc0I7O0FBRTVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIOztBQUVBO0FBQ0E7QUFDQSw4REFBOEQsWUFBWTtBQUMxRSxJQUFJO0FBQ0o7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0JBQWdCOztBQUVwQjtBQUNBOzs7Ozs7Ozs7Ozs7QUNoRWE7QUFDYixRQUFRLG1CQUFPLENBQUMseUdBQXFCO0FBQ3JDLGdCQUFnQix5SkFBK0M7QUFDL0QsWUFBWSxtQkFBTyxDQUFDLHVHQUFvQjtBQUN4Qyx1QkFBdUIsbUJBQU8sQ0FBQyxpSUFBaUM7O0FBRWhFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsSUFBSSx3REFBd0Q7QUFDNUQ7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBOzs7Ozs7Ozs7Ozs7QUNyQmE7QUFDYjtBQUNBLFFBQVEsbUJBQU8sQ0FBQyx5R0FBcUI7QUFDckMsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELFlBQVksbUJBQU8sQ0FBQyx5SEFBNkI7QUFDakQsb0NBQW9DLG1CQUFPLENBQUMsK0pBQWdEOztBQUU1RjtBQUNBOztBQUVBO0FBQ0EsOEJBQThCLFVBQVU7O0FBRXhDO0FBQ0E7QUFDQTtBQUNBLE1BQU0sMkRBQTJEO0FBQ2pFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSwrRUFBK0U7QUFDdkY7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DLENBQUM7QUFDRDtBQUNBLHVDQUF1QztBQUN2QyxDQUFDO0FBQ0Q7QUFDQSx3Q0FBd0M7QUFDeEMsQ0FBQztBQUNEO0FBQ0EsNENBQTRDO0FBQzVDLENBQUM7QUFDRDtBQUNBLHlDQUF5QztBQUN6QyxDQUFDO0FBQ0Q7QUFDQSx1Q0FBdUM7QUFDdkMsQ0FBQztBQUNEO0FBQ0Esc0NBQXNDO0FBQ3RDLENBQUM7QUFDRDtBQUNBLDBDQUEwQztBQUMxQyxDQUFDO0FBQ0Q7QUFDQSx1Q0FBdUM7QUFDdkMsQ0FBQztBQUNEO0FBQ0EsMENBQTBDO0FBQzFDLENBQUM7Ozs7Ozs7Ozs7OztBQ3pEWTtBQUNiLFFBQVEsbUJBQU8sQ0FBQyx5R0FBcUI7QUFDckMsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELDRCQUE0QixtQkFBTyxDQUFDLDZJQUF1QztBQUMzRSxrQkFBa0IsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRXBEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWCxTQUFTO0FBQ1Q7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLElBQUksU0FBUyxxREFBcUQ7QUFDbEU7QUFDQSxHQUFHO0FBQ0gsRUFBRSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4Q2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxhQUFhO0FBQ3hCLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRDtBQUNyRCxjQUFjLEtBQUssR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxPQUFPLEdBQUcsT0FBTyxHQUFHLFlBQVk7QUFDOUU7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLDRCQUE0QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsSUFBSTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBFQUEwRSxxQ0FBcUM7QUFDL0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLFFBQVEsa0JBQWtCLFlBQVk7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsaUNBQWlDLHVCQUF1QjtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRTRCOzs7Ozs7Ozs7Ozs7Ozs7O0FDalB5QjtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0EsTUFBTTtBQUNOO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDaUU7Ozs7Ozs7VUNqQ3BFO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7O1dDdEJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSxHQUFHO1dBQ0g7V0FDQTtXQUNBLENBQUM7Ozs7O1dDUEQ7Ozs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUM0QztBQUNjO0FBRTNEekcsa0RBQUlBLENBQUNDLElBQUk7QUFDVHdGLGdFQUFXQSxDQUFDeEYsSUFBSSIsInNvdXJjZXMiOlsid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL25hbm9iYXJAMC40LjIvbm9kZV9tb2R1bGVzL25hbm9iYXIvbmFub2Jhci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS93ZWJleHRlbnNpb24tcG9seWZpbGxAMC4xMi4wL25vZGVfbW9kdWxlcy93ZWJleHRlbnNpb24tcG9seWZpbGwvZGlzdC9icm93c2VyLXBvbHlmaWxsLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vRXh0ZW5zaW9uL3NyYy9jb21tb24vaTE4bi50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvY29tbW9uL2xvZ2dlci50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvY29tbW9uL21lc3NhZ2VzL2NvbnN0YW50cy50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvY29tbW9uL21lc3NhZ2VzL2luZGV4LnRzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vRXh0ZW5zaW9uL3NyYy9jb21tb24vbWVzc2FnZXMvbWVzc2FnZS1oYW5kbGVyLnRzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vRXh0ZW5zaW9uL3NyYy9jb21tb24vbWVzc2FnZXMvc2VuZC1tZXNzYWdlLnRzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vRXh0ZW5zaW9uL3NyYy9wYWdlcy9wb3N0LWluc3RhbGwudHMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vc3JjL3BhZ2VzL3NlcnZpY2VzL21lc3Nlbmdlci50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvYS1jYWxsYWJsZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvYS1wb3NzaWJsZS1wcm90b3R5cGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2FkZC10by11bnNjb3BhYmxlcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvYW4tb2JqZWN0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9hcnJheS1pbmNsdWRlcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvY2xhc3NvZi1yYXcuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2NsYXNzb2YuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2NvcHktY29uc3RydWN0b3ItcHJvcGVydGllcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvY3JlYXRlLW5vbi1lbnVtZXJhYmxlLXByb3BlcnR5LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9jcmVhdGUtcHJvcGVydHktZGVzY3JpcHRvci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZGVmaW5lLWJ1aWx0LWluLWFjY2Vzc29yLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9kZWZpbmUtYnVpbHQtaW4uanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHkuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Rlc2NyaXB0b3JzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9kb2N1bWVudC1jcmVhdGUtZWxlbWVudC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZW51bS1idWcta2V5cy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZW52aXJvbm1lbnQtdXNlci1hZ2VudC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZW52aXJvbm1lbnQtdjgtdmVyc2lvbi5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZXJyb3Itc3RhY2stY2xlYXIuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Vycm9yLXN0YWNrLWluc3RhbGwuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Vycm9yLXN0YWNrLWluc3RhbGxhYmxlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9leHBvcnQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2ZhaWxzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9mdW5jdGlvbi1hcHBseS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZnVuY3Rpb24tYmluZC1uYXRpdmUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Z1bmN0aW9uLWNhbGwuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Z1bmN0aW9uLW5hbWUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcy1hY2Nlc3Nvci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9nZXQtYnVpbHQtaW4uanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2dldC1tZXRob2QuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2dsb2JhbC10aGlzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9oaWRkZW4ta2V5cy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaHRtbC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaWU4LWRvbS1kZWZpbmUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2luZGV4ZWQtb2JqZWN0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pbmhlcml0LWlmLXJlcXVpcmVkLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pbnNwZWN0LXNvdXJjZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaW5zdGFsbC1lcnJvci1jYXVzZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaW50ZXJuYWwtc3RhdGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2lzLWNhbGxhYmxlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pcy1mb3JjZWQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2lzLW51bGwtb3ItdW5kZWZpbmVkLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pcy1vYmplY3QuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2lzLXBvc3NpYmxlLXByb3RvdHlwZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaXMtcHVyZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaXMtc3ltYm9sLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9sZW5ndGgtb2YtYXJyYXktbGlrZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvbWFrZS1idWlsdC1pbi5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvbWF0aC10cnVuYy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvbm9ybWFsaXplLXN0cmluZy1hcmd1bWVudC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWNyZWF0ZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0aWVzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1kZXNjcmlwdG9yLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1uYW1lcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWdldC1vd24tcHJvcGVydHktc3ltYm9scy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWlzLXByb3RvdHlwZS1vZi5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWtleXMtaW50ZXJuYWwuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1rZXlzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9vYmplY3QtcHJvcGVydHktaXMtZW51bWVyYWJsZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LXNldC1wcm90b3R5cGUtb2YuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29yZGluYXJ5LXRvLXByaW1pdGl2ZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb3duLWtleXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3Byb3h5LWFjY2Vzc29yLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9yZXF1aXJlLW9iamVjdC1jb2VyY2libGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3NoYXJlZC1rZXkuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3NoYXJlZC1zdG9yZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvc2hhcmVkLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9zeW1ib2wtY29uc3RydWN0b3ItZGV0ZWN0aW9uLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90by1hYnNvbHV0ZS1pbmRleC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdG8taW5kZXhlZC1vYmplY3QuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RvLWludGVnZXItb3ItaW5maW5pdHkuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RvLWxlbmd0aC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdG8tb2JqZWN0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90by1wcmltaXRpdmUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RvLXByb3BlcnR5LWtleS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdG8tc3RyaW5nLXRhZy1zdXBwb3J0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90by1zdHJpbmcuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RyeS10by1zdHJpbmcuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3VpZC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdXNlLXN5bWJvbC1hcy11aWQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3Y4LXByb3RvdHlwZS1kZWZpbmUtYnVnLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy93ZWFrLW1hcC1iYXNpYy1kZXRlY3Rpb24uanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy93cmFwLWVycm9yLWNvbnN0cnVjdG9yLXdpdGgtY2F1c2UuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvbW9kdWxlcy9lcy5hcnJheS5pbmNsdWRlcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9tb2R1bGVzL2VzLmVycm9yLmNhdXNlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL21vZHVsZXMvd2ViLnNlbGYuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vQGFkZ3VhcmQrbG9nZ2VyQDEuMS4xL25vZGVfbW9kdWxlcy9AYWRndWFyZC9sb2dnZXIvZGlzdC9lcy9pbmRleC5tanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vbmFub2lkQDMuMy42L25vZGVfbW9kdWxlcy9uYW5vaWQvaW5kZXguYnJvd3Nlci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2dsb2JhbCIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vRXh0ZW5zaW9uL3BhZ2VzL3Bvc3QtaW5zdGFsbC9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBodHRwOi8vbmFub2Jhci5taWNyb251YmUuY29tLyAgfHwgIGh0dHBzOi8vZ2l0aHViLmNvbS9qYWNvYm9ydXMvbmFub2Jhci8gICAgTUlUIExJQ0VOU0UgKi9cbihmdW5jdGlvbiAocm9vdCkge1xuICAndXNlIHN0cmljdCdcbiAgLy8gY29udGFpbmVyIHN0eWxlc1xuICB2YXIgY3NzID0gJy5uYW5vYmFye3dpZHRoOjEwMCU7aGVpZ2h0OjRweDt6LWluZGV4Ojk5OTk7dG9wOjB9LmJhcnt3aWR0aDowO2hlaWdodDoxMDAlO3RyYW5zaXRpb246aGVpZ2h0IC4zcztiYWNrZ3JvdW5kOiMwMDB9J1xuXG4gIC8vIGFkZCByZXF1aXJlZCBjc3MgaW4gaGVhZCBkaXZcbiAgZnVuY3Rpb24gYWRkQ3NzICgpIHtcbiAgICB2YXIgcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCduYW5vYmFyY3NzJylcblxuICAgIC8vIGNoZWNrIHdoZXRoZXIgc3R5bGUgdGFnIGlzIGFscmVhZHkgaW5zZXJ0ZWRcbiAgICBpZiAocyA9PT0gbnVsbCkge1xuICAgICAgcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJylcbiAgICAgIHMudHlwZSA9ICd0ZXh0L2NzcydcbiAgICAgIHMuaWQgPSAnbmFub2JhcmNzcydcbiAgICAgIGRvY3VtZW50LmhlYWQuaW5zZXJ0QmVmb3JlKHMsIGRvY3VtZW50LmhlYWQuZmlyc3RDaGlsZClcbiAgICAgIC8vIHRoZSB3b3JsZFxuICAgICAgaWYgKCFzLnN0eWxlU2hlZXQpIHJldHVybiBzLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNzcykpXG4gICAgICAvLyBJRVxuICAgICAgcy5zdHlsZVNoZWV0LmNzc1RleHQgPSBjc3NcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBhZGRDbGFzcyAoZWwsIGNscykge1xuICAgIGlmIChlbC5jbGFzc0xpc3QpIGVsLmNsYXNzTGlzdC5hZGQoY2xzKVxuICAgIGVsc2UgZWwuY2xhc3NOYW1lICs9ICcgJyArIGNsc1xuICB9XG5cbiAgLy8gY3JlYXRlIGEgcHJvZ3Jlc3MgYmFyXG4gIC8vIHRoaXMgd2lsbCBiZSBkZXN0cm95ZWQgYWZ0ZXIgcmVhY2hpbmcgMTAwJSBwcm9ncmVzc1xuICBmdW5jdGlvbiBjcmVhdGVCYXIgKHJtKSB7XG4gICAgLy8gY3JlYXRlIHByb2dyZXNzIGVsZW1lbnRcbiAgICB2YXIgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKSxcbiAgICAgICAgd2lkdGggPSAwLFxuICAgICAgICBoZXJlID0gMCxcbiAgICAgICAgb24gPSAwLFxuICAgICAgICBiYXIgPSB7XG4gICAgICAgICAgZWw6IGVsLFxuICAgICAgICAgIGdvOiBnb1xuICAgICAgICB9XG5cbiAgICBhZGRDbGFzcyhlbCwgJ2JhcicpXG5cbiAgICAvLyBhbmltYXRpb24gbG9vcFxuICAgIGZ1bmN0aW9uIG1vdmUgKCkge1xuICAgICAgdmFyIGRpc3QgPSB3aWR0aCAtIGhlcmVcblxuICAgICAgaWYgKGRpc3QgPCAwLjEgJiYgZGlzdCA+IC0wLjEpIHtcbiAgICAgICAgcGxhY2UoaGVyZSlcbiAgICAgICAgb24gPSAwXG4gICAgICAgIGlmICh3aWR0aCA9PT0gMTAwKSB7XG4gICAgICAgICAgZWwuc3R5bGUuaGVpZ2h0ID0gMFxuICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcm0oZWwpXG4gICAgICAgICAgfSwgMzAwKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwbGFjZSh3aWR0aCAtIGRpc3QgLyA0KVxuICAgICAgICBzZXRUaW1lb3V0KGdvLCAxNilcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBzZXQgYmFyIHdpZHRoXG4gICAgZnVuY3Rpb24gcGxhY2UgKG51bSkge1xuICAgICAgd2lkdGggPSBudW1cbiAgICAgIGVsLnN0eWxlLndpZHRoID0gd2lkdGggKyAnJSdcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBnbyAobnVtKSB7XG4gICAgICBpZiAobnVtID49IDApIHtcbiAgICAgICAgaGVyZSA9IG51bVxuICAgICAgICBpZiAoIW9uKSB7XG4gICAgICAgICAgb24gPSAxXG4gICAgICAgICAgbW92ZSgpXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAob24pIHtcbiAgICAgICAgbW92ZSgpXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBiYXJcbiAgfVxuXG4gIGZ1bmN0aW9uIE5hbm9iYXIgKG9wdHMpIHtcbiAgICBvcHRzID0gb3B0cyB8fCB7fVxuICAgIC8vIHNldCBvcHRpb25zXG4gICAgdmFyIGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JyksXG4gICAgICAgIGFwcGx5R28sXG4gICAgICAgIG5hbm9iYXIgPSB7XG4gICAgICAgICAgZWw6IGVsLFxuICAgICAgICAgIGdvOiBmdW5jdGlvbiAocCkge1xuICAgICAgICAgICAgLy8gZXhwYW5kIGJhclxuICAgICAgICAgICAgYXBwbHlHbyhwKVxuICAgICAgICAgICAgLy8gY3JlYXRlIG5ldyBiYXIgd2hlbiBwcm9ncmVzcyByZWFjaGVzIDEwMCVcbiAgICAgICAgICAgIGlmIChwID09PSAxMDApIHtcbiAgICAgICAgICAgICAgaW5pdCgpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAvLyByZW1vdmUgZWxlbWVudCBmcm9tIG5hbm9iYXIgY29udGFpbmVyXG4gICAgZnVuY3Rpb24gcm0gKGNoaWxkKSB7XG4gICAgICBlbC5yZW1vdmVDaGlsZChjaGlsZClcbiAgICB9XG5cbiAgICAvLyBjcmVhdGUgYW5kIGluc2VydCBwcm9ncmVzcyB2YXIgaW4gbmFub2JhciBjb250YWluZXJcbiAgICBmdW5jdGlvbiBpbml0ICgpIHtcbiAgICAgIHZhciBiYXIgPSBjcmVhdGVCYXIocm0pXG4gICAgICBlbC5hcHBlbmRDaGlsZChiYXIuZWwpXG4gICAgICBhcHBseUdvID0gYmFyLmdvXG4gICAgfVxuXG4gICAgYWRkQ3NzKClcblxuICAgIGFkZENsYXNzKGVsLCAnbmFub2JhcicpXG4gICAgaWYgKG9wdHMuaWQpIGVsLmlkID0gb3B0cy5pZFxuICAgIGlmIChvcHRzLmNsYXNzbmFtZSkgYWRkQ2xhc3MoZWwsIG9wdHMuY2xhc3NuYW1lKVxuXG4gICAgLy8gaW5zZXJ0IGNvbnRhaW5lclxuICAgIGlmIChvcHRzLnRhcmdldCkge1xuICAgICAgLy8gaW5zaWRlIGEgZGl2XG4gICAgICBlbC5zdHlsZS5wb3NpdGlvbiA9ICdyZWxhdGl2ZSdcbiAgICAgIG9wdHMudGFyZ2V0Lmluc2VydEJlZm9yZShlbCwgb3B0cy50YXJnZXQuZmlyc3RDaGlsZClcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gb24gdG9wIG9mIHRoZSBwYWdlXG4gICAgICBlbC5zdHlsZS5wb3NpdGlvbiA9ICdmaXhlZCdcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdib2R5JylbMF0uYXBwZW5kQ2hpbGQoZWwpXG4gICAgfVxuXG4gICAgaW5pdCgpXG4gICAgcmV0dXJuIG5hbm9iYXJcbiAgfVxuXG4gIGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gJ29iamVjdCcpIHtcbiAgICAvLyBDb21tb25KU1xuICAgIG1vZHVsZS5leHBvcnRzID0gTmFub2JhclxuICB9IGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09ICdmdW5jdGlvbicgJiYgZGVmaW5lLmFtZCkge1xuICAgIC8vIEFNRC4gUmVnaXN0ZXIgYXMgYW4gYW5vbnltb3VzIG1vZHVsZS5cbiAgICBkZWZpbmUoW10sIGZ1bmN0aW9uICgpIHsgcmV0dXJuIE5hbm9iYXIgfSlcbiAgfSBlbHNlIHtcbiAgICAvLyBCcm93c2VyIGdsb2JhbHNcbiAgICByb290Lk5hbm9iYXIgPSBOYW5vYmFyXG4gIH1cbn0odGhpcykpXG4iLCIoZnVuY3Rpb24gKGdsb2JhbCwgZmFjdG9yeSkge1xuICBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcbiAgICBkZWZpbmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIiwgW1wibW9kdWxlXCJdLCBmYWN0b3J5KTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgZXhwb3J0cyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGZhY3RvcnkobW9kdWxlKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgbW9kID0ge1xuICAgICAgZXhwb3J0czoge31cbiAgICB9O1xuICAgIGZhY3RvcnkobW9kKTtcbiAgICBnbG9iYWwuYnJvd3NlciA9IG1vZC5leHBvcnRzO1xuICB9XG59KSh0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbFRoaXMgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0aGlzLCBmdW5jdGlvbiAobW9kdWxlKSB7XG4gIC8qIHdlYmV4dGVuc2lvbi1wb2x5ZmlsbCAtIHYwLjEyLjAgLSBUdWUgTWF5IDE0IDIwMjQgMTg6MDE6MjkgKi9cbiAgLyogLSotIE1vZGU6IGluZGVudC10YWJzLW1vZGU6IG5pbDsganMtaW5kZW50LWxldmVsOiAyIC0qLSAqL1xuICAvKiB2aW06IHNldCBzdHM9MiBzdz0yIGV0IHR3PTgwOiAqL1xuICAvKiBUaGlzIFNvdXJjZSBDb2RlIEZvcm0gaXMgc3ViamVjdCB0byB0aGUgdGVybXMgb2YgdGhlIE1vemlsbGEgUHVibGljXG4gICAqIExpY2Vuc2UsIHYuIDIuMC4gSWYgYSBjb3B5IG9mIHRoZSBNUEwgd2FzIG5vdCBkaXN0cmlidXRlZCB3aXRoIHRoaXNcbiAgICogZmlsZSwgWW91IGNhbiBvYnRhaW4gb25lIGF0IGh0dHA6Ly9tb3ppbGxhLm9yZy9NUEwvMi4wLy4gKi9cbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgaWYgKCEoZ2xvYmFsVGhpcy5jaHJvbWUgJiYgZ2xvYmFsVGhpcy5jaHJvbWUucnVudGltZSAmJiBnbG9iYWxUaGlzLmNocm9tZS5ydW50aW1lLmlkKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIlRoaXMgc2NyaXB0IHNob3VsZCBvbmx5IGJlIGxvYWRlZCBpbiBhIGJyb3dzZXIgZXh0ZW5zaW9uLlwiKTtcbiAgfVxuICBpZiAoIShnbG9iYWxUaGlzLmJyb3dzZXIgJiYgZ2xvYmFsVGhpcy5icm93c2VyLnJ1bnRpbWUgJiYgZ2xvYmFsVGhpcy5icm93c2VyLnJ1bnRpbWUuaWQpKSB7XG4gICAgY29uc3QgQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFID0gXCJUaGUgbWVzc2FnZSBwb3J0IGNsb3NlZCBiZWZvcmUgYSByZXNwb25zZSB3YXMgcmVjZWl2ZWQuXCI7XG5cbiAgICAvLyBXcmFwcGluZyB0aGUgYnVsayBvZiB0aGlzIHBvbHlmaWxsIGluIGEgb25lLXRpbWUtdXNlIGZ1bmN0aW9uIGlzIGEgbWlub3JcbiAgICAvLyBvcHRpbWl6YXRpb24gZm9yIEZpcmVmb3guIFNpbmNlIFNwaWRlcm1vbmtleSBkb2VzIG5vdCBmdWxseSBwYXJzZSB0aGVcbiAgICAvLyBjb250ZW50cyBvZiBhIGZ1bmN0aW9uIHVudGlsIHRoZSBmaXJzdCB0aW1lIGl0J3MgY2FsbGVkLCBhbmQgc2luY2UgaXQgd2lsbFxuICAgIC8vIG5ldmVyIGFjdHVhbGx5IG5lZWQgdG8gYmUgY2FsbGVkLCB0aGlzIGFsbG93cyB0aGUgcG9seWZpbGwgdG8gYmUgaW5jbHVkZWRcbiAgICAvLyBpbiBGaXJlZm94IG5lYXJseSBmb3IgZnJlZS5cbiAgICBjb25zdCB3cmFwQVBJcyA9IGV4dGVuc2lvbkFQSXMgPT4ge1xuICAgICAgLy8gTk9URTogYXBpTWV0YWRhdGEgaXMgYXNzb2NpYXRlZCB0byB0aGUgY29udGVudCBvZiB0aGUgYXBpLW1ldGFkYXRhLmpzb24gZmlsZVxuICAgICAgLy8gYXQgYnVpbGQgdGltZSBieSByZXBsYWNpbmcgdGhlIGZvbGxvd2luZyBcImluY2x1ZGVcIiB3aXRoIHRoZSBjb250ZW50IG9mIHRoZVxuICAgICAgLy8gSlNPTiBmaWxlLlxuICAgICAgY29uc3QgYXBpTWV0YWRhdGEgPSB7XG4gICAgICAgIFwiYWxhcm1zXCI6IHtcbiAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY2xlYXJBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJib29rbWFya3NcIjoge1xuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Q2hpbGRyZW5cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRSZWNlbnRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRTdWJUcmVlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VHJlZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVUcmVlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiYnJvd3NlckFjdGlvblwiOiB7XG4gICAgICAgICAgXCJkaXNhYmxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZW5hYmxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3JcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCYWRnZVRleHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3BlblBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3JcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRCYWRnZVRleHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRJY29uXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0UG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRUaXRsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImJyb3dzaW5nRGF0YVwiOiB7XG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVDYWNoZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUNvb2tpZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVEb3dubG9hZHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVGb3JtRGF0YVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUhpc3RvcnlcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVMb2NhbFN0b3JhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVQYXNzd29yZHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVQbHVnaW5EYXRhXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0dGluZ3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJjb21tYW5kc1wiOiB7XG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJjb250ZXh0TWVudXNcIjoge1xuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiY29va2llc1wiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxDb29raWVTdG9yZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJkZXZ0b29sc1wiOiB7XG4gICAgICAgICAgXCJpbnNwZWN0ZWRXaW5kb3dcIjoge1xuICAgICAgICAgICAgXCJldmFsXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyLFxuICAgICAgICAgICAgICBcInNpbmdsZUNhbGxiYWNrQXJnXCI6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInBhbmVsc1wiOiB7XG4gICAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAzLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMyxcbiAgICAgICAgICAgICAgXCJzaW5nbGVDYWxsYmFja0FyZ1wiOiB0cnVlXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJlbGVtZW50c1wiOiB7XG4gICAgICAgICAgICAgIFwiY3JlYXRlU2lkZWJhclBhbmVcIjoge1xuICAgICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiZG93bmxvYWRzXCI6IHtcbiAgICAgICAgICBcImNhbmNlbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRvd25sb2FkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZXJhc2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRGaWxlSWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm9wZW5cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJwYXVzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUZpbGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXN1bWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzaG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiZXh0ZW5zaW9uXCI6IHtcbiAgICAgICAgICBcImlzQWxsb3dlZEZpbGVTY2hlbWVBY2Nlc3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJpc0FsbG93ZWRJbmNvZ25pdG9BY2Nlc3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJoaXN0b3J5XCI6IHtcbiAgICAgICAgICBcImFkZFVybFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRlbGV0ZUFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRlbGV0ZVJhbmdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlVXJsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VmlzaXRzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaTE4blwiOiB7XG4gICAgICAgICAgXCJkZXRlY3RMYW5ndWFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFjY2VwdExhbmd1YWdlc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImlkZW50aXR5XCI6IHtcbiAgICAgICAgICBcImxhdW5jaFdlYkF1dGhGbG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaWRsZVwiOiB7XG4gICAgICAgICAgXCJxdWVyeVN0YXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwibWFuYWdlbWVudFwiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRTZWxmXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0RW5hYmxlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVuaW5zdGFsbFNlbGZcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJub3RpZmljYXRpb25zXCI6IHtcbiAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UGVybWlzc2lvbkxldmVsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicGFnZUFjdGlvblwiOiB7XG4gICAgICAgICAgXCJnZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaGlkZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEljb25cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2hvd1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInBlcm1pc3Npb25zXCI6IHtcbiAgICAgICAgICBcImNvbnRhaW5zXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVxdWVzdFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInJ1bnRpbWVcIjoge1xuICAgICAgICAgIFwiZ2V0QmFja2dyb3VuZFBhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQbGF0Zm9ybUluZm9cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJvcGVuT3B0aW9uc1BhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXF1ZXN0VXBkYXRlQ2hlY2tcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZW5kTWVzc2FnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlbmROYXRpdmVNZXNzYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VW5pbnN0YWxsVVJMXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwic2Vzc2lvbnNcIjoge1xuICAgICAgICAgIFwiZ2V0RGV2aWNlc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFJlY2VudGx5Q2xvc2VkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVzdG9yZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInN0b3JhZ2VcIjoge1xuICAgICAgICAgIFwibG9jYWxcIjoge1xuICAgICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJtYW5hZ2VkXCI6IHtcbiAgICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInN5bmNcIjoge1xuICAgICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ0YWJzXCI6IHtcbiAgICAgICAgICBcImNhcHR1cmVWaXNpYmxlVGFiXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGV0ZWN0TGFuZ3VhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkaXNjYXJkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZHVwbGljYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZXhlY3V0ZVNjcmlwdFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEN1cnJlbnRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRab29tXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Wm9vbVNldHRpbmdzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ29CYWNrXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ29Gb3J3YXJkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaGlnaGxpZ2h0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaW5zZXJ0Q1NTXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwibW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInF1ZXJ5XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVsb2FkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQ1NTXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VuZE1lc3NhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogM1xuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRab29tXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0Wm9vbVNldHRpbmdzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwidG9wU2l0ZXNcIjoge1xuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwid2ViTmF2aWdhdGlvblwiOiB7XG4gICAgICAgICAgXCJnZXRBbGxGcmFtZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRGcmFtZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIndlYlJlcXVlc3RcIjoge1xuICAgICAgICAgIFwiaGFuZGxlckJlaGF2aW9yQ2hhbmdlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIndpbmRvd3NcIjoge1xuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Q3VycmVudFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldExhc3RGb2N1c2VkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBpZiAoT2JqZWN0LmtleXMoYXBpTWV0YWRhdGEpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJhcGktbWV0YWRhdGEuanNvbiBoYXMgbm90IGJlZW4gaW5jbHVkZWQgaW4gYnJvd3Nlci1wb2x5ZmlsbFwiKTtcbiAgICAgIH1cblxuICAgICAgLyoqXG4gICAgICAgKiBBIFdlYWtNYXAgc3ViY2xhc3Mgd2hpY2ggY3JlYXRlcyBhbmQgc3RvcmVzIGEgdmFsdWUgZm9yIGFueSBrZXkgd2hpY2ggZG9lc1xuICAgICAgICogbm90IGV4aXN0IHdoZW4gYWNjZXNzZWQsIGJ1dCBiZWhhdmVzIGV4YWN0bHkgYXMgYW4gb3JkaW5hcnkgV2Vha01hcFxuICAgICAgICogb3RoZXJ3aXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNyZWF0ZUl0ZW1cbiAgICAgICAqICAgICAgICBBIGZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIGluIG9yZGVyIHRvIGNyZWF0ZSB0aGUgdmFsdWUgZm9yIGFueVxuICAgICAgICogICAgICAgIGtleSB3aGljaCBkb2VzIG5vdCBleGlzdCwgdGhlIGZpcnN0IHRpbWUgaXQgaXMgYWNjZXNzZWQuIFRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uIHJlY2VpdmVzLCBhcyBpdHMgb25seSBhcmd1bWVudCwgdGhlIGtleSBiZWluZyBjcmVhdGVkLlxuICAgICAgICovXG4gICAgICBjbGFzcyBEZWZhdWx0V2Vha01hcCBleHRlbmRzIFdlYWtNYXAge1xuICAgICAgICBjb25zdHJ1Y3RvcihjcmVhdGVJdGVtLCBpdGVtcyA9IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHN1cGVyKGl0ZW1zKTtcbiAgICAgICAgICB0aGlzLmNyZWF0ZUl0ZW0gPSBjcmVhdGVJdGVtO1xuICAgICAgICB9XG4gICAgICAgIGdldChrZXkpIHtcbiAgICAgICAgICBpZiAoIXRoaXMuaGFzKGtleSkpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0KGtleSwgdGhpcy5jcmVhdGVJdGVtKGtleSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gc3VwZXIuZ2V0KGtleSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIGdpdmVuIG9iamVjdCBpcyBhbiBvYmplY3Qgd2l0aCBhIGB0aGVuYCBtZXRob2QsIGFuZCBjYW5cbiAgICAgICAqIHRoZXJlZm9yZSBiZSBhc3N1bWVkIHRvIGJlaGF2ZSBhcyBhIFByb21pc2UuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gdGVzdC5cbiAgICAgICAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHRoZSB2YWx1ZSBpcyB0aGVuYWJsZS5cbiAgICAgICAqL1xuICAgICAgY29uc3QgaXNUaGVuYWJsZSA9IHZhbHVlID0+IHtcbiAgICAgICAgcmV0dXJuIHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUudGhlbiA9PT0gXCJmdW5jdGlvblwiO1xuICAgICAgfTtcblxuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGFuZCByZXR1cm5zIGEgZnVuY3Rpb24gd2hpY2gsIHdoZW4gY2FsbGVkLCB3aWxsIHJlc29sdmUgb3IgcmVqZWN0XG4gICAgICAgKiB0aGUgZ2l2ZW4gcHJvbWlzZSBiYXNlZCBvbiBob3cgaXQgaXMgY2FsbGVkOlxuICAgICAgICpcbiAgICAgICAqIC0gSWYsIHdoZW4gY2FsbGVkLCBgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yYCBjb250YWlucyBhIG5vbi1udWxsIG9iamVjdCxcbiAgICAgICAqICAgdGhlIHByb21pc2UgaXMgcmVqZWN0ZWQgd2l0aCB0aGF0IHZhbHVlLlxuICAgICAgICogLSBJZiB0aGUgZnVuY3Rpb24gaXMgY2FsbGVkIHdpdGggZXhhY3RseSBvbmUgYXJndW1lbnQsIHRoZSBwcm9taXNlIGlzXG4gICAgICAgKiAgIHJlc29sdmVkIHRvIHRoYXQgdmFsdWUuXG4gICAgICAgKiAtIE90aGVyd2lzZSwgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgdG8gYW4gYXJyYXkgY29udGFpbmluZyBhbGwgb2YgdGhlXG4gICAgICAgKiAgIGZ1bmN0aW9uJ3MgYXJndW1lbnRzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBwcm9taXNlXG4gICAgICAgKiAgICAgICAgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIHJlc29sdXRpb24gYW5kIHJlamVjdGlvbiBmdW5jdGlvbnMgb2YgYVxuICAgICAgICogICAgICAgIHByb21pc2UuXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlc29sdmVcbiAgICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlc29sdXRpb24gZnVuY3Rpb24uXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlamVjdFxuICAgICAgICogICAgICAgIFRoZSBwcm9taXNlJ3MgcmVqZWN0aW9uIGZ1bmN0aW9uLlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IG1ldGFkYXRhXG4gICAgICAgKiAgICAgICAgTWV0YWRhdGEgYWJvdXQgdGhlIHdyYXBwZWQgbWV0aG9kIHdoaWNoIGhhcyBjcmVhdGVkIHRoZSBjYWxsYmFjay5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmdcbiAgICAgICAqICAgICAgICBXaGV0aGVyIG9yIG5vdCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB3aXRoIG9ubHkgdGhlIGZpcnN0XG4gICAgICAgKiAgICAgICAgYXJndW1lbnQgb2YgdGhlIGNhbGxiYWNrLCBhbHRlcm5hdGl2ZWx5IGFuIGFycmF5IG9mIGFsbCB0aGVcbiAgICAgICAqICAgICAgICBjYWxsYmFjayBhcmd1bWVudHMgaXMgcmVzb2x2ZWQuIEJ5IGRlZmF1bHQsIGlmIHRoZSBjYWxsYmFja1xuICAgICAgICogICAgICAgIGZ1bmN0aW9uIGlzIGludm9rZWQgd2l0aCBvbmx5IGEgc2luZ2xlIGFyZ3VtZW50LCB0aGF0IHdpbGwgYmVcbiAgICAgICAqICAgICAgICByZXNvbHZlZCB0byB0aGUgcHJvbWlzZSwgd2hpbGUgYWxsIGFyZ3VtZW50cyB3aWxsIGJlIHJlc29sdmVkIGFzXG4gICAgICAgKiAgICAgICAgYW4gYXJyYXkgaWYgbXVsdGlwbGUgYXJlIGdpdmVuLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAgICAgICAqICAgICAgICBUaGUgZ2VuZXJhdGVkIGNhbGxiYWNrIGZ1bmN0aW9uLlxuICAgICAgICovXG4gICAgICBjb25zdCBtYWtlQ2FsbGJhY2sgPSAocHJvbWlzZSwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgcmV0dXJuICguLi5jYWxsYmFja0FyZ3MpID0+IHtcbiAgICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgICAgcHJvbWlzZS5yZWplY3QobmV3IEVycm9yKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSkpO1xuICAgICAgICAgIH0gZWxzZSBpZiAobWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmcgfHwgY2FsbGJhY2tBcmdzLmxlbmd0aCA8PSAxICYmIG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnICE9PSBmYWxzZSkge1xuICAgICAgICAgICAgcHJvbWlzZS5yZXNvbHZlKGNhbGxiYWNrQXJnc1swXSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHByb21pc2UucmVzb2x2ZShjYWxsYmFja0FyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH07XG4gICAgICBjb25zdCBwbHVyYWxpemVBcmd1bWVudHMgPSBudW1BcmdzID0+IG51bUFyZ3MgPT0gMSA/IFwiYXJndW1lbnRcIiA6IFwiYXJndW1lbnRzXCI7XG5cbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlcyBhIHdyYXBwZXIgZnVuY3Rpb24gZm9yIGEgbWV0aG9kIHdpdGggdGhlIGdpdmVuIG5hbWUgYW5kIG1ldGFkYXRhLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lXG4gICAgICAgKiAgICAgICAgVGhlIG5hbWUgb2YgdGhlIG1ldGhvZCB3aGljaCBpcyBiZWluZyB3cmFwcGVkLlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IG1ldGFkYXRhXG4gICAgICAgKiAgICAgICAgTWV0YWRhdGEgYWJvdXQgdGhlIG1ldGhvZCBiZWluZyB3cmFwcGVkLlxuICAgICAgICogQHBhcmFtIHtpbnRlZ2VyfSBtZXRhZGF0YS5taW5BcmdzXG4gICAgICAgKiAgICAgICAgVGhlIG1pbmltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtdXN0IGJlIHBhc3NlZCB0byB0aGVcbiAgICAgICAqICAgICAgICBmdW5jdGlvbi4gSWYgY2FsbGVkIHdpdGggZmV3ZXIgdGhhbiB0aGlzIG51bWJlciBvZiBhcmd1bWVudHMsIHRoZVxuICAgICAgICogICAgICAgIHdyYXBwZXIgd2lsbCByYWlzZSBhbiBleGNlcHRpb24uXG4gICAgICAgKiBAcGFyYW0ge2ludGVnZXJ9IG1ldGFkYXRhLm1heEFyZ3NcbiAgICAgICAqICAgICAgICBUaGUgbWF4aW11bSBudW1iZXIgb2YgYXJndW1lbnRzIHdoaWNoIG1heSBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24uIElmIGNhbGxlZCB3aXRoIG1vcmUgdGhhbiB0aGlzIG51bWJlciBvZiBhcmd1bWVudHMsIHRoZVxuICAgICAgICogICAgICAgIHdyYXBwZXIgd2lsbCByYWlzZSBhbiBleGNlcHRpb24uXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnXG4gICAgICAgKiAgICAgICAgV2hldGhlciBvciBub3QgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgd2l0aCBvbmx5IHRoZSBmaXJzdFxuICAgICAgICogICAgICAgIGFyZ3VtZW50IG9mIHRoZSBjYWxsYmFjaywgYWx0ZXJuYXRpdmVseSBhbiBhcnJheSBvZiBhbGwgdGhlXG4gICAgICAgKiAgICAgICAgY2FsbGJhY2sgYXJndW1lbnRzIGlzIHJlc29sdmVkLiBCeSBkZWZhdWx0LCBpZiB0aGUgY2FsbGJhY2tcbiAgICAgICAqICAgICAgICBmdW5jdGlvbiBpcyBpbnZva2VkIHdpdGggb25seSBhIHNpbmdsZSBhcmd1bWVudCwgdGhhdCB3aWxsIGJlXG4gICAgICAgKiAgICAgICAgcmVzb2x2ZWQgdG8gdGhlIHByb21pc2UsIHdoaWxlIGFsbCBhcmd1bWVudHMgd2lsbCBiZSByZXNvbHZlZCBhc1xuICAgICAgICogICAgICAgIGFuIGFycmF5IGlmIG11bHRpcGxlIGFyZSBnaXZlbi5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7ZnVuY3Rpb24ob2JqZWN0LCAuLi4qKX1cbiAgICAgICAqICAgICAgIFRoZSBnZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbi5cbiAgICAgICAqL1xuICAgICAgY29uc3Qgd3JhcEFzeW5jRnVuY3Rpb24gPSAobmFtZSwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGFzeW5jRnVuY3Rpb25XcmFwcGVyKHRhcmdldCwgLi4uYXJncykge1xuICAgICAgICAgIGlmIChhcmdzLmxlbmd0aCA8IG1ldGFkYXRhLm1pbkFyZ3MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChhcmdzLmxlbmd0aCA+IG1ldGFkYXRhLm1heEFyZ3MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbW9zdCAke21ldGFkYXRhLm1heEFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1heEFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIGlmIChtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjaykge1xuICAgICAgICAgICAgICAvLyBUaGlzIEFQSSBtZXRob2QgaGFzIGN1cnJlbnRseSBubyBjYWxsYmFjayBvbiBDaHJvbWUsIGJ1dCBpdCByZXR1cm4gYSBwcm9taXNlIG9uIEZpcmVmb3gsXG4gICAgICAgICAgICAgIC8vIGFuZCBzbyB0aGUgcG9seWZpbGwgd2lsbCB0cnkgdG8gY2FsbCBpdCB3aXRoIGEgY2FsbGJhY2sgZmlyc3QsIGFuZCBpdCB3aWxsIGZhbGxiYWNrXG4gICAgICAgICAgICAgIC8vIHRvIG5vdCBwYXNzaW5nIHRoZSBjYWxsYmFjayBpZiB0aGUgZmlyc3QgY2FsbCBmYWlscy5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICAgICAgICByZWplY3RcbiAgICAgICAgICAgICAgICB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjYkVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGAke25hbWV9IEFQSSBtZXRob2QgZG9lc24ndCBzZWVtIHRvIHN1cHBvcnQgdGhlIGNhbGxiYWNrIHBhcmFtZXRlciwgYCArIFwiZmFsbGluZyBiYWNrIHRvIGNhbGwgaXQgd2l0aG91dCBhIGNhbGxiYWNrOiBcIiwgY2JFcnJvcik7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuXG4gICAgICAgICAgICAgICAgLy8gVXBkYXRlIHRoZSBBUEkgbWV0aG9kIG1ldGFkYXRhLCBzbyB0aGF0IHRoZSBuZXh0IEFQSSBjYWxscyB3aWxsIG5vdCB0cnkgdG9cbiAgICAgICAgICAgICAgICAvLyB1c2UgdGhlIHVuc3VwcG9ydGVkIGNhbGxiYWNrIGFueW1vcmUuXG4gICAgICAgICAgICAgICAgbWV0YWRhdGEuZmFsbGJhY2tUb05vQ2FsbGJhY2sgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBtZXRhZGF0YS5ub0NhbGxiYWNrID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAobWV0YWRhdGEubm9DYWxsYmFjaykge1xuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncyk7XG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRhcmdldFtuYW1lXSguLi5hcmdzLCBtYWtlQ2FsbGJhY2soe1xuICAgICAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICAgICAgcmVqZWN0XG4gICAgICAgICAgICAgIH0sIG1ldGFkYXRhKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgICB9O1xuXG4gICAgICAvKipcbiAgICAgICAqIFdyYXBzIGFuIGV4aXN0aW5nIG1ldGhvZCBvZiB0aGUgdGFyZ2V0IG9iamVjdCwgc28gdGhhdCBjYWxscyB0byBpdCBhcmVcbiAgICAgICAqIGludGVyY2VwdGVkIGJ5IHRoZSBnaXZlbiB3cmFwcGVyIGZ1bmN0aW9uLiBUaGUgd3JhcHBlciBmdW5jdGlvbiByZWNlaXZlcyxcbiAgICAgICAqIGFzIGl0cyBmaXJzdCBhcmd1bWVudCwgdGhlIG9yaWdpbmFsIGB0YXJnZXRgIG9iamVjdCwgZm9sbG93ZWQgYnkgZWFjaCBvZlxuICAgICAgICogdGhlIGFyZ3VtZW50cyBwYXNzZWQgdG8gdGhlIG9yaWdpbmFsIG1ldGhvZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFyZ2V0XG4gICAgICAgKiAgICAgICAgVGhlIG9yaWdpbmFsIHRhcmdldCBvYmplY3QgdGhhdCB0aGUgd3JhcHBlZCBtZXRob2QgYmVsb25ncyB0by5cbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IG1ldGhvZFxuICAgICAgICogICAgICAgIFRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC4gVGhpcyBpcyB1c2VkIGFzIHRoZSB0YXJnZXQgb2YgdGhlIFByb3h5XG4gICAgICAgKiAgICAgICAgb2JqZWN0IHdoaWNoIGlzIGNyZWF0ZWQgdG8gd3JhcCB0aGUgbWV0aG9kLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gd3JhcHBlclxuICAgICAgICogICAgICAgIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHdoaWNoIGlzIGNhbGxlZCBpbiBwbGFjZSBvZiBhIGRpcmVjdCBpbnZvY2F0aW9uXG4gICAgICAgKiAgICAgICAgb2YgdGhlIHdyYXBwZWQgbWV0aG9kLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtQcm94eTxmdW5jdGlvbj59XG4gICAgICAgKiAgICAgICAgQSBQcm94eSBvYmplY3QgZm9yIHRoZSBnaXZlbiBtZXRob2QsIHdoaWNoIGludm9rZXMgdGhlIGdpdmVuIHdyYXBwZXJcbiAgICAgICAqICAgICAgICBtZXRob2QgaW4gaXRzIHBsYWNlLlxuICAgICAgICovXG4gICAgICBjb25zdCB3cmFwTWV0aG9kID0gKHRhcmdldCwgbWV0aG9kLCB3cmFwcGVyKSA9PiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkobWV0aG9kLCB7XG4gICAgICAgICAgYXBwbHkodGFyZ2V0TWV0aG9kLCB0aGlzT2JqLCBhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gd3JhcHBlci5jYWxsKHRoaXNPYmosIHRhcmdldCwgLi4uYXJncyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBsZXQgaGFzT3duUHJvcGVydHkgPSBGdW5jdGlvbi5jYWxsLmJpbmQoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eSk7XG5cbiAgICAgIC8qKlxuICAgICAgICogV3JhcHMgYW4gb2JqZWN0IGluIGEgUHJveHkgd2hpY2ggaW50ZXJjZXB0cyBhbmQgd3JhcHMgY2VydGFpbiBtZXRob2RzXG4gICAgICAgKiBiYXNlZCBvbiB0aGUgZ2l2ZW4gYHdyYXBwZXJzYCBhbmQgYG1ldGFkYXRhYCBvYmplY3RzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSB0YXJnZXRcbiAgICAgICAqICAgICAgICBUaGUgdGFyZ2V0IG9iamVjdCB0byB3cmFwLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBbd3JhcHBlcnMgPSB7fV1cbiAgICAgICAqICAgICAgICBBbiBvYmplY3QgdHJlZSBjb250YWluaW5nIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBzcGVjaWFsIGNhc2VzLiBBbnlcbiAgICAgICAqICAgICAgICBmdW5jdGlvbiBwcmVzZW50IGluIHRoaXMgb2JqZWN0IHRyZWUgaXMgY2FsbGVkIGluIHBsYWNlIG9mIHRoZVxuICAgICAgICogICAgICAgIG1ldGhvZCBpbiB0aGUgc2FtZSBsb2NhdGlvbiBpbiB0aGUgYHRhcmdldGAgb2JqZWN0IHRyZWUuIFRoZXNlXG4gICAgICAgKiAgICAgICAgd3JhcHBlciBtZXRob2RzIGFyZSBpbnZva2VkIGFzIGRlc2NyaWJlZCBpbiB7QHNlZSB3cmFwTWV0aG9kfS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gW21ldGFkYXRhID0ge31dXG4gICAgICAgKiAgICAgICAgQW4gb2JqZWN0IHRyZWUgY29udGFpbmluZyBtZXRhZGF0YSB1c2VkIHRvIGF1dG9tYXRpY2FsbHkgZ2VuZXJhdGVcbiAgICAgICAqICAgICAgICBQcm9taXNlLWJhc2VkIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBhc3luY2hyb25vdXMuIEFueSBmdW5jdGlvbiBpblxuICAgICAgICogICAgICAgIHRoZSBgdGFyZ2V0YCBvYmplY3QgdHJlZSB3aGljaCBoYXMgYSBjb3JyZXNwb25kaW5nIG1ldGFkYXRhIG9iamVjdFxuICAgICAgICogICAgICAgIGluIHRoZSBzYW1lIGxvY2F0aW9uIGluIHRoZSBgbWV0YWRhdGFgIHRyZWUgaXMgcmVwbGFjZWQgd2l0aCBhblxuICAgICAgICogICAgICAgIGF1dG9tYXRpY2FsbHktZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24sIGFzIGRlc2NyaWJlZCBpblxuICAgICAgICogICAgICAgIHtAc2VlIHdyYXBBc3luY0Z1bmN0aW9ufVxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtQcm94eTxvYmplY3Q+fVxuICAgICAgICovXG4gICAgICBjb25zdCB3cmFwT2JqZWN0ID0gKHRhcmdldCwgd3JhcHBlcnMgPSB7fSwgbWV0YWRhdGEgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgY2FjaGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICBsZXQgaGFuZGxlcnMgPSB7XG4gICAgICAgICAgaGFzKHByb3h5VGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgICAgICByZXR1cm4gcHJvcCBpbiB0YXJnZXQgfHwgcHJvcCBpbiBjYWNoZTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIGdldChwcm94eVRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBjYWNoZVtwcm9wXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghKHByb3AgaW4gdGFyZ2V0KSkge1xuICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IHZhbHVlID0gdGFyZ2V0W3Byb3BdO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBtZXRob2Qgb24gdGhlIHVuZGVybHlpbmcgb2JqZWN0LiBDaGVjayBpZiB3ZSBuZWVkIHRvIGRvXG4gICAgICAgICAgICAgIC8vIGFueSB3cmFwcGluZy5cblxuICAgICAgICAgICAgICBpZiAodHlwZW9mIHdyYXBwZXJzW3Byb3BdID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgICAvLyBXZSBoYXZlIGEgc3BlY2lhbC1jYXNlIHdyYXBwZXIgZm9yIHRoaXMgbWV0aG9kLlxuICAgICAgICAgICAgICAgIHZhbHVlID0gd3JhcE1ldGhvZCh0YXJnZXQsIHRhcmdldFtwcm9wXSwgd3JhcHBlcnNbcHJvcF0pO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGhhc093blByb3BlcnR5KG1ldGFkYXRhLCBwcm9wKSkge1xuICAgICAgICAgICAgICAgIC8vIFRoaXMgaXMgYW4gYXN5bmMgbWV0aG9kIHRoYXQgd2UgaGF2ZSBtZXRhZGF0YSBmb3IuIENyZWF0ZSBhXG4gICAgICAgICAgICAgICAgLy8gUHJvbWlzZSB3cmFwcGVyIGZvciBpdC5cbiAgICAgICAgICAgICAgICBsZXQgd3JhcHBlciA9IHdyYXBBc3luY0Z1bmN0aW9uKHByb3AsIG1ldGFkYXRhW3Byb3BdKTtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXIpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBtZXRob2QgdGhhdCB3ZSBkb24ndCBrbm93IG9yIGNhcmUgYWJvdXQuIFJldHVybiB0aGVcbiAgICAgICAgICAgICAgICAvLyBvcmlnaW5hbCBtZXRob2QsIGJvdW5kIHRvIHRoZSB1bmRlcmx5aW5nIG9iamVjdC5cbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHZhbHVlLmJpbmQodGFyZ2V0KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwgJiYgKGhhc093blByb3BlcnR5KHdyYXBwZXJzLCBwcm9wKSB8fCBoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgcHJvcCkpKSB7XG4gICAgICAgICAgICAgIC8vIFRoaXMgaXMgYW4gb2JqZWN0IHRoYXQgd2UgbmVlZCB0byBkbyBzb21lIHdyYXBwaW5nIGZvciB0aGUgY2hpbGRyZW5cbiAgICAgICAgICAgICAgLy8gb2YuIENyZWF0ZSBhIHN1Yi1vYmplY3Qgd3JhcHBlciBmb3IgaXQgd2l0aCB0aGUgYXBwcm9wcmlhdGUgY2hpbGRcbiAgICAgICAgICAgICAgLy8gbWV0YWRhdGEuXG4gICAgICAgICAgICAgIHZhbHVlID0gd3JhcE9iamVjdCh2YWx1ZSwgd3JhcHBlcnNbcHJvcF0sIG1ldGFkYXRhW3Byb3BdKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIFwiKlwiKSkge1xuICAgICAgICAgICAgICAvLyBXcmFwIGFsbCBwcm9wZXJ0aWVzIGluICogbmFtZXNwYWNlLlxuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBPYmplY3QodmFsdWUsIHdyYXBwZXJzW3Byb3BdLCBtZXRhZGF0YVtcIipcIl0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gV2UgZG9uJ3QgbmVlZCB0byBkbyBhbnkgd3JhcHBpbmcgZm9yIHRoaXMgcHJvcGVydHksXG4gICAgICAgICAgICAgIC8vIHNvIGp1c3QgZm9yd2FyZCBhbGwgYWNjZXNzIHRvIHRoZSB1bmRlcmx5aW5nIG9iamVjdC5cbiAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNhY2hlLCBwcm9wLCB7XG4gICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgZ2V0KCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHNldCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgdGFyZ2V0W3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FjaGVbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNldChwcm94eVRhcmdldCwgcHJvcCwgdmFsdWUsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICBpZiAocHJvcCBpbiBjYWNoZSkge1xuICAgICAgICAgICAgICBjYWNoZVtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIGRlZmluZVByb3BlcnR5KHByb3h5VGFyZ2V0LCBwcm9wLCBkZXNjKSB7XG4gICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwgZGVzYyk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBkZWxldGVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZGVsZXRlUHJvcGVydHkoY2FjaGUsIHByb3ApO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvLyBQZXIgY29udHJhY3Qgb2YgdGhlIFByb3h5IEFQSSwgdGhlIFwiZ2V0XCIgcHJveHkgaGFuZGxlciBtdXN0IHJldHVybiB0aGVcbiAgICAgICAgLy8gb3JpZ2luYWwgdmFsdWUgb2YgdGhlIHRhcmdldCBpZiB0aGF0IHZhbHVlIGlzIGRlY2xhcmVkIHJlYWQtb25seSBhbmRcbiAgICAgICAgLy8gbm9uLWNvbmZpZ3VyYWJsZS4gRm9yIHRoaXMgcmVhc29uLCB3ZSBjcmVhdGUgYW4gb2JqZWN0IHdpdGggdGhlXG4gICAgICAgIC8vIHByb3RvdHlwZSBzZXQgdG8gYHRhcmdldGAgaW5zdGVhZCBvZiB1c2luZyBgdGFyZ2V0YCBkaXJlY3RseS5cbiAgICAgICAgLy8gT3RoZXJ3aXNlIHdlIGNhbm5vdCByZXR1cm4gYSBjdXN0b20gb2JqZWN0IGZvciBBUElzIHRoYXRcbiAgICAgICAgLy8gYXJlIGRlY2xhcmVkIHJlYWQtb25seSBhbmQgbm9uLWNvbmZpZ3VyYWJsZSwgc3VjaCBhcyBgY2hyb21lLmRldnRvb2xzYC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gVGhlIHByb3h5IGhhbmRsZXJzIHRoZW1zZWx2ZXMgd2lsbCBzdGlsbCB1c2UgdGhlIG9yaWdpbmFsIGB0YXJnZXRgXG4gICAgICAgIC8vIGluc3RlYWQgb2YgdGhlIGBwcm94eVRhcmdldGAsIHNvIHRoYXQgdGhlIG1ldGhvZHMgYW5kIHByb3BlcnRpZXMgYXJlXG4gICAgICAgIC8vIGRlcmVmZXJlbmNlZCB2aWEgdGhlIG9yaWdpbmFsIHRhcmdldHMuXG4gICAgICAgIGxldCBwcm94eVRhcmdldCA9IE9iamVjdC5jcmVhdGUodGFyZ2V0KTtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm94eShwcm94eVRhcmdldCwgaGFuZGxlcnMpO1xuICAgICAgfTtcblxuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGEgc2V0IG9mIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBhbiBldmVudCBvYmplY3QsIHdoaWNoIGhhbmRsZXNcbiAgICAgICAqIHdyYXBwaW5nIG9mIGxpc3RlbmVyIGZ1bmN0aW9ucyB0aGF0IHRob3NlIG1lc3NhZ2VzIGFyZSBwYXNzZWQuXG4gICAgICAgKlxuICAgICAgICogQSBzaW5nbGUgd3JhcHBlciBpcyBjcmVhdGVkIGZvciBlYWNoIGxpc3RlbmVyIGZ1bmN0aW9uLCBhbmQgc3RvcmVkIGluIGFcbiAgICAgICAqIG1hcC4gU3Vic2VxdWVudCBjYWxscyB0byBgYWRkTGlzdGVuZXJgLCBgaGFzTGlzdGVuZXJgLCBvciBgcmVtb3ZlTGlzdGVuZXJgXG4gICAgICAgKiByZXRyaWV2ZSB0aGUgb3JpZ2luYWwgd3JhcHBlciwgc28gdGhhdCAgYXR0ZW1wdHMgdG8gcmVtb3ZlIGFcbiAgICAgICAqIHByZXZpb3VzbHktYWRkZWQgbGlzdGVuZXIgd29yayBhcyBleHBlY3RlZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0RlZmF1bHRXZWFrTWFwPGZ1bmN0aW9uLCBmdW5jdGlvbj59IHdyYXBwZXJNYXBcbiAgICAgICAqICAgICAgICBBIERlZmF1bHRXZWFrTWFwIG9iamVjdCB3aGljaCB3aWxsIGNyZWF0ZSB0aGUgYXBwcm9wcmlhdGUgd3JhcHBlclxuICAgICAgICogICAgICAgIGZvciBhIGdpdmVuIGxpc3RlbmVyIGZ1bmN0aW9uIHdoZW4gb25lIGRvZXMgbm90IGV4aXN0LCBhbmQgcmV0cmlldmVcbiAgICAgICAqICAgICAgICBhbiBleGlzdGluZyBvbmUgd2hlbiBpdCBkb2VzLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtvYmplY3R9XG4gICAgICAgKi9cbiAgICAgIGNvbnN0IHdyYXBFdmVudCA9IHdyYXBwZXJNYXAgPT4gKHtcbiAgICAgICAgYWRkTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lciwgLi4uYXJncykge1xuICAgICAgICAgIHRhcmdldC5hZGRMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lciksIC4uLmFyZ3MpO1xuICAgICAgICB9LFxuICAgICAgICBoYXNMaXN0ZW5lcih0YXJnZXQsIGxpc3RlbmVyKSB7XG4gICAgICAgICAgcmV0dXJuIHRhcmdldC5oYXNMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgICB9LFxuICAgICAgICByZW1vdmVMaXN0ZW5lcih0YXJnZXQsIGxpc3RlbmVyKSB7XG4gICAgICAgICAgdGFyZ2V0LnJlbW92ZUxpc3RlbmVyKHdyYXBwZXJNYXAuZ2V0KGxpc3RlbmVyKSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgY29uc3Qgb25SZXF1ZXN0RmluaXNoZWRXcmFwcGVycyA9IG5ldyBEZWZhdWx0V2Vha01hcChsaXN0ZW5lciA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgbGlzdGVuZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIHJldHVybiBsaXN0ZW5lcjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcmFwcyBhbiBvblJlcXVlc3RGaW5pc2hlZCBsaXN0ZW5lciBmdW5jdGlvbiBzbyB0aGF0IGl0IHdpbGwgcmV0dXJuIGFcbiAgICAgICAgICogYGdldENvbnRlbnQoKWAgcHJvcGVydHkgd2hpY2ggcmV0dXJucyBhIGBQcm9taXNlYCByYXRoZXIgdGhhbiB1c2luZyBhXG4gICAgICAgICAqIGNhbGxiYWNrIEFQSS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtvYmplY3R9IHJlcVxuICAgICAgICAgKiAgICAgICAgVGhlIEhBUiBlbnRyeSBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBuZXR3b3JrIHJlcXVlc3QuXG4gICAgICAgICAqL1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gb25SZXF1ZXN0RmluaXNoZWQocmVxKSB7XG4gICAgICAgICAgY29uc3Qgd3JhcHBlZFJlcSA9IHdyYXBPYmplY3QocmVxLCB7fSAvKiB3cmFwcGVycyAqLywge1xuICAgICAgICAgICAgZ2V0Q29udGVudDoge1xuICAgICAgICAgICAgICBtaW5BcmdzOiAwLFxuICAgICAgICAgICAgICBtYXhBcmdzOiAwXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGlzdGVuZXIod3JhcHBlZFJlcSk7XG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG9uTWVzc2FnZVdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFdyYXBzIGEgbWVzc2FnZSBsaXN0ZW5lciBmdW5jdGlvbiBzbyB0aGF0IGl0IG1heSBzZW5kIHJlc3BvbnNlcyBiYXNlZCBvblxuICAgICAgICAgKiBpdHMgcmV0dXJuIHZhbHVlLCByYXRoZXIgdGhhbiBieSByZXR1cm5pbmcgYSBzZW50aW5lbCB2YWx1ZSBhbmQgY2FsbGluZyBhXG4gICAgICAgICAqIGNhbGxiYWNrLiBJZiB0aGUgbGlzdGVuZXIgZnVuY3Rpb24gcmV0dXJucyBhIFByb21pc2UsIHRoZSByZXNwb25zZSBpc1xuICAgICAgICAgKiBzZW50IHdoZW4gdGhlIHByb21pc2UgZWl0aGVyIHJlc29sdmVzIG9yIHJlamVjdHMuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7Kn0gbWVzc2FnZVxuICAgICAgICAgKiAgICAgICAgVGhlIG1lc3NhZ2Ugc2VudCBieSB0aGUgb3RoZXIgZW5kIG9mIHRoZSBjaGFubmVsLlxuICAgICAgICAgKiBAcGFyYW0ge29iamVjdH0gc2VuZGVyXG4gICAgICAgICAqICAgICAgICBEZXRhaWxzIGFib3V0IHRoZSBzZW5kZXIgb2YgdGhlIG1lc3NhZ2UuXG4gICAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb24oKil9IHNlbmRSZXNwb25zZVxuICAgICAgICAgKiAgICAgICAgQSBjYWxsYmFjayB3aGljaCwgd2hlbiBjYWxsZWQgd2l0aCBhbiBhcmJpdHJhcnkgYXJndW1lbnQsIHNlbmRzXG4gICAgICAgICAqICAgICAgICB0aGF0IHZhbHVlIGFzIGEgcmVzcG9uc2UuXG4gICAgICAgICAqIEByZXR1cm5zIHtib29sZWFufVxuICAgICAgICAgKiAgICAgICAgVHJ1ZSBpZiB0aGUgd3JhcHBlZCBsaXN0ZW5lciByZXR1cm5lZCBhIFByb21pc2UsIHdoaWNoIHdpbGwgbGF0ZXJcbiAgICAgICAgICogICAgICAgIHlpZWxkIGEgcmVzcG9uc2UuIEZhbHNlIG90aGVyd2lzZS5cbiAgICAgICAgICovXG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBvbk1lc3NhZ2UobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpIHtcbiAgICAgICAgICBsZXQgZGlkQ2FsbFNlbmRSZXNwb25zZSA9IGZhbHNlO1xuICAgICAgICAgIGxldCB3cmFwcGVkU2VuZFJlc3BvbnNlO1xuICAgICAgICAgIGxldCBzZW5kUmVzcG9uc2VQcm9taXNlID0gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgICB3cmFwcGVkU2VuZFJlc3BvbnNlID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgIGRpZENhbGxTZW5kUmVzcG9uc2UgPSB0cnVlO1xuICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGV0IHJlc3VsdDtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmVzdWx0ID0gbGlzdGVuZXIobWVzc2FnZSwgc2VuZGVyLCB3cmFwcGVkU2VuZFJlc3BvbnNlKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IFByb21pc2UucmVqZWN0KGVycik7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGlzUmVzdWx0VGhlbmFibGUgPSByZXN1bHQgIT09IHRydWUgJiYgaXNUaGVuYWJsZShyZXN1bHQpO1xuXG4gICAgICAgICAgLy8gSWYgdGhlIGxpc3RlbmVyIGRpZG4ndCByZXR1cm5lZCB0cnVlIG9yIGEgUHJvbWlzZSwgb3IgY2FsbGVkXG4gICAgICAgICAgLy8gd3JhcHBlZFNlbmRSZXNwb25zZSBzeW5jaHJvbm91c2x5LCB3ZSBjYW4gZXhpdCBlYXJsaWVyXG4gICAgICAgICAgLy8gYmVjYXVzZSB0aGVyZSB3aWxsIGJlIG5vIHJlc3BvbnNlIHNlbnQgZnJvbSB0aGlzIGxpc3RlbmVyLlxuICAgICAgICAgIGlmIChyZXN1bHQgIT09IHRydWUgJiYgIWlzUmVzdWx0VGhlbmFibGUgJiYgIWRpZENhbGxTZW5kUmVzcG9uc2UpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBBIHNtYWxsIGhlbHBlciB0byBzZW5kIHRoZSBtZXNzYWdlIGlmIHRoZSBwcm9taXNlIHJlc29sdmVzXG4gICAgICAgICAgLy8gYW5kIGFuIGVycm9yIGlmIHRoZSBwcm9taXNlIHJlamVjdHMgKGEgd3JhcHBlZCBzZW5kTWVzc2FnZSBoYXNcbiAgICAgICAgICAvLyB0byB0cmFuc2xhdGUgdGhlIG1lc3NhZ2UgaW50byBhIHJlc29sdmVkIHByb21pc2Ugb3IgYSByZWplY3RlZFxuICAgICAgICAgIC8vIHByb21pc2UpLlxuICAgICAgICAgIGNvbnN0IHNlbmRQcm9taXNlZFJlc3VsdCA9IHByb21pc2UgPT4ge1xuICAgICAgICAgICAgcHJvbWlzZS50aGVuKG1zZyA9PiB7XG4gICAgICAgICAgICAgIC8vIHNlbmQgdGhlIG1lc3NhZ2UgdmFsdWUuXG4gICAgICAgICAgICAgIHNlbmRSZXNwb25zZShtc2cpO1xuICAgICAgICAgICAgfSwgZXJyb3IgPT4ge1xuICAgICAgICAgICAgICAvLyBTZW5kIGEgSlNPTiByZXByZXNlbnRhdGlvbiBvZiB0aGUgZXJyb3IgaWYgdGhlIHJlamVjdGVkIHZhbHVlXG4gICAgICAgICAgICAgIC8vIGlzIGFuIGluc3RhbmNlIG9mIGVycm9yLCBvciB0aGUgb2JqZWN0IGl0c2VsZiBvdGhlcndpc2UuXG4gICAgICAgICAgICAgIGxldCBtZXNzYWdlO1xuICAgICAgICAgICAgICBpZiAoZXJyb3IgJiYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgfHwgdHlwZW9mIGVycm9yLm1lc3NhZ2UgPT09IFwic3RyaW5nXCIpKSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2U7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZFwiO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgICAgICAgICAgX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fOiB0cnVlLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2VcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgICAvLyBQcmludCBhbiBlcnJvciBvbiB0aGUgY29uc29sZSBpZiB1bmFibGUgdG8gc2VuZCB0aGUgcmVzcG9uc2UuXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBvbk1lc3NhZ2UgcmVqZWN0ZWQgcmVwbHlcIiwgZXJyKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvLyBJZiB0aGUgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCBzZW5kIHRoZSByZXNvbHZlZCB2YWx1ZSBhcyBhXG4gICAgICAgICAgLy8gcmVzdWx0LCBvdGhlcndpc2Ugd2FpdCB0aGUgcHJvbWlzZSByZWxhdGVkIHRvIHRoZSB3cmFwcGVkU2VuZFJlc3BvbnNlXG4gICAgICAgICAgLy8gY2FsbGJhY2sgdG8gcmVzb2x2ZSBhbmQgc2VuZCBpdCBhcyBhIHJlc3BvbnNlLlxuICAgICAgICAgIGlmIChpc1Jlc3VsdFRoZW5hYmxlKSB7XG4gICAgICAgICAgICBzZW5kUHJvbWlzZWRSZXN1bHQocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2VuZFByb21pc2VkUmVzdWx0KHNlbmRSZXNwb25zZVByb21pc2UpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIExldCBDaHJvbWUga25vdyB0aGF0IHRoZSBsaXN0ZW5lciBpcyByZXBseWluZy5cbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgY29uc3Qgd3JhcHBlZFNlbmRNZXNzYWdlQ2FsbGJhY2sgPSAoe1xuICAgICAgICByZWplY3QsXG4gICAgICAgIHJlc29sdmVcbiAgICAgIH0sIHJlcGx5KSA9PiB7XG4gICAgICAgIGlmIChleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgLy8gRGV0ZWN0IHdoZW4gbm9uZSBvZiB0aGUgbGlzdGVuZXJzIHJlcGxpZWQgdG8gdGhlIHNlbmRNZXNzYWdlIGNhbGwgYW5kIHJlc29sdmVcbiAgICAgICAgICAvLyB0aGUgcHJvbWlzZSB0byB1bmRlZmluZWQgYXMgaW4gRmlyZWZveC5cbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL21vemlsbGEvd2ViZXh0ZW5zaW9uLXBvbHlmaWxsL2lzc3Vlcy8xMzBcbiAgICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlID09PSBDSFJPTUVfU0VORF9NRVNTQUdFX0NBTExCQUNLX05PX1JFU1BPTlNFX01FU1NBR0UpIHtcbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAocmVwbHkgJiYgcmVwbHkuX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fKSB7XG4gICAgICAgICAgLy8gQ29udmVydCBiYWNrIHRoZSBKU09OIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBlcnJvciBpbnRvXG4gICAgICAgICAgLy8gYW4gRXJyb3IgaW5zdGFuY2UuXG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihyZXBseS5tZXNzYWdlKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZShyZXBseSk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCB3cmFwcGVkU2VuZE1lc3NhZ2UgPSAobmFtZSwgbWV0YWRhdGEsIGFwaU5hbWVzcGFjZU9iaiwgLi4uYXJncykgPT4ge1xuICAgICAgICBpZiAoYXJncy5sZW5ndGggPCBtZXRhZGF0YS5taW5BcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYXJncy5sZW5ndGggPiBtZXRhZGF0YS5tYXhBcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBtb3N0ICR7bWV0YWRhdGEubWF4QXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWF4QXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgY29uc3Qgd3JhcHBlZENiID0gd3JhcHBlZFNlbmRNZXNzYWdlQ2FsbGJhY2suYmluZChudWxsLCB7XG4gICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgcmVqZWN0XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgYXJncy5wdXNoKHdyYXBwZWRDYik7XG4gICAgICAgICAgYXBpTmFtZXNwYWNlT2JqLnNlbmRNZXNzYWdlKC4uLmFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBjb25zdCBzdGF0aWNXcmFwcGVycyA9IHtcbiAgICAgICAgZGV2dG9vbHM6IHtcbiAgICAgICAgICBuZXR3b3JrOiB7XG4gICAgICAgICAgICBvblJlcXVlc3RGaW5pc2hlZDogd3JhcEV2ZW50KG9uUmVxdWVzdEZpbmlzaGVkV3JhcHBlcnMpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBydW50aW1lOiB7XG4gICAgICAgICAgb25NZXNzYWdlOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICAgIG9uTWVzc2FnZUV4dGVybmFsOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgICBtYXhBcmdzOiAzXG4gICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgdGFiczoge1xuICAgICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDIsXG4gICAgICAgICAgICBtYXhBcmdzOiAzXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHNldHRpbmdNZXRhZGF0YSA9IHtcbiAgICAgICAgY2xlYXI6IHtcbiAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgIG1heEFyZ3M6IDFcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0OiB7XG4gICAgICAgICAgbWluQXJnczogMSxcbiAgICAgICAgICBtYXhBcmdzOiAxXG4gICAgICAgIH0sXG4gICAgICAgIHNldDoge1xuICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgbWF4QXJnczogMVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgYXBpTWV0YWRhdGEucHJpdmFjeSA9IHtcbiAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgIFwiKlwiOiBzZXR0aW5nTWV0YWRhdGFcbiAgICAgICAgfSxcbiAgICAgICAgc2VydmljZXM6IHtcbiAgICAgICAgICBcIipcIjogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH0sXG4gICAgICAgIHdlYnNpdGVzOiB7XG4gICAgICAgICAgXCIqXCI6IHNldHRpbmdNZXRhZGF0YVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgcmV0dXJuIHdyYXBPYmplY3QoZXh0ZW5zaW9uQVBJcywgc3RhdGljV3JhcHBlcnMsIGFwaU1ldGFkYXRhKTtcbiAgICB9O1xuXG4gICAgLy8gVGhlIGJ1aWxkIHByb2Nlc3MgYWRkcyBhIFVNRCB3cmFwcGVyIGFyb3VuZCB0aGlzIGZpbGUsIHdoaWNoIG1ha2VzIHRoZVxuICAgIC8vIGBtb2R1bGVgIHZhcmlhYmxlIGF2YWlsYWJsZS5cbiAgICBtb2R1bGUuZXhwb3J0cyA9IHdyYXBBUElzKGNocm9tZSk7XG4gIH0gZWxzZSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSBnbG9iYWxUaGlzLmJyb3dzZXI7XG4gIH1cbn0pO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnJvd3Nlci1wb2x5ZmlsbC5qcy5tYXBcbiIsIi8qKlxuICogQGZpbGVcbiAqIEkxOG4gZmlsZSBpcyBwYXJ0IG9mIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gKGh0dHBzOi8vZ2l0aHViLmNvbS9BZGd1YXJkVGVhbS9BZGd1YXJkQnJvd3NlckV4dGVuc2lvbikuXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBmcmVlIHNvZnR3YXJlOiB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbiwgZWl0aGVyIHZlcnNpb24gMyBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBkaXN0cmlidXRlZCBpbiB0aGUgaG9wZSB0aGF0IGl0IHdpbGwgYmUgdXNlZnVsLFxuICogYnV0IFdJVEhPVVQgQU5ZIFdBUlJBTlRZOyB3aXRob3V0IGV2ZW4gdGhlIGltcGxpZWQgd2FycmFudHkgb2ZcbiAqIE1FUkNIQU5UQUJJTElUWSBvciBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRS5cbiAqIFNlZSB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgZm9yIG1vcmUgZGV0YWlscy5cbiAqXG4gKiBZb3Ugc2hvdWxkIGhhdmUgcmVjZWl2ZWQgYSBjb3B5IG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZVxuICogYWxvbmcgd2l0aCBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uLiBJZiBub3QsIHNlZSA8aHR0cDovL3d3dy5nbnUub3JnL2xpY2Vuc2VzLz4uXG4gKi9cbmltcG9ydCBicm93c2VyIGZyb20gJ3dlYmV4dGVuc2lvbi1wb2x5ZmlsbCc7XG5cbi8qKlxuICogSW5qZWN0cyB0cmFuc2xhdGlvbnMgdG8gRE9NIGVsZW1lbnRzIHdpdGggaTE4biBhdHRyaWJ1dGVzXG4gKi9cbmV4cG9ydCBjbGFzcyBJMThuIHtcbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplcyBpbmplY3Rvci5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGluaXQoKSB7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBJMThuLnRyYW5zbGF0ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUHJvY2Vzc2VzIGkxOG4gaW5qZWN0aW9uc1xuICAgICAqL1xuICAgIHByaXZhdGUgc3RhdGljIHRyYW5zbGF0ZSgpIHtcbiAgICAgICAgSTE4bi50cmFuc2xhdGVFbGVtZW50cygnaTE4bicpO1xuICAgICAgICBJMThuLnRyYW5zbGF0ZUF0dHJpYnV0ZXMoJ2kxOG4tcGxocicsICdwbGFjZWhvbGRlcicpO1xuICAgICAgICBJMThuLnRyYW5zbGF0ZUF0dHJpYnV0ZXMoJ2kxOG4taHJlZicsICdocmVmJyk7XG4gICAgICAgIEkxOG4udHJhbnNsYXRlQXR0cmlidXRlcygnaTE4bi10aXRsZScsICd0aXRsZScpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRyYW5zbGF0ZXMgZWxlbWVudHMgd2l0aCBzcGVjaWZpZWQge0BsaW5rIGkxOG5BdHRyaWJ1dGVOYW1lfVxuICAgICAqXG4gICAgICogQHBhcmFtIGkxOG5BdHRyaWJ1dGVOYW1lIC0gaTE4biBhdHRyaWJ1dGVcbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyB0cmFuc2xhdGVFbGVtZW50cyhpMThuQXR0cmlidXRlTmFtZTogc3RyaW5nKSB7XG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYFske2kxOG5BdHRyaWJ1dGVOYW1lfV1gKS5mb3JFYWNoKChlbCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbWVzc2FnZSA9IEkxOG4uZ2V0STE4bk1lc3NhZ2UoZWwsIGkxOG5BdHRyaWJ1dGVOYW1lKTtcblxuICAgICAgICAgICAgaWYgKCFtZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBJMThuLnRyYW5zbGF0ZUVsZW1lbnQoZWwsIG1lc3NhZ2UpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXBsYWNlcyBjb250ZW50IG9mIHtAbGluayBlbGVtZW50fSB0byB0cmFuc2xhdGlvblxuICAgICAqXG4gICAgICogQHBhcmFtIGVsZW1lbnQgLSB0YXJnZXQgZWxlbWVudFxuICAgICAqIEBwYXJhbSBtZXNzYWdlIC0gZWxlbWVudCB0ZXh0XG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgdHJhbnNsYXRlRWxlbWVudChlbGVtZW50OiBFbGVtZW50LCBtZXNzYWdlOiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIHJlbW92ZSBvcmlnaW5hbCBjb250ZW50XG4gICAgICAgICAgICB3aGlsZSAoZWxlbWVudC5sYXN0Q2hpbGQpIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50LnJlbW92ZUNoaWxkKGVsZW1lbnQubGFzdENoaWxkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGFwcGVuZCB0cmFuc2xhdGVkIGNvbnRlbnRcbiAgICAgICAgICAgIEkxOG4ucHJvY2Vzc1N0cmluZyhtZXNzYWdlLCBlbGVtZW50KTtcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIC8vIElnbm9yZSBleGNlcHRpb25zXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIHRyYW5zbGF0ZWQge0BsaW5rIGVsZW1lbnR9IGNoaWxkIG5vZGVzIGFuZCBhcHBlbmRzIGl0IHRvIHBhcmVudFxuICAgICAqXG4gICAgICogQHBhcmFtIGh0bWwgLSBodG1sIHN0cmluZ1xuICAgICAqIEBwYXJhbSBlbGVtZW50IC0gdGFyZ2V0IGVsZW1lbnRcbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBwcm9jZXNzU3RyaW5nKGh0bWw6IHN0cmluZywgZWxlbWVudDogRWxlbWVudCk6IHZvaWQge1xuICAgICAgICBsZXQgZWw6IEVsZW1lbnQ7XG5cbiAgICAgICAgY29uc3QgbWF0Y2gxID0gL14oW15dKj8pPChhfHN0cm9uZ3xzcGFufGkpKFtePl0qKT4oLio/KTxcXC9cXDI+KFteXSopJC9tLmV4ZWMoaHRtbCk7XG4gICAgICAgIGNvbnN0IG1hdGNoMiA9IC9eKFteXSo/KTwoYnJ8aW5wdXQpKFtePl0qKVxcLz8+KFteXSopJC9tLmV4ZWMoaHRtbCk7XG4gICAgICAgIGlmIChtYXRjaDEpIHtcbiAgICAgICAgICAgIC8vIFRPRE86IHNhZmUgdHlwZXNcbiAgICAgICAgICAgIC8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1ub24tbnVsbC1hc3NlcnRpb24gKi9cbiAgICAgICAgICAgIEkxOG4ucHJvY2Vzc1N0cmluZyhtYXRjaDFbMV0hLCBlbGVtZW50KTtcblxuICAgICAgICAgICAgZWwgPSBJMThuLmNyZWF0ZUVsZW1lbnQobWF0Y2gxWzJdISwgbWF0Y2gxWzNdISk7XG5cbiAgICAgICAgICAgIEkxOG4ucHJvY2Vzc1N0cmluZyhtYXRjaDFbNF0hLCBlbCk7XG4gICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGVsKTtcblxuICAgICAgICAgICAgSTE4bi5wcm9jZXNzU3RyaW5nKG1hdGNoMVs1XSEsIGVsZW1lbnQpO1xuICAgICAgICB9IGVsc2UgaWYgKG1hdGNoMikge1xuICAgICAgICAgICAgSTE4bi5wcm9jZXNzU3RyaW5nKG1hdGNoMlsxXSEsIGVsZW1lbnQpO1xuXG4gICAgICAgICAgICBlbCA9IEkxOG4uY3JlYXRlRWxlbWVudChtYXRjaDJbMl0hLCBtYXRjaDJbM10hKTtcbiAgICAgICAgICAgIGVsZW1lbnQuYXBwZW5kQ2hpbGQoZWwpO1xuXG4gICAgICAgICAgICBJMThuLnByb2Nlc3NTdHJpbmcobWF0Y2gyWzRdISwgZWxlbWVudCk7XG4gICAgICAgICAgICAvKiBlc2xpbnQtZW5hYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1ub24tbnVsbC1hc3NlcnRpb24gKi9cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVsZW1lbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoaHRtbC5yZXBsYWNlKC8mbmJzcDsvZywgJ1xcdTAwQTAnKSkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBlbGVtZW50cyB3aXRoIHNwZWNpZmllZCBhdHRyaWJ1dGVzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHRhZ05hbWUgLSBlbGVtZW50IHRhZ1xuICAgICAqIEBwYXJhbSBhdHRyaWJ1dGVzIC0gYXR0cmlidXRlcyBzdHJpbmcgdmFsdWVcbiAgICAgKlxuICAgICAqIEByZXR1cm5zIGNyZWF0ZWQgZWxlbWVudFxuICAgICAqL1xuICAgIHByaXZhdGUgc3RhdGljIGNyZWF0ZUVsZW1lbnQodGFnTmFtZTogc3RyaW5nLCBhdHRyaWJ1dGVzOiBzdHJpbmcpOiBFbGVtZW50IHtcbiAgICAgICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZ05hbWUpO1xuICAgICAgICBpZiAoIWF0dHJpYnV0ZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBlbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGF0dHJpYnV0ZXNcbiAgICAgICAgICAgIC5zcGxpdCgvKFthLXpdKz0nW14nXSsnKS8pXG4gICAgICAgICAgICAuZm9yRWFjaCgoYXR0cikgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghYXR0cikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3QgaW5kZXggPSBhdHRyLmluZGV4T2YoJz0nKTtcbiAgICAgICAgICAgICAgICBsZXQgYXR0ck5hbWU7XG4gICAgICAgICAgICAgICAgbGV0IGF0dHJWYWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGF0dHJOYW1lID0gYXR0ci5zdWJzdHJpbmcoMCwgaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICBhdHRyVmFsdWUgPSBhdHRyLnN1YnN0cmluZyhpbmRleCArIDIsIGF0dHIubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChhdHRyTmFtZSAmJiBhdHRyVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgZWwuc2V0QXR0cmlidXRlKGF0dHJOYW1lLCBhdHRyVmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBlbDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGaW5kcyBhbGwgZWxlbWVudHMgd2l0aCBzcGVjaWZpZWQge0BsaW5rIGkxOG5BdHRyaWJ1dGVOYW1lfSxcbiAgICAgKiB0cmFuc2xhdGVzIGF0dHJpYnV0ZXMgYW5kIHNldHMgdG8gZWxlbWVudHMge0BsaW5rIGF0dHJpYnV0ZU5hbWV9XG4gICAgICpcbiAgICAgKiBAcGFyYW0gaTE4bkF0dHJpYnV0ZU5hbWUgLSAgbmFtZSBvZiBpMThuIGF0dHJpYnV0ZVxuICAgICAqIEBwYXJhbSBhdHRyaWJ1dGVOYW1lICAtIG5hbWUgb2YgdHJhbnNsYXRlZCBhdHRyaWJ1dGVcbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyB0cmFuc2xhdGVBdHRyaWJ1dGVzKFxuICAgICAgICBpMThuQXR0cmlidXRlTmFtZTogc3RyaW5nLFxuICAgICAgICBhdHRyaWJ1dGVOYW1lOiBzdHJpbmcsXG4gICAgKTogdm9pZCB7XG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYFske2kxOG5BdHRyaWJ1dGVOYW1lfV1gKS5mb3JFYWNoKChlbGVtZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBtZXNzYWdlID0gSTE4bi5nZXRJMThuTWVzc2FnZShlbGVtZW50LCBpMThuQXR0cmlidXRlTmFtZSk7XG5cbiAgICAgICAgICAgIGlmICghbWVzc2FnZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoYXR0cmlidXRlTmFtZSwgbWVzc2FnZSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgZWxlbWVudCBhdHRyaWJ1dGUgdmFsdWUgYW5kIHRyYW5zbGF0ZSBpdC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBlbGVtZW50IC0gcGFnZSBlbGVtZW50XG4gICAgICogQHBhcmFtIGF0dHJpYnV0ZU5hbWUgLSBuYW1lIG9mIGVsZW1lbnQgYXR0cmlidXRlXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB0cmFuc2xhdGVkIGF0dHJpYnV0ZSB2YWx1ZVxuICAgICAqL1xuICAgIHByaXZhdGUgc3RhdGljIGdldEkxOG5NZXNzYWdlKGVsZW1lbnQ6IEVsZW1lbnQsIGF0dHJpYnV0ZU5hbWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgICAgICBjb25zdCBhdHRyaWJ1dGUgPSBlbGVtZW50LmdldEF0dHJpYnV0ZShhdHRyaWJ1dGVOYW1lKTtcblxuICAgICAgICBpZiAoIWF0dHJpYnV0ZSkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYnJvd3Nlci5pMThuLmdldE1lc3NhZ2UoYXR0cmlidXRlKTtcbiAgICB9XG59XG4iLCIvKipcbiAqIEBmaWxlXG4gKlxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5pbXBvcnQgeyBMb2dnZXIsIExvZ0xldmVsIH0gZnJvbSAnQGFkZ3VhcmQvbG9nZ2VyJztcblxuY2xhc3MgRXh0ZW5kZWRMb2dnZXIgZXh0ZW5kcyBMb2dnZXIge1xuICAgIGlzVmVyYm9zZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY3VycmVudExldmVsID09PSBMb2dMZXZlbC5EZWJ1Z1xuICAgICAgICAgICAgIHx8IHRoaXMuY3VycmVudExldmVsID09PSBMb2dMZXZlbC5UcmFjZTtcbiAgICB9XG59XG5cbmNvbnN0IGxvZ2dlciA9IG5ldyBFeHRlbmRlZExvZ2dlcigpO1xuXG5sb2dnZXIuY3VycmVudExldmVsID0gSVNfUkVMRUFTRSB8fCBJU19CRVRBXG4gICAgPyBMb2dMZXZlbC5JbmZvXG4gICAgOiBMb2dMZXZlbC5UcmFjZTtcblxuLy8gRXhwb3NlIGxvZ2dlciB0byB0aGUgd2luZG93IG9iamVjdCxcbi8vIHRvIGhhdmUgcG9zc2liaWxpdHkgdG8gc3dpdGNoIGxvZyBsZXZlbCBmcm9tIHRoZSBjb25zb2xlLlxuLy8gRXhhbXBsZTogYWRndWFyZC5sb2dnZXIuY3VycmVudExldmVsID0gJ2RlYnVnJ1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1nbG9iYWxzXG5PYmplY3QuYXNzaWduKHNlbGYsIHsgYWRndWFyZDogeyAuLi5zZWxmLmFkZ3VhcmQsIGxvZ2dlciB9IH0pO1xuXG5leHBvcnQgeyBMb2dMZXZlbCwgbG9nZ2VyIH07XG4iLCIvKipcbiAqIEBmaWxlXG4gKiBUaGlzIGZpbGUgaXMgcGFydCBvZiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIChodHRwczovL2dpdGh1Yi5jb20vQWRndWFyZFRlYW0vQWRndWFyZEJyb3dzZXJFeHRlbnNpb24pLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXG4gKiBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuXG4gKiBTZWUgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogWW91IHNob3VsZCBoYXZlIHJlY2VpdmVkIGEgY29weSBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2VcbiAqIGFsb25nIHdpdGggQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbi4gSWYgbm90LCBzZWUgPGh0dHA6Ly93d3cuZ251Lm9yZy9saWNlbnNlcy8+LlxuICovXG5cbi8qKlxuICogSW1wb3J0YW50OiBkbyBub3QgdXNlIHouaW5mZXJPZiwgYmVjYXVzZSBpdCBicmluZ3MgYSBsb3Qgb2Ygc2lkZSBlZmZlY3RzIHdpdGhcbiAqIG1hbnkgZGVwZW5kZW5jaWVzIHRvIHRoZSBidW5kbGUuXG4gKlxuICogQWxzbyBwbGVhc2UgdHJ5LCBpZiBwb3NzaWJsZSwgdG8gbm90IGltcG9ydCBoZXJlIGV4dGVybmFsIG1vZHVsZXNcbiAqIG90aGVyIHRoYXQgdHlwZXMuXG4gKi9cbmltcG9ydCB7IHR5cGUgV2luZG93cyB9IGZyb20gJ3dlYmV4dGVuc2lvbi1wb2x5ZmlsbCc7XG5cbmltcG9ydCB7IHR5cGUgRm9yd2FyZEZyb20gfSBmcm9tICcuLi9mb3J3YXJkJztcbmltcG9ydCB0eXBlIHtcbiAgICBDdXN0b21GaWx0ZXJNZXRhZGF0YSxcbiAgICBTZXR0aW5nT3B0aW9uLFxuICAgIFNldHRpbmdzLFxufSBmcm9tICcuLi8uLi9iYWNrZ3JvdW5kL3NjaGVtYSc7XG5pbXBvcnQgdHlwZSB7IE5vdGlmaWVyVHlwZSB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5pbXBvcnQgdHlwZSB7IEFwcGVhcmFuY2VUaGVtZSB9IGZyb20gJy4uL3NldHRpbmdzJztcbmltcG9ydCB0eXBlIHsgRmlsdGVyaW5nTG9nVGFiSW5mbyB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvYXBpL2ZpbHRlcmluZy1sb2cnO1xuaW1wb3J0IHR5cGUgeyBHZXRUYWJJbmZvRm9yUG9wdXBSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvdWkvcG9wdXAnO1xuaW1wb3J0IHR5cGUgeyBHZXRGaWx0ZXJpbmdMb2dEYXRhUmVzcG9uc2UgfSBmcm9tICcuLi8uLi9iYWNrZ3JvdW5kL3NlcnZpY2VzL2ZpbHRlcmluZy1sb2cnO1xuaW1wb3J0IHR5cGUge1xuICAgIElSdWxlc0xpbWl0cyxcbiAgICBNdjNMaW1pdHNDaGVja1Jlc3VsdCxcbiAgICBTdGF0aWNMaW1pdHNDaGVja1Jlc3VsdCxcbn0gZnJvbSAnLi4vLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy9ydWxlcy1saW1pdHMvaW50ZXJmYWNlJztcbmltcG9ydCB0eXBlIHsgUGFnZUluaXRBcHBEYXRhIH0gZnJvbSAnLi4vLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy91aS9tYWluJztcbmltcG9ydCB0eXBlIHsgRXhwb3J0TWVzc2FnZVJlc3BvbnNlLCBHZXRPcHRpb25zRGF0YVJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy9zZXR0aW5ncy90eXBlcyc7XG5pbXBvcnQgdHlwZSB7IENyZWF0ZUV2ZW50TGlzdGVuZXJSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvZXZlbnQnO1xuaW1wb3J0IHR5cGUgeyBGaWx0ZXJNZXRhZGF0YSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvYXBpL2ZpbHRlcnMvbWFpbic7XG5pbXBvcnQgdHlwZSB7IEdldEFsbG93bGlzdERvbWFpbnNSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvYWxsb3dsaXN0JztcbmltcG9ydCB0eXBlIHsgR2V0VXNlclJ1bGVzRWRpdG9yRGF0YVJlc3BvbnNlLCBHZXRVc2VyUnVsZXNSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvdXNlcnJ1bGVzJztcbmltcG9ydCB0eXBlIHsgR2V0Q3VzdG9tRmlsdGVySW5mb1Jlc3VsdCB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvYXBpJztcblxuZXhwb3J0IGNvbnN0IEFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSA9ICdhcHAnO1xuXG5leHBvcnQgdHlwZSBNZXNzYWdlQ29tbW9uUHJvcHMgPSB7XG4gICAgaGFuZGxlck5hbWU6IHR5cGVvZiBBUFBfTUVTU0FHRV9IQU5ETEVSX05BTUU7XG59O1xuXG4vKipcbiAqIE1lc3NhZ2UgdHlwZXMgdXNlZCBmb3IgbWVzc2FnZSBwYXNzaW5nIGJldHdlZW4gZXh0ZW5zaW9uIGNvbnRleHRzXG4gKiAocG9wdXAsIGZpbHRlcmluZyBsb2csIGNvbnRlbnQgc2NyaXB0cywgYmFja2dyb3VuZClcbiAqL1xuZXhwb3J0IGVudW0gTWVzc2FnZVR5cGUge1xuICAgIENyZWF0ZUV2ZW50TGlzdGVuZXIgPSAnY3JlYXRlRXZlbnRMaXN0ZW5lcicsXG4gICAgUmVtb3ZlTGlzdGVuZXIgPSAncmVtb3ZlTGlzdGVuZXInLFxuICAgIE9wZW5FeHRlbnNpb25TdG9yZSA9ICdvcGVuRXh0ZW5zaW9uU3RvcmUnLFxuICAgIEFkZEFuZEVuYWJsZUZpbHRlciA9ICdhZGRBbmRFbmFibGVGaWx0ZXInLFxuICAgIEFwcGx5U2V0dGluZ3NKc29uID0gJ2FwcGx5U2V0dGluZ3NKc29uJyxcbiAgICBPcGVuRmlsdGVyaW5nTG9nID0gJ29wZW5GaWx0ZXJpbmdMb2cnLFxuICAgIE9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzID0gJ29wZW5GdWxsc2NyZWVuVXNlclJ1bGVzJyxcbiAgICBVcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWUgPSAndXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lJyxcbiAgICBSZXNldEJsb2NrZWRBZHNDb3VudCA9ICdyZXNldEJsb2NrZWRBZHNDb3VudCcsXG4gICAgUmVzZXRTZXR0aW5ncyA9ICdyZXNldFNldHRpbmdzJyxcbiAgICBHZXRVc2VyUnVsZXMgPSAnZ2V0VXNlclJ1bGVzJyxcbiAgICBTYXZlVXNlclJ1bGVzID0gJ3NhdmVVc2VyUnVsZXMnLFxuICAgIEdldEFsbG93bGlzdERvbWFpbnMgPSAnZ2V0QWxsb3dsaXN0RG9tYWlucycsXG4gICAgU2F2ZUFsbG93bGlzdERvbWFpbnMgPSAnc2F2ZUFsbG93bGlzdERvbWFpbnMnLFxuICAgIENoZWNrRmlsdGVyc1VwZGF0ZSA9ICdjaGVja0ZpbHRlcnNVcGRhdGUnLFxuICAgIERpc2FibGVGaWx0ZXJzR3JvdXAgPSAnZGlzYWJsZUZpbHRlcnNHcm91cCcsXG4gICAgRGlzYWJsZUZpbHRlciA9ICdkaXNhYmxlRmlsdGVyJyxcbiAgICBMb2FkQ3VzdG9tRmlsdGVySW5mbyA9ICdsb2FkQ3VzdG9tRmlsdGVySW5mbycsXG4gICAgU3Vic2NyaWJlVG9DdXN0b21GaWx0ZXIgPSAnc3Vic2NyaWJlVG9DdXN0b21GaWx0ZXInLFxuICAgIFJlbW92ZUFudGlCYW5uZXJGaWx0ZXIgPSAncmVtb3ZlQW50aUJhbm5lckZpbHRlcicsXG4gICAgR2V0SXNFbmdpbmVTdGFydGVkID0gJ2dldElzRW5naW5lU3RhcnRlZCcsXG4gICAgR2V0VGFiSW5mb0ZvclBvcHVwID0gJ2dldFRhYkluZm9Gb3JQb3B1cCcsXG4gICAgQ2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWQgPSAnY2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWQnLFxuICAgIE9wZW5SdWxlc0xpbWl0c1RhYiA9ICdvcGVuUnVsZXNMaW1pdHNUYWInLFxuICAgIE9wZW5TZXR0aW5nc1RhYiA9ICdvcGVuU2V0dGluZ3NUYWInLFxuICAgIE9wZW5Bc3Npc3RhbnQgPSAnb3BlbkFzc2lzdGFudCcsXG4gICAgT3BlbkFidXNlVGFiID0gJ29wZW5BYnVzZVRhYicsXG4gICAgT3BlblNpdGVSZXBvcnRUYWIgPSAnb3BlblNpdGVSZXBvcnRUYWInLFxuICAgIE9wZW5Db21wYXJlUGFnZSA9ICdvcGVuQ29tcGFyZVBhZ2UnLFxuICAgIFJlc2V0VXNlclJ1bGVzRm9yUGFnZSA9ICdyZXNldFVzZXJSdWxlc0ZvclBhZ2UnLFxuICAgIFJlbW92ZUFsbG93bGlzdERvbWFpbiA9ICdyZW1vdmVBbGxvd2xpc3REb21haW4nLFxuICAgIEFkZEFsbG93bGlzdERvbWFpbiA9ICdhZGRBbGxvd2xpc3REb21haW4nLFxuICAgIE9uT3BlbkZpbHRlcmluZ0xvZ1BhZ2UgPSAnb25PcGVuRmlsdGVyaW5nTG9nUGFnZScsXG4gICAgR2V0RmlsdGVyaW5nTG9nRGF0YSA9ICdnZXRGaWx0ZXJpbmdMb2dEYXRhJyxcbiAgICBJbml0aWFsaXplRnJhbWVTY3JpcHQgPSAnaW5pdGlhbGl6ZUZyYW1lU2NyaXB0JyxcbiAgICBPbkNsb3NlRmlsdGVyaW5nTG9nUGFnZSA9ICdvbkNsb3NlRmlsdGVyaW5nTG9nUGFnZScsXG4gICAgR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQgPSAnZ2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQnLFxuICAgIFN5bmNocm9uaXplT3BlblRhYnMgPSAnc3luY2hyb25pemVPcGVuVGFicycsXG4gICAgQ2xlYXJFdmVudHNCeVRhYklkID0gJ2NsZWFyRXZlbnRzQnlUYWJJZCcsXG4gICAgUmVmcmVzaFBhZ2UgPSAncmVmcmVzaFBhZ2UnLFxuICAgIEFkZFVzZXJSdWxlID0gJ2FkZFVzZXJSdWxlJyxcbiAgICBSZW1vdmVVc2VyUnVsZSA9ICdyZW1vdmVVc2VyUnVsZScsXG4gICAgRW5hYmxlRmlsdGVyc0dyb3VwID0gJ2VuYWJsZUZpbHRlcnNHcm91cCcsXG4gICAgTm90aWZ5TGlzdGVuZXJzID0gJ25vdGlmeUxpc3RlbmVycycsXG4gICAgQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbiA9ICdhZGRMb25nTGl2ZWRDb25uZWN0aW9uJyxcbiAgICBHZXRPcHRpb25zRGF0YSA9ICdnZXRPcHRpb25zRGF0YScsXG4gICAgQ2hhbmdlVXNlclNldHRpbmdzID0gJ2NoYW5nZVVzZXJTZXR0aW5nJyxcbiAgICBDaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSA9ICdjaGVja1JlcXVlc3RGaWx0ZXJSZWFkeScsXG4gICAgT3BlblRoYW5reW91UGFnZSA9ICdvcGVuVGhhbmtZb3VQYWdlJyxcbiAgICBPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCA9ICdvcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCcsXG4gICAgR2V0U2VsZWN0b3JzQW5kU2NyaXB0cyA9ICdnZXRTZWxlY3RvcnNBbmRTY3JpcHRzJyxcbiAgICBDaGVja1BhZ2VTY3JpcHRXcmFwcGVyUmVxdWVzdCA9ICdjaGVja1BhZ2VTY3JpcHRXcmFwcGVyUmVxdWVzdCcsXG4gICAgUHJvY2Vzc1Nob3VsZENvbGxhcHNlID0gJ3Byb2Nlc3NTaG91bGRDb2xsYXBzZScsXG4gICAgUHJvY2Vzc1Nob3VsZENvbGxhcHNlTWFueSA9ICdwcm9jZXNzU2hvdWxkQ29sbGFwc2VNYW55JyxcbiAgICBBZGRGaWx0ZXJpbmdTdWJzY3JpcHRpb24gPSAnYWRkRmlsdGVyU3Vic2NyaXB0aW9uJyxcbiAgICBTZXROb3RpZmljYXRpb25WaWV3ZWQgPSAnc2V0Tm90aWZpY2F0aW9uVmlld2VkJyxcbiAgICBTYXZlQ3NzSGl0c1N0YXRzID0gJ3NhdmVDc3NIaXRTdGF0cycsXG4gICAgR2V0Q29va2llUnVsZXMgPSAnZ2V0Q29va2llUnVsZXMnLFxuICAgIFNhdmVDb29raWVMb2dFdmVudCA9ICdzYXZlQ29va2llUnVsZUV2ZW50JyxcbiAgICBMb2FkU2V0dGluZ3NKc29uID0gJ2xvYWRTZXR0aW5nc0pzb24nLFxuICAgIEFkZFVybFRvVHJ1c3RlZCA9ICdhZGRVcmxUb1RydXN0ZWQnLFxuICAgIFNldFByZXNlcnZlTG9nU3RhdGUgPSAnc2V0UHJlc2VydmVMb2dTdGF0ZScsXG4gICAgR2V0VXNlclJ1bGVzRWRpdG9yRGF0YSA9ICdnZXRVc2VyUnVsZXNFZGl0b3JEYXRhJyxcbiAgICBHZXRFZGl0b3JTdG9yYWdlQ29udGVudCA9ICdnZXRFZGl0b3JTdG9yYWdlQ29udGVudCcsXG4gICAgU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQgPSAnc2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQnLFxuICAgIFNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlID0gJ3NldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlJyxcbiAgICBBcHBJbml0aWFsaXplZCA9ICdhcHBJbml0aWFsaXplZCcsXG4gICAgVXBkYXRlVG90YWxCbG9ja2VkID0gJ3VwZGF0ZVRvdGFsQmxvY2tlZCcsXG4gICAgU2NyaXB0bGV0Q2xvc2VXaW5kb3cgPSAnc2NyaXB0bGV0Q2xvc2VXaW5kb3cnLFxuICAgIFNob3dSdWxlTGltaXRzQWxlcnQgPSAnc2hvd1J1bGVMaW1pdHNBbGVydCcsXG4gICAgU2hvd0FsZXJ0UG9wdXAgPSAnc2hvd0FsZXJ0UG9wdXAnLFxuICAgIFNob3dWZXJzaW9uVXBkYXRlZFBvcHVwID0gJ3Nob3dWZXJzaW9uVXBkYXRlZFBvcHVwJyxcbiAgICBVcGRhdGVMaXN0ZW5lcnMgPSAndXBkYXRlTGlzdGVuZXJzJyxcbiAgICBTZXRDb25zZW50ZWRGaWx0ZXJzID0gJ3NldENvbnNlbnRlZEZpbHRlcnMnLFxuICAgIEdldElzQ29uc2VudGVkRmlsdGVyID0gJ2dldElzQ29uc2VudGVkRmlsdGVyJyxcbiAgICBHZXRSdWxlc0xpbWl0c0NvdW50ZXJzTXYzID0gJ2dldFJ1bGVzTGltaXRzQ291bnRlcnNNdjMnLFxuICAgIENhbkVuYWJsZVN0YXRpY0ZpbHRlck12MyA9ICdjYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjMnLFxuICAgIENhbkVuYWJsZVN0YXRpY0dyb3VwTXYzID0gJ2NhbkVuYWJsZVN0YXRpY0dyb3VwTXYzJyxcbiAgICBDbGVhclJ1bGVzTGltaXRzV2FybmluZ012MyA9ICdjbGVhclJ1bGVzTGltaXRzV2FybmluZ012MycsXG4gICAgUmVzdG9yZUZpbHRlcnNNdjMgPSAncmVzdG9yZUZpbHRlcnNNdjMnLFxuICAgIEN1cnJlbnRMaW1pdHNNdjMgPSAnY3VycmVudExpbWl0c012MycsXG59XG5cbmV4cG9ydCB0eXBlIEFwcGx5U2V0dGluZ3NKc29uTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5BcHBseVNldHRpbmdzSnNvbixcbiAgICBkYXRhOiB7XG4gICAgICAgIGpzb246IHN0cmluZyxcbiAgICB9LFxufTtcblxuZXhwb3J0IHR5cGUgTG9hZFNldHRpbmdzSnNvbk1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuTG9hZFNldHRpbmdzSnNvbixcbiAgICBkYXRhOiB7XG4gICAgICAgIGpzb246IHN0cmluZyxcbiAgICB9LFxufTtcblxuZXhwb3J0IHR5cGUgQWRkRmlsdGVyaW5nU3Vic2NyaXB0aW9uTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5BZGRGaWx0ZXJpbmdTdWJzY3JpcHRpb24sXG4gICAgZGF0YToge1xuICAgICAgICB1cmw6IHN0cmluZyxcbiAgICAgICAgdGl0bGU/OiBzdHJpbmcsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgQ3JlYXRlRXZlbnRMaXN0ZW5lck1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ3JlYXRlRXZlbnRMaXN0ZW5lcixcbiAgICBkYXRhOiB7XG4gICAgICAgIGV2ZW50czogTm90aWZpZXJUeXBlW11cbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBSZW1vdmVMaXN0ZW5lck1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuUmVtb3ZlTGlzdGVuZXIsXG4gICAgZGF0YToge1xuICAgICAgICBsaXN0ZW5lcklkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgR2V0SXNFbmdpbmVTdGFydGVkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5HZXRJc0VuZ2luZVN0YXJ0ZWQsXG59O1xuXG5leHBvcnQgdHlwZSBHZXRUYWJJbmZvRm9yUG9wdXBNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldFRhYkluZm9Gb3JQb3B1cDtcbiAgICBkYXRhOiB7XG4gICAgICAgIHRhYklkOiBudW1iZXI7XG4gICAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIENoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5DaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZDtcbiAgICBkYXRhOiB7XG4gICAgICAgIHN0YXRlOiBib29sZWFuO1xuICAgIH07XG59O1xuXG5leHBvcnQgdHlwZSBPcGVuUnVsZXNMaW1pdHNUYWJNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk9wZW5SdWxlc0xpbWl0c1RhYjtcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5TZXR0aW5nc1RhYk1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlblNldHRpbmdzVGFiO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkFzc2lzdGFudE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlbkFzc2lzdGFudDtcbn07XG5cbmV4cG9ydCB0eXBlIFVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lO1xuICAgIGRhdGE6IHtcbiAgICAgICAgdGhlbWU6IEFwcGVhcmFuY2VUaGVtZTtcbiAgICB9O1xufTtcblxuZXhwb3J0IHR5cGUgQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbk1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbixcbiAgICBkYXRhOiB7XG4gICAgICAgIGV2ZW50czogTm90aWZpZXJUeXBlW11cbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBOb3RpZnlMaXN0ZW5lcnNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk5vdGlmeUxpc3RlbmVycyxcbiAgICBkYXRhOiBhbnk7XG59O1xuXG5leHBvcnQgdHlwZSBVcGRhdGVMaXN0ZW5lcnNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlVwZGF0ZUxpc3RlbmVycyxcbn07XG5cbmV4cG9ydCB0eXBlIENoZWNrRmlsdGVyc1VwZGF0ZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ2hlY2tGaWx0ZXJzVXBkYXRlO1xufTtcblxuZXhwb3J0IHR5cGUgR2V0QWxsb3dsaXN0RG9tYWluc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0QWxsb3dsaXN0RG9tYWlucztcbn07XG5cbmV4cG9ydCB0eXBlIFJlc2V0QmxvY2tlZEFkc0NvdW50TWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5SZXNldEJsb2NrZWRBZHNDb3VudDtcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5Db21wYXJlUGFnZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlbkNvbXBhcmVQYWdlO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkV4dGVuc2lvblN0b3JlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuRXh0ZW5zaW9uU3RvcmU7XG59O1xuXG5leHBvcnQgdHlwZSBPcGVuRmlsdGVyaW5nTG9nTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuRmlsdGVyaW5nTG9nO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkFidXNlVGFiTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuQWJ1c2VUYWI7XG4gICAgZGF0YToge1xuICAgICAgICB1cmw6IHN0cmluZztcbiAgICAgICAgZnJvbTogRm9yd2FyZEZyb207XG4gICAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5TaXRlUmVwb3J0VGFiTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuU2l0ZVJlcG9ydFRhYjtcbiAgICBkYXRhOiB7XG4gICAgICAgIHVybDogc3RyaW5nO1xuICAgICAgICBmcm9tOiBGb3J3YXJkRnJvbTtcbiAgICB9O1xufTtcblxuZXhwb3J0IHR5cGUgT3BlblRoYW5reW91UGFnZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZTtcbn07XG5cbmV4cG9ydCB0eXBlIEdldE9wdGlvbnNEYXRhTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5HZXRPcHRpb25zRGF0YTtcbn07XG5cbmV4cG9ydCB0eXBlIENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZTxUIGV4dGVuZHMgU2V0dGluZ09wdGlvbiA9IFNldHRpbmdPcHRpb24+ID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkNoYW5nZVVzZXJTZXR0aW5ncztcbiAgICBkYXRhOiB7XG4gICAgICAgIGtleTogVCxcbiAgICAgICAgdmFsdWU6IFNldHRpbmdzW1RdXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgUmVzZXRTZXR0aW5nc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuUmVzZXRTZXR0aW5nc1xufTtcblxuZXhwb3J0IHR5cGUgQWRkQW5kRW5hYmxlRmlsdGVyTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5BZGRBbmRFbmFibGVGaWx0ZXJcbiAgICBkYXRhOiB7XG4gICAgICAgIGZpbHRlcklkOiBudW1iZXJcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBEaXNhYmxlRmlsdGVyTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5EaXNhYmxlRmlsdGVyXG4gICAgZGF0YToge1xuICAgICAgICBmaWx0ZXJJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFJlbW92ZUFudGlCYW5uZXJGaWx0ZXJNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlbW92ZUFudGlCYW5uZXJGaWx0ZXJcbiAgICBkYXRhOiB7XG4gICAgICAgIGZpbHRlcklkOiBudW1iZXJcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBTYXZlQWxsb3dsaXN0RG9tYWluc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU2F2ZUFsbG93bGlzdERvbWFpbnNcbiAgICBkYXRhOiB7XG4gICAgICAgIHZhbHVlOiBzdHJpbmcsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgU2F2ZVVzZXJSdWxlc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU2F2ZVVzZXJSdWxlc1xuICAgIGRhdGE6IHtcbiAgICAgICAgdmFsdWU6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBHZXRVc2VyUnVsZXNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc1xufTtcblxuZXhwb3J0IHR5cGUgR2V0VXNlclJ1bGVzRWRpdG9yRGF0YU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0VXNlclJ1bGVzRWRpdG9yRGF0YVxufTtcblxuZXhwb3J0IHR5cGUgQWRkVXNlclJ1bGVNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkFkZFVzZXJSdWxlXG4gICAgZGF0YToge1xuICAgICAgICBydWxlVGV4dDogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFJlbW92ZVVzZXJSdWxlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5SZW1vdmVVc2VyUnVsZVxuICAgIGRhdGE6IHtcbiAgICAgICAgcnVsZVRleHQ6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBSZXNldFVzZXJSdWxlc0ZvclBhZ2VNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlc2V0VXNlclJ1bGVzRm9yUGFnZVxuICAgIGRhdGE6IHtcbiAgICAgICAgdXJsOiBzdHJpbmcsXG4gICAgICAgIHRhYklkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgR2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldEVkaXRvclN0b3JhZ2VDb250ZW50XG59O1xuXG5leHBvcnQgdHlwZSBTZXRFZGl0b3JTdG9yYWdlQ29udGVudE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRcbiAgICBkYXRhOiB7XG4gICAgICAgIGNvbnRlbnQ6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBBZGRBbGxvd2xpc3REb21haW5NZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkFkZEFsbG93bGlzdERvbWFpblxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBSZW1vdmVBbGxvd2xpc3REb21haW5NZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlbW92ZUFsbG93bGlzdERvbWFpblxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICAgICAgdGFiUmVmcmVzaDogYm9vbGVhbixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBMb2FkQ3VzdG9tRmlsdGVySW5mb01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuTG9hZEN1c3RvbUZpbHRlckluZm9cbiAgICBkYXRhOiB7XG4gICAgICAgIHVybDogc3RyaW5nLFxuICAgICAgICB0aXRsZT86IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBDdXN0b21GaWx0ZXJTdWJzY3JpcHRpb25EYXRhID0ge1xuICAgIGN1c3RvbVVybDogc3RyaW5nLFxuICAgIG5hbWU6IHN0cmluZyxcbiAgICB0cnVzdGVkOiBib29sZWFuLFxufTtcblxuZXhwb3J0IHR5cGUgU3Vic2NyaWJlVG9DdXN0b21GaWx0ZXJNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlN1YnNjcmliZVRvQ3VzdG9tRmlsdGVyXG4gICAgZGF0YToge1xuICAgICAgICBmaWx0ZXI6IEN1c3RvbUZpbHRlclN1YnNjcmlwdGlvbkRhdGFcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBBcHBJbml0aWFsaXplZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQXBwSW5pdGlhbGl6ZWRcbn07XG5cbmV4cG9ydCB0eXBlIFVwZGF0ZVRvdGFsQmxvY2tlZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuVXBkYXRlVG90YWxCbG9ja2VkXG4gICAgZGF0YToge1xuICAgICAgICB0YWJJZDogbnVtYmVyLFxuICAgICAgICB0b3RhbEJsb2NrZWQ6IG51bWJlcixcbiAgICAgICAgdG90YWxCbG9ja2VkVGFiOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgQ2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHlNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkNoZWNrUmVxdWVzdEZpbHRlclJlYWR5XG59O1xuXG5leHBvcnQgdHlwZSBHZXRGaWx0ZXJpbmdMb2dEYXRhTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5HZXRGaWx0ZXJpbmdMb2dEYXRhLFxufTtcblxuZXhwb3J0IHR5cGUgU3luY2hyb25pemVPcGVuVGFic01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU3luY2hyb25pemVPcGVuVGFicyxcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5GaWx0ZXJpbmdMb2dQYWdlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5Pbk9wZW5GaWx0ZXJpbmdMb2dQYWdlXG59O1xuXG5leHBvcnQgdHlwZSBDbG9zZUZpbHRlcmluZ0xvZ1BhZ2VNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk9uQ2xvc2VGaWx0ZXJpbmdMb2dQYWdlXG59O1xuXG5leHBvcnQgdHlwZSBDbGVhckV2ZW50c0J5VGFiSWRNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkNsZWFyRXZlbnRzQnlUYWJJZFxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICAgICAgaWdub3JlUHJlc2VydmVMb2c/OiBib29sZWFuLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFNldFByZXNlcnZlTG9nU3RhdGVNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlNldFByZXNlcnZlTG9nU3RhdGVcbiAgICBkYXRhOiB7XG4gICAgICAgIHN0YXRlOiBib29sZWFuLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZSxcbiAgICBkYXRhOiB7XG4gICAgICAgIHdpbmRvd1N0YXRlOiBXaW5kb3dzLkNyZWF0ZUNyZWF0ZURhdGFUeXBlXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgUmVmcmVzaFBhZ2VNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlLFxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBHZXRGaWx0ZXJpbmdJbmZvQnlUYWJJZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQsXG4gICAgZGF0YToge1xuICAgICAgICB0YWJJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIEVuYWJsZUZpbHRlcnNHcm91cE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuRW5hYmxlRmlsdGVyc0dyb3VwLFxuICAgIGRhdGE6IHtcbiAgICAgICAgZ3JvdXBJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIERpc2FibGVGaWx0ZXJzR3JvdXBNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXJzR3JvdXAsXG4gICAgZGF0YToge1xuICAgICAgICBncm91cElkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgSW5pdGlhbGl6ZUZyYW1lU2NyaXB0TWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5Jbml0aWFsaXplRnJhbWVTY3JpcHQsXG59O1xuXG5leHBvcnQgdHlwZSBTZXRDb25zZW50ZWRGaWx0ZXJzTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TZXRDb25zZW50ZWRGaWx0ZXJzLFxuICAgIGRhdGE6IHtcbiAgICAgICAgZmlsdGVySWRzOiBudW1iZXJbXSxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBHZXRJc0NvbnNlbnRlZEZpbHRlck1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0SXNDb25zZW50ZWRGaWx0ZXIsXG4gICAgZGF0YToge1xuICAgICAgICBmaWx0ZXJJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5TYWZlYnJvd3NpbmdUcnVzdGVkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCxcbiAgICBkYXRhOiB7XG4gICAgICAgIHVybDogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIEFkZFVybFRvVHJ1c3RlZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQWRkVXJsVG9UcnVzdGVkLFxuICAgIGRhdGE6IHtcbiAgICAgICAgdXJsOiBzdHJpbmcsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgU2V0Tm90aWZpY2F0aW9uVmlld2VkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TZXROb3RpZmljYXRpb25WaWV3ZWQsXG4gICAgZGF0YToge1xuICAgICAgICB3aXRoRGVsYXk6IGJvb2xlYW4sXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgU2NyaXB0bGV0Q2xvc2VXaW5kb3dNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlNjcmlwdGxldENsb3NlV2luZG93LFxufTtcblxuZXhwb3J0IHR5cGUgU2hvd0FsZXJ0UG9wdXBNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlNob3dBbGVydFBvcHVwLFxuICAgIGRhdGE6IHtcbiAgICAgICAgaXNBZGd1YXJkVGFiOiBib29sZWFuLFxuICAgICAgICB0aXRsZTogc3RyaW5nLFxuICAgICAgICB0ZXh0OiBzdHJpbmcgfCBzdHJpbmdbXSxcbiAgICAgICAgYWxlcnRTdHlsZXM6IHN0cmluZyxcbiAgICAgICAgYWxlcnRDb250YWluZXJTdHlsZXM6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBTaG93UnVsZUxpbWl0c0FsZXJ0TWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TaG93UnVsZUxpbWl0c0FsZXJ0LFxuICAgIGRhdGE6IHtcbiAgICAgICAgaXNBZGd1YXJkVGFiOiBib29sZWFuLFxuICAgICAgICBtYWluVGV4dDogc3RyaW5nLFxuICAgICAgICBsaW5rVGV4dDogc3RyaW5nLFxuICAgICAgICBhbGVydFN0eWxlczogc3RyaW5nLFxuICAgICAgICBhbGVydENvbnRhaW5lclN0eWxlczogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFNob3dWZXJzaW9uVXBkYXRlZFBvcHVwTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TaG93VmVyc2lvblVwZGF0ZWRQb3B1cCxcbiAgICBkYXRhOiB7XG4gICAgICAgIGlzQWRndWFyZFRhYjogYm9vbGVhbixcbiAgICAgICAgdGl0bGU6IHN0cmluZyxcbiAgICAgICAgZGVzY3JpcHRpb246IHN0cmluZyxcbiAgICAgICAgY2hhbmdlbG9nSHJlZjogc3RyaW5nLFxuICAgICAgICBjaGFuZ2Vsb2dUZXh0OiBzdHJpbmcsXG4gICAgICAgIHNob3dQcm9tb05vdGlmaWNhdGlvbjogYm9vbGVhbixcbiAgICAgICAgb2ZmZXI6IHN0cmluZyxcbiAgICAgICAgb2ZmZXJEZXNjOiBzdHJpbmcsXG4gICAgICAgIG9mZmVyQnV0dG9uVGV4dDogc3RyaW5nLFxuICAgICAgICBvZmZlckJ1dHRvbkhyZWY6IHN0cmluZyxcbiAgICAgICAgb2ZmZXJCZ0ltYWdlOiBzdHJpbmcsXG4gICAgICAgIGRpc2FibGVOb3RpZmljYXRpb25UZXh0OiBzdHJpbmcsXG4gICAgICAgIGFsZXJ0U3R5bGVzOiBzdHJpbmcsXG4gICAgICAgIGlmcmFtZVN0eWxlczogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIENhbkVuYWJsZVN0YXRpY0ZpbHRlck12M01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ2FuRW5hYmxlU3RhdGljRmlsdGVyTXYzLFxuICAgIGRhdGE6IHtcbiAgICAgICAgZmlsdGVySWQ6IG51bWJlcixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBDYW5FbmFibGVTdGF0aWNHcm91cE12M01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ2FuRW5hYmxlU3RhdGljR3JvdXBNdjMsXG4gICAgZGF0YToge1xuICAgICAgICBncm91cElkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgQ3VycmVudExpbWl0c012M01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012Mztcbn07XG5cbmV4cG9ydCB0eXBlIFJlc3RvcmVGaWx0ZXJzTXYzTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5SZXN0b3JlRmlsdGVyc012Mztcbn07XG5cbmV4cG9ydCB0eXBlIENsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5DbGVhclJ1bGVzTGltaXRzV2FybmluZ012Mztcbn07XG5cbmV4cG9ydCB0eXBlIEdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjM7XG59O1xuXG4vLyBVbmlmaWVkIG1lc3NhZ2UgbWFwIHRoYXQgaW5jbHVkZXMgYm90aCBtZXNzYWdlIHN0cnVjdHVyZSBhbmQgcmVzcG9uc2UgdHlwZXNcbmV4cG9ydCB0eXBlIE1lc3NhZ2VNYXAgPSB7XG4gICAgW01lc3NhZ2VUeXBlLkNyZWF0ZUV2ZW50TGlzdGVuZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IENyZWF0ZUV2ZW50TGlzdGVuZXJNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogQ3JlYXRlRXZlbnRMaXN0ZW5lclJlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbl06IHtcbiAgICAgICAgbWVzc2FnZTogQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQXBwbHlTZXR0aW5nc0pzb25dOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFwcGx5U2V0dGluZ3NKc29uTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5Mb2FkU2V0dGluZ3NKc29uXToge1xuICAgICAgICBtZXNzYWdlOiBMb2FkU2V0dGluZ3NKc29uTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEV4cG9ydE1lc3NhZ2VSZXNwb25zZTtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkFkZEZpbHRlcmluZ1N1YnNjcmlwdGlvbl06IHtcbiAgICAgICAgbWVzc2FnZTogQWRkRmlsdGVyaW5nU3Vic2NyaXB0aW9uTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5HZXRJc0VuZ2luZVN0YXJ0ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldElzRW5naW5lU3RhcnRlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBib29sZWFuO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0VGFiSW5mb0ZvclBvcHVwXToge1xuICAgICAgICBtZXNzYWdlOiBHZXRUYWJJbmZvRm9yUG9wdXBNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogR2V0VGFiSW5mb0ZvclBvcHVwUmVzcG9uc2UgfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5DaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZF06IHtcbiAgICAgICAgbWVzc2FnZTogQ2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLk9wZW5SdWxlc0xpbWl0c1RhYl06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlblJ1bGVzTGltaXRzVGFiTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5PcGVuU2V0dGluZ3NUYWJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IE9wZW5TZXR0aW5nc1RhYk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkFzc2lzdGFudF06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkFzc2lzdGFudE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lXToge1xuICAgICAgICBtZXNzYWdlOiBVcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlN5bmNocm9uaXplT3BlblRhYnNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFN5bmNocm9uaXplT3BlblRhYnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogRmlsdGVyaW5nTG9nVGFiSW5mb1tdO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2hlY2tGaWx0ZXJzVXBkYXRlXToge1xuICAgICAgICBtZXNzYWdlOiBDaGVja0ZpbHRlcnNVcGRhdGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogRmlsdGVyTWV0YWRhdGFbXSB8IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldEFsbG93bGlzdERvbWFpbnNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldEFsbG93bGlzdERvbWFpbnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogR2V0QWxsb3dsaXN0RG9tYWluc1Jlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkV4dGVuc2lvblN0b3JlXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuRXh0ZW5zaW9uU3RvcmVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLk9wZW5Db21wYXJlUGFnZV06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkNvbXBhcmVQYWdlTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5PcGVuRnVsbHNjcmVlblVzZXJSdWxlc106IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlc2V0QmxvY2tlZEFkc0NvdW50XToge1xuICAgICAgICBtZXNzYWdlOiBSZXNldEJsb2NrZWRBZHNDb3VudE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkZpbHRlcmluZ0xvZ106IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkZpbHRlcmluZ0xvZ01lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkFidXNlVGFiXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuQWJ1c2VUYWJNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLk9wZW5TaXRlUmVwb3J0VGFiXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuU2l0ZVJlcG9ydFRhYk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZV06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlblRoYW5reW91UGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0T3B0aW9uc0RhdGFdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldE9wdGlvbnNEYXRhTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEdldE9wdGlvbnNEYXRhUmVzcG9uc2U7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5DaGFuZ2VVc2VyU2V0dGluZ3NdOiB7XG4gICAgICAgIG1lc3NhZ2U6IENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5SZXNldFNldHRpbmdzXToge1xuICAgICAgICBtZXNzYWdlOiBSZXNldFNldHRpbmdzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRBbmRFbmFibGVGaWx0ZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFkZEFuZEVuYWJsZUZpbHRlck1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5EaXNhYmxlRmlsdGVyXToge1xuICAgICAgICBtZXNzYWdlOiBEaXNhYmxlRmlsdGVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5SZW1vdmVBbnRpQmFubmVyRmlsdGVyXToge1xuICAgICAgICBtZXNzYWdlOiBSZW1vdmVBbnRpQmFubmVyRmlsdGVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TYXZlQWxsb3dsaXN0RG9tYWluc106IHtcbiAgICAgICAgbWVzc2FnZTogU2F2ZUFsbG93bGlzdERvbWFpbnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNhdmVVc2VyUnVsZXNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNhdmVVc2VyUnVsZXNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc106IHtcbiAgICAgICAgbWVzc2FnZTogR2V0VXNlclJ1bGVzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEdldFVzZXJSdWxlc1Jlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0VXNlclJ1bGVzRWRpdG9yRGF0YV06IHtcbiAgICAgICAgbWVzc2FnZTogR2V0VXNlclJ1bGVzRWRpdG9yRGF0YU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBHZXRVc2VyUnVsZXNFZGl0b3JEYXRhUmVzcG9uc2U7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRVc2VyUnVsZV06IHtcbiAgICAgICAgbWVzc2FnZTogQWRkVXNlclJ1bGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlbW92ZVVzZXJSdWxlXToge1xuICAgICAgICBtZXNzYWdlOiBSZW1vdmVVc2VyUnVsZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuUmVzZXRVc2VyUnVsZXNGb3JQYWdlXToge1xuICAgICAgICBtZXNzYWdlOiBSZXNldFVzZXJSdWxlc0ZvclBhZ2VNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldEVkaXRvclN0b3JhZ2VDb250ZW50XToge1xuICAgICAgICBtZXNzYWdlOiBHZXRFZGl0b3JTdG9yYWdlQ29udGVudE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXRFZGl0b3JTdG9yYWdlQ29udGVudF06IHtcbiAgICAgICAgbWVzc2FnZTogU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlbW92ZUFsbG93bGlzdERvbWFpbl06IHtcbiAgICAgICAgbWVzc2FnZTogUmVtb3ZlQWxsb3dsaXN0RG9tYWluTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRBbGxvd2xpc3REb21haW5dOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFkZEFsbG93bGlzdERvbWFpbk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuTG9hZEN1c3RvbUZpbHRlckluZm9dOiB7XG4gICAgICAgIG1lc3NhZ2U6IExvYWRDdXN0b21GaWx0ZXJJbmZvTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEdldEN1c3RvbUZpbHRlckluZm9SZXN1bHQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TdWJzY3JpYmVUb0N1c3RvbUZpbHRlcl06IHtcbiAgICAgICAgbWVzc2FnZTogU3Vic2NyaWJlVG9DdXN0b21GaWx0ZXJNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogQ3VzdG9tRmlsdGVyTWV0YWRhdGE7XG4gICAgfVxuICAgIC8vIFRoaXMgbWVzc2FnZSBpcyBzZW50IGZyb20gYmFja2dyb3VuZCBhbmQgaGFuZGxlZCBvbiBVSSBzaWRlLlxuICAgIFtNZXNzYWdlVHlwZS5BcHBJbml0aWFsaXplZF06IHtcbiAgICAgICAgbWVzc2FnZTogQXBwSW5pdGlhbGl6ZWRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogbmV2ZXI7XG4gICAgfVxuICAgIC8vIFRoaXMgbWVzc2FnZSBpcyBzZW50IGZyb20gYmFja2dyb3VuZCBhbmQgaGFuZGxlZCBvbiBVSSBzaWRlLlxuICAgIFtNZXNzYWdlVHlwZS5VcGRhdGVUb3RhbEJsb2NrZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFVwZGF0ZVRvdGFsQmxvY2tlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBuZXZlcjtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0xvZ0RhdGFdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldEZpbHRlcmluZ0xvZ0RhdGFNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogR2V0RmlsdGVyaW5nTG9nRGF0YVJlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHldOiB7XG4gICAgICAgIG1lc3NhZ2U6IENoZWNrUmVxdWVzdEZpbHRlclJlYWR5TWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5Pbk9wZW5GaWx0ZXJpbmdMb2dQYWdlXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuRmlsdGVyaW5nTG9nUGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT25DbG9zZUZpbHRlcmluZ0xvZ1BhZ2VdOiB7XG4gICAgICAgIG1lc3NhZ2U6IENsb3NlRmlsdGVyaW5nTG9nUGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2xlYXJFdmVudHNCeVRhYklkXToge1xuICAgICAgICBtZXNzYWdlOiBDbGVhckV2ZW50c0J5VGFiSWRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNldFByZXNlcnZlTG9nU3RhdGVdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNldFByZXNlcnZlTG9nU3RhdGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlXToge1xuICAgICAgICBtZXNzYWdlOiBSZWZyZXNoUGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldEZpbHRlcmluZ0luZm9CeVRhYklkTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEZpbHRlcmluZ0xvZ1RhYkluZm8gfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZV06IHtcbiAgICAgICAgbWVzc2FnZTogU2V0RmlsdGVyaW5nTG9nV2luZG93U3RhdGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkVuYWJsZUZpbHRlcnNHcm91cF06IHtcbiAgICAgICAgbWVzc2FnZTogRW5hYmxlRmlsdGVyc0dyb3VwTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IG51bWJlcltdIHwgdW5kZWZpbmVkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuRGlzYWJsZUZpbHRlcnNHcm91cF06IHtcbiAgICAgICAgbWVzc2FnZTogRGlzYWJsZUZpbHRlcnNHcm91cE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlblNhZmVicm93c2luZ1RydXN0ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IE9wZW5TYWZlYnJvd3NpbmdUcnVzdGVkTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXROb3RpZmljYXRpb25WaWV3ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNldE5vdGlmaWNhdGlvblZpZXdlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBQcm9taXNlPHZvaWQ+O1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuUmVtb3ZlTGlzdGVuZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFJlbW92ZUxpc3RlbmVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TY3JpcHRsZXRDbG9zZVdpbmRvd106IHtcbiAgICAgICAgbWVzc2FnZTogU2NyaXB0bGV0Q2xvc2VXaW5kb3dNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNob3dSdWxlTGltaXRzQWxlcnRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNob3dSdWxlTGltaXRzQWxlcnRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogYm9vbGVhbjtcbiAgICB9XG4gICAgLy8gVGhpcyBtZXNzYWdlIGlzIHNlbnQgZnJvbSBiYWNrZ3JvdW5kIGFuZCBoYW5kbGVkIG9uIFVJIHNpZGUuXG4gICAgW01lc3NhZ2VUeXBlLk5vdGlmeUxpc3RlbmVyc106IHtcbiAgICAgICAgbWVzc2FnZTogTm90aWZ5TGlzdGVuZXJzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IG5ldmVyO1xuICAgIH1cbiAgICAvLyBUaGlzIG1lc3NhZ2UgaXMgc2VudCBmcm9tIGJhY2tncm91bmQgYW5kIGhhbmRsZWQgb24gVUkgc2lkZS5cbiAgICBbTWVzc2FnZVR5cGUuVXBkYXRlTGlzdGVuZXJzXToge1xuICAgICAgICBtZXNzYWdlOiBVcGRhdGVMaXN0ZW5lcnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogbmV2ZXI7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TaG93QWxlcnRQb3B1cF06IHtcbiAgICAgICAgbWVzc2FnZTogU2hvd0FsZXJ0UG9wdXBNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNob3dWZXJzaW9uVXBkYXRlZFBvcHVwXToge1xuICAgICAgICBtZXNzYWdlOiBTaG93VmVyc2lvblVwZGF0ZWRQb3B1cE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBib29sZWFuO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0SXNDb25zZW50ZWRGaWx0ZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldElzQ29uc2VudGVkRmlsdGVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXRDb25zZW50ZWRGaWx0ZXJzXToge1xuICAgICAgICBtZXNzYWdlOiBTZXRDb25zZW50ZWRGaWx0ZXJzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRVcmxUb1RydXN0ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFkZFVybFRvVHJ1c3RlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012M106IHtcbiAgICAgICAgbWVzc2FnZTogQ3VycmVudExpbWl0c012M01lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBNdjNMaW1pdHNDaGVja1Jlc3VsdDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogSVJ1bGVzTGltaXRzIHwgdW5kZWZpbmVkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2FuRW5hYmxlU3RhdGljRmlsdGVyTXYzXToge1xuICAgICAgICBtZXNzYWdlOiBDYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogU3RhdGljTGltaXRzQ2hlY2tSZXN1bHQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5DYW5FbmFibGVTdGF0aWNHcm91cE12M106IHtcbiAgICAgICAgbWVzc2FnZTogQ2FuRW5hYmxlU3RhdGljR3JvdXBNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogU3RhdGljTGltaXRzQ2hlY2tSZXN1bHQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5SZXN0b3JlRmlsdGVyc012M106IHtcbiAgICAgICAgbWVzc2FnZTogUmVzdG9yZUZpbHRlcnNNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkNsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzXToge1xuICAgICAgICBtZXNzYWdlOiBDbGVhclJ1bGVzTGltaXRzV2FybmluZ012M01lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuSW5pdGlhbGl6ZUZyYW1lU2NyaXB0XToge1xuICAgICAgICBtZXNzYWdlOiBJbml0aWFsaXplRnJhbWVTY3JpcHRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogUGFnZUluaXRBcHBEYXRhO1xuICAgIH1cbn07XG5cbi8qKlxuICogSGVscGVyIHR5cGUgdG8gY2hlY2sgaWYgYSBnaXZlbiB0eXBlIGlzIGEgdmFsaWQgbWVzc2FnZSB0eXBlLlxuICovXG5leHBvcnQgdHlwZSBWYWxpZE1lc3NhZ2VUeXBlcyA9IGtleW9mIE1lc3NhZ2VNYXA7XG5cbi8qKlxuICogQWxsIG1lc3NhZ2VzIHRoYXQgY2FuIGJlIHNlbnQuXG4gKi9cbmV4cG9ydCB0eXBlIE1lc3NhZ2UgPSBNZXNzYWdlTWFwW1ZhbGlkTWVzc2FnZVR5cGVzXVsnbWVzc2FnZSddICYgTWVzc2FnZUNvbW1vblByb3BzO1xuXG4vKipcbiAqIEhlbHBlciB0eXBlIHRvIGV4dHJhY3QgdGhlIG1lc3NhZ2UgdHlwZSBmb3IgYSBnaXZlbiBtZXNzYWdlLlxuICovXG5leHBvcnQgdHlwZSBFeHRyYWN0ZWRNZXNzYWdlPFQ+ID0gRXh0cmFjdDxNZXNzYWdlLCB7IHR5cGU6IFQgfT47XG5cbi8qKlxuICogSGVscGVyIHR5cGUgdG8gZXh0cmFjdCB0aGUgcmVzcG9uc2UgdHlwZSBmb3IgYSBnaXZlbiBtZXNzYWdlIHR5cGVcbiAqL1xuZXhwb3J0IHR5cGUgRXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+ID0gTWVzc2FnZU1hcFtUXVsncmVzcG9uc2UnXTtcblxuLyoqXG4gKiBIZWxwZXIgdHlwZSB0byBleHRyYWN0IHRoZSBtZXNzYWdlIHR5cGUgZm9yIGEgZ2l2ZW4gbWVzc2FnZSB3aXRob3V0IGhhbmRsZXJOYW1lLlxuICovXG5leHBvcnQgdHlwZSBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+ID0geyB0eXBlOiBUIH0gJiBPbWl0PEV4dHJhY3RlZE1lc3NhZ2U8VD4sICdoYW5kbGVyTmFtZSc+O1xuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2NvbnN0YW50cyc7XG5leHBvcnQgKiBmcm9tICcuL3NlbmQtbWVzc2FnZSc7XG5leHBvcnQgKiBmcm9tICcuL21lc3NhZ2UtaGFuZGxlcic7XG4iLCIvKipcbiAqIEBmaWxlXG4gKiBUaGlzIGZpbGUgaXMgcGFydCBvZiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIChodHRwczovL2dpdGh1Yi5jb20vQWRndWFyZFRlYW0vQWRndWFyZEJyb3dzZXJFeHRlbnNpb24pLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXG4gKiBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuXG4gKiBTZWUgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogWW91IHNob3VsZCBoYXZlIHJlY2VpdmVkIGEgY29weSBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2VcbiAqIGFsb25nIHdpdGggQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbi4gSWYgbm90LCBzZWUgPGh0dHA6Ly93d3cuZ251Lm9yZy9saWNlbnNlcy8+LlxuICovXG5pbXBvcnQgYnJvd3NlciwgeyBSdW50aW1lIH0gZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJztcblxuaW1wb3J0IHsgdHlwZSBFbmdpbmVNZXNzYWdlIH0gZnJvbSAnZW5naW5lJztcblxuaW1wb3J0IHtcbiAgICB0eXBlIE1lc3NhZ2VUeXBlLFxuICAgIHR5cGUgTWVzc2FnZSxcbiAgICB0eXBlIEV4dHJhY3RlZE1lc3NhZ2UsXG4gICAgdHlwZSBWYWxpZE1lc3NhZ2VUeXBlcyxcbiAgICB0eXBlIEV4dHJhY3RNZXNzYWdlUmVzcG9uc2UsXG4gICAgQVBQX01FU1NBR0VfSEFORExFUl9OQU1FLFxufSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbmV4cG9ydCB0eXBlIE1lc3NhZ2VMaXN0ZW5lcjxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+ID0gKFxuICAgIG1lc3NhZ2U6IEV4dHJhY3RlZE1lc3NhZ2U8VD4sXG4gICAgc2VuZGVyOiBSdW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4pID0+IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxUPj4gfCBFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPFQ+O1xuXG4vKipcbiAqIFR5cGUgZ3VhcmQgZm9yIG1lc3NhZ2VzIHRoYXQgaGF2ZSBhICd0eXBlJyBmaWVsZCB3aXRoIHBvc3NpYmxlIHtAbGluayBNZXNzYWdlVHlwZX0uXG4gKlxuICogQG5vdGUgQWRkZWQgdG8gbm8gYnJpbmcgaGVyZSBodWdlIHpvZCBsaWJyYXJ5LlxuICpcbiAqIEBwYXJhbSBtZXNzYWdlIFVua25vd24gbWVzc2FnZS5cbiAqXG4gKiBAcmV0dXJucyBUcnVlIGlmIG1lc3NhZ2UgaGFzICd0eXBlJyBmaWVsZCB3aXRoIHBvc3NpYmxlIHtAbGluayBNZXNzYWdlVHlwZX0uXG4gKi9cbmV4cG9ydCBjb25zdCBtZXNzYWdlSGFzVHlwZUZpZWxkID0gKG1lc3NhZ2U6IHVua25vd24pOiBtZXNzYWdlIGlzIHsgdHlwZTogTWVzc2FnZVR5cGUgfSA9PiB7XG4gICAgcmV0dXJuIHR5cGVvZiBtZXNzYWdlID09PSAnb2JqZWN0JyAmJiBtZXNzYWdlICE9PSBudWxsICYmICd0eXBlJyBpbiBtZXNzYWdlO1xufTtcblxuLyoqXG4gKiBUeXBlIGd1YXJkIGZvciBtZXNzYWdlcyB0aGF0IGhhdmUgYSAndHlwZScgZmllbGQgYW5kICdkYXRhJyBmaWVsZCBhbmQgbG9va3MgbGlrZSB7QGxpbmsgTWVzc2FnZX0uXG4gKlxuICogQG5vdGUgQWRkZWQgdG8gbm8gYnJpbmcgaGVyZSBodWdlIHpvZCBsaWJyYXJ5LlxuICpcbiAqIEBwYXJhbSBtZXNzYWdlIFVua25vd24gbWVzc2FnZS5cbiAqXG4gKiBAcmV0dXJucyBUcnVlIGlmIG1lc3NhZ2UgaGFzICd0eXBlJyBhbmQgJ2RhdGEnIGZpZWxkcyBhbmQgbG9va3MgbGlrZSB7QGxpbmsgTWVzc2FnZX0uXG4gKi9cbmV4cG9ydCBjb25zdCBtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMgPSAobWVzc2FnZTogdW5rbm93bik6IG1lc3NhZ2UgaXMgTWVzc2FnZSA9PiB7XG4gICAgcmV0dXJuIG1lc3NhZ2VIYXNUeXBlRmllbGQobWVzc2FnZSkgJiYgJ2RhdGEnIGluIG1lc3NhZ2U7XG59O1xuXG4vKipcbiAqIEFQSSBmb3IgaGFuZGxpbmcgTWVzc2FnZXMgdmlhIHtAbGluayBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlfVxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTWVzc2FnZUhhbmRsZXIge1xuICAgIHByb3RlY3RlZCBsaXN0ZW5lcnMgPSBuZXcgTWFwPFZhbGlkTWVzc2FnZVR5cGVzLCBNZXNzYWdlTGlzdGVuZXI8VmFsaWRNZXNzYWdlVHlwZXM+PigpO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuaGFuZGxlTWVzc2FnZSA9IHRoaXMuaGFuZGxlTWVzc2FnZS5iaW5kKHRoaXMpO1xuICAgIH1cblxuICAgIHB1YmxpYyBpbml0KCk6IHZvaWQge1xuICAgICAgICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKHRoaXMuaGFuZGxlTWVzc2FnZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkIG1lc3NhZ2UgbGlzdGVuZXIuXG4gICAgICogTGlzdGVuZXJzIGxpbWl0ZWQgdG8gMSBwZXIgbWVzc2FnZSB0eXBlIHRvIHByZXZlbnQgcmFjZVxuICAgICAqIGNvbmRpdGlvbiB3aGlsZSByZXNwb25zZSBwcm9jZXNzaW5nLlxuICAgICAqXG4gICAgICogVE9ETzogaW1wbGVtZW50IGxpc3RlbmVycyBwcmlvcml0eSBleGVjdXRpb24gc3RyYXRlZ3lcbiAgICAgKlxuICAgICAqIEBwYXJhbSB0eXBlIC0ge0BsaW5rIFZhbGlkTWVzc2FnZVR5cGVzfVxuICAgICAqIEBwYXJhbSBsaXN0ZW5lciAtIHtAbGluayBNZXNzYWdlTGlzdGVuZXJ9XG4gICAgICpcbiAgICAgKiBAdGhyb3dzIGVycm9yLCBpZiBtZXNzYWdlIGxpc3RlbmVyIGFscmVhZHkgYWRkZWRcbiAgICAgKi9cbiAgICBwdWJsaWMgYWRkTGlzdGVuZXI8VCBleHRlbmRzIFZhbGlkTWVzc2FnZVR5cGVzPihcbiAgICAgICAgdHlwZTogVCxcbiAgICAgICAgbGlzdGVuZXI6IE1lc3NhZ2VMaXN0ZW5lcjxUPixcbiAgICApOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMubGlzdGVuZXJzLmhhcyh0eXBlKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNZXNzYWdlIGhhbmRsZXI6ICR7dHlwZX0gbGlzdGVuZXIgaGFzIGFscmVhZHkgYmVlbiByZWdpc3RlcmVkYCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDYXN0IHRocm91Z2ggdW5rbm93biB0byBoZWxwIFRTIHVuZGVyc3RhbmQgdGhhdCB0aGUgbGlzdGVuZXIgaXMgb2ZcbiAgICAgICAgLy8gdGhlIGNvcnJlY3QgdHlwZS4gSXQgd2lsbCBjaGVjayB0eXBlcyBhdCBjb21waWxlIHRpbWUuXG4gICAgICAgIHRoaXMubGlzdGVuZXJzLnNldCh0eXBlLCBsaXN0ZW5lciBhcyB1bmtub3duIGFzIE1lc3NhZ2VMaXN0ZW5lcjxWYWxpZE1lc3NhZ2VUeXBlcz4pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlbW92ZXMgbWVzc2FnZSBsaXN0ZW5lci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0eXBlIC0ge0BsaW5rIFZhbGlkTWVzc2FnZVR5cGVzfVxuICAgICAqL1xuICAgIHB1YmxpYyByZW1vdmVMaXN0ZW5lcjxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+KHR5cGU6IFQpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5saXN0ZW5lcnMuZGVsZXRlKHR5cGUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlbW92ZXMgYWxsIGxpc3RlbmVyc1xuICAgICAqL1xuICAgIHB1YmxpYyByZW1vdmVMaXN0ZW5lcnMoKTogdm9pZCB7XG4gICAgICAgIHRoaXMubGlzdGVuZXJzLmNsZWFyKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIG1lc3NhZ2UgaXMgb2YgdHlwZSB7QGxpbmsgTWVzc2FnZX0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbWVzc2FnZSBNZXNzYWdlIG9mIGJhc2ljIHR5cGUge0BsaW5rIE1lc3NhZ2V9IG9yIHtAbGluayBFbmdpbmVNZXNzYWdlfS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFRydWUgaWYgdGhlIG1lc3NhZ2UgaXMgb2YgdHlwZSB7QGxpbmsgTWVzc2FnZX0uXG4gICAgICovXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBpc1ZhbGlkTWVzc2FnZVR5cGUobWVzc2FnZTogTWVzc2FnZSB8IEVuZ2luZU1lc3NhZ2UpOiBtZXNzYWdlIGlzIE1lc3NhZ2Uge1xuICAgICAgICByZXR1cm4gbWVzc2FnZS5oYW5kbGVyTmFtZSA9PT0gQVBQX01FU1NBR0VfSEFORExFUl9OQU1FICYmICd0eXBlJyBpbiBtZXNzYWdlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZXMgZGF0YSBmcm9tIHtAbGluayBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlfSBhbmQgbWF0Y2ggc3BlY2lmaWVkIGxpc3RlbmVyLlxuICAgICAqXG4gICAgICogQHBhcmFtIG1lc3NhZ2UgLSB7QGxpbmsgTWVzc2FnZX1cbiAgICAgKiBAcGFyYW0gc2VuZGVyIC0gQW4gb2JqZWN0IGNvbnRhaW5pbmcgaW5mb3JtYXRpb24gYWJvdXQgdGhlIHNjcmlwdCBjb250ZXh0IHRoYXQgc2VudCBhIG1lc3NhZ2Ugb3IgcmVxdWVzdC5cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgaGFuZGxlTWVzc2FnZShcbiAgICAgICAgbWVzc2FnZTogTWVzc2FnZSB8IHVua25vd24sXG4gICAgICAgIHNlbmRlcjogUnVudGltZS5NZXNzYWdlU2VuZGVyXG4gICAgKTogUHJvbWlzZTx1bmtub3duPiB8IHVuZGVmaW5lZDtcbn1cbiIsIi8qKlxuICogQGZpbGVcbiAqIFRoaXMgZmlsZSBpcyBwYXJ0IG9mIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gKGh0dHBzOi8vZ2l0aHViLmNvbS9BZGd1YXJkVGVhbS9BZGd1YXJkQnJvd3NlckV4dGVuc2lvbikuXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBmcmVlIHNvZnR3YXJlOiB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbiwgZWl0aGVyIHZlcnNpb24gMyBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBkaXN0cmlidXRlZCBpbiB0aGUgaG9wZSB0aGF0IGl0IHdpbGwgYmUgdXNlZnVsLFxuICogYnV0IFdJVEhPVVQgQU5ZIFdBUlJBTlRZOyB3aXRob3V0IGV2ZW4gdGhlIGltcGxpZWQgd2FycmFudHkgb2ZcbiAqIE1FUkNIQU5UQUJJTElUWSBvciBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRS5cbiAqIFNlZSB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgZm9yIG1vcmUgZGV0YWlscy5cbiAqXG4gKiBZb3Ugc2hvdWxkIGhhdmUgcmVjZWl2ZWQgYSBjb3B5IG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZVxuICogYWxvbmcgd2l0aCBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uLiBJZiBub3QsIHNlZSA8aHR0cDovL3d3dy5nbnUub3JnL2xpY2Vuc2VzLz4uXG4gKi9cblxuaW1wb3J0IGJyb3dzZXIgZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJztcblxuaW1wb3J0IHtcbiAgICBNZXNzYWdlVHlwZSxcbiAgICBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lLFxuICAgIEFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSxcbn0gZnJvbSAnLi9jb25zdGFudHMnO1xuXG4vKipcbiAqIFRPRE86IENvbnNpZGVyIG1vdmluZyB0aGlzIGZpbGUgdG8gdGhlIGJhY2tncm91bmQgZm9sZGVyLCBiZWNhdXNlIGFsbCBtZXNzYWdlc1xuICogZnJvbSB0aGUgVUkgc2hvdWxkIGJlIHNlbmQgdmlhIG1ldGhvZHMgb2YgTWVzc2VuZ2VyIGNsYXNzIGluc3RlYWQgb2YgdXNpbmdcbiAqIGRpcmVjdGx5IHNlbmRNZXNzYWdlIHRvIHByb3BlciB0eXBlcyBjaGVja2luZy5cbiAqXG4gKiB7QGxpbmsgc2VuZE1lc3NhZ2V9IHNlbmRzIGFwcCBtZXNzYWdlIHZpYSB7QGxpbmsgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlfSBhbmRcbiAqIGdldHMgcmVzcG9uc2UgZnJvbSBhbm90aGVyIGV4dGVuc2lvbiBwYWdlIG1lc3NhZ2UgaGFuZGxlclxuICpcbiAqIEBwYXJhbSBtZXNzYWdlIC0gcGFydGlhbCB7QGxpbmsgTWVzc2FnZX0gcmVjb3JkIHdpdGhvdXQge0BsaW5rIE1lc3NhZ2UuaGFuZGxlck5hbWV9IGZpZWxkXG4gKlxuICogQHJldHVybnMgbWVzc2FnZSBoYW5kbGVyIHJlc3BvbnNlXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kTWVzc2FnZTxUIGV4dGVuZHMgTWVzc2FnZVR5cGU+KFxuICAgIG1lc3NhZ2U6IE1lc3NhZ2VXaXRob3V0SGFuZGxlck5hbWU8VD4sXG4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICAgIGhhbmRsZXJOYW1lOiBBUFBfTUVTU0FHRV9IQU5ETEVSX05BTUUsXG4gICAgICAgICAgICAuLi5tZXNzYWdlLFxuICAgICAgICB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIGRvIG5vdGhpbmdcbiAgICB9XG59XG5cbi8qKlxuICoge0BsaW5rIHNlbmRUYWJNZXNzYWdlfSBzZW5kcyBtZXNzYWdlIHRvIHNwZWNpZmllZCB0YWIgdmlhIHtAbGluayBicm93c2VyLnRhYnMuc2VuZE1lc3NhZ2V9IGFuZFxuICogZ2V0cyByZXNwb25zZSBmcm9tIGl0XG4gKlxuICogQHBhcmFtIHRhYklkIC0gdGFiIGlkXG4gKiBAcGFyYW0gbWVzc2FnZSAtIHBhcnRpYWwge0BsaW5rIE1lc3NhZ2V9IHJlY29yZCB3aXRob3V0IHtAbGluayBNZXNzYWdlLmhhbmRsZXJOYW1lfSBmaWVsZFxuICpcbiAqIEByZXR1cm5zIHRhYiBtZXNzYWdlIGhhbmRsZXIgcmVzcG9uc2VcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRUYWJNZXNzYWdlPFQgZXh0ZW5kcyBNZXNzYWdlVHlwZT4oXG4gICAgdGFiSWQ6IG51bWJlcixcbiAgICBtZXNzYWdlOiBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+LFxuKTogUHJvbWlzZTx1bmtub3duPiB7XG4gICAgcmV0dXJuIGJyb3dzZXIudGFicy5zZW5kTWVzc2FnZSh0YWJJZCwge1xuICAgICAgICBoYW5kbGVyTmFtZTogQVBQX01FU1NBR0VfSEFORExFUl9OQU1FLFxuICAgICAgICAuLi5tZXNzYWdlLFxuICAgIH0pO1xufVxuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG4vLyBAdHMtaWdub3JlXG5pbXBvcnQgTmFub2JhciBmcm9tICduYW5vYmFyJztcblxuaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSAnLi4vY29tbW9uL2xvZ2dlcic7XG5cbmltcG9ydCB7IG1lc3NlbmdlciB9IGZyb20gJy4vc2VydmljZXMvbWVzc2VuZ2VyJztcblxuZXhwb3J0IGNsYXNzIFBvc3RJbnN0YWxsIHtcbiAgICBwcml2YXRlIHN0YXRpYyBuYW5vYmFyID0gbmV3IE5hbm9iYXIoe1xuICAgICAgICBjbGFzc25hbWU6ICdhZGctcHJvZ3Jlc3MtYmFyJyxcbiAgICB9KTtcblxuICAgIHByaXZhdGUgc3RhdGljIGNoZWNrUmVxdWVzdFRpbWVvdXRNcyA9IDUwMDtcblxuICAgIHByaXZhdGUgc3RhdGljIG9wZW5UaGFua3lvdVBhZ2VUaW1lb3V0TXMgPSAxMDAwO1xuXG4gICAgcHVibGljIHN0YXRpYyBpbml0KCk6IHZvaWQge1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgUG9zdEluc3RhbGwub25ET01Db250ZW50TG9hZGVkKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBvbkRPTUNvbnRlbnRMb2FkZWQoKTogdm9pZCB7XG4gICAgICAgIFBvc3RJbnN0YWxsLm5hbm9iYXIuZ28oMTUpO1xuXG4gICAgICAgIFBvc3RJbnN0YWxsLmNoZWNrUmVxdWVzdEZpbHRlclJlYWR5KCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgY2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZWFkeSA9IGF3YWl0IG1lc3Nlbmdlci5jaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSgpO1xuXG4gICAgICAgICAgICBpZiAocmVhZHkpIHtcbiAgICAgICAgICAgICAgICBQb3N0SW5zdGFsbC5vbkVuZ2luZUxvYWRlZCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KFBvc3RJbnN0YWxsLmNoZWNrUmVxdWVzdEZpbHRlclJlYWR5LCBQb3N0SW5zdGFsbC5jaGVja1JlcXVlc3RUaW1lb3V0TXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBsb2dnZXIuZXJyb3IoZSk7XG4gICAgICAgICAgICAvLyByZXRyeSByZXF1ZXN0LCBpZiBtZXNzYWdlIGhhbmRsZXIgaXMgbm90IHJlYWR5XG4gICAgICAgICAgICBzZXRUaW1lb3V0KFBvc3RJbnN0YWxsLmNoZWNrUmVxdWVzdEZpbHRlclJlYWR5LCBQb3N0SW5zdGFsbC5jaGVja1JlcXVlc3RUaW1lb3V0TXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25FbmdpbmVMb2FkZWQoKTogdm9pZCB7XG4gICAgICAgIFBvc3RJbnN0YWxsLm5hbm9iYXIuZ28oMTAwKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBpZiAod2luZG93KSB7XG4gICAgICAgICAgICAgICAgbWVzc2VuZ2VyLm9wZW5UaGFua3lvdVBhZ2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgUG9zdEluc3RhbGwub3BlblRoYW5reW91UGFnZVRpbWVvdXRNcyk7XG4gICAgfVxufVxuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5pbXBvcnQgYnJvd3NlciBmcm9tICd3ZWJleHRlbnNpb24tcG9seWZpbGwnO1xuaW1wb3J0IHsgbmFub2lkIH0gZnJvbSAnbmFub2lkJztcblxuaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSAnLi4vLi4vY29tbW9uL2xvZ2dlcic7XG5pbXBvcnQge1xuICAgIEFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSxcbiAgICBNZXNzYWdlVHlwZSxcbiAgICBtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMsXG4gICAgbWVzc2FnZUhhc1R5cGVGaWVsZCxcbn0gZnJvbSAnLi4vLi4vY29tbW9uL21lc3NhZ2VzJztcbmltcG9ydCB0eXBlIHtcbiAgICBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lLFxuICAgIENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZSxcbiAgICBBZGRBbmRFbmFibGVGaWx0ZXJNZXNzYWdlLFxuICAgIERpc2FibGVGaWx0ZXJNZXNzYWdlLFxuICAgIEFwcGx5U2V0dGluZ3NKc29uTWVzc2FnZSxcbiAgICBTZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZU1lc3NhZ2UsXG4gICAgU2F2ZVVzZXJSdWxlc01lc3NhZ2UsXG4gICAgU2V0Q29uc2VudGVkRmlsdGVyc01lc3NhZ2UsXG4gICAgR2V0SXNDb25zZW50ZWRGaWx0ZXJNZXNzYWdlLFxuICAgIExvYWRDdXN0b21GaWx0ZXJJbmZvTWVzc2FnZSxcbiAgICBTdWJzY3JpYmVUb0N1c3RvbUZpbHRlck1lc3NhZ2UsXG4gICAgUmVtb3ZlQW50aUJhbm5lckZpbHRlck1lc3NhZ2UsXG4gICAgR2V0VGFiSW5mb0ZvclBvcHVwTWVzc2FnZSxcbiAgICBDaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZE1lc3NhZ2UsXG4gICAgT3BlbkFidXNlVGFiTWVzc2FnZSxcbiAgICBPcGVuU2l0ZVJlcG9ydFRhYk1lc3NhZ2UsXG4gICAgUmVzZXRVc2VyUnVsZXNGb3JQYWdlTWVzc2FnZSxcbiAgICBSZW1vdmVBbGxvd2xpc3REb21haW5NZXNzYWdlLFxuICAgIEFkZEFsbG93bGlzdERvbWFpbk1lc3NhZ2UsXG4gICAgR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWRNZXNzYWdlLFxuICAgIENsZWFyRXZlbnRzQnlUYWJJZE1lc3NhZ2UsXG4gICAgUmVmcmVzaFBhZ2VNZXNzYWdlLFxuICAgIEFkZFVzZXJSdWxlTWVzc2FnZSxcbiAgICBSZW1vdmVVc2VyUnVsZU1lc3NhZ2UsXG4gICAgU2V0UHJlc2VydmVMb2dTdGF0ZU1lc3NhZ2UsXG4gICAgU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRNZXNzYWdlLFxuICAgIENhbkVuYWJsZVN0YXRpY0ZpbHRlck12M01lc3NhZ2UsXG4gICAgQ2FuRW5hYmxlU3RhdGljR3JvdXBNdjNNZXNzYWdlLFxuICAgIEV4dHJhY3RNZXNzYWdlUmVzcG9uc2UsXG4gICAgVmFsaWRNZXNzYWdlVHlwZXMsXG4gICAgU2V0Tm90aWZpY2F0aW9uVmlld2VkTWVzc2FnZSxcbiAgICBVcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWVNZXNzYWdlLFxuICAgIEFkZFVybFRvVHJ1c3RlZE1lc3NhZ2UsXG4gICAgRXh0cmFjdGVkTWVzc2FnZSxcbiAgICBPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZE1lc3NhZ2UsXG59IGZyb20gJy4uLy4uL2NvbW1vbi9tZXNzYWdlcyc7XG5pbXBvcnQgeyBOb3RpZmllclR5cGUgfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IENyZWF0ZUV2ZW50TGlzdGVuZXJSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvZXZlbnQnO1xuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJy4uLy4uL2NvbW1vbi9tZXNzYWdlcycpLk1lc3NhZ2VNYXB9IE1lc3NhZ2VNYXBcbiAqL1xuXG4vKipcbiAqIFR5cGUgb2YgbWVzc2FnZSBmb3IgbG9uZy1saXZlZCBjb25uZWN0aW9uIGxpc3RlbmVyIGNhbGxiYWNrIG1lc3NhZ2UgYXJndW1lbnQuXG4gKi9cbmV4cG9ydCB0eXBlIExvbmdMaXZlZENvbm5lY3Rpb25DYWxsYmFja01lc3NhZ2UgPSB7XG4gICAgLyoqXG4gICAgICogVHlwZSBvZiBub3RpZmllci5cbiAgICAgKi9cbiAgICB0eXBlOiBOb3RpZmllclR5cGUsXG5cbiAgICAvKipcbiAgICAgKiBEYXRhIG9mIG5vdGlmaWVyLlxuICAgICAqL1xuICAgIGRhdGE6IGFueSxcbn07XG5cbmV4cG9ydCBjb25zdCBlbnVtIFBhZ2Uge1xuICAgIEZ1bGxzY3JlZW5Vc2VyUnVsZXMgPSAnZnVsbHNjcmVlbi11c2VyLXJ1bGVzJyxcbiAgICBGaWx0ZXJpbmdMb2cgPSAnZmlsdGVyaW5nLWxvZycsXG59XG5cbnR5cGUgVW5sb2FkQ2FsbGJhY2sgPSAoKSA9PiB2b2lkO1xuXG4vKipcbiAqIE1lc3NlbmdlciBjbGFzcywgdXNlZCB0byBjb21tdW5pY2F0ZSB3aXRoIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgZnJvbSB0aGUgVUkuXG4gKiBBY3R1YWxseSwgaXQncyBhIHdyYXBwZXIgYXJvdW5kIHRoZSBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UgbWV0aG9kLlxuICovXG5jbGFzcyBNZXNzZW5nZXIge1xuICAgIG9uTWVzc2FnZSA9IGJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2U7XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGFuIGluc3RhbmNlIG9mIHRoZSBNZXNzZW5nZXIgY2xhc3MuXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMucmVzZXRVc2VyUnVsZXNGb3JQYWdlID0gdGhpcy5yZXNldFVzZXJSdWxlc0ZvclBhZ2UuYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy51cGRhdGVGaWx0ZXJzID0gdGhpcy51cGRhdGVGaWx0ZXJzLmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMucmVtb3ZlQWxsb3dsaXN0RG9tYWluID0gdGhpcy5yZW1vdmVBbGxvd2xpc3REb21haW4uYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy5hZGRBbGxvd2xpc3REb21haW4gPSB0aGlzLmFkZEFsbG93bGlzdERvbWFpbi5iaW5kKHRoaXMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlLlxuICAgICAqXG4gICAgICogQWxsIG1lc3NhZ2VzIGRlc2NyaWJlZCBpbiB0aGUge0BsaW5rIE1lc3NhZ2VUeXBlfSBlbnVtLlxuICAgICAqIEFsbCBhbnN3ZXJzIGRlc2NyaWJlZCBpbiB0aGUge0BsaW5rIE1lc3NhZ2VNYXB9IHR5cGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdHlwZSBNZXNzYWdlIHR5cGUuXG4gICAgICogQHBhcmFtIGRhdGEgTWVzc2FnZSBkYXRhLiBPcHRpb25hbCBiZWNhdXNlIG5vdCBhbGwgbWVzc2FnZXMgaGF2ZSBkYXRhLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3BvbnNlIGZyb20gdGhlIGJhY2tncm91bmQgcGFnZS5cbiAgICAgKiBUeXBlIG9mIHRoZSByZXNwb25zZSBkZXBlbmRzIG9uIHRoZSBtZXNzYWdlIHR5cGUuIEdvIHRvIHtAbGluayBNZXNzYWdlTWFwfVxuICAgICAqIHRvIHNlZSBhbGwgcG9zc2libGUgbWVzc2FnZSB0eXBlcyBhbmQgdGhlaXIgcmVzcG9uc2VzLlxuICAgICAqL1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gICAgcHJpdmF0ZSBhc3luYyBzZW5kTWVzc2FnZTxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+KFxuICAgICAgICB0eXBlOiBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+Wyd0eXBlJ10sXG4gICAgICAgIGRhdGE/OiAnZGF0YScgZXh0ZW5kcyBrZXlvZiBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+ID8gTWVzc2FnZVdpdGhvdXRIYW5kbGVyTmFtZTxUPlsnZGF0YSddIDogdW5kZWZpbmVkLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxUPj4ge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgICAgICBoYW5kbGVyTmFtZTogQVBQX01FU1NBR0VfSEFORExFUl9OQU1FLFxuICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgIGRhdGEsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZSBhcyBFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPFQ+O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgbG9uZy1saXZlZCBjb25uZWN0aW9ucyBiZXR3ZWVuIHBvcHVwIGFuZCBiYWNrZ3JvdW5kIHBhZ2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcGFnZSBQYWdlIG5hbWUuXG4gICAgICogQHBhcmFtIGV2ZW50cyBMaXN0IG9mIGV2ZW50cyB0byB3aGljaCBzdWJzY3JpYmUuXG4gICAgICogQHBhcmFtIGNhbGxiYWNrIENhbGxiYWNrIGNhbGxlZCB3aGVuIGV2ZW50IGZpcmVzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgRnVuY3Rpb24gdG8gcmVtb3ZlIGxpc3RlbmVyIG9uIHVubG9hZC5cbiAgICAgKi9cbiAgICBzdGF0aWMgY3JlYXRlTG9uZ0xpdmVkQ29ubmVjdGlvbiA9IChcbiAgICAgICAgcGFnZTogUGFnZSxcbiAgICAgICAgZXZlbnRzOiBOb3RpZmllclR5cGVbXSxcbiAgICAgICAgY2FsbGJhY2s6IChtZXNzYWdlOiBMb25nTGl2ZWRDb25uZWN0aW9uQ2FsbGJhY2tNZXNzYWdlKSA9PiB2b2lkLFxuICAgICk6IFVubG9hZENhbGxiYWNrID0+IHtcbiAgICAgICAgbGV0IHBvcnQ6IGJyb3dzZXIuUnVudGltZS5Qb3J0O1xuICAgICAgICBsZXQgZm9yY2VEaXNjb25uZWN0ZWQgPSBmYWxzZTtcblxuICAgICAgICBjb25zdCBjb25uZWN0ID0gKCk6IHZvaWQgPT4ge1xuICAgICAgICAgICAgcG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHsgbmFtZTogYCR7cGFnZX1fJHtuYW5vaWQoKX1gIH0pO1xuICAgICAgICAgICAgcG9ydC5wb3N0TWVzc2FnZSh7IHR5cGU6IE1lc3NhZ2VUeXBlLkFkZExvbmdMaXZlZENvbm5lY3Rpb24sIGRhdGE6IHsgZXZlbnRzIH0gfSk7XG5cbiAgICAgICAgICAgIHBvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKChtZXNzYWdlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFtZXNzYWdlSGFzVHlwZUZpZWxkKG1lc3NhZ2UpKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcignUmVjZWl2ZWQgbWVzc2FnZSBpbiBNZXNzZW5nZXIuY3JlYXRlTG9uZ0xpdmVkQ29ubmVjdGlvbiBoYXMgbm8gdHlwZSBmaWVsZDogJywgbWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS50eXBlID09PSBNZXNzYWdlVHlwZS5Ob3RpZnlMaXN0ZW5lcnMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMobWVzc2FnZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcignUmVjZWl2ZWQgbWVzc2FnZSB3aXRoIHR5cGUgTWVzc2FnZVR5cGUuTm90aWZ5TGlzdGVuZXJzIGhhcyBubyBkYXRhOiAnLCBtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhc3RlZE1lc3NhZ2UgPSBtZXNzYWdlIGFzIEV4dHJhY3RlZE1lc3NhZ2U8TWVzc2FnZVR5cGUuTm90aWZ5TGlzdGVuZXJzPjtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBbdHlwZSwgLi4uZGF0YV0gPSBjYXN0ZWRNZXNzYWdlLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKHsgdHlwZSwgZGF0YSB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChicm93c2VyLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihicm93c2VyLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyB3ZSB0cnkgdG8gY29ubmVjdCBhZ2FpbiBpZiB0aGUgYmFja2dyb3VuZCBwYWdlIHdhcyB0ZXJtaW5hdGVkXG4gICAgICAgICAgICAgICAgaWYgKCFmb3JjZURpc2Nvbm5lY3RlZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25uZWN0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29ubmVjdCgpO1xuXG4gICAgICAgIGNvbnN0IG9uVW5sb2FkID0gKCk6IHZvaWQgPT4ge1xuICAgICAgICAgICAgaWYgKHBvcnQpIHtcbiAgICAgICAgICAgICAgICBmb3JjZURpc2Nvbm5lY3RlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JlZm9yZXVubG9hZCcsIG9uVW5sb2FkKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3VubG9hZCcsIG9uVW5sb2FkKTtcblxuICAgICAgICByZXR1cm4gb25VbmxvYWQ7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIE1ldGhvZCBzdWJzY3JpYmVzIHRvIG5vdGlmaWVyIG1vZHVsZSBldmVudHMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXZlbnRzIExpc3Qgb2YgZXZlbnRzIHRvIHdoaWNoIHN1YnNjcmliZS5cbiAgICAgKiBAcGFyYW0gY2FsbGJhY2sgQ2FsbGJhY2sgY2FsbGVkIHdoZW4gZXZlbnQgZmlyZXMuXG4gICAgICogQHBhcmFtIG9uVW5sb2FkQ2FsbGJhY2sgQ2FsbGJhY2sgdXNlZCB0byByZW1vdmUgbGlzdGVuZXIgb24gdW5sb2FkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgRnVuY3Rpb24gdG8gcmVtb3ZlIGxpc3RlbmVyIG9uIHVubG9hZC5cbiAgICAgKi9cbiAgICBjcmVhdGVFdmVudExpc3RlbmVyID0gYXN5bmMgKFxuICAgICAgICBldmVudHM6IE5vdGlmaWVyVHlwZVtdLFxuICAgICAgICBjYWxsYmFjazogKG1lc3NhZ2U6IExvbmdMaXZlZENvbm5lY3Rpb25DYWxsYmFja01lc3NhZ2UpID0+IHZvaWQsXG4gICAgICAgIG9uVW5sb2FkQ2FsbGJhY2s/OiAoKSA9PiB2b2lkLFxuICAgICk6IFByb21pc2U8VW5sb2FkQ2FsbGJhY2s+ID0+IHtcbiAgICAgICAgbGV0IGxpc3RlbmVySWQ6IG51bWJlciB8IG51bGw7XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2U6IENyZWF0ZUV2ZW50TGlzdGVuZXJSZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICBNZXNzYWdlVHlwZS5DcmVhdGVFdmVudExpc3RlbmVyLFxuICAgICAgICAgICAgeyBldmVudHMgfSxcbiAgICAgICAgKTtcblxuICAgICAgICBsaXN0ZW5lcklkID0gcmVzcG9uc2UubGlzdGVuZXJJZDtcblxuICAgICAgICBjb25zdCBvblVwZGF0ZUxpc3RlbmVycyA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRSZXNwb25zZTogQ3JlYXRlRXZlbnRMaXN0ZW5lclJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShcbiAgICAgICAgICAgICAgICBNZXNzYWdlVHlwZS5DcmVhdGVFdmVudExpc3RlbmVyLFxuICAgICAgICAgICAgICAgIHsgZXZlbnRzIH0sXG4gICAgICAgICAgICApO1xuXG4gICAgICAgICAgICBsaXN0ZW5lcklkID0gdXBkYXRlZFJlc3BvbnNlLmxpc3RlbmVySWQ7XG4gICAgICAgIH07XG5cbiAgICAgICAgYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSkgPT4ge1xuICAgICAgICAgICAgaWYgKCFtZXNzYWdlSGFzVHlwZUZpZWxkKG1lc3NhZ2UpKSB7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmVycm9yKCdSZWNlaXZlZCBtZXNzYWdlIGluIE1lc3Nlbmdlci5jcmVhdGVFdmVudExpc3RlbmVyIGhhcyBubyB0eXBlIGZpZWxkOiAnLCBtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobWVzc2FnZS50eXBlID09PSBNZXNzYWdlVHlwZS5Ob3RpZnlMaXN0ZW5lcnMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIW1lc3NhZ2VIYXNUeXBlQW5kRGF0YUZpZWxkcyhtZXNzYWdlKSkge1xuICAgICAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoJ1JlY2VpdmVkIG1lc3NhZ2Ugd2l0aCB0eXBlIE1lc3NhZ2VUeXBlLk5vdGlmeUxpc3RlbmVycyBoYXMgbm8gZGF0YTogJywgbWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3QgY2FzdGVkTWVzc2FnZSA9IG1lc3NhZ2UgYXMgRXh0cmFjdGVkTWVzc2FnZTxNZXNzYWdlVHlwZS5Ob3RpZnlMaXN0ZW5lcnM+O1xuXG4gICAgICAgICAgICAgICAgY29uc3QgW3R5cGUsIC4uLmRhdGFdID0gY2FzdGVkTWVzc2FnZS5kYXRhO1xuXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50cy5pbmNsdWRlcyh0eXBlKSkge1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayh7IHR5cGUsIGRhdGEgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTWVzc2FnZVR5cGUuVXBkYXRlTGlzdGVuZXJzKSB7XG4gICAgICAgICAgICAgICAgb25VcGRhdGVMaXN0ZW5lcnMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3Qgb25VbmxvYWQgPSAoKTogdm9pZCA9PiB7XG4gICAgICAgICAgICBpZiAoIWxpc3RlbmVySWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICAgICAgTWVzc2FnZVR5cGUuUmVtb3ZlTGlzdGVuZXIsXG4gICAgICAgICAgICAgICAgeyBsaXN0ZW5lcklkIH0sXG4gICAgICAgICAgICApO1xuXG4gICAgICAgICAgICBsaXN0ZW5lcklkID0gbnVsbDtcblxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvblVubG9hZENhbGxiYWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgb25VbmxvYWRDYWxsYmFjaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBvblVubG9hZCk7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd1bmxvYWQnLCBvblVubG9hZCk7XG5cbiAgICAgICAgcmV0dXJuIG9uVW5sb2FkO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgZnJvbSBiYWNrZ3JvdW5kIHBhZ2UgdG8gdXBkYXRlIGxpc3RlbmVycyBvbiB0aGUgVUkuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2hlbiB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUxpc3RlbmVycygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuVXBkYXRlTGlzdGVuZXJzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5VcGRhdGVMaXN0ZW5lcnMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGdldCB0aGUgc2V0dGluZ3MgZGF0YSBmb3JcbiAgICAgKiB0aGUgb3B0aW9ucyBwYWdlIHdpdGggc29tZSBhZGRpdGlvbmFsIGluZm8uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgc2V0dGluZ3MgZGF0YSBmb3JcbiAgICAgKiB0aGUgb3B0aW9ucyBwYWdlIHdpdGggc29tZSBhZGRpdGlvbmFsIGluZm8uXG4gICAgICovXG4gICAgYXN5bmMgZ2V0T3B0aW9uc0RhdGEoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldE9wdGlvbnNEYXRhPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRPcHRpb25zRGF0YSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hhbmdlIHRoZSB1c2VyIHNldHRpbmcuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc2V0dGluZ0lkIFNldHRpbmcgaWRlbnRpZmllci5cbiAgICAgKiBAcGFyYW0gdmFsdWUgU2V0dGluZyB2YWx1ZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIGNoYW5nZVVzZXJTZXR0aW5nKFxuICAgICAgICBzZXR0aW5nSWQ6IENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZVsnZGF0YSddWydrZXknXSxcbiAgICAgICAgdmFsdWU6IENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZVsnZGF0YSddWyd2YWx1ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5DaGFuZ2VVc2VyU2V0dGluZ3M+PiB7XG4gICAgICAgIGF3YWl0IHRoaXMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICBNZXNzYWdlVHlwZS5DaGFuZ2VVc2VyU2V0dGluZ3MsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAga2V5OiBzZXR0aW5nSWQsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIGV4dGVuc2lvbiBzdG9yZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIG9wZW5FeHRlbnNpb25TdG9yZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkV4dGVuc2lvblN0b3JlPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuRXh0ZW5zaW9uU3RvcmUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIGNvbXBhcmUgcGFnZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIG9wZW5Db21wYXJlUGFnZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkNvbXBhcmVQYWdlPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuQ29tcGFyZVBhZ2UpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGVuYWJsZSBhIGZpbHRlciBieSBmaWx0ZXIgaWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZmlsdGVySWQgRmlsdGVyIGlkZW50aWZpZXIuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBlbmFibGVGaWx0ZXIoXG4gICAgICAgIGZpbHRlcklkOiBBZGRBbmRFbmFibGVGaWx0ZXJNZXNzYWdlWydkYXRhJ11bJ2ZpbHRlcklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkFkZEFuZEVuYWJsZUZpbHRlcj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQWRkQW5kRW5hYmxlRmlsdGVyLCB7IGZpbHRlcklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGRpc2FibGUgYSBmaWx0ZXIgYnkgZmlsdGVyIGlkLlxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbHRlcklkIEZpbHRlciBpZGVudGlmaWVyLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgZGlzYWJsZUZpbHRlcihcbiAgICAgICAgZmlsdGVySWQ6IERpc2FibGVGaWx0ZXJNZXNzYWdlWydkYXRhJ11bJ2ZpbHRlcklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXI+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXIsIHsgZmlsdGVySWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gYXBwbHkgc2V0dGluZ3MgZnJvbSBhIEpTT04gb2JqZWN0LlxuICAgICAqXG4gICAgICogQHBhcmFtIGpzb24gSlNPTiBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBzZXR0aW5ncyB0byBhcHBseS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIGFwcGx5U2V0dGluZ3NKc29uKFxuICAgICAgICBqc29uOiBBcHBseVNldHRpbmdzSnNvbk1lc3NhZ2VbJ2RhdGEnXVsnanNvbiddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5BcHBseVNldHRpbmdzSnNvbj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQXBwbHlTZXR0aW5nc0pzb24sIHsganNvbiB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBvcGVuIHRoZSBmaWx0ZXJpbmcgbG9nLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlbkZpbHRlcmluZ0xvZygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkZpbHRlcmluZ0xvZz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlbkZpbHRlcmluZ0xvZyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gcmVzZXQgdGhlIGJsb2NrZWQgYWRzIHN0YXRpc3RpY3MuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyByZXNldFN0YXRpc3RpY3MoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlJlc2V0QmxvY2tlZEFkc0NvdW50Pj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5SZXNldEJsb2NrZWRBZHNDb3VudCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2V0IHRoZSBmaWx0ZXJpbmcgbG9nIHdpbmRvdyBzdGF0ZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB3aW5kb3dTdGF0ZSBTdGF0ZSBvZiB0aGUgZmlsdGVyaW5nIGxvZyB3aW5kb3cuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBzZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZShcbiAgICAgICAgd2luZG93U3RhdGU6IFNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlTWVzc2FnZVsnZGF0YSddWyd3aW5kb3dTdGF0ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuU2V0RmlsdGVyaW5nTG9nV2luZG93U3RhdGUsIHsgd2luZG93U3RhdGUgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gcmVzZXQgdGhlIHNldHRpbmdzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgcmVzZXRTZXR0aW5ncygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuUmVzZXRTZXR0aW5ncz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuUmVzZXRTZXR0aW5ncyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IHRoZSB1c2VyIHJ1bGVzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHVzZXIgcnVsZXMuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0VXNlclJ1bGVzKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5HZXRVc2VyUnVsZXM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2F2ZSB1c2VyIHJ1bGVzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHZhbHVlIFVzZXIgcnVsZXMgdmFsdWUgdG8gc2F2ZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHNhdmVVc2VyUnVsZXMoXG4gICAgICAgIHZhbHVlOiBTYXZlVXNlclJ1bGVzTWVzc2FnZVsnZGF0YSddWyd2YWx1ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TYXZlVXNlclJ1bGVzPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlNhdmVVc2VyUnVsZXMsIHsgdmFsdWUgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gb3BlbiB1c2VyIHJ1bGVzIGVkaXRvciBpbiBmdWxsc2NyZWVuLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXMoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuRnVsbHNjcmVlblVzZXJSdWxlcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IHRoZSBhbGxvd2xpc3QgZG9tYWlucy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBsaXN0IG9mIGFsbG93bGlzdCBkb21haW5zLlxuICAgICAqL1xuICAgIGFzeW5jIGdldEFsbG93bGlzdCgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0QWxsb3dsaXN0RG9tYWlucz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuR2V0QWxsb3dsaXN0RG9tYWlucyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2F2ZSB0aGUgYWxsb3dsaXN0IGRvbWFpbnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdmFsdWUgQWxsb3dsaXN0IGRvbWFpbnMgdmFsdWUgdG8gc2F2ZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHNhdmVBbGxvd2xpc3QoXG4gICAgICAgIHZhbHVlOiBTYXZlVXNlclJ1bGVzTWVzc2FnZVsnZGF0YSddWyd2YWx1ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TYXZlQWxsb3dsaXN0RG9tYWlucz4+IHtcbiAgICAgICAgYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TYXZlQWxsb3dsaXN0RG9tYWlucywgeyB2YWx1ZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBtYXJrIGEgbm90aWZpY2F0aW9uIGFzIHZpZXdlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB3aXRoRGVsYXkgV2hldGhlciB0aGUgbm90aWZpY2F0aW9uIHNob3VsZCBiZSBtYXJrZWQgYXMgdmlld2VkIGFmdGVyIGEgZGVsYXkuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBzZXROb3RpZmljYXRpb25WaWV3ZWQoXG4gICAgICAgIHdpdGhEZWxheTogU2V0Tm90aWZpY2F0aW9uVmlld2VkTWVzc2FnZVsnZGF0YSddWyd3aXRoRGVsYXknXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuU2V0Tm90aWZpY2F0aW9uVmlld2VkPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlNldE5vdGlmaWNhdGlvblZpZXdlZCwgeyB3aXRoRGVsYXkgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gdXBkYXRlIGZpbHRlcnMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbGlzdCBvZiBmaWx0ZXJzLlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUZpbHRlcnMoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNoZWNrRmlsdGVyc1VwZGF0ZT4+IHtcbiAgICAgICAgaWYgKF9fSVNfTVYzX18pIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZygnRmlsdGVycyB1cGRhdGUgaXMgbm90IHN1cHBvcnRlZCBpbiBNVjMnKTtcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkNoZWNrRmlsdGVyc1VwZGF0ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gdXBkYXRlIHRoZSBzdGF0dXMgb2YgYSBmaWx0ZXIgZ3JvdXAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gaWQgR3JvdXAgaWRlbnRpZmllci5cbiAgICAgKiBAcGFyYW0gZW5hYmxlZCBXaGV0aGVyIHRoZSBncm91cCBzaG91bGQgYmUgZW5hYmxlZCBvciBkaXNhYmxlZC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUdyb3VwU3RhdHVzKFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgICAgICBlbmFibGVkOiBib29sZWFuLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5FbmFibGVGaWx0ZXJzR3JvdXAgfCBNZXNzYWdlVHlwZS5EaXNhYmxlRmlsdGVyc0dyb3VwPj4ge1xuICAgICAgICBjb25zdCB0eXBlID0gZW5hYmxlZCA/IE1lc3NhZ2VUeXBlLkVuYWJsZUZpbHRlcnNHcm91cCA6IE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXJzR3JvdXA7XG4gICAgICAgIGNvbnN0IGdyb3VwSWQgPSBOdW1iZXIucGFyc2VJbnQoaWQsIDEwKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZSh0eXBlLCB7IGdyb3VwSWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2V0IGNvbnNlbnRlZCBmaWx0ZXJzLlxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbHRlcklkcyBMaXN0IG9mIGZpbHRlciBpZGVudGlmaWVycy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHNldENvbnNlbnRlZEZpbHRlcnMoXG4gICAgICAgIGZpbHRlcklkczogU2V0Q29uc2VudGVkRmlsdGVyc01lc3NhZ2VbJ2RhdGEnXVsnZmlsdGVySWRzJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlNldENvbnNlbnRlZEZpbHRlcnM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlNldENvbnNlbnRlZEZpbHRlcnMsIHsgZmlsdGVySWRzIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNoZWNrIGlmIGEgZmlsdGVyIGlzIGNvbnNlbnRlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWx0ZXJJZCBGaWx0ZXIgaWRlbnRpZmllci5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgb2YgdGhlIGNoZWNrLlxuICAgICAqL1xuICAgIGFzeW5jIGdldElzQ29uc2VudGVkRmlsdGVyKFxuICAgICAgICBmaWx0ZXJJZDogR2V0SXNDb25zZW50ZWRGaWx0ZXJNZXNzYWdlWydkYXRhJ11bJ2ZpbHRlcklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldElzQ29uc2VudGVkRmlsdGVyPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRJc0NvbnNlbnRlZEZpbHRlciwgeyBmaWx0ZXJJZCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjaGVjayBhIGN1c3RvbSBmaWx0ZXIgVVJMLlxuICAgICAqXG4gICAgICogQHBhcmFtIHVybCBDdXN0b20gZmlsdGVyIFVSTC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgb2YgdGhlIGNoZWNrLlxuICAgICAqL1xuICAgIGFzeW5jIGNoZWNrQ3VzdG9tVXJsKFxuICAgICAgICB1cmw6IExvYWRDdXN0b21GaWx0ZXJJbmZvTWVzc2FnZVsnZGF0YSddWyd1cmwnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuTG9hZEN1c3RvbUZpbHRlckluZm8+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkxvYWRDdXN0b21GaWx0ZXJJbmZvLCB7IHVybCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBhZGQgYSBjdXN0b20gZmlsdGVyLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtDdXN0b21GaWx0ZXJTdWJzY3JpcHRpb25EYXRhfSBmaWx0ZXIgQ3VzdG9tIGZpbHRlciBkYXRhLlxuICAgICAqXG4gICAgICogQHJldHVybnMge1Byb21pc2U8Q3VzdG9tRmlsdGVyTWV0YWRhdGE+fSBDdXN0b20gZmlsdGVyIG1ldGFkYXRhLlxuICAgICAqL1xuICAgIGFzeW5jIGFkZEN1c3RvbUZpbHRlcihcbiAgICAgICAgZmlsdGVyOiBTdWJzY3JpYmVUb0N1c3RvbUZpbHRlck1lc3NhZ2VbJ2RhdGEnXVsnZmlsdGVyJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlN1YnNjcmliZVRvQ3VzdG9tRmlsdGVyPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TdWJzY3JpYmVUb0N1c3RvbUZpbHRlciwgeyBmaWx0ZXIgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gcmVtb3ZlIGEgY3VzdG9tIGZpbHRlci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWx0ZXJJZCBDdXN0b20gZmlsdGVyIElELlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBmaWx0ZXIgaXMgcmVtb3ZlZC5cbiAgICAgKi9cbiAgICBhc3luYyByZW1vdmVDdXN0b21GaWx0ZXIoXG4gICAgICAgIGZpbHRlcklkOiBSZW1vdmVBbnRpQmFubmVyRmlsdGVyTWVzc2FnZVsnZGF0YSddWydmaWx0ZXJJZCddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5SZW1vdmVBbnRpQmFubmVyRmlsdGVyPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlbW92ZUFudGlCYW5uZXJGaWx0ZXIsIHsgZmlsdGVySWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hlY2sgaWYgdGhlIGVuZ2luZSBpcyBzdGFydGVkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIGEgYm9vbGVhbiB2YWx1ZTpcbiAgICAgKiB0cnVlIGlmIHRoZSBlbmdpbmUgaXMgc3RhcnRlZCwgZmFsc2Ugb3RoZXJ3aXNlLlxuICAgICAqL1xuICAgIGFzeW5jIGdldElzRW5naW5lU3RhcnRlZCgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0SXNFbmdpbmVTdGFydGVkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRJc0VuZ2luZVN0YXJ0ZWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCB0byBnZXQgdGhlIHRhYiBpbmZvIGZvciB0aGUgcG9wdXAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGFiSWQgVGFiIElELlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHRhYiBpbmZvIG9yIHVuZGVmaW5lZC5cbiAgICAgKi9cbiAgICBhc3luYyBnZXRUYWJJbmZvRm9yUG9wdXAoXG4gICAgICAgIHRhYklkOiBHZXRUYWJJbmZvRm9yUG9wdXBNZXNzYWdlWydkYXRhJ11bJ3RhYklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldFRhYkluZm9Gb3JQb3B1cD4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuR2V0VGFiSW5mb0ZvclBvcHVwLCB7IHRhYklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNoYW5nZSBhcHBsaWNhdGlvbiBmaWx0ZXJpbmcgc3RhdGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc3RhdGUgQXBwbGljYXRpb24gZmlsdGVyaW5nIHN0YXRlLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBzdGF0ZSBpcyBjaGFuZ2VkLlxuICAgICAqL1xuICAgIGFzeW5jIGNoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkKFxuICAgICAgICBzdGF0ZTogQ2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWRNZXNzYWdlWydkYXRhJ11bJ3N0YXRlJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZCwgeyBzdGF0ZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byB1cGRhdGUgdGhlIHRoZW1lIG9mIHRoZSBmdWxsc2NyZWVuIHVzZXIgcnVsZXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGhlbWUgVGhlbWUgdG8gc2V0LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSB0aGVtZSBpcyB1cGRhdGVkLlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZShcbiAgICAgICAgdGhlbWU6IFVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZU1lc3NhZ2VbJ2RhdGEnXVsndGhlbWUnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5VcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWUsIHsgdGhlbWUgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gb3BlbiB0aGUgcnVsZXMgbGltaXRzIHRhYi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgdGFiIGlzIG9wZW5lZC5cbiAgICAgKi9cbiAgICBhc3luYyBvcGVuUnVsZXNMaW1pdHNUYWIoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5SdWxlc0xpbWl0c1RhYj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlblJ1bGVzTGltaXRzVGFiKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBvcGVuIHRoZSBzZXR0aW5ncyB0YWIuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHRhYiBpcyBvcGVuZWQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlblNldHRpbmdzVGFiKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5PcGVuU2V0dGluZ3NUYWI+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLk9wZW5TZXR0aW5nc1RhYik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gb3BlbiB0aGUgYXNzaXN0YW50LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBhc3Npc3RhbnQgaXMgb3BlbmVkLlxuICAgICAqL1xuICAgIGFzeW5jIG9wZW5Bc3Npc3RhbnQoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5Bc3Npc3RhbnQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLk9wZW5Bc3Npc3RhbnQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIGFidXNlIHJlcG9ydGluZyB0YWIgZm9yIGEgc2l0ZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmwgVGhlIFVSTCBvZiB0aGUgc2l0ZSB0byByZXBvcnQgYWJ1c2UgZm9yLlxuICAgICAqIEBwYXJhbSBmcm9tIFRoZSBzb3VyY2Ugb2YgdGhlIHJlcXVlc3QuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHRhYiBpcyBvcGVuZWQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlbkFidXNlU2l0ZShcbiAgICAgICAgdXJsOiBPcGVuQWJ1c2VUYWJNZXNzYWdlWydkYXRhJ11bJ3VybCddLFxuICAgICAgICBmcm9tOiBPcGVuQWJ1c2VUYWJNZXNzYWdlWydkYXRhJ11bJ2Zyb20nXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkFidXNlVGFiPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuQWJ1c2VUYWIsIHsgdXJsLCBmcm9tIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNoZWNrIHNpdGUgc2VjdXJpdHkuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdXJsIFRoZSBVUkwgb2YgdGhlIHNpdGUgdG8gY2hlY2suXG4gICAgICogQHBhcmFtIGZyb20gVGhlIHNvdXJjZSBvZiB0aGUgcmVxdWVzdC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBzaXRlIHNlY3VyaXR5IGluZm8uXG4gICAgICovXG4gICAgYXN5bmMgY2hlY2tTaXRlU2VjdXJpdHkoXG4gICAgICAgIHVybDogT3BlblNpdGVSZXBvcnRUYWJNZXNzYWdlWydkYXRhJ11bJ3VybCddLFxuICAgICAgICBmcm9tOiBPcGVuU2l0ZVJlcG9ydFRhYk1lc3NhZ2VbJ2RhdGEnXVsnZnJvbSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5PcGVuU2l0ZVJlcG9ydFRhYj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlblNpdGVSZXBvcnRUYWIsIHsgdXJsLCBmcm9tIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlc2V0IHVzZXIgcnVsZXMgZm9yIGEgc3BlY2lmaWMgcGFnZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmwgVGhlIFVSTCBvZiB0aGUgcGFnZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgdXNlciBydWxlcyBhcmUgcmVzZXQuXG4gICAgICovXG4gICAgYXN5bmMgcmVzZXRVc2VyUnVsZXNGb3JQYWdlKFxuICAgICAgICB1cmw6IFJlc2V0VXNlclJ1bGVzRm9yUGFnZU1lc3NhZ2VbJ2RhdGEnXVsndXJsJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlJlc2V0VXNlclJ1bGVzRm9yUGFnZT4+IHtcbiAgICAgICAgY29uc3QgW2N1cnJlbnRUYWJdID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuXG4gICAgICAgIGlmICghY3VycmVudFRhYj8uaWQpIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZygnW3Jlc2V0VXNlclJ1bGVzRm9yUGFnZV06IGNhbm5vdCBnZXQgY3VycmVudCB0YWIgaWQnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKFxuICAgICAgICAgICAgTWVzc2FnZVR5cGUuUmVzZXRVc2VyUnVsZXNGb3JQYWdlLFxuICAgICAgICAgICAgeyB1cmwsIHRhYklkOiBjdXJyZW50VGFiPy5pZCB9LFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlbW92ZSBhbiBhbGxvd2xpc3QgZG9tYWluLlxuICAgICAqXG4gICAgICogQHBhcmFtIHRhYklkIFRoZSBJRCBvZiB0aGUgdGFiLlxuICAgICAqIEBwYXJhbSB0YWJSZWZyZXNoIFdoZXRoZXIgdGhlIHRhYiBzaG91bGQgYmUgcmVmcmVzaGVkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBkb21haW4gaXMgcmVtb3ZlZC5cbiAgICAgKi9cbiAgICBhc3luYyByZW1vdmVBbGxvd2xpc3REb21haW4oXG4gICAgICAgIHRhYklkOiBSZW1vdmVBbGxvd2xpc3REb21haW5NZXNzYWdlWydkYXRhJ11bJ3RhYklkJ10sXG4gICAgICAgIHRhYlJlZnJlc2g6IFJlbW92ZUFsbG93bGlzdERvbWFpbk1lc3NhZ2VbJ2RhdGEnXVsndGFiUmVmcmVzaCddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5SZW1vdmVBbGxvd2xpc3REb21haW4+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlbW92ZUFsbG93bGlzdERvbWFpbiwgeyB0YWJJZCwgdGFiUmVmcmVzaCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBhZGQgYW4gYWxsb3dsaXN0IGRvbWFpbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0YWJJZCBUaGUgSUQgb2YgdGhlIHRhYi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgZG9tYWluIGlzIGFkZGVkLlxuICAgICAqL1xuICAgIGFzeW5jIGFkZEFsbG93bGlzdERvbWFpbihcbiAgICAgICAgdGFiSWQ6IEFkZEFsbG93bGlzdERvbWFpbk1lc3NhZ2VbJ2RhdGEnXVsndGFiSWQnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQWRkQWxsb3dsaXN0RG9tYWluPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5BZGRBbGxvd2xpc3REb21haW4sIHsgdGFiSWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogV29ya3Mgb25seSBpbiBNVjIsIHNpbmNlIE1WMyBkb2Vzbid0IHN1cHBvcnQgZmlsdGVyaW5nIGxvZyB5ZXQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIGZpbHRlcmluZyBsb2cgcGFnZSBpcyBvcGVuZWQuXG4gICAgICovXG4gICAgYXN5bmMgb25PcGVuRmlsdGVyaW5nTG9nUGFnZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT25PcGVuRmlsdGVyaW5nTG9nUGFnZT4+IHtcbiAgICAgICAgYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5Pbk9wZW5GaWx0ZXJpbmdMb2dQYWdlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBnZXQgZmlsdGVyaW5nIGxvZyBkYXRhLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggZmlsdGVyaW5nIGxvZyBkYXRhLlxuICAgICAqL1xuICAgIGFzeW5jIGdldEZpbHRlcmluZ0xvZ0RhdGEoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0xvZ0RhdGE+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0xvZ0RhdGEpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNsb3NlIHRoZSBmaWx0ZXJpbmcgbG9nIHBhZ2UuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHBhZ2UgaXMgY2xvc2VkLlxuICAgICAqL1xuICAgIGFzeW5jIG9uQ2xvc2VGaWx0ZXJpbmdMb2dQYWdlKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5PbkNsb3NlRmlsdGVyaW5nTG9nUGFnZT4+IHtcbiAgICAgICAgYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PbkNsb3NlRmlsdGVyaW5nTG9nUGFnZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IGZpbHRlcmluZyBpbmZvIGJ5IHRhYiBJRC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0YWJJZCBUaGUgSUQgb2YgdGhlIHRhYi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGZpbHRlcmluZyBpbmZvIGFib3V0IHRoZSB0YWIuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQoXG4gICAgICAgIHRhYklkOiBHZXRGaWx0ZXJpbmdJbmZvQnlUYWJJZE1lc3NhZ2VbJ2RhdGEnXVsndGFiSWQnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0luZm9CeVRhYklkLCB7IHRhYklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHN5bmNocm9uaXplIHRoZSBsaXN0IG9mIG9wZW4gdGFicy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGFuIGFycmF5IG9mIGZpbHRlcmluZyBpbmZvIGFib3V0IG9wZW4gdGFicy5cbiAgICAgKi9cbiAgICBhc3luYyBzeW5jaHJvbml6ZU9wZW5UYWJzKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TeW5jaHJvbml6ZU9wZW5UYWJzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TeW5jaHJvbml6ZU9wZW5UYWJzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjbGVhciBldmVudHMgYnkgdGFiIElELlxuICAgICAqXG4gICAgICogQHBhcmFtIHRhYklkIFRoZSBJRCBvZiB0aGUgdGFiLlxuICAgICAqIEBwYXJhbSBpZ25vcmVQcmVzZXJ2ZUxvZyBPcHRpb25hbCBmbGFnIHRvIGlnbm9yZSB0aGUgcHJlc2VydmUgbG9nIHN0YXRlLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBldmVudHMgYXJlIGNsZWFyZWQuXG4gICAgICovXG4gICAgYXN5bmMgY2xlYXJFdmVudHNCeVRhYklkKFxuICAgICAgICB0YWJJZDogQ2xlYXJFdmVudHNCeVRhYklkTWVzc2FnZVsnZGF0YSddWyd0YWJJZCddLFxuICAgICAgICBpZ25vcmVQcmVzZXJ2ZUxvZz86IENsZWFyRXZlbnRzQnlUYWJJZE1lc3NhZ2VbJ2RhdGEnXVsnaWdub3JlUHJlc2VydmVMb2cnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQ2xlYXJFdmVudHNCeVRhYklkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DbGVhckV2ZW50c0J5VGFiSWQsIHsgdGFiSWQsIGlnbm9yZVByZXNlcnZlTG9nIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlZnJlc2ggdGhlIGN1cnJlbnQgcGFnZSBieSB0YWIgSUQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGFiSWQgVGhlIElEIG9mIHRoZSB0YWIuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHBhZ2UgaXMgcmVmcmVzaGVkLlxuICAgICAqL1xuICAgIGFzeW5jIHJlZnJlc2hQYWdlKFxuICAgICAgICB0YWJJZDogUmVmcmVzaFBhZ2VNZXNzYWdlWydkYXRhJ11bJ3RhYklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlLCB7IHRhYklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGFkZCBhIHVzZXIgcnVsZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBydWxlVGV4dCBVc2VyIHJ1bGUgdGV4dCB0byBiZSBhZGRlZC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIGFkZFVzZXJSdWxlKFxuICAgICAgICBydWxlVGV4dDogQWRkVXNlclJ1bGVNZXNzYWdlWydkYXRhJ11bJ3J1bGVUZXh0J10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkFkZFVzZXJSdWxlPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkFkZFVzZXJSdWxlLCB7IHJ1bGVUZXh0IH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlbW92ZSBhIHVzZXIgcnVsZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBydWxlVGV4dCBVc2VyIHJ1bGUgdGV4dCB0byBiZSByZW1vdmVkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgcmVtb3ZlVXNlclJ1bGUoXG4gICAgICAgIHJ1bGVUZXh0OiBSZW1vdmVVc2VyUnVsZU1lc3NhZ2VbJ2RhdGEnXVsncnVsZVRleHQnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuUmVtb3ZlVXNlclJ1bGU+PiB7XG4gICAgICAgIGF3YWl0IHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuUmVtb3ZlVXNlclJ1bGUsIHsgcnVsZVRleHQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2V0IHRoZSBwcmVzZXJ2ZSBsb2cgc3RhdGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc3RhdGUgU3RhdGUgaW5kaWNhdGluZyB3aGV0aGVyIHRvIHByZXNlcnZlIHRoZSBsb2cuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBzZXRQcmVzZXJ2ZUxvZ1N0YXRlKFxuICAgICAgICBzdGF0ZTogU2V0UHJlc2VydmVMb2dTdGF0ZU1lc3NhZ2VbJ2RhdGEnXVsnc3RhdGUnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuU2V0UHJlc2VydmVMb2dTdGF0ZT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuU2V0UHJlc2VydmVMb2dTdGF0ZSwgeyBzdGF0ZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBnZXQgdGhlIGVkaXRvciBzdG9yYWdlIGNvbnRlbnQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZWRpdG9yIHN0b3JhZ2UgY29udGVudC5cbiAgICAgKi9cbiAgICBhc3luYyBnZXRFZGl0b3JTdG9yYWdlQ29udGVudCgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldEVkaXRvclN0b3JhZ2VDb250ZW50KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBzZXQgdGhlIGVkaXRvciBzdG9yYWdlIGNvbnRlbnQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY29udGVudCBDb250ZW50IHRvIGJlIHN0b3JlZCBpbiB0aGUgZWRpdG9yLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgc2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQoXG4gICAgICAgIGNvbnRlbnQ6IFNldEVkaXRvclN0b3JhZ2VDb250ZW50TWVzc2FnZVsnZGF0YSddWydjb250ZW50J10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlNldEVkaXRvclN0b3JhZ2VDb250ZW50Pj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TZXRFZGl0b3JTdG9yYWdlQ29udGVudCwgeyBjb250ZW50IH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGdldCB0aGUgcnVsZXMgbGltaXRzIGNvdW50ZXJzIGZvciBNVjMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcnVsZXMgbGltaXRzIGNvdW50ZXJzIGZvciBNVjMuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0UnVsZXNMaW1pdHNDb3VudGVycygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0UnVsZXNMaW1pdHNDb3VudGVyc012Mz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuR2V0UnVsZXNMaW1pdHNDb3VudGVyc012Myk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hlY2sgaWYgaXQgaXMgcG9zc2libGUgdG8gZW5hYmxlIGEgc3RhdGljIGZpbHRlci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWx0ZXJJZCBGaWx0ZXIgSUQgdG8gY2hlY2suXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0IG9mIHRoZSBzdGF0aWMgZmlsdGVyIGNoZWNrLlxuICAgICAqXG4gICAgICogQHRocm93cyBFcnJvciBJZiB0aGUgZmlsdGVyIGlzIG5vdCBzdGF0aWMuXG4gICAgICovXG4gICAgYXN5bmMgY2FuRW5hYmxlU3RhdGljRmlsdGVyKFxuICAgICAgICBmaWx0ZXJJZDogQ2FuRW5hYmxlU3RhdGljRmlsdGVyTXYzTWVzc2FnZVsnZGF0YSddWydmaWx0ZXJJZCddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5DYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkNhbkVuYWJsZVN0YXRpY0ZpbHRlck12MywgeyBmaWx0ZXJJZCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjaGVjayBpZiBhbGwgZHluYW1pYyBydWxlcyBmb3IgYSB1c2VyIHJ1bGVzJyBncm91cCBjYW4gYmUgZW5hYmxlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBncm91cElkIEdyb3VwIGlkZW50aWZpZXIgdG8gY2hlY2suXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0IG9mIHRoZSBzdGF0aWMgZ3JvdXAgY2hlY2suXG4gICAgICovXG4gICAgYXN5bmMgY2FuRW5hYmxlU3RhdGljR3JvdXAoXG4gICAgICAgIGdyb3VwSWQ6IENhbkVuYWJsZVN0YXRpY0dyb3VwTXYzTWVzc2FnZVsnZGF0YSddWydncm91cElkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNhbkVuYWJsZVN0YXRpY0dyb3VwTXYzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DYW5FbmFibGVTdGF0aWNHcm91cE12MywgeyBncm91cElkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGdldCB0aGUgY3VycmVudCBzdGF0aWMgZmlsdGVycyBsaW1pdHMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgY3VycmVudCBzdGF0aWMgZmlsdGVycyBsaW1pdHMuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0Q3VycmVudExpbWl0cygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012Mz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012Myk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hlY2sgaWYgdGhlIHJlcXVlc3QgZmlsdGVyIGlzIHJlYWR5LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIGEgYm9vbGVhbiBpbmRpY2F0aW5nIGlmIHRoZSByZXF1ZXN0IGZpbHRlciBpcyByZWFkeS5cbiAgICAgKi9cbiAgICBhc3luYyBjaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQ2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHk+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkNoZWNrUmVxdWVzdEZpbHRlclJlYWR5KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBhZGQgYSBVUkwgdG8gdGhlIHRydXN0ZWQgbGlzdC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmwgVVJMIHRvIGJlIGFkZGVkIHRvIHRoZSB0cnVzdGVkIGxpc3QuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBhZGRVcmxUb1RydXN0ZWQodXJsOiBBZGRVcmxUb1RydXN0ZWRNZXNzYWdlWydkYXRhJ11bJ3VybCddKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkFkZFVybFRvVHJ1c3RlZD4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQWRkVXJsVG9UcnVzdGVkLCB7IHVybCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBnZXQgdXNlciBydWxlcyBlZGl0b3IgZGF0YS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB1c2VyIHJ1bGVzIGVkaXRvciBkYXRhLlxuICAgICAqL1xuICAgIGFzeW5jIGdldFVzZXJSdWxlc0VkaXRvckRhdGEoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc0VkaXRvckRhdGE+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc0VkaXRvckRhdGEpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlc3RvcmUgZmlsdGVycyBpbiBNVjMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyByZXN0b3JlRmlsdGVyc012MygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuUmVzdG9yZUZpbHRlcnNNdjM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlc3RvcmVGaWx0ZXJzTXYzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjbGVhciB0aGUgcnVsZXMgbGltaXRzIHdhcm5pbmcgaW4gTVYzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgY2xlYXJSdWxlc0xpbWl0c1dhcm5pbmdNdjMoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DbGVhclJ1bGVzTGltaXRzV2FybmluZ012Myk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IHRoZSBhbGxvd2xpc3QgZG9tYWlucy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBhbGxvd2xpc3QgZG9tYWlucy5cbiAgICAgKi9cbiAgICBhc3luYyBnZXRBbGxvd2xpc3REb21haW5zKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5HZXRBbGxvd2xpc3REb21haW5zPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRBbGxvd2xpc3REb21haW5zKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBsb2FkIHRoZSBzZXR0aW5ncyBKU09OLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGxvYWRlZCBzZXR0aW5ncyBKU09OLlxuICAgICAqL1xuICAgIGFzeW5jIGxvYWRTZXR0aW5nc0pzb24oKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkxvYWRTZXR0aW5nc0pzb24+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkxvYWRTZXR0aW5nc0pzb24pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIHRoYW5rIHlvdSBwYWdlLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlblRoYW5reW91UGFnZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gaW5pdGlhbGl6ZSB0aGUgZnJhbWUgc2NyaXB0LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGluaXRpYWxpemF0aW9uIGRhdGEgZm9yIHRoZSBmcmFtZSBzY3JpcHQuXG4gICAgICovXG4gICAgYXN5bmMgaW5pdGlhbGl6ZUZyYW1lU2NyaXB0KCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5Jbml0aWFsaXplRnJhbWVTY3JpcHQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkluaXRpYWxpemVGcmFtZVNjcmlwdCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gbWFyayB1cmwgYXMgdHJ1c3RlZCBhbmQgaWdub3JlXG4gICAgICogc2FmZWJyb3dzaW5nIGNoZWNrcyBmb3IgaXQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgaW5pdGlhbGl6YXRpb24gZGF0YSBmb3IgdGhlIGZyYW1lIHNjcmlwdC5cbiAgICAgKi9cbiAgICBhc3luYyBvcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZChcbiAgICAgICAgdXJsOiBPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZE1lc3NhZ2VbJ2RhdGEnXVsndXJsJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5TYWZlYnJvd3NpbmdUcnVzdGVkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCwgeyB1cmwgfSk7XG4gICAgfVxufVxuXG5jb25zdCBtZXNzZW5nZXIgPSBuZXcgTWVzc2VuZ2VyKCk7XG5cbmV4cG9ydCB7IG1lc3NlbmdlciwgTWVzc2VuZ2VyIH07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIHRyeVRvU3RyaW5nID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RyeS10by1zdHJpbmcnKTtcblxudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG5cbi8vIGBBc3NlcnQ6IElzQ2FsbGFibGUoYXJndW1lbnQpIGlzIHRydWVgXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICBpZiAoaXNDYWxsYWJsZShhcmd1bWVudCkpIHJldHVybiBhcmd1bWVudDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IodHJ5VG9TdHJpbmcoYXJndW1lbnQpICsgJyBpcyBub3QgYSBmdW5jdGlvbicpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc1Bvc3NpYmxlUHJvdG90eXBlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLXBvc3NpYmxlLXByb3RvdHlwZScpO1xuXG52YXIgJFN0cmluZyA9IFN0cmluZztcbnZhciAkVHlwZUVycm9yID0gVHlwZUVycm9yO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICBpZiAoaXNQb3NzaWJsZVByb3RvdHlwZShhcmd1bWVudCkpIHJldHVybiBhcmd1bWVudDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IoXCJDYW4ndCBzZXQgXCIgKyAkU3RyaW5nKGFyZ3VtZW50KSArICcgYXMgYSBwcm90b3R5cGUnKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgd2VsbEtub3duU3ltYm9sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sJyk7XG52YXIgY3JlYXRlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1jcmVhdGUnKTtcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5JykuZjtcblxudmFyIFVOU0NPUEFCTEVTID0gd2VsbEtub3duU3ltYm9sKCd1bnNjb3BhYmxlcycpO1xudmFyIEFycmF5UHJvdG90eXBlID0gQXJyYXkucHJvdG90eXBlO1xuXG4vLyBBcnJheS5wcm90b3R5cGVbQEB1bnNjb3BhYmxlc11cbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtYXJyYXkucHJvdG90eXBlLUBAdW5zY29wYWJsZXNcbmlmIChBcnJheVByb3RvdHlwZVtVTlNDT1BBQkxFU10gPT09IHVuZGVmaW5lZCkge1xuICBkZWZpbmVQcm9wZXJ0eShBcnJheVByb3RvdHlwZSwgVU5TQ09QQUJMRVMsIHtcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgdmFsdWU6IGNyZWF0ZShudWxsKVxuICB9KTtcbn1cblxuLy8gYWRkIGEga2V5IHRvIEFycmF5LnByb3RvdHlwZVtAQHVuc2NvcGFibGVzXVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIEFycmF5UHJvdG90eXBlW1VOU0NPUEFCTEVTXVtrZXldID0gdHJ1ZTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG5cbnZhciAkU3RyaW5nID0gU3RyaW5nO1xudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG5cbi8vIGBBc3NlcnQ6IFR5cGUoYXJndW1lbnQpIGlzIE9iamVjdGBcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyZ3VtZW50KSB7XG4gIGlmIChpc09iamVjdChhcmd1bWVudCkpIHJldHVybiBhcmd1bWVudDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IoJFN0cmluZyhhcmd1bWVudCkgKyAnIGlzIG5vdCBhbiBvYmplY3QnKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9JbmRleGVkT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLWluZGV4ZWQtb2JqZWN0Jyk7XG52YXIgdG9BYnNvbHV0ZUluZGV4ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLWFic29sdXRlLWluZGV4Jyk7XG52YXIgbGVuZ3RoT2ZBcnJheUxpa2UgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvbGVuZ3RoLW9mLWFycmF5LWxpa2UnKTtcblxuLy8gYEFycmF5LnByb3RvdHlwZS57IGluZGV4T2YsIGluY2x1ZGVzIH1gIG1ldGhvZHMgaW1wbGVtZW50YXRpb25cbnZhciBjcmVhdGVNZXRob2QgPSBmdW5jdGlvbiAoSVNfSU5DTFVERVMpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICgkdGhpcywgZWwsIGZyb21JbmRleCkge1xuICAgIHZhciBPID0gdG9JbmRleGVkT2JqZWN0KCR0aGlzKTtcbiAgICB2YXIgbGVuZ3RoID0gbGVuZ3RoT2ZBcnJheUxpa2UoTyk7XG4gICAgaWYgKGxlbmd0aCA9PT0gMCkgcmV0dXJuICFJU19JTkNMVURFUyAmJiAtMTtcbiAgICB2YXIgaW5kZXggPSB0b0Fic29sdXRlSW5kZXgoZnJvbUluZGV4LCBsZW5ndGgpO1xuICAgIHZhciB2YWx1ZTtcbiAgICAvLyBBcnJheSNpbmNsdWRlcyB1c2VzIFNhbWVWYWx1ZVplcm8gZXF1YWxpdHkgYWxnb3JpdGhtXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXNlbGYtY29tcGFyZSAtLSBOYU4gY2hlY2tcbiAgICBpZiAoSVNfSU5DTFVERVMgJiYgZWwgIT09IGVsKSB3aGlsZSAobGVuZ3RoID4gaW5kZXgpIHtcbiAgICAgIHZhbHVlID0gT1tpbmRleCsrXTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zZWxmLWNvbXBhcmUgLS0gTmFOIGNoZWNrXG4gICAgICBpZiAodmFsdWUgIT09IHZhbHVlKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBBcnJheSNpbmRleE9mIGlnbm9yZXMgaG9sZXMsIEFycmF5I2luY2x1ZGVzIC0gbm90XG4gICAgfSBlbHNlIGZvciAoO2xlbmd0aCA+IGluZGV4OyBpbmRleCsrKSB7XG4gICAgICBpZiAoKElTX0lOQ0xVREVTIHx8IGluZGV4IGluIE8pICYmIE9baW5kZXhdID09PSBlbCkgcmV0dXJuIElTX0lOQ0xVREVTIHx8IGluZGV4IHx8IDA7XG4gICAgfSByZXR1cm4gIUlTX0lOQ0xVREVTICYmIC0xO1xuICB9O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIC8vIGBBcnJheS5wcm90b3R5cGUuaW5jbHVkZXNgIG1ldGhvZFxuICAvLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWFycmF5LnByb3RvdHlwZS5pbmNsdWRlc1xuICBpbmNsdWRlczogY3JlYXRlTWV0aG9kKHRydWUpLFxuICAvLyBgQXJyYXkucHJvdG90eXBlLmluZGV4T2ZgIG1ldGhvZFxuICAvLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWFycmF5LnByb3RvdHlwZS5pbmRleG9mXG4gIGluZGV4T2Y6IGNyZWF0ZU1ldGhvZChmYWxzZSlcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdW5jdXJyeVRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzJyk7XG5cbnZhciB0b1N0cmluZyA9IHVuY3VycnlUaGlzKHt9LnRvU3RyaW5nKTtcbnZhciBzdHJpbmdTbGljZSA9IHVuY3VycnlUaGlzKCcnLnNsaWNlKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIHN0cmluZ1NsaWNlKHRvU3RyaW5nKGl0KSwgOCwgLTEpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBUT19TVFJJTkdfVEFHX1NVUFBPUlQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8tc3RyaW5nLXRhZy1zdXBwb3J0Jyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIGNsYXNzb2ZSYXcgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY2xhc3NvZi1yYXcnKTtcbnZhciB3ZWxsS25vd25TeW1ib2wgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvd2VsbC1rbm93bi1zeW1ib2wnKTtcblxudmFyIFRPX1NUUklOR19UQUcgPSB3ZWxsS25vd25TeW1ib2woJ3RvU3RyaW5nVGFnJyk7XG52YXIgJE9iamVjdCA9IE9iamVjdDtcblxuLy8gRVMzIHdyb25nIGhlcmVcbnZhciBDT1JSRUNUX0FSR1VNRU5UUyA9IGNsYXNzb2ZSYXcoZnVuY3Rpb24gKCkgeyByZXR1cm4gYXJndW1lbnRzOyB9KCkpID09PSAnQXJndW1lbnRzJztcblxuLy8gZmFsbGJhY2sgZm9yIElFMTEgU2NyaXB0IEFjY2VzcyBEZW5pZWQgZXJyb3JcbnZhciB0cnlHZXQgPSBmdW5jdGlvbiAoaXQsIGtleSkge1xuICB0cnkge1xuICAgIHJldHVybiBpdFtrZXldO1xuICB9IGNhdGNoIChlcnJvcikgeyAvKiBlbXB0eSAqLyB9XG59O1xuXG4vLyBnZXR0aW5nIHRhZyBmcm9tIEVTNisgYE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmdgXG5tb2R1bGUuZXhwb3J0cyA9IFRPX1NUUklOR19UQUdfU1VQUE9SVCA/IGNsYXNzb2ZSYXcgOiBmdW5jdGlvbiAoaXQpIHtcbiAgdmFyIE8sIHRhZywgcmVzdWx0O1xuICByZXR1cm4gaXQgPT09IHVuZGVmaW5lZCA/ICdVbmRlZmluZWQnIDogaXQgPT09IG51bGwgPyAnTnVsbCdcbiAgICAvLyBAQHRvU3RyaW5nVGFnIGNhc2VcbiAgICA6IHR5cGVvZiAodGFnID0gdHJ5R2V0KE8gPSAkT2JqZWN0KGl0KSwgVE9fU1RSSU5HX1RBRykpID09ICdzdHJpbmcnID8gdGFnXG4gICAgLy8gYnVpbHRpblRhZyBjYXNlXG4gICAgOiBDT1JSRUNUX0FSR1VNRU5UUyA/IGNsYXNzb2ZSYXcoTylcbiAgICAvLyBFUzMgYXJndW1lbnRzIGZhbGxiYWNrXG4gICAgOiAocmVzdWx0ID0gY2xhc3NvZlJhdyhPKSkgPT09ICdPYmplY3QnICYmIGlzQ2FsbGFibGUoTy5jYWxsZWUpID8gJ0FyZ3VtZW50cycgOiByZXN1bHQ7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgb3duS2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vd24ta2V5cycpO1xudmFyIGdldE93blByb3BlcnR5RGVzY3JpcHRvck1vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1kZXNjcmlwdG9yJyk7XG52YXIgZGVmaW5lUHJvcGVydHlNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uICh0YXJnZXQsIHNvdXJjZSwgZXhjZXB0aW9ucykge1xuICB2YXIga2V5cyA9IG93bktleXMoc291cmNlKTtcbiAgdmFyIGRlZmluZVByb3BlcnR5ID0gZGVmaW5lUHJvcGVydHlNb2R1bGUuZjtcbiAgdmFyIGdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvck1vZHVsZS5mO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIga2V5ID0ga2V5c1tpXTtcbiAgICBpZiAoIWhhc093bih0YXJnZXQsIGtleSkgJiYgIShleGNlcHRpb25zICYmIGhhc093bihleGNlcHRpb25zLCBrZXkpKSkge1xuICAgICAgZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIGdldE93blByb3BlcnR5RGVzY3JpcHRvcihzb3VyY2UsIGtleSkpO1xuICAgIH1cbiAgfVxufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xudmFyIGRlZmluZVByb3BlcnR5TW9kdWxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1kZWZpbmUtcHJvcGVydHknKTtcbnZhciBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3InKTtcblxubW9kdWxlLmV4cG9ydHMgPSBERVNDUklQVE9SUyA/IGZ1bmN0aW9uIChvYmplY3QsIGtleSwgdmFsdWUpIHtcbiAgcmV0dXJuIGRlZmluZVByb3BlcnR5TW9kdWxlLmYob2JqZWN0LCBrZXksIGNyZWF0ZVByb3BlcnR5RGVzY3JpcHRvcigxLCB2YWx1ZSkpO1xufSA6IGZ1bmN0aW9uIChvYmplY3QsIGtleSwgdmFsdWUpIHtcbiAgb2JqZWN0W2tleV0gPSB2YWx1ZTtcbiAgcmV0dXJuIG9iamVjdDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChiaXRtYXAsIHZhbHVlKSB7XG4gIHJldHVybiB7XG4gICAgZW51bWVyYWJsZTogIShiaXRtYXAgJiAxKSxcbiAgICBjb25maWd1cmFibGU6ICEoYml0bWFwICYgMiksXG4gICAgd3JpdGFibGU6ICEoYml0bWFwICYgNCksXG4gICAgdmFsdWU6IHZhbHVlXG4gIH07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIG1ha2VCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL21ha2UtYnVpbHQtaW4nKTtcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5Jyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHRhcmdldCwgbmFtZSwgZGVzY3JpcHRvcikge1xuICBpZiAoZGVzY3JpcHRvci5nZXQpIG1ha2VCdWlsdEluKGRlc2NyaXB0b3IuZ2V0LCBuYW1lLCB7IGdldHRlcjogdHJ1ZSB9KTtcbiAgaWYgKGRlc2NyaXB0b3Iuc2V0KSBtYWtlQnVpbHRJbihkZXNjcmlwdG9yLnNldCwgbmFtZSwgeyBzZXR0ZXI6IHRydWUgfSk7XG4gIHJldHVybiBkZWZpbmVQcm9wZXJ0eS5mKHRhcmdldCwgbmFtZSwgZGVzY3JpcHRvcik7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcbnZhciBkZWZpbmVQcm9wZXJ0eU1vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5Jyk7XG52YXIgbWFrZUJ1aWx0SW4gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvbWFrZS1idWlsdC1pbicpO1xudmFyIGRlZmluZUdsb2JhbFByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHknKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoTywga2V5LCB2YWx1ZSwgb3B0aW9ucykge1xuICBpZiAoIW9wdGlvbnMpIG9wdGlvbnMgPSB7fTtcbiAgdmFyIHNpbXBsZSA9IG9wdGlvbnMuZW51bWVyYWJsZTtcbiAgdmFyIG5hbWUgPSBvcHRpb25zLm5hbWUgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMubmFtZSA6IGtleTtcbiAgaWYgKGlzQ2FsbGFibGUodmFsdWUpKSBtYWtlQnVpbHRJbih2YWx1ZSwgbmFtZSwgb3B0aW9ucyk7XG4gIGlmIChvcHRpb25zLmdsb2JhbCkge1xuICAgIGlmIChzaW1wbGUpIE9ba2V5XSA9IHZhbHVlO1xuICAgIGVsc2UgZGVmaW5lR2xvYmFsUHJvcGVydHkoa2V5LCB2YWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICghb3B0aW9ucy51bnNhZmUpIGRlbGV0ZSBPW2tleV07XG4gICAgICBlbHNlIGlmIChPW2tleV0pIHNpbXBsZSA9IHRydWU7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHsgLyogZW1wdHkgKi8gfVxuICAgIGlmIChzaW1wbGUpIE9ba2V5XSA9IHZhbHVlO1xuICAgIGVsc2UgZGVmaW5lUHJvcGVydHlNb2R1bGUuZihPLCBrZXksIHtcbiAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgY29uZmlndXJhYmxlOiAhb3B0aW9ucy5ub25Db25maWd1cmFibGUsXG4gICAgICB3cml0YWJsZTogIW9wdGlvbnMubm9uV3JpdGFibGVcbiAgICB9KTtcbiAgfSByZXR1cm4gTztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuICB0cnkge1xuICAgIGRlZmluZVByb3BlcnR5KGdsb2JhbFRoaXMsIGtleSwgeyB2YWx1ZTogdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgZ2xvYmFsVGhpc1trZXldID0gdmFsdWU7XG4gIH0gcmV0dXJuIHZhbHVlO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBmYWlscyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mYWlscycpO1xuXG4vLyBEZXRlY3QgSUU4J3MgaW5jb21wbGV0ZSBkZWZpbmVQcm9wZXJ0eSBpbXBsZW1lbnRhdGlvblxubW9kdWxlLmV4cG9ydHMgPSAhZmFpbHMoZnVuY3Rpb24gKCkge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHJlcXVpcmVkIGZvciB0ZXN0aW5nXG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoe30sIDEsIHsgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiA3OyB9IH0pWzFdICE9PSA3O1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xudmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLW9iamVjdCcpO1xuXG52YXIgZG9jdW1lbnQgPSBnbG9iYWxUaGlzLmRvY3VtZW50O1xuLy8gdHlwZW9mIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQgaXMgJ29iamVjdCcgaW4gb2xkIElFXG52YXIgRVhJU1RTID0gaXNPYmplY3QoZG9jdW1lbnQpICYmIGlzT2JqZWN0KGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gRVhJU1RTID8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChpdCkgOiB7fTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyBJRTgtIGRvbid0IGVudW0gYnVnIGtleXNcbm1vZHVsZS5leHBvcnRzID0gW1xuICAnY29uc3RydWN0b3InLFxuICAnaGFzT3duUHJvcGVydHknLFxuICAnaXNQcm90b3R5cGVPZicsXG4gICdwcm9wZXJ0eUlzRW51bWVyYWJsZScsXG4gICd0b0xvY2FsZVN0cmluZycsXG4gICd0b1N0cmluZycsXG4gICd2YWx1ZU9mJ1xuXTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG5cbnZhciBuYXZpZ2F0b3IgPSBnbG9iYWxUaGlzLm5hdmlnYXRvcjtcbnZhciB1c2VyQWdlbnQgPSBuYXZpZ2F0b3IgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudDtcblxubW9kdWxlLmV4cG9ydHMgPSB1c2VyQWdlbnQgPyBTdHJpbmcodXNlckFnZW50KSA6ICcnO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdsb2JhbFRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2xvYmFsLXRoaXMnKTtcbnZhciB1c2VyQWdlbnQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW52aXJvbm1lbnQtdXNlci1hZ2VudCcpO1xuXG52YXIgcHJvY2VzcyA9IGdsb2JhbFRoaXMucHJvY2VzcztcbnZhciBEZW5vID0gZ2xvYmFsVGhpcy5EZW5vO1xudmFyIHZlcnNpb25zID0gcHJvY2VzcyAmJiBwcm9jZXNzLnZlcnNpb25zIHx8IERlbm8gJiYgRGVuby52ZXJzaW9uO1xudmFyIHY4ID0gdmVyc2lvbnMgJiYgdmVyc2lvbnMudjg7XG52YXIgbWF0Y2gsIHZlcnNpb247XG5cbmlmICh2OCkge1xuICBtYXRjaCA9IHY4LnNwbGl0KCcuJyk7XG4gIC8vIGluIG9sZCBDaHJvbWUsIHZlcnNpb25zIG9mIFY4IGlzbid0IFY4ID0gQ2hyb21lIC8gMTBcbiAgLy8gYnV0IHRoZWlyIGNvcnJlY3QgdmVyc2lvbnMgYXJlIG5vdCBpbnRlcmVzdGluZyBmb3IgdXNcbiAgdmVyc2lvbiA9IG1hdGNoWzBdID4gMCAmJiBtYXRjaFswXSA8IDQgPyAxIDogKyhtYXRjaFswXSArIG1hdGNoWzFdKTtcbn1cblxuLy8gQnJvd3NlckZTIE5vZGVKUyBgcHJvY2Vzc2AgcG9seWZpbGwgaW5jb3JyZWN0bHkgc2V0IGAudjhgIHRvIGAwLjBgXG4vLyBzbyBjaGVjayBgdXNlckFnZW50YCBldmVuIGlmIGAudjhgIGV4aXN0cywgYnV0IDBcbmlmICghdmVyc2lvbiAmJiB1c2VyQWdlbnQpIHtcbiAgbWF0Y2ggPSB1c2VyQWdlbnQubWF0Y2goL0VkZ2VcXC8oXFxkKykvKTtcbiAgaWYgKCFtYXRjaCB8fCBtYXRjaFsxXSA+PSA3NCkge1xuICAgIG1hdGNoID0gdXNlckFnZW50Lm1hdGNoKC9DaHJvbWVcXC8oXFxkKykvKTtcbiAgICBpZiAobWF0Y2gpIHZlcnNpb24gPSArbWF0Y2hbMV07XG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB2ZXJzaW9uO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xuXG52YXIgJEVycm9yID0gRXJyb3I7XG52YXIgcmVwbGFjZSA9IHVuY3VycnlUaGlzKCcnLnJlcGxhY2UpO1xuXG52YXIgVEVTVCA9IChmdW5jdGlvbiAoYXJnKSB7IHJldHVybiBTdHJpbmcobmV3ICRFcnJvcihhcmcpLnN0YWNrKTsgfSkoJ3p4Y2FzZCcpO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlZG9zL25vLXZ1bG5lcmFibGUsIHNvbmFyanMvc2xvdy1yZWdleCAtLSBzYWZlXG52YXIgVjhfT1JfQ0hBS1JBX1NUQUNLX0VOVFJZID0gL1xcblxccyphdCBbXjpdKjpbXlxcbl0qLztcbnZhciBJU19WOF9PUl9DSEFLUkFfU1RBQ0sgPSBWOF9PUl9DSEFLUkFfU1RBQ0tfRU5UUlkudGVzdChURVNUKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoc3RhY2ssIGRyb3BFbnRyaWVzKSB7XG4gIGlmIChJU19WOF9PUl9DSEFLUkFfU1RBQ0sgJiYgdHlwZW9mIHN0YWNrID09ICdzdHJpbmcnICYmICEkRXJyb3IucHJlcGFyZVN0YWNrVHJhY2UpIHtcbiAgICB3aGlsZSAoZHJvcEVudHJpZXMtLSkgc3RhY2sgPSByZXBsYWNlKHN0YWNrLCBWOF9PUl9DSEFLUkFfU1RBQ0tfRU5UUlksICcnKTtcbiAgfSByZXR1cm4gc3RhY2s7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGNyZWF0ZU5vbkVudW1lcmFibGVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jcmVhdGUtbm9uLWVudW1lcmFibGUtcHJvcGVydHknKTtcbnZhciBjbGVhckVycm9yU3RhY2sgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZXJyb3Itc3RhY2stY2xlYXInKTtcbnZhciBFUlJPUl9TVEFDS19JTlNUQUxMQUJMRSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9lcnJvci1zdGFjay1pbnN0YWxsYWJsZScpO1xuXG4vLyBub24tc3RhbmRhcmQgVjhcbnZhciBjYXB0dXJlU3RhY2tUcmFjZSA9IEVycm9yLmNhcHR1cmVTdGFja1RyYWNlO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChlcnJvciwgQywgc3RhY2ssIGRyb3BFbnRyaWVzKSB7XG4gIGlmIChFUlJPUl9TVEFDS19JTlNUQUxMQUJMRSkge1xuICAgIGlmIChjYXB0dXJlU3RhY2tUcmFjZSkgY2FwdHVyZVN0YWNrVHJhY2UoZXJyb3IsIEMpO1xuICAgIGVsc2UgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KGVycm9yLCAnc3RhY2snLCBjbGVhckVycm9yU3RhY2soc3RhY2ssIGRyb3BFbnRyaWVzKSk7XG4gIH1cbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcbnZhciBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3InKTtcblxubW9kdWxlLmV4cG9ydHMgPSAhZmFpbHMoZnVuY3Rpb24gKCkge1xuICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IoJ2EnKTtcbiAgaWYgKCEoJ3N0YWNrJyBpbiBlcnJvcikpIHJldHVybiB0cnVlO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGVycm9yLCAnc3RhY2snLCBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IoMSwgNykpO1xuICByZXR1cm4gZXJyb3Iuc3RhY2sgIT09IDc7XG59KTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1nZXQtb3duLXByb3BlcnR5LWRlc2NyaXB0b3InKS5mO1xudmFyIGNyZWF0ZU5vbkVudW1lcmFibGVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jcmVhdGUtbm9uLWVudW1lcmFibGUtcHJvcGVydHknKTtcbnZhciBkZWZpbmVCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1idWlsdC1pbicpO1xudmFyIGRlZmluZUdsb2JhbFByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHknKTtcbnZhciBjb3B5Q29uc3RydWN0b3JQcm9wZXJ0aWVzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NvcHktY29uc3RydWN0b3ItcHJvcGVydGllcycpO1xudmFyIGlzRm9yY2VkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLWZvcmNlZCcpO1xuXG4vKlxuICBvcHRpb25zLnRhcmdldCAgICAgICAgIC0gbmFtZSBvZiB0aGUgdGFyZ2V0IG9iamVjdFxuICBvcHRpb25zLmdsb2JhbCAgICAgICAgIC0gdGFyZ2V0IGlzIHRoZSBnbG9iYWwgb2JqZWN0XG4gIG9wdGlvbnMuc3RhdCAgICAgICAgICAgLSBleHBvcnQgYXMgc3RhdGljIG1ldGhvZHMgb2YgdGFyZ2V0XG4gIG9wdGlvbnMucHJvdG8gICAgICAgICAgLSBleHBvcnQgYXMgcHJvdG90eXBlIG1ldGhvZHMgb2YgdGFyZ2V0XG4gIG9wdGlvbnMucmVhbCAgICAgICAgICAgLSByZWFsIHByb3RvdHlwZSBtZXRob2QgZm9yIHRoZSBgcHVyZWAgdmVyc2lvblxuICBvcHRpb25zLmZvcmNlZCAgICAgICAgIC0gZXhwb3J0IGV2ZW4gaWYgdGhlIG5hdGl2ZSBmZWF0dXJlIGlzIGF2YWlsYWJsZVxuICBvcHRpb25zLmJpbmQgICAgICAgICAgIC0gYmluZCBtZXRob2RzIHRvIHRoZSB0YXJnZXQsIHJlcXVpcmVkIGZvciB0aGUgYHB1cmVgIHZlcnNpb25cbiAgb3B0aW9ucy53cmFwICAgICAgICAgICAtIHdyYXAgY29uc3RydWN0b3JzIHRvIHByZXZlbnRpbmcgZ2xvYmFsIHBvbGx1dGlvbiwgcmVxdWlyZWQgZm9yIHRoZSBgcHVyZWAgdmVyc2lvblxuICBvcHRpb25zLnVuc2FmZSAgICAgICAgIC0gdXNlIHRoZSBzaW1wbGUgYXNzaWdubWVudCBvZiBwcm9wZXJ0eSBpbnN0ZWFkIG9mIGRlbGV0ZSArIGRlZmluZVByb3BlcnR5XG4gIG9wdGlvbnMuc2hhbSAgICAgICAgICAgLSBhZGQgYSBmbGFnIHRvIG5vdCBjb21wbGV0ZWx5IGZ1bGwgcG9seWZpbGxzXG4gIG9wdGlvbnMuZW51bWVyYWJsZSAgICAgLSBleHBvcnQgYXMgZW51bWVyYWJsZSBwcm9wZXJ0eVxuICBvcHRpb25zLmRvbnRDYWxsR2V0U2V0IC0gcHJldmVudCBjYWxsaW5nIGEgZ2V0dGVyIG9uIHRhcmdldFxuICBvcHRpb25zLm5hbWUgICAgICAgICAgIC0gdGhlIC5uYW1lIG9mIHRoZSBmdW5jdGlvbiBpZiBpdCBkb2VzIG5vdCBtYXRjaCB0aGUga2V5XG4qL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAob3B0aW9ucywgc291cmNlKSB7XG4gIHZhciBUQVJHRVQgPSBvcHRpb25zLnRhcmdldDtcbiAgdmFyIEdMT0JBTCA9IG9wdGlvbnMuZ2xvYmFsO1xuICB2YXIgU1RBVElDID0gb3B0aW9ucy5zdGF0O1xuICB2YXIgRk9SQ0VELCB0YXJnZXQsIGtleSwgdGFyZ2V0UHJvcGVydHksIHNvdXJjZVByb3BlcnR5LCBkZXNjcmlwdG9yO1xuICBpZiAoR0xPQkFMKSB7XG4gICAgdGFyZ2V0ID0gZ2xvYmFsVGhpcztcbiAgfSBlbHNlIGlmIChTVEFUSUMpIHtcbiAgICB0YXJnZXQgPSBnbG9iYWxUaGlzW1RBUkdFVF0gfHwgZGVmaW5lR2xvYmFsUHJvcGVydHkoVEFSR0VULCB7fSk7XG4gIH0gZWxzZSB7XG4gICAgdGFyZ2V0ID0gZ2xvYmFsVGhpc1tUQVJHRVRdICYmIGdsb2JhbFRoaXNbVEFSR0VUXS5wcm90b3R5cGU7XG4gIH1cbiAgaWYgKHRhcmdldCkgZm9yIChrZXkgaW4gc291cmNlKSB7XG4gICAgc291cmNlUHJvcGVydHkgPSBzb3VyY2Vba2V5XTtcbiAgICBpZiAob3B0aW9ucy5kb250Q2FsbEdldFNldCkge1xuICAgICAgZGVzY3JpcHRvciA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSk7XG4gICAgICB0YXJnZXRQcm9wZXJ0eSA9IGRlc2NyaXB0b3IgJiYgZGVzY3JpcHRvci52YWx1ZTtcbiAgICB9IGVsc2UgdGFyZ2V0UHJvcGVydHkgPSB0YXJnZXRba2V5XTtcbiAgICBGT1JDRUQgPSBpc0ZvcmNlZChHTE9CQUwgPyBrZXkgOiBUQVJHRVQgKyAoU1RBVElDID8gJy4nIDogJyMnKSArIGtleSwgb3B0aW9ucy5mb3JjZWQpO1xuICAgIC8vIGNvbnRhaW5lZCBpbiB0YXJnZXRcbiAgICBpZiAoIUZPUkNFRCAmJiB0YXJnZXRQcm9wZXJ0eSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHNvdXJjZVByb3BlcnR5ID09IHR5cGVvZiB0YXJnZXRQcm9wZXJ0eSkgY29udGludWU7XG4gICAgICBjb3B5Q29uc3RydWN0b3JQcm9wZXJ0aWVzKHNvdXJjZVByb3BlcnR5LCB0YXJnZXRQcm9wZXJ0eSk7XG4gICAgfVxuICAgIC8vIGFkZCBhIGZsYWcgdG8gbm90IGNvbXBsZXRlbHkgZnVsbCBwb2x5ZmlsbHNcbiAgICBpZiAob3B0aW9ucy5zaGFtIHx8ICh0YXJnZXRQcm9wZXJ0eSAmJiB0YXJnZXRQcm9wZXJ0eS5zaGFtKSkge1xuICAgICAgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KHNvdXJjZVByb3BlcnR5LCAnc2hhbScsIHRydWUpO1xuICAgIH1cbiAgICBkZWZpbmVCdWlsdEluKHRhcmdldCwga2V5LCBzb3VyY2VQcm9wZXJ0eSwgb3B0aW9ucyk7XG4gIH1cbn07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChleGVjKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuICEhZXhlYygpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIE5BVElWRV9CSU5EID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLWJpbmQtbmF0aXZlJyk7XG5cbnZhciBGdW5jdGlvblByb3RvdHlwZSA9IEZ1bmN0aW9uLnByb3RvdHlwZTtcbnZhciBhcHBseSA9IEZ1bmN0aW9uUHJvdG90eXBlLmFwcGx5O1xudmFyIGNhbGwgPSBGdW5jdGlvblByb3RvdHlwZS5jYWxsO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tZnVuY3Rpb24tcHJvdG90eXBlLWJpbmQsIGVzL25vLXJlZmxlY3QgLS0gc2FmZVxubW9kdWxlLmV4cG9ydHMgPSB0eXBlb2YgUmVmbGVjdCA9PSAnb2JqZWN0JyAmJiBSZWZsZWN0LmFwcGx5IHx8IChOQVRJVkVfQklORCA/IGNhbGwuYmluZChhcHBseSkgOiBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBjYWxsLmFwcGx5KGFwcGx5LCBhcmd1bWVudHMpO1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSAhZmFpbHMoZnVuY3Rpb24gKCkge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tZnVuY3Rpb24tcHJvdG90eXBlLWJpbmQgLS0gc2FmZVxuICB2YXIgdGVzdCA9IChmdW5jdGlvbiAoKSB7IC8qIGVtcHR5ICovIH0pLmJpbmQoKTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXByb3RvdHlwZS1idWlsdGlucyAtLSBzYWZlXG4gIHJldHVybiB0eXBlb2YgdGVzdCAhPSAnZnVuY3Rpb24nIHx8IHRlc3QuaGFzT3duUHJvcGVydHkoJ3Byb3RvdHlwZScpO1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgTkFUSVZFX0JJTkQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tYmluZC1uYXRpdmUnKTtcblxudmFyIGNhbGwgPSBGdW5jdGlvbi5wcm90b3R5cGUuY2FsbDtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1mdW5jdGlvbi1wcm90b3R5cGUtYmluZCAtLSBzYWZlXG5tb2R1bGUuZXhwb3J0cyA9IE5BVElWRV9CSU5EID8gY2FsbC5iaW5kKGNhbGwpIDogZnVuY3Rpb24gKCkge1xuICByZXR1cm4gY2FsbC5hcHBseShjYWxsLCBhcmd1bWVudHMpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG5cbnZhciBGdW5jdGlvblByb3RvdHlwZSA9IEZ1bmN0aW9uLnByb3RvdHlwZTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZ2V0b3ducHJvcGVydHlkZXNjcmlwdG9yIC0tIHNhZmVcbnZhciBnZXREZXNjcmlwdG9yID0gREVTQ1JJUFRPUlMgJiYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcblxudmFyIEVYSVNUUyA9IGhhc093bihGdW5jdGlvblByb3RvdHlwZSwgJ25hbWUnKTtcbi8vIGFkZGl0aW9uYWwgcHJvdGVjdGlvbiBmcm9tIG1pbmlmaWVkIC8gbWFuZ2xlZCAvIGRyb3BwZWQgZnVuY3Rpb24gbmFtZXNcbnZhciBQUk9QRVIgPSBFWElTVFMgJiYgKGZ1bmN0aW9uIHNvbWV0aGluZygpIHsgLyogZW1wdHkgKi8gfSkubmFtZSA9PT0gJ3NvbWV0aGluZyc7XG52YXIgQ09ORklHVVJBQkxFID0gRVhJU1RTICYmICghREVTQ1JJUFRPUlMgfHwgKERFU0NSSVBUT1JTICYmIGdldERlc2NyaXB0b3IoRnVuY3Rpb25Qcm90b3R5cGUsICduYW1lJykuY29uZmlndXJhYmxlKSk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBFWElTVFM6IEVYSVNUUyxcbiAgUFJPUEVSOiBQUk9QRVIsXG4gIENPTkZJR1VSQUJMRTogQ09ORklHVVJBQkxFXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xudmFyIGFDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hLWNhbGxhYmxlJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKG9iamVjdCwga2V5LCBtZXRob2QpIHtcbiAgdHJ5IHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5ZGVzY3JpcHRvciAtLSBzYWZlXG4gICAgcmV0dXJuIHVuY3VycnlUaGlzKGFDYWxsYWJsZShPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iamVjdCwga2V5KVttZXRob2RdKSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgTkFUSVZFX0JJTkQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tYmluZC1uYXRpdmUnKTtcblxudmFyIEZ1bmN0aW9uUHJvdG90eXBlID0gRnVuY3Rpb24ucHJvdG90eXBlO1xudmFyIGNhbGwgPSBGdW5jdGlvblByb3RvdHlwZS5jYWxsO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLWZ1bmN0aW9uLXByb3RvdHlwZS1iaW5kIC0tIHNhZmVcbnZhciB1bmN1cnJ5VGhpc1dpdGhCaW5kID0gTkFUSVZFX0JJTkQgJiYgRnVuY3Rpb25Qcm90b3R5cGUuYmluZC5iaW5kKGNhbGwsIGNhbGwpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IE5BVElWRV9CSU5EID8gdW5jdXJyeVRoaXNXaXRoQmluZCA6IGZ1bmN0aW9uIChmbikge1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBjYWxsLmFwcGx5KGZuLCBhcmd1bWVudHMpO1xuICB9O1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xuXG52YXIgYUZ1bmN0aW9uID0gZnVuY3Rpb24gKGFyZ3VtZW50KSB7XG4gIHJldHVybiBpc0NhbGxhYmxlKGFyZ3VtZW50KSA/IGFyZ3VtZW50IDogdW5kZWZpbmVkO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAobmFtZXNwYWNlLCBtZXRob2QpIHtcbiAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPCAyID8gYUZ1bmN0aW9uKGdsb2JhbFRoaXNbbmFtZXNwYWNlXSkgOiBnbG9iYWxUaGlzW25hbWVzcGFjZV0gJiYgZ2xvYmFsVGhpc1tuYW1lc3BhY2VdW21ldGhvZF07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGFDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hLWNhbGxhYmxlJyk7XG52YXIgaXNOdWxsT3JVbmRlZmluZWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtbnVsbC1vci11bmRlZmluZWQnKTtcblxuLy8gYEdldE1ldGhvZGAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWdldG1ldGhvZFxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoViwgUCkge1xuICB2YXIgZnVuYyA9IFZbUF07XG4gIHJldHVybiBpc051bGxPclVuZGVmaW5lZChmdW5jKSA/IHVuZGVmaW5lZCA6IGFDYWxsYWJsZShmdW5jKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgY2hlY2sgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGl0ICYmIGl0Lk1hdGggPT09IE1hdGggJiYgaXQ7XG59O1xuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vemxvaXJvY2svY29yZS1qcy9pc3N1ZXMvODYjaXNzdWVjb21tZW50LTExNTc1OTAyOFxubW9kdWxlLmV4cG9ydHMgPVxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tZ2xvYmFsLXRoaXMgLS0gc2FmZVxuICBjaGVjayh0eXBlb2YgZ2xvYmFsVGhpcyA9PSAnb2JqZWN0JyAmJiBnbG9iYWxUaGlzKSB8fFxuICBjaGVjayh0eXBlb2Ygd2luZG93ID09ICdvYmplY3QnICYmIHdpbmRvdykgfHxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtZ2xvYmFscyAtLSBzYWZlXG4gIGNoZWNrKHR5cGVvZiBzZWxmID09ICdvYmplY3QnICYmIHNlbGYpIHx8XG4gIGNoZWNrKHR5cGVvZiBnbG9iYWwgPT0gJ29iamVjdCcgJiYgZ2xvYmFsKSB8fFxuICBjaGVjayh0eXBlb2YgdGhpcyA9PSAnb2JqZWN0JyAmJiB0aGlzKSB8fFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmV3LWZ1bmMgLS0gZmFsbGJhY2tcbiAgKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0pKCkgfHwgRnVuY3Rpb24oJ3JldHVybiB0aGlzJykoKTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciB1bmN1cnJ5VGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mdW5jdGlvbi11bmN1cnJ5LXRoaXMnKTtcbnZhciB0b09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1vYmplY3QnKTtcblxudmFyIGhhc093blByb3BlcnR5ID0gdW5jdXJyeVRoaXMoe30uaGFzT3duUHJvcGVydHkpO1xuXG4vLyBgSGFzT3duUHJvcGVydHlgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1oYXNvd25wcm9wZXJ0eVxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1oYXNvd24gLS0gc2FmZVxubW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuaGFzT3duIHx8IGZ1bmN0aW9uIGhhc093bihpdCwga2V5KSB7XG4gIHJldHVybiBoYXNPd25Qcm9wZXJ0eSh0b09iamVjdChpdCksIGtleSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xubW9kdWxlLmV4cG9ydHMgPSB7fTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnZXRCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dldC1idWlsdC1pbicpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGdldEJ1aWx0SW4oJ2RvY3VtZW50JywgJ2RvY3VtZW50RWxlbWVudCcpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcbnZhciBjcmVhdGVFbGVtZW50ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RvY3VtZW50LWNyZWF0ZS1lbGVtZW50Jyk7XG5cbi8vIFRoYW5rcyB0byBJRTggZm9yIGl0cyBmdW5ueSBkZWZpbmVQcm9wZXJ0eVxubW9kdWxlLmV4cG9ydHMgPSAhREVTQ1JJUFRPUlMgJiYgIWZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1kZWZpbmVwcm9wZXJ0eSAtLSByZXF1aXJlZCBmb3IgdGVzdGluZ1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGNyZWF0ZUVsZW1lbnQoJ2RpdicpLCAnYScsIHtcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIDc7IH1cbiAgfSkuYSAhPT0gNztcbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2ZhaWxzJyk7XG52YXIgY2xhc3NvZiA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jbGFzc29mLXJhdycpO1xuXG52YXIgJE9iamVjdCA9IE9iamVjdDtcbnZhciBzcGxpdCA9IHVuY3VycnlUaGlzKCcnLnNwbGl0KTtcblxuLy8gZmFsbGJhY2sgZm9yIG5vbi1hcnJheS1saWtlIEVTMyBhbmQgbm9uLWVudW1lcmFibGUgb2xkIFY4IHN0cmluZ3Ncbm1vZHVsZS5leHBvcnRzID0gZmFpbHMoZnVuY3Rpb24gKCkge1xuICAvLyB0aHJvd3MgYW4gZXJyb3IgaW4gcmhpbm8sIHNlZSBodHRwczovL2dpdGh1Yi5jb20vbW96aWxsYS9yaGluby9pc3N1ZXMvMzQ2XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wcm90b3R5cGUtYnVpbHRpbnMgLS0gc2FmZVxuICByZXR1cm4gISRPYmplY3QoJ3onKS5wcm9wZXJ0eUlzRW51bWVyYWJsZSgwKTtcbn0pID8gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBjbGFzc29mKGl0KSA9PT0gJ1N0cmluZycgPyBzcGxpdChpdCwgJycpIDogJE9iamVjdChpdCk7XG59IDogJE9iamVjdDtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc0NhbGxhYmxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLWNhbGxhYmxlJyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG52YXIgc2V0UHJvdG90eXBlT2YgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LXNldC1wcm90b3R5cGUtb2YnKTtcblxuLy8gbWFrZXMgc3ViY2xhc3Npbmcgd29yayBjb3JyZWN0IGZvciB3cmFwcGVkIGJ1aWx0LWluc1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoJHRoaXMsIGR1bW15LCBXcmFwcGVyKSB7XG4gIHZhciBOZXdUYXJnZXQsIE5ld1RhcmdldFByb3RvdHlwZTtcbiAgaWYgKFxuICAgIC8vIGl0IGNhbiB3b3JrIG9ubHkgd2l0aCBuYXRpdmUgYHNldFByb3RvdHlwZU9mYFxuICAgIHNldFByb3RvdHlwZU9mICYmXG4gICAgLy8gd2UgaGF2ZW4ndCBjb21wbGV0ZWx5IGNvcnJlY3QgcHJlLUVTNiB3YXkgZm9yIGdldHRpbmcgYG5ldy50YXJnZXRgLCBzbyB1c2UgdGhpc1xuICAgIGlzQ2FsbGFibGUoTmV3VGFyZ2V0ID0gZHVtbXkuY29uc3RydWN0b3IpICYmXG4gICAgTmV3VGFyZ2V0ICE9PSBXcmFwcGVyICYmXG4gICAgaXNPYmplY3QoTmV3VGFyZ2V0UHJvdG90eXBlID0gTmV3VGFyZ2V0LnByb3RvdHlwZSkgJiZcbiAgICBOZXdUYXJnZXRQcm90b3R5cGUgIT09IFdyYXBwZXIucHJvdG90eXBlXG4gICkgc2V0UHJvdG90eXBlT2YoJHRoaXMsIE5ld1RhcmdldFByb3RvdHlwZSk7XG4gIHJldHVybiAkdGhpcztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdW5jdXJyeVRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIHN0b3JlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZC1zdG9yZScpO1xuXG52YXIgZnVuY3Rpb25Ub1N0cmluZyA9IHVuY3VycnlUaGlzKEZ1bmN0aW9uLnRvU3RyaW5nKTtcblxuLy8gdGhpcyBoZWxwZXIgYnJva2VuIGluIGBjb3JlLWpzQDMuNC4xLTMuNC40YCwgc28gd2UgY2FuJ3QgdXNlIGBzaGFyZWRgIGhlbHBlclxuaWYgKCFpc0NhbGxhYmxlKHN0b3JlLmluc3BlY3RTb3VyY2UpKSB7XG4gIHN0b3JlLmluc3BlY3RTb3VyY2UgPSBmdW5jdGlvbiAoaXQpIHtcbiAgICByZXR1cm4gZnVuY3Rpb25Ub1N0cmluZyhpdCk7XG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3RvcmUuaW5zcGVjdFNvdXJjZTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcbnZhciBjcmVhdGVOb25FbnVtZXJhYmxlUHJvcGVydHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLW5vbi1lbnVtZXJhYmxlLXByb3BlcnR5Jyk7XG5cbi8vIGBJbnN0YWxsRXJyb3JDYXVzZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvcHJvcG9zYWwtZXJyb3ItY2F1c2UvI3NlYy1lcnJvcm9iamVjdHMtaW5zdGFsbC1lcnJvci1jYXVzZVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoTywgb3B0aW9ucykge1xuICBpZiAoaXNPYmplY3Qob3B0aW9ucykgJiYgJ2NhdXNlJyBpbiBvcHRpb25zKSB7XG4gICAgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KE8sICdjYXVzZScsIG9wdGlvbnMuY2F1c2UpO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIE5BVElWRV9XRUFLX01BUCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy93ZWFrLW1hcC1iYXNpYy1kZXRlY3Rpb24nKTtcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG52YXIgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NyZWF0ZS1ub24tZW51bWVyYWJsZS1wcm9wZXJ0eScpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgc2hhcmVkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZC1zdG9yZScpO1xudmFyIHNoYXJlZEtleSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9zaGFyZWQta2V5Jyk7XG52YXIgaGlkZGVuS2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oaWRkZW4ta2V5cycpO1xuXG52YXIgT0JKRUNUX0FMUkVBRFlfSU5JVElBTElaRUQgPSAnT2JqZWN0IGFscmVhZHkgaW5pdGlhbGl6ZWQnO1xudmFyIFR5cGVFcnJvciA9IGdsb2JhbFRoaXMuVHlwZUVycm9yO1xudmFyIFdlYWtNYXAgPSBnbG9iYWxUaGlzLldlYWtNYXA7XG52YXIgc2V0LCBnZXQsIGhhcztcblxudmFyIGVuZm9yY2UgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGhhcyhpdCkgPyBnZXQoaXQpIDogc2V0KGl0LCB7fSk7XG59O1xuXG52YXIgZ2V0dGVyRm9yID0gZnVuY3Rpb24gKFRZUEUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChpdCkge1xuICAgIHZhciBzdGF0ZTtcbiAgICBpZiAoIWlzT2JqZWN0KGl0KSB8fCAoc3RhdGUgPSBnZXQoaXQpKS50eXBlICE9PSBUWVBFKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbmNvbXBhdGlibGUgcmVjZWl2ZXIsICcgKyBUWVBFICsgJyByZXF1aXJlZCcpO1xuICAgIH0gcmV0dXJuIHN0YXRlO1xuICB9O1xufTtcblxuaWYgKE5BVElWRV9XRUFLX01BUCB8fCBzaGFyZWQuc3RhdGUpIHtcbiAgdmFyIHN0b3JlID0gc2hhcmVkLnN0YXRlIHx8IChzaGFyZWQuc3RhdGUgPSBuZXcgV2Vha01hcCgpKTtcbiAgLyogZXNsaW50LWRpc2FibGUgbm8tc2VsZi1hc3NpZ24gLS0gcHJvdG90eXBlIG1ldGhvZHMgcHJvdGVjdGlvbiAqL1xuICBzdG9yZS5nZXQgPSBzdG9yZS5nZXQ7XG4gIHN0b3JlLmhhcyA9IHN0b3JlLmhhcztcbiAgc3RvcmUuc2V0ID0gc3RvcmUuc2V0O1xuICAvKiBlc2xpbnQtZW5hYmxlIG5vLXNlbGYtYXNzaWduIC0tIHByb3RvdHlwZSBtZXRob2RzIHByb3RlY3Rpb24gKi9cbiAgc2V0ID0gZnVuY3Rpb24gKGl0LCBtZXRhZGF0YSkge1xuICAgIGlmIChzdG9yZS5oYXMoaXQpKSB0aHJvdyBuZXcgVHlwZUVycm9yKE9CSkVDVF9BTFJFQURZX0lOSVRJQUxJWkVEKTtcbiAgICBtZXRhZGF0YS5mYWNhZGUgPSBpdDtcbiAgICBzdG9yZS5zZXQoaXQsIG1ldGFkYXRhKTtcbiAgICByZXR1cm4gbWV0YWRhdGE7XG4gIH07XG4gIGdldCA9IGZ1bmN0aW9uIChpdCkge1xuICAgIHJldHVybiBzdG9yZS5nZXQoaXQpIHx8IHt9O1xuICB9O1xuICBoYXMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgICByZXR1cm4gc3RvcmUuaGFzKGl0KTtcbiAgfTtcbn0gZWxzZSB7XG4gIHZhciBTVEFURSA9IHNoYXJlZEtleSgnc3RhdGUnKTtcbiAgaGlkZGVuS2V5c1tTVEFURV0gPSB0cnVlO1xuICBzZXQgPSBmdW5jdGlvbiAoaXQsIG1ldGFkYXRhKSB7XG4gICAgaWYgKGhhc093bihpdCwgU1RBVEUpKSB0aHJvdyBuZXcgVHlwZUVycm9yKE9CSkVDVF9BTFJFQURZX0lOSVRJQUxJWkVEKTtcbiAgICBtZXRhZGF0YS5mYWNhZGUgPSBpdDtcbiAgICBjcmVhdGVOb25FbnVtZXJhYmxlUHJvcGVydHkoaXQsIFNUQVRFLCBtZXRhZGF0YSk7XG4gICAgcmV0dXJuIG1ldGFkYXRhO1xuICB9O1xuICBnZXQgPSBmdW5jdGlvbiAoaXQpIHtcbiAgICByZXR1cm4gaGFzT3duKGl0LCBTVEFURSkgPyBpdFtTVEFURV0gOiB7fTtcbiAgfTtcbiAgaGFzID0gZnVuY3Rpb24gKGl0KSB7XG4gICAgcmV0dXJuIGhhc093bihpdCwgU1RBVEUpO1xuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgc2V0OiBzZXQsXG4gIGdldDogZ2V0LFxuICBoYXM6IGhhcyxcbiAgZW5mb3JjZTogZW5mb3JjZSxcbiAgZ2V0dGVyRm9yOiBnZXR0ZXJGb3Jcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLUlzSFRNTEREQS1pbnRlcm5hbC1zbG90XG52YXIgZG9jdW1lbnRBbGwgPSB0eXBlb2YgZG9jdW1lbnQgPT0gJ29iamVjdCcgJiYgZG9jdW1lbnQuYWxsO1xuXG4vLyBgSXNDYWxsYWJsZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWlzY2FsbGFibGVcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSB1bmljb3JuL25vLXR5cGVvZi11bmRlZmluZWQgLS0gcmVxdWlyZWQgZm9yIHRlc3Rpbmdcbm1vZHVsZS5leHBvcnRzID0gdHlwZW9mIGRvY3VtZW50QWxsID09ICd1bmRlZmluZWQnICYmIGRvY3VtZW50QWxsICE9PSB1bmRlZmluZWQgPyBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmd1bWVudCA9PSAnZnVuY3Rpb24nIHx8IGFyZ3VtZW50ID09PSBkb2N1bWVudEFsbDtcbn0gOiBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmd1bWVudCA9PSAnZnVuY3Rpb24nO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBmYWlscyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mYWlscycpO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcblxudmFyIHJlcGxhY2VtZW50ID0gLyN8XFwucHJvdG90eXBlXFwuLztcblxudmFyIGlzRm9yY2VkID0gZnVuY3Rpb24gKGZlYXR1cmUsIGRldGVjdGlvbikge1xuICB2YXIgdmFsdWUgPSBkYXRhW25vcm1hbGl6ZShmZWF0dXJlKV07XG4gIHJldHVybiB2YWx1ZSA9PT0gUE9MWUZJTEwgPyB0cnVlXG4gICAgOiB2YWx1ZSA9PT0gTkFUSVZFID8gZmFsc2VcbiAgICA6IGlzQ2FsbGFibGUoZGV0ZWN0aW9uKSA/IGZhaWxzKGRldGVjdGlvbilcbiAgICA6ICEhZGV0ZWN0aW9uO1xufTtcblxudmFyIG5vcm1hbGl6ZSA9IGlzRm9yY2VkLm5vcm1hbGl6ZSA9IGZ1bmN0aW9uIChzdHJpbmcpIHtcbiAgcmV0dXJuIFN0cmluZyhzdHJpbmcpLnJlcGxhY2UocmVwbGFjZW1lbnQsICcuJykudG9Mb3dlckNhc2UoKTtcbn07XG5cbnZhciBkYXRhID0gaXNGb3JjZWQuZGF0YSA9IHt9O1xudmFyIE5BVElWRSA9IGlzRm9yY2VkLk5BVElWRSA9ICdOJztcbnZhciBQT0xZRklMTCA9IGlzRm9yY2VkLlBPTFlGSUxMID0gJ1AnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGlzRm9yY2VkO1xuIiwiJ3VzZSBzdHJpY3QnO1xuLy8gd2UgY2FuJ3QgdXNlIGp1c3QgYGl0ID09IG51bGxgIHNpbmNlIG9mIGBkb2N1bWVudC5hbGxgIHNwZWNpYWwgY2FzZVxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1Jc0hUTUxEREEtaW50ZXJuYWwtc2xvdC1hZWNcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBpdCA9PT0gbnVsbCB8fCBpdCA9PT0gdW5kZWZpbmVkO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc0NhbGxhYmxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLWNhbGxhYmxlJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiB0eXBlb2YgaXQgPT0gJ29iamVjdCcgPyBpdCAhPT0gbnVsbCA6IGlzQ2FsbGFibGUoaXQpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuIGlzT2JqZWN0KGFyZ3VtZW50KSB8fCBhcmd1bWVudCA9PT0gbnVsbDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGZhbHNlO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdldEJ1aWx0SW4gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2V0LWJ1aWx0LWluJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIGlzUHJvdG90eXBlT2YgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWlzLXByb3RvdHlwZS1vZicpO1xudmFyIFVTRV9TWU1CT0xfQVNfVUlEID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3VzZS1zeW1ib2wtYXMtdWlkJyk7XG5cbnZhciAkT2JqZWN0ID0gT2JqZWN0O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFVTRV9TWU1CT0xfQVNfVUlEID8gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiB0eXBlb2YgaXQgPT0gJ3N5bWJvbCc7XG59IDogZnVuY3Rpb24gKGl0KSB7XG4gIHZhciAkU3ltYm9sID0gZ2V0QnVpbHRJbignU3ltYm9sJyk7XG4gIHJldHVybiBpc0NhbGxhYmxlKCRTeW1ib2wpICYmIGlzUHJvdG90eXBlT2YoJFN5bWJvbC5wcm90b3R5cGUsICRPYmplY3QoaXQpKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9MZW5ndGggPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8tbGVuZ3RoJyk7XG5cbi8vIGBMZW5ndGhPZkFycmF5TGlrZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWxlbmd0aG9mYXJyYXlsaWtlXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChvYmopIHtcbiAgcmV0dXJuIHRvTGVuZ3RoKG9iai5sZW5ndGgpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciB1bmN1cnJ5VGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mdW5jdGlvbi11bmN1cnJ5LXRoaXMnKTtcbnZhciBmYWlscyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mYWlscycpO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcbnZhciBoYXNPd24gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaGFzLW93bi1wcm9wZXJ0eScpO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgQ09ORklHVVJBQkxFX0ZVTkNUSU9OX05BTUUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tbmFtZScpLkNPTkZJR1VSQUJMRTtcbnZhciBpbnNwZWN0U291cmNlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2luc3BlY3Qtc291cmNlJyk7XG52YXIgSW50ZXJuYWxTdGF0ZU1vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pbnRlcm5hbC1zdGF0ZScpO1xuXG52YXIgZW5mb3JjZUludGVybmFsU3RhdGUgPSBJbnRlcm5hbFN0YXRlTW9kdWxlLmVuZm9yY2U7XG52YXIgZ2V0SW50ZXJuYWxTdGF0ZSA9IEludGVybmFsU3RhdGVNb2R1bGUuZ2V0O1xudmFyICRTdHJpbmcgPSBTdHJpbmc7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBzdHJpbmdTbGljZSA9IHVuY3VycnlUaGlzKCcnLnNsaWNlKTtcbnZhciByZXBsYWNlID0gdW5jdXJyeVRoaXMoJycucmVwbGFjZSk7XG52YXIgam9pbiA9IHVuY3VycnlUaGlzKFtdLmpvaW4pO1xuXG52YXIgQ09ORklHVVJBQkxFX0xFTkdUSCA9IERFU0NSSVBUT1JTICYmICFmYWlscyhmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBkZWZpbmVQcm9wZXJ0eShmdW5jdGlvbiAoKSB7IC8qIGVtcHR5ICovIH0sICdsZW5ndGgnLCB7IHZhbHVlOiA4IH0pLmxlbmd0aCAhPT0gODtcbn0pO1xuXG52YXIgVEVNUExBVEUgPSBTdHJpbmcoU3RyaW5nKS5zcGxpdCgnU3RyaW5nJyk7XG5cbnZhciBtYWtlQnVpbHRJbiA9IG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHZhbHVlLCBuYW1lLCBvcHRpb25zKSB7XG4gIGlmIChzdHJpbmdTbGljZSgkU3RyaW5nKG5hbWUpLCAwLCA3KSA9PT0gJ1N5bWJvbCgnKSB7XG4gICAgbmFtZSA9ICdbJyArIHJlcGxhY2UoJFN0cmluZyhuYW1lKSwgL15TeW1ib2xcXCgoW14pXSopXFwpLiokLywgJyQxJykgKyAnXSc7XG4gIH1cbiAgaWYgKG9wdGlvbnMgJiYgb3B0aW9ucy5nZXR0ZXIpIG5hbWUgPSAnZ2V0ICcgKyBuYW1lO1xuICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLnNldHRlcikgbmFtZSA9ICdzZXQgJyArIG5hbWU7XG4gIGlmICghaGFzT3duKHZhbHVlLCAnbmFtZScpIHx8IChDT05GSUdVUkFCTEVfRlVOQ1RJT05fTkFNRSAmJiB2YWx1ZS5uYW1lICE9PSBuYW1lKSkge1xuICAgIGlmIChERVNDUklQVE9SUykgZGVmaW5lUHJvcGVydHkodmFsdWUsICduYW1lJywgeyB2YWx1ZTogbmFtZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuICAgIGVsc2UgdmFsdWUubmFtZSA9IG5hbWU7XG4gIH1cbiAgaWYgKENPTkZJR1VSQUJMRV9MRU5HVEggJiYgb3B0aW9ucyAmJiBoYXNPd24ob3B0aW9ucywgJ2FyaXR5JykgJiYgdmFsdWUubGVuZ3RoICE9PSBvcHRpb25zLmFyaXR5KSB7XG4gICAgZGVmaW5lUHJvcGVydHkodmFsdWUsICdsZW5ndGgnLCB7IHZhbHVlOiBvcHRpb25zLmFyaXR5IH0pO1xuICB9XG4gIHRyeSB7XG4gICAgaWYgKG9wdGlvbnMgJiYgaGFzT3duKG9wdGlvbnMsICdjb25zdHJ1Y3RvcicpICYmIG9wdGlvbnMuY29uc3RydWN0b3IpIHtcbiAgICAgIGlmIChERVNDUklQVE9SUykgZGVmaW5lUHJvcGVydHkodmFsdWUsICdwcm90b3R5cGUnLCB7IHdyaXRhYmxlOiBmYWxzZSB9KTtcbiAgICAvLyBpbiBWOCB+IENocm9tZSA1MywgcHJvdG90eXBlcyBvZiBzb21lIG1ldGhvZHMsIGxpa2UgYEFycmF5LnByb3RvdHlwZS52YWx1ZXNgLCBhcmUgbm9uLXdyaXRhYmxlXG4gICAgfSBlbHNlIGlmICh2YWx1ZS5wcm90b3R5cGUpIHZhbHVlLnByb3RvdHlwZSA9IHVuZGVmaW5lZDtcbiAgfSBjYXRjaCAoZXJyb3IpIHsgLyogZW1wdHkgKi8gfVxuICB2YXIgc3RhdGUgPSBlbmZvcmNlSW50ZXJuYWxTdGF0ZSh2YWx1ZSk7XG4gIGlmICghaGFzT3duKHN0YXRlLCAnc291cmNlJykpIHtcbiAgICBzdGF0ZS5zb3VyY2UgPSBqb2luKFRFTVBMQVRFLCB0eXBlb2YgbmFtZSA9PSAnc3RyaW5nJyA/IG5hbWUgOiAnJyk7XG4gIH0gcmV0dXJuIHZhbHVlO1xufTtcblxuLy8gYWRkIGZha2UgRnVuY3Rpb24jdG9TdHJpbmcgZm9yIGNvcnJlY3Qgd29yayB3cmFwcGVkIG1ldGhvZHMgLyBjb25zdHJ1Y3RvcnMgd2l0aCBtZXRob2RzIGxpa2UgTG9EYXNoIGlzTmF0aXZlXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZXh0ZW5kLW5hdGl2ZSAtLSByZXF1aXJlZFxuRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nID0gbWFrZUJ1aWx0SW4oZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gIHJldHVybiBpc0NhbGxhYmxlKHRoaXMpICYmIGdldEludGVybmFsU3RhdGUodGhpcykuc291cmNlIHx8IGluc3BlY3RTb3VyY2UodGhpcyk7XG59LCAndG9TdHJpbmcnKTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBjZWlsID0gTWF0aC5jZWlsO1xudmFyIGZsb29yID0gTWF0aC5mbG9vcjtcblxuLy8gYE1hdGgudHJ1bmNgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1tYXRoLnRydW5jXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tbWF0aC10cnVuYyAtLSBzYWZlXG5tb2R1bGUuZXhwb3J0cyA9IE1hdGgudHJ1bmMgfHwgZnVuY3Rpb24gdHJ1bmMoeCkge1xuICB2YXIgbiA9ICt4O1xuICByZXR1cm4gKG4gPiAwID8gZmxvb3IgOiBjZWlsKShuKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9TdHJpbmcgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8tc3RyaW5nJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyZ3VtZW50LCAkZGVmYXVsdCkge1xuICByZXR1cm4gYXJndW1lbnQgPT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50cy5sZW5ndGggPCAyID8gJycgOiAkZGVmYXVsdCA6IHRvU3RyaW5nKGFyZ3VtZW50KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vKiBnbG9iYWwgQWN0aXZlWE9iamVjdCAtLSBvbGQgSUUsIFdTSCAqL1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2FuLW9iamVjdCcpO1xudmFyIGRlZmluZVByb3BlcnRpZXNNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0aWVzJyk7XG52YXIgZW51bUJ1Z0tleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW51bS1idWcta2V5cycpO1xudmFyIGhpZGRlbktleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaGlkZGVuLWtleXMnKTtcbnZhciBodG1sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2h0bWwnKTtcbnZhciBkb2N1bWVudENyZWF0ZUVsZW1lbnQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZG9jdW1lbnQtY3JlYXRlLWVsZW1lbnQnKTtcbnZhciBzaGFyZWRLZXkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvc2hhcmVkLWtleScpO1xuXG52YXIgR1QgPSAnPic7XG52YXIgTFQgPSAnPCc7XG52YXIgUFJPVE9UWVBFID0gJ3Byb3RvdHlwZSc7XG52YXIgU0NSSVBUID0gJ3NjcmlwdCc7XG52YXIgSUVfUFJPVE8gPSBzaGFyZWRLZXkoJ0lFX1BST1RPJyk7XG5cbnZhciBFbXB0eUNvbnN0cnVjdG9yID0gZnVuY3Rpb24gKCkgeyAvKiBlbXB0eSAqLyB9O1xuXG52YXIgc2NyaXB0VGFnID0gZnVuY3Rpb24gKGNvbnRlbnQpIHtcbiAgcmV0dXJuIExUICsgU0NSSVBUICsgR1QgKyBjb250ZW50ICsgTFQgKyAnLycgKyBTQ1JJUFQgKyBHVDtcbn07XG5cbi8vIENyZWF0ZSBvYmplY3Qgd2l0aCBmYWtlIGBudWxsYCBwcm90b3R5cGU6IHVzZSBBY3RpdmVYIE9iamVjdCB3aXRoIGNsZWFyZWQgcHJvdG90eXBlXG52YXIgTnVsbFByb3RvT2JqZWN0VmlhQWN0aXZlWCA9IGZ1bmN0aW9uIChhY3RpdmVYRG9jdW1lbnQpIHtcbiAgYWN0aXZlWERvY3VtZW50LndyaXRlKHNjcmlwdFRhZygnJykpO1xuICBhY3RpdmVYRG9jdW1lbnQuY2xvc2UoKTtcbiAgdmFyIHRlbXAgPSBhY3RpdmVYRG9jdW1lbnQucGFyZW50V2luZG93Lk9iamVjdDtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZWxlc3MtYXNzaWdubWVudCAtLSBhdm9pZCBtZW1vcnkgbGVha1xuICBhY3RpdmVYRG9jdW1lbnQgPSBudWxsO1xuICByZXR1cm4gdGVtcDtcbn07XG5cbi8vIENyZWF0ZSBvYmplY3Qgd2l0aCBmYWtlIGBudWxsYCBwcm90b3R5cGU6IHVzZSBpZnJhbWUgT2JqZWN0IHdpdGggY2xlYXJlZCBwcm90b3R5cGVcbnZhciBOdWxsUHJvdG9PYmplY3RWaWFJRnJhbWUgPSBmdW5jdGlvbiAoKSB7XG4gIC8vIFRocmFzaCwgd2FzdGUgYW5kIHNvZG9teTogSUUgR0MgYnVnXG4gIHZhciBpZnJhbWUgPSBkb2N1bWVudENyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xuICB2YXIgSlMgPSAnamF2YScgKyBTQ1JJUFQgKyAnOic7XG4gIHZhciBpZnJhbWVEb2N1bWVudDtcbiAgaWZyYW1lLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gIGh0bWwuYXBwZW5kQ2hpbGQoaWZyYW1lKTtcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvaXNzdWVzLzQ3NVxuICBpZnJhbWUuc3JjID0gU3RyaW5nKEpTKTtcbiAgaWZyYW1lRG9jdW1lbnQgPSBpZnJhbWUuY29udGVudFdpbmRvdy5kb2N1bWVudDtcbiAgaWZyYW1lRG9jdW1lbnQub3BlbigpO1xuICBpZnJhbWVEb2N1bWVudC53cml0ZShzY3JpcHRUYWcoJ2RvY3VtZW50LkY9T2JqZWN0JykpO1xuICBpZnJhbWVEb2N1bWVudC5jbG9zZSgpO1xuICByZXR1cm4gaWZyYW1lRG9jdW1lbnQuRjtcbn07XG5cbi8vIENoZWNrIGZvciBkb2N1bWVudC5kb21haW4gYW5kIGFjdGl2ZSB4IHN1cHBvcnRcbi8vIE5vIG5lZWQgdG8gdXNlIGFjdGl2ZSB4IGFwcHJvYWNoIHdoZW4gZG9jdW1lbnQuZG9tYWluIGlzIG5vdCBzZXRcbi8vIHNlZSBodHRwczovL2dpdGh1Yi5jb20vZXMtc2hpbXMvZXM1LXNoaW0vaXNzdWVzLzE1MFxuLy8gdmFyaWF0aW9uIG9mIGh0dHBzOi8vZ2l0aHViLmNvbS9raXRjYW1icmlkZ2UvZXM1LXNoaW0vY29tbWl0LzRmNzM4YWMwNjYzNDZcbi8vIGF2b2lkIElFIEdDIGJ1Z1xudmFyIGFjdGl2ZVhEb2N1bWVudDtcbnZhciBOdWxsUHJvdG9PYmplY3QgPSBmdW5jdGlvbiAoKSB7XG4gIHRyeSB7XG4gICAgYWN0aXZlWERvY3VtZW50ID0gbmV3IEFjdGl2ZVhPYmplY3QoJ2h0bWxmaWxlJyk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGlnbm9yZSAqLyB9XG4gIE51bGxQcm90b09iamVjdCA9IHR5cGVvZiBkb2N1bWVudCAhPSAndW5kZWZpbmVkJ1xuICAgID8gZG9jdW1lbnQuZG9tYWluICYmIGFjdGl2ZVhEb2N1bWVudFxuICAgICAgPyBOdWxsUHJvdG9PYmplY3RWaWFBY3RpdmVYKGFjdGl2ZVhEb2N1bWVudCkgLy8gb2xkIElFXG4gICAgICA6IE51bGxQcm90b09iamVjdFZpYUlGcmFtZSgpXG4gICAgOiBOdWxsUHJvdG9PYmplY3RWaWFBY3RpdmVYKGFjdGl2ZVhEb2N1bWVudCk7IC8vIFdTSFxuICB2YXIgbGVuZ3RoID0gZW51bUJ1Z0tleXMubGVuZ3RoO1xuICB3aGlsZSAobGVuZ3RoLS0pIGRlbGV0ZSBOdWxsUHJvdG9PYmplY3RbUFJPVE9UWVBFXVtlbnVtQnVnS2V5c1tsZW5ndGhdXTtcbiAgcmV0dXJuIE51bGxQcm90b09iamVjdCgpO1xufTtcblxuaGlkZGVuS2V5c1tJRV9QUk9UT10gPSB0cnVlO1xuXG4vLyBgT2JqZWN0LmNyZWF0ZWAgbWV0aG9kXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5jcmVhdGVcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtY3JlYXRlIC0tIHNhZmVcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmNyZWF0ZSB8fCBmdW5jdGlvbiBjcmVhdGUoTywgUHJvcGVydGllcykge1xuICB2YXIgcmVzdWx0O1xuICBpZiAoTyAhPT0gbnVsbCkge1xuICAgIEVtcHR5Q29uc3RydWN0b3JbUFJPVE9UWVBFXSA9IGFuT2JqZWN0KE8pO1xuICAgIHJlc3VsdCA9IG5ldyBFbXB0eUNvbnN0cnVjdG9yKCk7XG4gICAgRW1wdHlDb25zdHJ1Y3RvcltQUk9UT1RZUEVdID0gbnVsbDtcbiAgICAvLyBhZGQgXCJfX3Byb3RvX19cIiBmb3IgT2JqZWN0LmdldFByb3RvdHlwZU9mIHBvbHlmaWxsXG4gICAgcmVzdWx0W0lFX1BST1RPXSA9IE87XG4gIH0gZWxzZSByZXN1bHQgPSBOdWxsUHJvdG9PYmplY3QoKTtcbiAgcmV0dXJuIFByb3BlcnRpZXMgPT09IHVuZGVmaW5lZCA/IHJlc3VsdCA6IGRlZmluZVByb3BlcnRpZXNNb2R1bGUuZihyZXN1bHQsIFByb3BlcnRpZXMpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xudmFyIFY4X1BST1RPVFlQRV9ERUZJTkVfQlVHID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3Y4LXByb3RvdHlwZS1kZWZpbmUtYnVnJyk7XG52YXIgZGVmaW5lUHJvcGVydHlNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eScpO1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2FuLW9iamVjdCcpO1xudmFyIHRvSW5kZXhlZE9iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1pbmRleGVkLW9iamVjdCcpO1xudmFyIG9iamVjdEtleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWtleXMnKTtcblxuLy8gYE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzYCBtZXRob2Rcbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtb2JqZWN0LmRlZmluZXByb3BlcnRpZXNcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZGVmaW5lcHJvcGVydGllcyAtLSBzYWZlXG5leHBvcnRzLmYgPSBERVNDUklQVE9SUyAmJiAhVjhfUFJPVE9UWVBFX0RFRklORV9CVUcgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyA6IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXMoTywgUHJvcGVydGllcykge1xuICBhbk9iamVjdChPKTtcbiAgdmFyIHByb3BzID0gdG9JbmRleGVkT2JqZWN0KFByb3BlcnRpZXMpO1xuICB2YXIga2V5cyA9IG9iamVjdEtleXMoUHJvcGVydGllcyk7XG4gIHZhciBsZW5ndGggPSBrZXlzLmxlbmd0aDtcbiAgdmFyIGluZGV4ID0gMDtcbiAgdmFyIGtleTtcbiAgd2hpbGUgKGxlbmd0aCA+IGluZGV4KSBkZWZpbmVQcm9wZXJ0eU1vZHVsZS5mKE8sIGtleSA9IGtleXNbaW5kZXgrK10sIHByb3BzW2tleV0pO1xuICByZXR1cm4gTztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgREVTQ1JJUFRPUlMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZGVzY3JpcHRvcnMnKTtcbnZhciBJRThfRE9NX0RFRklORSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pZTgtZG9tLWRlZmluZScpO1xudmFyIFY4X1BST1RPVFlQRV9ERUZJTkVfQlVHID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3Y4LXByb3RvdHlwZS1kZWZpbmUtYnVnJyk7XG52YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvYW4tb2JqZWN0Jyk7XG52YXIgdG9Qcm9wZXJ0eUtleSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1wcm9wZXJ0eS1rZXknKTtcblxudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbnZhciAkZGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5ZGVzY3JpcHRvciAtLSBzYWZlXG52YXIgJGdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgRU5VTUVSQUJMRSA9ICdlbnVtZXJhYmxlJztcbnZhciBDT05GSUdVUkFCTEUgPSAnY29uZmlndXJhYmxlJztcbnZhciBXUklUQUJMRSA9ICd3cml0YWJsZSc7XG5cbi8vIGBPYmplY3QuZGVmaW5lUHJvcGVydHlgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1vYmplY3QuZGVmaW5lcHJvcGVydHlcbmV4cG9ydHMuZiA9IERFU0NSSVBUT1JTID8gVjhfUFJPVE9UWVBFX0RFRklORV9CVUcgPyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKSB7XG4gIGFuT2JqZWN0KE8pO1xuICBQID0gdG9Qcm9wZXJ0eUtleShQKTtcbiAgYW5PYmplY3QoQXR0cmlidXRlcyk7XG4gIGlmICh0eXBlb2YgTyA9PT0gJ2Z1bmN0aW9uJyAmJiBQID09PSAncHJvdG90eXBlJyAmJiAndmFsdWUnIGluIEF0dHJpYnV0ZXMgJiYgV1JJVEFCTEUgaW4gQXR0cmlidXRlcyAmJiAhQXR0cmlidXRlc1tXUklUQUJMRV0pIHtcbiAgICB2YXIgY3VycmVudCA9ICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoTywgUCk7XG4gICAgaWYgKGN1cnJlbnQgJiYgY3VycmVudFtXUklUQUJMRV0pIHtcbiAgICAgIE9bUF0gPSBBdHRyaWJ1dGVzLnZhbHVlO1xuICAgICAgQXR0cmlidXRlcyA9IHtcbiAgICAgICAgY29uZmlndXJhYmxlOiBDT05GSUdVUkFCTEUgaW4gQXR0cmlidXRlcyA/IEF0dHJpYnV0ZXNbQ09ORklHVVJBQkxFXSA6IGN1cnJlbnRbQ09ORklHVVJBQkxFXSxcbiAgICAgICAgZW51bWVyYWJsZTogRU5VTUVSQUJMRSBpbiBBdHRyaWJ1dGVzID8gQXR0cmlidXRlc1tFTlVNRVJBQkxFXSA6IGN1cnJlbnRbRU5VTUVSQUJMRV0sXG4gICAgICAgIHdyaXRhYmxlOiBmYWxzZVxuICAgICAgfTtcbiAgICB9XG4gIH0gcmV0dXJuICRkZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKTtcbn0gOiAkZGVmaW5lUHJvcGVydHkgOiBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKSB7XG4gIGFuT2JqZWN0KE8pO1xuICBQID0gdG9Qcm9wZXJ0eUtleShQKTtcbiAgYW5PYmplY3QoQXR0cmlidXRlcyk7XG4gIGlmIChJRThfRE9NX0RFRklORSkgdHJ5IHtcbiAgICByZXR1cm4gJGRlZmluZVByb3BlcnR5KE8sIFAsIEF0dHJpYnV0ZXMpO1xuICB9IGNhdGNoIChlcnJvcikgeyAvKiBlbXB0eSAqLyB9XG4gIGlmICgnZ2V0JyBpbiBBdHRyaWJ1dGVzIHx8ICdzZXQnIGluIEF0dHJpYnV0ZXMpIHRocm93IG5ldyAkVHlwZUVycm9yKCdBY2Nlc3NvcnMgbm90IHN1cHBvcnRlZCcpO1xuICBpZiAoJ3ZhbHVlJyBpbiBBdHRyaWJ1dGVzKSBPW1BdID0gQXR0cmlidXRlcy52YWx1ZTtcbiAgcmV0dXJuIE87XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgY2FsbCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mdW5jdGlvbi1jYWxsJyk7XG52YXIgcHJvcGVydHlJc0VudW1lcmFibGVNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LXByb3BlcnR5LWlzLWVudW1lcmFibGUnKTtcbnZhciBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3InKTtcbnZhciB0b0luZGV4ZWRPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8taW5kZXhlZC1vYmplY3QnKTtcbnZhciB0b1Byb3BlcnR5S2V5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLXByb3BlcnR5LWtleScpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgSUU4X0RPTV9ERUZJTkUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaWU4LWRvbS1kZWZpbmUnKTtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1nZXRvd25wcm9wZXJ0eWRlc2NyaXB0b3IgLS0gc2FmZVxudmFyICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuXG4vLyBgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcmAgbWV0aG9kXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5nZXRvd25wcm9wZXJ0eWRlc2NyaXB0b3JcbmV4cG9ydHMuZiA9IERFU0NSSVBUT1JTID8gJGdldE93blByb3BlcnR5RGVzY3JpcHRvciA6IGZ1bmN0aW9uIGdldE93blByb3BlcnR5RGVzY3JpcHRvcihPLCBQKSB7XG4gIE8gPSB0b0luZGV4ZWRPYmplY3QoTyk7XG4gIFAgPSB0b1Byb3BlcnR5S2V5KFApO1xuICBpZiAoSUU4X0RPTV9ERUZJTkUpIHRyeSB7XG4gICAgcmV0dXJuICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoTywgUCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbiAgaWYgKGhhc093bihPLCBQKSkgcmV0dXJuIGNyZWF0ZVByb3BlcnR5RGVzY3JpcHRvcighY2FsbChwcm9wZXJ0eUlzRW51bWVyYWJsZU1vZHVsZS5mLCBPLCBQKSwgT1tQXSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGludGVybmFsT2JqZWN0S2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3Qta2V5cy1pbnRlcm5hbCcpO1xudmFyIGVudW1CdWdLZXlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2VudW0tYnVnLWtleXMnKTtcblxudmFyIGhpZGRlbktleXMgPSBlbnVtQnVnS2V5cy5jb25jYXQoJ2xlbmd0aCcsICdwcm90b3R5cGUnKTtcblxuLy8gYE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzYCBtZXRob2Rcbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtb2JqZWN0LmdldG93bnByb3BlcnR5bmFtZXNcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZ2V0b3ducHJvcGVydHluYW1lcyAtLSBzYWZlXG5leHBvcnRzLmYgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyB8fCBmdW5jdGlvbiBnZXRPd25Qcm9wZXJ0eU5hbWVzKE8pIHtcbiAgcmV0dXJuIGludGVybmFsT2JqZWN0S2V5cyhPLCBoaWRkZW5LZXlzKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5c3ltYm9scyAtLSBzYWZlXG5leHBvcnRzLmYgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHVuY3VycnlUaGlzKHt9LmlzUHJvdG90eXBlT2YpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgdG9JbmRleGVkT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLWluZGV4ZWQtb2JqZWN0Jyk7XG52YXIgaW5kZXhPZiA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hcnJheS1pbmNsdWRlcycpLmluZGV4T2Y7XG52YXIgaGlkZGVuS2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oaWRkZW4ta2V5cycpO1xuXG52YXIgcHVzaCA9IHVuY3VycnlUaGlzKFtdLnB1c2gpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChvYmplY3QsIG5hbWVzKSB7XG4gIHZhciBPID0gdG9JbmRleGVkT2JqZWN0KG9iamVjdCk7XG4gIHZhciBpID0gMDtcbiAgdmFyIHJlc3VsdCA9IFtdO1xuICB2YXIga2V5O1xuICBmb3IgKGtleSBpbiBPKSAhaGFzT3duKGhpZGRlbktleXMsIGtleSkgJiYgaGFzT3duKE8sIGtleSkgJiYgcHVzaChyZXN1bHQsIGtleSk7XG4gIC8vIERvbid0IGVudW0gYnVnICYgaGlkZGVuIGtleXNcbiAgd2hpbGUgKG5hbWVzLmxlbmd0aCA+IGkpIGlmIChoYXNPd24oTywga2V5ID0gbmFtZXNbaSsrXSkpIHtcbiAgICB+aW5kZXhPZihyZXN1bHQsIGtleSkgfHwgcHVzaChyZXN1bHQsIGtleSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgaW50ZXJuYWxPYmplY3RLZXlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1rZXlzLWludGVybmFsJyk7XG52YXIgZW51bUJ1Z0tleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW51bS1idWcta2V5cycpO1xuXG4vLyBgT2JqZWN0LmtleXNgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1vYmplY3Qua2V5c1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1rZXlzIC0tIHNhZmVcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmtleXMgfHwgZnVuY3Rpb24ga2V5cyhPKSB7XG4gIHJldHVybiBpbnRlcm5hbE9iamVjdEtleXMoTywgZW51bUJ1Z0tleXMpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciAkcHJvcGVydHlJc0VudW1lcmFibGUgPSB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZ2V0b3ducHJvcGVydHlkZXNjcmlwdG9yIC0tIHNhZmVcbnZhciBnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuXG4vLyBOYXNob3JuIH4gSkRLOCBidWdcbnZhciBOQVNIT1JOX0JVRyA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvciAmJiAhJHByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoeyAxOiAyIH0sIDEpO1xuXG4vLyBgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZWAgbWV0aG9kIGltcGxlbWVudGF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5wcm90b3R5cGUucHJvcGVydHlpc2VudW1lcmFibGVcbmV4cG9ydHMuZiA9IE5BU0hPUk5fQlVHID8gZnVuY3Rpb24gcHJvcGVydHlJc0VudW1lcmFibGUoVikge1xuICB2YXIgZGVzY3JpcHRvciA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvcih0aGlzLCBWKTtcbiAgcmV0dXJuICEhZGVzY3JpcHRvciAmJiBkZXNjcmlwdG9yLmVudW1lcmFibGU7XG59IDogJHByb3BlcnR5SXNFbnVtZXJhYmxlO1xuIiwiJ3VzZSBzdHJpY3QnO1xuLyogZXNsaW50LWRpc2FibGUgbm8tcHJvdG8gLS0gc2FmZSAqL1xudmFyIHVuY3VycnlUaGlzQWNjZXNzb3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzLWFjY2Vzc29yJyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG52YXIgcmVxdWlyZU9iamVjdENvZXJjaWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9yZXF1aXJlLW9iamVjdC1jb2VyY2libGUnKTtcbnZhciBhUG9zc2libGVQcm90b3R5cGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvYS1wb3NzaWJsZS1wcm90b3R5cGUnKTtcblxuLy8gYE9iamVjdC5zZXRQcm90b3R5cGVPZmAgbWV0aG9kXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5zZXRwcm90b3R5cGVvZlxuLy8gV29ya3Mgd2l0aCBfX3Byb3RvX18gb25seS4gT2xkIHY4IGNhbid0IHdvcmsgd2l0aCBudWxsIHByb3RvIG9iamVjdHMuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LXNldHByb3RvdHlwZW9mIC0tIHNhZmVcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8ICgnX19wcm90b19fJyBpbiB7fSA/IGZ1bmN0aW9uICgpIHtcbiAgdmFyIENPUlJFQ1RfU0VUVEVSID0gZmFsc2U7XG4gIHZhciB0ZXN0ID0ge307XG4gIHZhciBzZXR0ZXI7XG4gIHRyeSB7XG4gICAgc2V0dGVyID0gdW5jdXJyeVRoaXNBY2Nlc3NvcihPYmplY3QucHJvdG90eXBlLCAnX19wcm90b19fJywgJ3NldCcpO1xuICAgIHNldHRlcih0ZXN0LCBbXSk7XG4gICAgQ09SUkVDVF9TRVRURVIgPSB0ZXN0IGluc3RhbmNlb2YgQXJyYXk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbiAgcmV0dXJuIGZ1bmN0aW9uIHNldFByb3RvdHlwZU9mKE8sIHByb3RvKSB7XG4gICAgcmVxdWlyZU9iamVjdENvZXJjaWJsZShPKTtcbiAgICBhUG9zc2libGVQcm90b3R5cGUocHJvdG8pO1xuICAgIGlmICghaXNPYmplY3QoTykpIHJldHVybiBPO1xuICAgIGlmIChDT1JSRUNUX1NFVFRFUikgc2V0dGVyKE8sIHByb3RvKTtcbiAgICBlbHNlIE8uX19wcm90b19fID0gcHJvdG87XG4gICAgcmV0dXJuIE87XG4gIH07XG59KCkgOiB1bmRlZmluZWQpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGNhbGwgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tY2FsbCcpO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcblxudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG5cbi8vIGBPcmRpbmFyeVRvUHJpbWl0aXZlYCBhYnN0cmFjdCBvcGVyYXRpb25cbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtb3JkaW5hcnl0b3ByaW1pdGl2ZVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaW5wdXQsIHByZWYpIHtcbiAgdmFyIGZuLCB2YWw7XG4gIGlmIChwcmVmID09PSAnc3RyaW5nJyAmJiBpc0NhbGxhYmxlKGZuID0gaW5wdXQudG9TdHJpbmcpICYmICFpc09iamVjdCh2YWwgPSBjYWxsKGZuLCBpbnB1dCkpKSByZXR1cm4gdmFsO1xuICBpZiAoaXNDYWxsYWJsZShmbiA9IGlucHV0LnZhbHVlT2YpICYmICFpc09iamVjdCh2YWwgPSBjYWxsKGZuLCBpbnB1dCkpKSByZXR1cm4gdmFsO1xuICBpZiAocHJlZiAhPT0gJ3N0cmluZycgJiYgaXNDYWxsYWJsZShmbiA9IGlucHV0LnRvU3RyaW5nKSAmJiAhaXNPYmplY3QodmFsID0gY2FsbChmbiwgaW5wdXQpKSkgcmV0dXJuIHZhbDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IoXCJDYW4ndCBjb252ZXJ0IG9iamVjdCB0byBwcmltaXRpdmUgdmFsdWVcIik7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdldEJ1aWx0SW4gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2V0LWJ1aWx0LWluJyk7XG52YXIgdW5jdXJyeVRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzJyk7XG52YXIgZ2V0T3duUHJvcGVydHlOYW1lc01vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1uYW1lcycpO1xudmFyIGdldE93blByb3BlcnR5U3ltYm9sc01vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1zeW1ib2xzJyk7XG52YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvYW4tb2JqZWN0Jyk7XG5cbnZhciBjb25jYXQgPSB1bmN1cnJ5VGhpcyhbXS5jb25jYXQpO1xuXG4vLyBhbGwgb2JqZWN0IGtleXMsIGluY2x1ZGVzIG5vbi1lbnVtZXJhYmxlIGFuZCBzeW1ib2xzXG5tb2R1bGUuZXhwb3J0cyA9IGdldEJ1aWx0SW4oJ1JlZmxlY3QnLCAnb3duS2V5cycpIHx8IGZ1bmN0aW9uIG93bktleXMoaXQpIHtcbiAgdmFyIGtleXMgPSBnZXRPd25Qcm9wZXJ0eU5hbWVzTW9kdWxlLmYoYW5PYmplY3QoaXQpKTtcbiAgdmFyIGdldE93blByb3BlcnR5U3ltYm9scyA9IGdldE93blByb3BlcnR5U3ltYm9sc01vZHVsZS5mO1xuICByZXR1cm4gZ2V0T3duUHJvcGVydHlTeW1ib2xzID8gY29uY2F0KGtleXMsIGdldE93blByb3BlcnR5U3ltYm9scyhpdCkpIDoga2V5cztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZGVmaW5lUHJvcGVydHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eScpLmY7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKFRhcmdldCwgU291cmNlLCBrZXkpIHtcbiAga2V5IGluIFRhcmdldCB8fCBkZWZpbmVQcm9wZXJ0eShUYXJnZXQsIGtleSwge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFNvdXJjZVtrZXldOyB9LFxuICAgIHNldDogZnVuY3Rpb24gKGl0KSB7IFNvdXJjZVtrZXldID0gaXQ7IH1cbiAgfSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGlzTnVsbE9yVW5kZWZpbmVkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLW51bGwtb3ItdW5kZWZpbmVkJyk7XG5cbnZhciAkVHlwZUVycm9yID0gVHlwZUVycm9yO1xuXG4vLyBgUmVxdWlyZU9iamVjdENvZXJjaWJsZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLXJlcXVpcmVvYmplY3Rjb2VyY2libGVcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIGlmIChpc051bGxPclVuZGVmaW5lZChpdCkpIHRocm93IG5ldyAkVHlwZUVycm9yKFwiQ2FuJ3QgY2FsbCBtZXRob2Qgb24gXCIgKyBpdCk7XG4gIHJldHVybiBpdDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgc2hhcmVkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZCcpO1xudmFyIHVpZCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy91aWQnKTtcblxudmFyIGtleXMgPSBzaGFyZWQoJ2tleXMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIHJldHVybiBrZXlzW2tleV0gfHwgKGtleXNba2V5XSA9IHVpZChrZXkpKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgSVNfUFVSRSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1wdXJlJyk7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xudmFyIGRlZmluZUdsb2JhbFByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHknKTtcblxudmFyIFNIQVJFRCA9ICdfX2NvcmUtanNfc2hhcmVkX18nO1xudmFyIHN0b3JlID0gbW9kdWxlLmV4cG9ydHMgPSBnbG9iYWxUaGlzW1NIQVJFRF0gfHwgZGVmaW5lR2xvYmFsUHJvcGVydHkoU0hBUkVELCB7fSk7XG5cbihzdG9yZS52ZXJzaW9ucyB8fCAoc3RvcmUudmVyc2lvbnMgPSBbXSkpLnB1c2goe1xuICB2ZXJzaW9uOiAnMy40MC4wJyxcbiAgbW9kZTogSVNfUFVSRSA/ICdwdXJlJyA6ICdnbG9iYWwnLFxuICBjb3B5cmlnaHQ6ICfCqSAyMDE0LTIwMjUgRGVuaXMgUHVzaGthcmV2ICh6bG9pcm9jay5ydSknLFxuICBsaWNlbnNlOiAnaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvYmxvYi92My40MC4wL0xJQ0VOU0UnLFxuICBzb3VyY2U6ICdodHRwczovL2dpdGh1Yi5jb20vemxvaXJvY2svY29yZS1qcydcbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHN0b3JlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZC1zdG9yZScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChrZXksIHZhbHVlKSB7XG4gIHJldHVybiBzdG9yZVtrZXldIHx8IChzdG9yZVtrZXldID0gdmFsdWUgfHwge30pO1xufTtcbiIsIid1c2Ugc3RyaWN0Jztcbi8qIGVzbGludC1kaXNhYmxlIGVzL25vLXN5bWJvbCAtLSByZXF1aXJlZCBmb3IgdGVzdGluZyAqL1xudmFyIFY4X1ZFUlNJT04gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW52aXJvbm1lbnQtdjgtdmVyc2lvbicpO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2ZhaWxzJyk7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xuXG52YXIgJFN0cmluZyA9IGdsb2JhbFRoaXMuU3RyaW5nO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5c3ltYm9scyAtLSByZXF1aXJlZCBmb3IgdGVzdGluZ1xubW9kdWxlLmV4cG9ydHMgPSAhIU9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgJiYgIWZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgdmFyIHN5bWJvbCA9IFN5bWJvbCgnc3ltYm9sIGRldGVjdGlvbicpO1xuICAvLyBDaHJvbWUgMzggU3ltYm9sIGhhcyBpbmNvcnJlY3QgdG9TdHJpbmcgY29udmVyc2lvblxuICAvLyBgZ2V0LW93bi1wcm9wZXJ0eS1zeW1ib2xzYCBwb2x5ZmlsbCBzeW1ib2xzIGNvbnZlcnRlZCB0byBvYmplY3QgYXJlIG5vdCBTeW1ib2wgaW5zdGFuY2VzXG4gIC8vIG5iOiBEbyBub3QgY2FsbCBgU3RyaW5nYCBkaXJlY3RseSB0byBhdm9pZCB0aGlzIGJlaW5nIG9wdGltaXplZCBvdXQgdG8gYHN5bWJvbCsnJ2Agd2hpY2ggd2lsbCxcbiAgLy8gb2YgY291cnNlLCBmYWlsLlxuICByZXR1cm4gISRTdHJpbmcoc3ltYm9sKSB8fCAhKE9iamVjdChzeW1ib2wpIGluc3RhbmNlb2YgU3ltYm9sKSB8fFxuICAgIC8vIENocm9tZSAzOC00MCBzeW1ib2xzIGFyZSBub3QgaW5oZXJpdGVkIGZyb20gRE9NIGNvbGxlY3Rpb25zIHByb3RvdHlwZXMgdG8gaW5zdGFuY2VzXG4gICAgIVN5bWJvbC5zaGFtICYmIFY4X1ZFUlNJT04gJiYgVjhfVkVSU0lPTiA8IDQxO1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9JbnRlZ2VyT3JJbmZpbml0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1pbnRlZ2VyLW9yLWluZmluaXR5Jyk7XG5cbnZhciBtYXggPSBNYXRoLm1heDtcbnZhciBtaW4gPSBNYXRoLm1pbjtcblxuLy8gSGVscGVyIGZvciBhIHBvcHVsYXIgcmVwZWF0aW5nIGNhc2Ugb2YgdGhlIHNwZWM6XG4vLyBMZXQgaW50ZWdlciBiZSA/IFRvSW50ZWdlcihpbmRleCkuXG4vLyBJZiBpbnRlZ2VyIDwgMCwgbGV0IHJlc3VsdCBiZSBtYXgoKGxlbmd0aCArIGludGVnZXIpLCAwKTsgZWxzZSBsZXQgcmVzdWx0IGJlIG1pbihpbnRlZ2VyLCBsZW5ndGgpLlxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaW5kZXgsIGxlbmd0aCkge1xuICB2YXIgaW50ZWdlciA9IHRvSW50ZWdlck9ySW5maW5pdHkoaW5kZXgpO1xuICByZXR1cm4gaW50ZWdlciA8IDAgPyBtYXgoaW50ZWdlciArIGxlbmd0aCwgMCkgOiBtaW4oaW50ZWdlciwgbGVuZ3RoKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyB0b09iamVjdCB3aXRoIGZhbGxiYWNrIGZvciBub24tYXJyYXktbGlrZSBFUzMgc3RyaW5nc1xudmFyIEluZGV4ZWRPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaW5kZXhlZC1vYmplY3QnKTtcbnZhciByZXF1aXJlT2JqZWN0Q29lcmNpYmxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3JlcXVpcmUtb2JqZWN0LWNvZXJjaWJsZScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gSW5kZXhlZE9iamVjdChyZXF1aXJlT2JqZWN0Q29lcmNpYmxlKGl0KSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHRydW5jID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL21hdGgtdHJ1bmMnKTtcblxuLy8gYFRvSW50ZWdlck9ySW5maW5pdHlgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy10b2ludGVnZXJvcmluZmluaXR5XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICB2YXIgbnVtYmVyID0gK2FyZ3VtZW50O1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2VsZi1jb21wYXJlIC0tIE5hTiBjaGVja1xuICByZXR1cm4gbnVtYmVyICE9PSBudW1iZXIgfHwgbnVtYmVyID09PSAwID8gMCA6IHRydW5jKG51bWJlcik7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHRvSW50ZWdlck9ySW5maW5pdHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8taW50ZWdlci1vci1pbmZpbml0eScpO1xuXG52YXIgbWluID0gTWF0aC5taW47XG5cbi8vIGBUb0xlbmd0aGAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLXRvbGVuZ3RoXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICB2YXIgbGVuID0gdG9JbnRlZ2VyT3JJbmZpbml0eShhcmd1bWVudCk7XG4gIHJldHVybiBsZW4gPiAwID8gbWluKGxlbiwgMHgxRkZGRkZGRkZGRkZGRikgOiAwOyAvLyAyICoqIDUzIC0gMSA9PSA5MDA3MTk5MjU0NzQwOTkxXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHJlcXVpcmVPYmplY3RDb2VyY2libGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvcmVxdWlyZS1vYmplY3QtY29lcmNpYmxlJyk7XG5cbnZhciAkT2JqZWN0ID0gT2JqZWN0O1xuXG4vLyBgVG9PYmplY3RgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy10b29iamVjdFxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuICRPYmplY3QocmVxdWlyZU9iamVjdENvZXJjaWJsZShhcmd1bWVudCkpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBjYWxsID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLWNhbGwnKTtcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcbnZhciBpc1N5bWJvbCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1zeW1ib2wnKTtcbnZhciBnZXRNZXRob2QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2V0LW1ldGhvZCcpO1xudmFyIG9yZGluYXJ5VG9QcmltaXRpdmUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb3JkaW5hcnktdG8tcHJpbWl0aXZlJyk7XG52YXIgd2VsbEtub3duU3ltYm9sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sJyk7XG5cbnZhciAkVHlwZUVycm9yID0gVHlwZUVycm9yO1xudmFyIFRPX1BSSU1JVElWRSA9IHdlbGxLbm93blN5bWJvbCgndG9QcmltaXRpdmUnKTtcblxuLy8gYFRvUHJpbWl0aXZlYCBhYnN0cmFjdCBvcGVyYXRpb25cbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtdG9wcmltaXRpdmVcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGlucHV0LCBwcmVmKSB7XG4gIGlmICghaXNPYmplY3QoaW5wdXQpIHx8IGlzU3ltYm9sKGlucHV0KSkgcmV0dXJuIGlucHV0O1xuICB2YXIgZXhvdGljVG9QcmltID0gZ2V0TWV0aG9kKGlucHV0LCBUT19QUklNSVRJVkUpO1xuICB2YXIgcmVzdWx0O1xuICBpZiAoZXhvdGljVG9QcmltKSB7XG4gICAgaWYgKHByZWYgPT09IHVuZGVmaW5lZCkgcHJlZiA9ICdkZWZhdWx0JztcbiAgICByZXN1bHQgPSBjYWxsKGV4b3RpY1RvUHJpbSwgaW5wdXQsIHByZWYpO1xuICAgIGlmICghaXNPYmplY3QocmVzdWx0KSB8fCBpc1N5bWJvbChyZXN1bHQpKSByZXR1cm4gcmVzdWx0O1xuICAgIHRocm93IG5ldyAkVHlwZUVycm9yKFwiQ2FuJ3QgY29udmVydCBvYmplY3QgdG8gcHJpbWl0aXZlIHZhbHVlXCIpO1xuICB9XG4gIGlmIChwcmVmID09PSB1bmRlZmluZWQpIHByZWYgPSAnbnVtYmVyJztcbiAgcmV0dXJuIG9yZGluYXJ5VG9QcmltaXRpdmUoaW5wdXQsIHByZWYpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciB0b1ByaW1pdGl2ZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1wcmltaXRpdmUnKTtcbnZhciBpc1N5bWJvbCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1zeW1ib2wnKTtcblxuLy8gYFRvUHJvcGVydHlLZXlgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy10b3Byb3BlcnR5a2V5XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICB2YXIga2V5ID0gdG9QcmltaXRpdmUoYXJndW1lbnQsICdzdHJpbmcnKTtcbiAgcmV0dXJuIGlzU3ltYm9sKGtleSkgPyBrZXkgOiBrZXkgKyAnJztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgd2VsbEtub3duU3ltYm9sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sJyk7XG5cbnZhciBUT19TVFJJTkdfVEFHID0gd2VsbEtub3duU3ltYm9sKCd0b1N0cmluZ1RhZycpO1xudmFyIHRlc3QgPSB7fTtcblxudGVzdFtUT19TVFJJTkdfVEFHXSA9ICd6JztcblxubW9kdWxlLmV4cG9ydHMgPSBTdHJpbmcodGVzdCkgPT09ICdbb2JqZWN0IHpdJztcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBjbGFzc29mID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NsYXNzb2YnKTtcblxudmFyICRTdHJpbmcgPSBTdHJpbmc7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyZ3VtZW50KSB7XG4gIGlmIChjbGFzc29mKGFyZ3VtZW50KSA9PT0gJ1N5bWJvbCcpIHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjb252ZXJ0IGEgU3ltYm9sIHZhbHVlIHRvIGEgc3RyaW5nJyk7XG4gIHJldHVybiAkU3RyaW5nKGFyZ3VtZW50KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgJFN0cmluZyA9IFN0cmluZztcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gJFN0cmluZyhhcmd1bWVudCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuICdPYmplY3QnO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xuXG52YXIgaWQgPSAwO1xudmFyIHBvc3RmaXggPSBNYXRoLnJhbmRvbSgpO1xudmFyIHRvU3RyaW5nID0gdW5jdXJyeVRoaXMoMS4wLnRvU3RyaW5nKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIHJldHVybiAnU3ltYm9sKCcgKyAoa2V5ID09PSB1bmRlZmluZWQgPyAnJyA6IGtleSkgKyAnKV8nICsgdG9TdHJpbmcoKytpZCArIHBvc3RmaXgsIDM2KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vKiBlc2xpbnQtZGlzYWJsZSBlcy9uby1zeW1ib2wgLS0gcmVxdWlyZWQgZm9yIHRlc3RpbmcgKi9cbnZhciBOQVRJVkVfU1lNQk9MID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3N5bWJvbC1jb25zdHJ1Y3Rvci1kZXRlY3Rpb24nKTtcblxubW9kdWxlLmV4cG9ydHMgPSBOQVRJVkVfU1lNQk9MICYmXG4gICFTeW1ib2wuc2hhbSAmJlxuICB0eXBlb2YgU3ltYm9sLml0ZXJhdG9yID09ICdzeW1ib2wnO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcblxuLy8gVjggfiBDaHJvbWUgMzYtXG4vLyBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvdjgvaXNzdWVzL2RldGFpbD9pZD0zMzM0XG5tb2R1bGUuZXhwb3J0cyA9IERFU0NSSVBUT1JTICYmIGZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1kZWZpbmVwcm9wZXJ0eSAtLSByZXF1aXJlZCBmb3IgdGVzdGluZ1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGZ1bmN0aW9uICgpIHsgLyogZW1wdHkgKi8gfSwgJ3Byb3RvdHlwZScsIHtcbiAgICB2YWx1ZTogNDIsXG4gICAgd3JpdGFibGU6IGZhbHNlXG4gIH0pLnByb3RvdHlwZSAhPT0gNDI7XG59KTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xuXG52YXIgV2Vha01hcCA9IGdsb2JhbFRoaXMuV2Vha01hcDtcblxubW9kdWxlLmV4cG9ydHMgPSBpc0NhbGxhYmxlKFdlYWtNYXApICYmIC9uYXRpdmUgY29kZS8udGVzdChTdHJpbmcoV2Vha01hcCkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdsb2JhbFRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2xvYmFsLXRoaXMnKTtcbnZhciBzaGFyZWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvc2hhcmVkJyk7XG52YXIgaGFzT3duID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2hhcy1vd24tcHJvcGVydHknKTtcbnZhciB1aWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdWlkJyk7XG52YXIgTkFUSVZFX1NZTUJPTCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9zeW1ib2wtY29uc3RydWN0b3ItZGV0ZWN0aW9uJyk7XG52YXIgVVNFX1NZTUJPTF9BU19VSUQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdXNlLXN5bWJvbC1hcy11aWQnKTtcblxudmFyIFN5bWJvbCA9IGdsb2JhbFRoaXMuU3ltYm9sO1xudmFyIFdlbGxLbm93blN5bWJvbHNTdG9yZSA9IHNoYXJlZCgnd2tzJyk7XG52YXIgY3JlYXRlV2VsbEtub3duU3ltYm9sID0gVVNFX1NZTUJPTF9BU19VSUQgPyBTeW1ib2xbJ2ZvciddIHx8IFN5bWJvbCA6IFN5bWJvbCAmJiBTeW1ib2wud2l0aG91dFNldHRlciB8fCB1aWQ7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgaWYgKCFoYXNPd24oV2VsbEtub3duU3ltYm9sc1N0b3JlLCBuYW1lKSkge1xuICAgIFdlbGxLbm93blN5bWJvbHNTdG9yZVtuYW1lXSA9IE5BVElWRV9TWU1CT0wgJiYgaGFzT3duKFN5bWJvbCwgbmFtZSlcbiAgICAgID8gU3ltYm9sW25hbWVdXG4gICAgICA6IGNyZWF0ZVdlbGxLbm93blN5bWJvbCgnU3ltYm9sLicgKyBuYW1lKTtcbiAgfSByZXR1cm4gV2VsbEtub3duU3ltYm9sc1N0b3JlW25hbWVdO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnZXRCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dldC1idWlsdC1pbicpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NyZWF0ZS1ub24tZW51bWVyYWJsZS1wcm9wZXJ0eScpO1xudmFyIGlzUHJvdG90eXBlT2YgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWlzLXByb3RvdHlwZS1vZicpO1xudmFyIHNldFByb3RvdHlwZU9mID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1zZXQtcHJvdG90eXBlLW9mJyk7XG52YXIgY29weUNvbnN0cnVjdG9yUHJvcGVydGllcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jb3B5LWNvbnN0cnVjdG9yLXByb3BlcnRpZXMnKTtcbnZhciBwcm94eUFjY2Vzc29yID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3Byb3h5LWFjY2Vzc29yJyk7XG52YXIgaW5oZXJpdElmUmVxdWlyZWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaW5oZXJpdC1pZi1yZXF1aXJlZCcpO1xudmFyIG5vcm1hbGl6ZVN0cmluZ0FyZ3VtZW50ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL25vcm1hbGl6ZS1zdHJpbmctYXJndW1lbnQnKTtcbnZhciBpbnN0YWxsRXJyb3JDYXVzZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pbnN0YWxsLWVycm9yLWNhdXNlJyk7XG52YXIgaW5zdGFsbEVycm9yU3RhY2sgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZXJyb3Itc3RhY2staW5zdGFsbCcpO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgSVNfUFVSRSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1wdXJlJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKEZVTExfTkFNRSwgd3JhcHBlciwgRk9SQ0VELCBJU19BR0dSRUdBVEVfRVJST1IpIHtcbiAgdmFyIFNUQUNLX1RSQUNFX0xJTUlUID0gJ3N0YWNrVHJhY2VMaW1pdCc7XG4gIHZhciBPUFRJT05TX1BPU0lUSU9OID0gSVNfQUdHUkVHQVRFX0VSUk9SID8gMiA6IDE7XG4gIHZhciBwYXRoID0gRlVMTF9OQU1FLnNwbGl0KCcuJyk7XG4gIHZhciBFUlJPUl9OQU1FID0gcGF0aFtwYXRoLmxlbmd0aCAtIDFdO1xuICB2YXIgT3JpZ2luYWxFcnJvciA9IGdldEJ1aWx0SW4uYXBwbHkobnVsbCwgcGF0aCk7XG5cbiAgaWYgKCFPcmlnaW5hbEVycm9yKSByZXR1cm47XG5cbiAgdmFyIE9yaWdpbmFsRXJyb3JQcm90b3R5cGUgPSBPcmlnaW5hbEVycm9yLnByb3RvdHlwZTtcblxuICAvLyBWOCA5LjMtIGJ1ZyBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvdjgvaXNzdWVzL2RldGFpbD9pZD0xMjAwNlxuICBpZiAoIUlTX1BVUkUgJiYgaGFzT3duKE9yaWdpbmFsRXJyb3JQcm90b3R5cGUsICdjYXVzZScpKSBkZWxldGUgT3JpZ2luYWxFcnJvclByb3RvdHlwZS5jYXVzZTtcblxuICBpZiAoIUZPUkNFRCkgcmV0dXJuIE9yaWdpbmFsRXJyb3I7XG5cbiAgdmFyIEJhc2VFcnJvciA9IGdldEJ1aWx0SW4oJ0Vycm9yJyk7XG5cbiAgdmFyIFdyYXBwZWRFcnJvciA9IHdyYXBwZXIoZnVuY3Rpb24gKGEsIGIpIHtcbiAgICB2YXIgbWVzc2FnZSA9IG5vcm1hbGl6ZVN0cmluZ0FyZ3VtZW50KElTX0FHR1JFR0FURV9FUlJPUiA/IGIgOiBhLCB1bmRlZmluZWQpO1xuICAgIHZhciByZXN1bHQgPSBJU19BR0dSRUdBVEVfRVJST1IgPyBuZXcgT3JpZ2luYWxFcnJvcihhKSA6IG5ldyBPcmlnaW5hbEVycm9yKCk7XG4gICAgaWYgKG1lc3NhZ2UgIT09IHVuZGVmaW5lZCkgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KHJlc3VsdCwgJ21lc3NhZ2UnLCBtZXNzYWdlKTtcbiAgICBpbnN0YWxsRXJyb3JTdGFjayhyZXN1bHQsIFdyYXBwZWRFcnJvciwgcmVzdWx0LnN0YWNrLCAyKTtcbiAgICBpZiAodGhpcyAmJiBpc1Byb3RvdHlwZU9mKE9yaWdpbmFsRXJyb3JQcm90b3R5cGUsIHRoaXMpKSBpbmhlcml0SWZSZXF1aXJlZChyZXN1bHQsIHRoaXMsIFdyYXBwZWRFcnJvcik7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiBPUFRJT05TX1BPU0lUSU9OKSBpbnN0YWxsRXJyb3JDYXVzZShyZXN1bHQsIGFyZ3VtZW50c1tPUFRJT05TX1BPU0lUSU9OXSk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSk7XG5cbiAgV3JhcHBlZEVycm9yLnByb3RvdHlwZSA9IE9yaWdpbmFsRXJyb3JQcm90b3R5cGU7XG5cbiAgaWYgKEVSUk9SX05BTUUgIT09ICdFcnJvcicpIHtcbiAgICBpZiAoc2V0UHJvdG90eXBlT2YpIHNldFByb3RvdHlwZU9mKFdyYXBwZWRFcnJvciwgQmFzZUVycm9yKTtcbiAgICBlbHNlIGNvcHlDb25zdHJ1Y3RvclByb3BlcnRpZXMoV3JhcHBlZEVycm9yLCBCYXNlRXJyb3IsIHsgbmFtZTogdHJ1ZSB9KTtcbiAgfSBlbHNlIGlmIChERVNDUklQVE9SUyAmJiBTVEFDS19UUkFDRV9MSU1JVCBpbiBPcmlnaW5hbEVycm9yKSB7XG4gICAgcHJveHlBY2Nlc3NvcihXcmFwcGVkRXJyb3IsIE9yaWdpbmFsRXJyb3IsIFNUQUNLX1RSQUNFX0xJTUlUKTtcbiAgICBwcm94eUFjY2Vzc29yKFdyYXBwZWRFcnJvciwgT3JpZ2luYWxFcnJvciwgJ3ByZXBhcmVTdGFja1RyYWNlJyk7XG4gIH1cblxuICBjb3B5Q29uc3RydWN0b3JQcm9wZXJ0aWVzKFdyYXBwZWRFcnJvciwgT3JpZ2luYWxFcnJvcik7XG5cbiAgaWYgKCFJU19QVVJFKSB0cnkge1xuICAgIC8vIFNhZmFyaSAxMy0gYnVnOiBXZWJBc3NlbWJseSBlcnJvcnMgZG9lcyBub3QgaGF2ZSBhIHByb3BlciBgLm5hbWVgXG4gICAgaWYgKE9yaWdpbmFsRXJyb3JQcm90b3R5cGUubmFtZSAhPT0gRVJST1JfTkFNRSkge1xuICAgICAgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KE9yaWdpbmFsRXJyb3JQcm90b3R5cGUsICduYW1lJywgRVJST1JfTkFNRSk7XG4gICAgfVxuICAgIE9yaWdpbmFsRXJyb3JQcm90b3R5cGUuY29uc3RydWN0b3IgPSBXcmFwcGVkRXJyb3I7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cblxuICByZXR1cm4gV3JhcHBlZEVycm9yO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciAkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2V4cG9ydCcpO1xudmFyICRpbmNsdWRlcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hcnJheS1pbmNsdWRlcycpLmluY2x1ZGVzO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2ZhaWxzJyk7XG52YXIgYWRkVG9VbnNjb3BhYmxlcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hZGQtdG8tdW5zY29wYWJsZXMnKTtcblxuLy8gRkY5OSsgYnVnXG52YXIgQlJPS0VOX09OX1NQQVJTRSA9IGZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLWFycmF5LXByb3RvdHlwZS1pbmNsdWRlcyAtLSBkZXRlY3Rpb25cbiAgcmV0dXJuICFBcnJheSgxKS5pbmNsdWRlcygpO1xufSk7XG5cbi8vIGBBcnJheS5wcm90b3R5cGUuaW5jbHVkZXNgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1hcnJheS5wcm90b3R5cGUuaW5jbHVkZXNcbiQoeyB0YXJnZXQ6ICdBcnJheScsIHByb3RvOiB0cnVlLCBmb3JjZWQ6IEJST0tFTl9PTl9TUEFSU0UgfSwge1xuICBpbmNsdWRlczogZnVuY3Rpb24gaW5jbHVkZXMoZWwgLyogLCBmcm9tSW5kZXggPSAwICovKSB7XG4gICAgcmV0dXJuICRpbmNsdWRlcyh0aGlzLCBlbCwgYXJndW1lbnRzLmxlbmd0aCA+IDEgPyBhcmd1bWVudHNbMV0gOiB1bmRlZmluZWQpO1xuICB9XG59KTtcblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1hcnJheS5wcm90b3R5cGUtQEB1bnNjb3BhYmxlc1xuYWRkVG9VbnNjb3BhYmxlcygnaW5jbHVkZXMnKTtcbiIsIid1c2Ugc3RyaWN0Jztcbi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzIC0tIHJlcXVpcmVkIGZvciBmdW5jdGlvbnMgYC5sZW5ndGhgICovXG52YXIgJCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9leHBvcnQnKTtcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgYXBwbHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tYXBwbHknKTtcbnZhciB3cmFwRXJyb3JDb25zdHJ1Y3RvcldpdGhDYXVzZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy93cmFwLWVycm9yLWNvbnN0cnVjdG9yLXdpdGgtY2F1c2UnKTtcblxudmFyIFdFQl9BU1NFTUJMWSA9ICdXZWJBc3NlbWJseSc7XG52YXIgV2ViQXNzZW1ibHkgPSBnbG9iYWxUaGlzW1dFQl9BU1NFTUJMWV07XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1lcnJvci1jYXVzZSAtLSBmZWF0dXJlIGRldGVjdGlvblxudmFyIEZPUkNFRCA9IG5ldyBFcnJvcignZScsIHsgY2F1c2U6IDcgfSkuY2F1c2UgIT09IDc7XG5cbnZhciBleHBvcnRHbG9iYWxFcnJvckNhdXNlV3JhcHBlciA9IGZ1bmN0aW9uIChFUlJPUl9OQU1FLCB3cmFwcGVyKSB7XG4gIHZhciBPID0ge307XG4gIE9bRVJST1JfTkFNRV0gPSB3cmFwRXJyb3JDb25zdHJ1Y3RvcldpdGhDYXVzZShFUlJPUl9OQU1FLCB3cmFwcGVyLCBGT1JDRUQpO1xuICAkKHsgZ2xvYmFsOiB0cnVlLCBjb25zdHJ1Y3RvcjogdHJ1ZSwgYXJpdHk6IDEsIGZvcmNlZDogRk9SQ0VEIH0sIE8pO1xufTtcblxudmFyIGV4cG9ydFdlYkFzc2VtYmx5RXJyb3JDYXVzZVdyYXBwZXIgPSBmdW5jdGlvbiAoRVJST1JfTkFNRSwgd3JhcHBlcikge1xuICBpZiAoV2ViQXNzZW1ibHkgJiYgV2ViQXNzZW1ibHlbRVJST1JfTkFNRV0pIHtcbiAgICB2YXIgTyA9IHt9O1xuICAgIE9bRVJST1JfTkFNRV0gPSB3cmFwRXJyb3JDb25zdHJ1Y3RvcldpdGhDYXVzZShXRUJfQVNTRU1CTFkgKyAnLicgKyBFUlJPUl9OQU1FLCB3cmFwcGVyLCBGT1JDRUQpO1xuICAgICQoeyB0YXJnZXQ6IFdFQl9BU1NFTUJMWSwgc3RhdDogdHJ1ZSwgY29uc3RydWN0b3I6IHRydWUsIGFyaXR5OiAxLCBmb3JjZWQ6IEZPUkNFRCB9LCBPKTtcbiAgfVxufTtcblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1uYXRpdmVlcnJvclxuZXhwb3J0R2xvYmFsRXJyb3JDYXVzZVdyYXBwZXIoJ0Vycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIEVycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydEdsb2JhbEVycm9yQ2F1c2VXcmFwcGVyKCdFdmFsRXJyb3InLCBmdW5jdGlvbiAoaW5pdCkge1xuICByZXR1cm4gZnVuY3Rpb24gRXZhbEVycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydEdsb2JhbEVycm9yQ2F1c2VXcmFwcGVyKCdSYW5nZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIFJhbmdlRXJyb3IobWVzc2FnZSkgeyByZXR1cm4gYXBwbHkoaW5pdCwgdGhpcywgYXJndW1lbnRzKTsgfTtcbn0pO1xuZXhwb3J0R2xvYmFsRXJyb3JDYXVzZVdyYXBwZXIoJ1JlZmVyZW5jZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIFJlZmVyZW5jZUVycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydEdsb2JhbEVycm9yQ2F1c2VXcmFwcGVyKCdTeW50YXhFcnJvcicsIGZ1bmN0aW9uIChpbml0KSB7XG4gIHJldHVybiBmdW5jdGlvbiBTeW50YXhFcnJvcihtZXNzYWdlKSB7IHJldHVybiBhcHBseShpbml0LCB0aGlzLCBhcmd1bWVudHMpOyB9O1xufSk7XG5leHBvcnRHbG9iYWxFcnJvckNhdXNlV3JhcHBlcignVHlwZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIFR5cGVFcnJvcihtZXNzYWdlKSB7IHJldHVybiBhcHBseShpbml0LCB0aGlzLCBhcmd1bWVudHMpOyB9O1xufSk7XG5leHBvcnRHbG9iYWxFcnJvckNhdXNlV3JhcHBlcignVVJJRXJyb3InLCBmdW5jdGlvbiAoaW5pdCkge1xuICByZXR1cm4gZnVuY3Rpb24gVVJJRXJyb3IobWVzc2FnZSkgeyByZXR1cm4gYXBwbHkoaW5pdCwgdGhpcywgYXJndW1lbnRzKTsgfTtcbn0pO1xuZXhwb3J0V2ViQXNzZW1ibHlFcnJvckNhdXNlV3JhcHBlcignQ29tcGlsZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIENvbXBpbGVFcnJvcihtZXNzYWdlKSB7IHJldHVybiBhcHBseShpbml0LCB0aGlzLCBhcmd1bWVudHMpOyB9O1xufSk7XG5leHBvcnRXZWJBc3NlbWJseUVycm9yQ2F1c2VXcmFwcGVyKCdMaW5rRXJyb3InLCBmdW5jdGlvbiAoaW5pdCkge1xuICByZXR1cm4gZnVuY3Rpb24gTGlua0Vycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydFdlYkFzc2VtYmx5RXJyb3JDYXVzZVdyYXBwZXIoJ1J1bnRpbWVFcnJvcicsIGZ1bmN0aW9uIChpbml0KSB7XG4gIHJldHVybiBmdW5jdGlvbiBSdW50aW1lRXJyb3IobWVzc2FnZSkgeyByZXR1cm4gYXBwbHkoaW5pdCwgdGhpcywgYXJndW1lbnRzKTsgfTtcbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyICQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZXhwb3J0Jyk7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xudmFyIGRlZmluZUJ1aWx0SW5BY2Nlc3NvciA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZWZpbmUtYnVpbHQtaW4tYWNjZXNzb3InKTtcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xuXG52YXIgJFR5cGVFcnJvciA9IFR5cGVFcnJvcjtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZGVmaW5lcHJvcGVydHkgLS0gc2FmZVxudmFyIGRlZmluZVByb3BlcnR5ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIElOQ09SUkVDVF9WQUxVRSA9IGdsb2JhbFRoaXMuc2VsZiAhPT0gZ2xvYmFsVGhpcztcblxuLy8gYHNlbGZgIGdldHRlclxuLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2Uvd2luZG93LW9iamVjdC5odG1sI2RvbS1zZWxmXG50cnkge1xuICBpZiAoREVTQ1JJUFRPUlMpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5ZGVzY3JpcHRvciAtLSBzYWZlXG4gICAgdmFyIGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGdsb2JhbFRoaXMsICdzZWxmJyk7XG4gICAgLy8gc29tZSBlbmdpbmVzIGhhdmUgYHNlbGZgLCBidXQgd2l0aCBpbmNvcnJlY3QgZGVzY3JpcHRvclxuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9kZW5vbGFuZC9kZW5vL2lzc3Vlcy8xNTc2NVxuICAgIGlmIChJTkNPUlJFQ1RfVkFMVUUgfHwgIWRlc2NyaXB0b3IgfHwgIWRlc2NyaXB0b3IuZ2V0IHx8ICFkZXNjcmlwdG9yLmVudW1lcmFibGUpIHtcbiAgICAgIGRlZmluZUJ1aWx0SW5BY2Nlc3NvcihnbG9iYWxUaGlzLCAnc2VsZicsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiBzZWxmKCkge1xuICAgICAgICAgIHJldHVybiBnbG9iYWxUaGlzO1xuICAgICAgICB9LFxuICAgICAgICBzZXQ6IGZ1bmN0aW9uIHNlbGYodmFsdWUpIHtcbiAgICAgICAgICBpZiAodGhpcyAhPT0gZ2xvYmFsVGhpcykgdGhyb3cgbmV3ICRUeXBlRXJyb3IoJ0lsbGVnYWwgaW52b2NhdGlvbicpO1xuICAgICAgICAgIGRlZmluZVByb3BlcnR5KGdsb2JhbFRoaXMsICdzZWxmJywge1xuICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9IGVsc2UgJCh7IGdsb2JhbDogdHJ1ZSwgc2ltcGxlOiB0cnVlLCBmb3JjZWQ6IElOQ09SUkVDVF9WQUxVRSB9LCB7XG4gICAgc2VsZjogZ2xvYmFsVGhpc1xuICB9KTtcbn0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbiIsIi8qKlxuICogQ2hlY2tzIGlmIGVycm9yIGhhcyBtZXNzYWdlLlxuICpcbiAqIEBwYXJhbSBlcnJvciBFcnJvciBvYmplY3QuXG4gKiBAcmV0dXJucyBUcnVlIGlmIGVycm9yIGhhcyBtZXNzYWdlLlxuICovXG5mdW5jdGlvbiBpc0Vycm9yV2l0aE1lc3NhZ2UoZXJyb3IpIHtcbiAgICByZXR1cm4gKHR5cGVvZiBlcnJvciA9PT0gJ29iamVjdCdcbiAgICAgICAgJiYgZXJyb3IgIT09IG51bGxcbiAgICAgICAgJiYgJ21lc3NhZ2UnIGluIGVycm9yXG4gICAgICAgICYmIHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSAnc3RyaW5nJyk7XG59XG4vKipcbiAqIENvbnZlcnRzIGVycm9yIHRvIHRoZSBlcnJvciB3aXRoIGEgbWVzc2FnZS5cbiAqXG4gKiBAcGFyYW0gbWF5YmVFcnJvciBQb3NzaWJsZSBlcnJvci5cbiAqIEByZXR1cm5zIEVycm9yIHdpdGggYSBtZXNzYWdlLlxuICovXG5mdW5jdGlvbiB0b0Vycm9yV2l0aE1lc3NhZ2UobWF5YmVFcnJvcikge1xuICAgIGlmIChpc0Vycm9yV2l0aE1lc3NhZ2UobWF5YmVFcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIG1heWJlRXJyb3I7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkobWF5YmVFcnJvcikpO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIC8vIGZhbGxiYWNrIGluIGNhc2UgdGhlcmUncyBhbiBlcnJvciBzdHJpbmdpZnlpbmcgdGhlIG1heWJlRXJyb3JcbiAgICAgICAgLy8gbGlrZSB3aXRoIGNpcmN1bGFyIHJlZmVyZW5jZXMsIGZvciBleGFtcGxlLlxuICAgICAgICByZXR1cm4gbmV3IEVycm9yKFN0cmluZyhtYXliZUVycm9yKSk7XG4gICAgfVxufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBlcnJvciBvYmplY3QgdG8gYW4gZXJyb3Igd2l0aCBhIG1lc3NhZ2UuIFRoaXMgbWV0aG9kIG1pZ2h0IGJlIGhlbHBmdWwgdG8gaGFuZGxlIHRocm93biBlcnJvcnMuXG4gKlxuICogQHBhcmFtIGVycm9yIEVycm9yIG9iamVjdC5cbiAqXG4gKiBAcmV0dXJucyBNZXNzYWdlIG9mIHRoZSBlcnJvci5cbiAqL1xuZnVuY3Rpb24gZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB7XG4gICAgcmV0dXJuIHRvRXJyb3JXaXRoTWVzc2FnZShlcnJvcikubWVzc2FnZTtcbn1cblxuLyoqXG4gKiBQYWRzIGEgbnVtYmVyIHdpdGggbGVhZGluZyB6ZXJvcy5cbiAqIEBwYXJhbSBudW0gVGhlIG51bWJlciB0byBwYWQuXG4gKiBAcGFyYW0gc2l6ZSBUaGUgbnVtYmVyIG9mIGRpZ2l0cyB0byBwYWQgdG8uXG4gKiBAcmV0dXJucyBUaGUgcGFkZGVkIG51bWJlci5cbiAqL1xuY29uc3QgcGFkID0gKG51bSwgc2l6ZSA9IDIpID0+IHtcbiAgICByZXR1cm4gbnVtLnRvU3RyaW5nKCkucGFkU3RhcnQoc2l6ZSwgJzAnKTtcbn07XG4vKipcbiAqIEZvcm1hdHMgYSBkYXRlIGludG8gYW4gSVNPIDg2MDEtbGlrZSBzdHJpbmcgd2l0aCBtaWxsaXNlY29uZHMuXG4gKlxuICogQHBhcmFtIHtEYXRlfG51bWJlcn0gZGF0ZSBUaGUgZGF0ZSBvYmplY3Qgb3IgdGltZXN0YW1wIHRvIGZvcm1hdC5cbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBmb3JtYXR0ZWQgZGF0ZSBzdHJpbmcuXG4gKi9cbmNvbnN0IGZvcm1hdFRpbWUgPSAoZGF0ZSkgPT4ge1xuICAgIGNvbnN0IGQgPSAoZGF0ZSBpbnN0YW5jZW9mIERhdGUpID8gZGF0ZSA6IG5ldyBEYXRlKGRhdGUpO1xuICAgIGNvbnN0IHllYXIgPSBkLmdldEZ1bGxZZWFyKCk7XG4gICAgY29uc3QgbW9udGggPSBwYWQoZC5nZXRNb250aCgpICsgMSk7IC8vIE1vbnRocyBhcmUgMC1iYXNlZFxuICAgIGNvbnN0IGRheSA9IHBhZChkLmdldERhdGUoKSk7XG4gICAgY29uc3QgaG91ciA9IHBhZChkLmdldEhvdXJzKCkpO1xuICAgIGNvbnN0IG1pbnV0ZSA9IHBhZChkLmdldE1pbnV0ZXMoKSk7XG4gICAgY29uc3Qgc2Vjb25kID0gcGFkKGQuZ2V0U2Vjb25kcygpKTtcbiAgICBjb25zdCBtaWxsaXNlY29uZCA9IHBhZChkLmdldE1pbGxpc2Vjb25kcygpLCAzKTsgLy8gTWlsbGlzZWNvbmRzIGFyZSAzIGRpZ2l0c1xuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1UJHtob3VyfToke21pbnV0ZX06JHtzZWNvbmR9OiR7bWlsbGlzZWNvbmR9YDtcbn07XG5cbi8qKlxuICogU3RyaW5nIHByZXNlbnRhdGlvbiBvZiBsb2cgbGV2ZWxzLCBmb3IgY29udmVuaWVudCB1c2VycyB1c2FnZS5cbiAqL1xudmFyIExvZ0xldmVsO1xuKGZ1bmN0aW9uIChMb2dMZXZlbCkge1xuICAgIExvZ0xldmVsW1wiRXJyb3JcIl0gPSBcImVycm9yXCI7XG4gICAgTG9nTGV2ZWxbXCJXYXJuXCJdID0gXCJ3YXJuXCI7XG4gICAgTG9nTGV2ZWxbXCJJbmZvXCJdID0gXCJpbmZvXCI7XG4gICAgTG9nTGV2ZWxbXCJEZWJ1Z1wiXSA9IFwiZGVidWdcIjtcbiAgICBMb2dMZXZlbFtcIlRyYWNlXCJdID0gXCJ0cmFjZVwiO1xufSkoTG9nTGV2ZWwgfHwgKExvZ0xldmVsID0ge30pKTtcbi8qKlxuICogTG9nIGxldmVscyBtYXAsIHdoaWNoIG1hcHMgbnVtYmVyIGxldmVsIHRvIHN0cmluZyBsZXZlbC5cbiAqL1xuY29uc3QgbGV2ZWxNYXBOdW1Ub1N0cmluZyA9IHtcbiAgICBbMSAvKiBMb2dMZXZlbE51bWVyaWMuRXJyb3IgKi9dOiBMb2dMZXZlbC5FcnJvcixcbiAgICBbMiAvKiBMb2dMZXZlbE51bWVyaWMuV2FybiAqL106IExvZ0xldmVsLldhcm4sXG4gICAgWzMgLyogTG9nTGV2ZWxOdW1lcmljLkluZm8gKi9dOiBMb2dMZXZlbC5JbmZvLFxuICAgIFs0IC8qIExvZ0xldmVsTnVtZXJpYy5EZWJ1ZyAqL106IExvZ0xldmVsLkRlYnVnLFxuICAgIFs1IC8qIExvZ0xldmVsTnVtZXJpYy5UcmFjZSAqL106IExvZ0xldmVsLlRyYWNlLFxufTtcbi8qKlxuICogTG9nIGxldmVscyBtYXAsIHdoaWNoIG1hcHMgc3RyaW5nIGxldmVsIHRvIG51bWJlciBsZXZlbC5cbiAqL1xuY29uc3QgbGV2ZWxNYXBTdHJpbmdUb051bSA9IE9iamVjdC5lbnRyaWVzKGxldmVsTWFwTnVtVG9TdHJpbmcpXG4gICAgLnJlZHVjZSgoYWNjLCBba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAvLyBIZXJlLCBrZXkgaXMgb3JpZ2luYWxseSBhIHN0cmluZyBzaW5jZSBPYmplY3QuZW50cmllcygpIHJldHVybnMgW3N0cmluZywgc3RyaW5nXVtdLlxuICAgIC8vIFdlIG5lZWQgdG8gY2FzdCB0aGUga2V5IHRvIExvZ0xldmVsTnVtZXJpYyBjb3JyZWN0bHkgd2l0aG91dCBjYXVzaW5nIHR5cGUgbWlzbWF0Y2hlcy5cbiAgICBjb25zdCBudW1lcmljS2V5ID0gTnVtYmVyKGtleSk7XG4gICAgaWYgKCFOdW1iZXIuaXNOYU4obnVtZXJpY0tleSkpIHtcbiAgICAgICAgYWNjW3ZhbHVlXSA9IG51bWVyaWNLZXk7XG4gICAgfVxuICAgIHJldHVybiBhY2M7XG59LCB7fSk7XG4vKipcbiAqIFNpbXBsZSBsb2dnZXIgd2l0aCBsb2cgbGV2ZWxzLlxuICovXG5jbGFzcyBMb2dnZXIge1xuICAgIGN1cnJlbnRMZXZlbFZhbHVlID0gMyAvKiBMb2dMZXZlbE51bWVyaWMuSW5mbyAqLztcbiAgICB3cml0ZXI7XG4gICAgLyoqXG4gICAgICogQ29uc3RydWN0b3IuXG4gICAgICogQHBhcmFtIHdyaXRlciBXcml0ZXIgb2JqZWN0LlxuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKHdyaXRlciA9IGNvbnNvbGUpIHtcbiAgICAgICAgdGhpcy53cml0ZXIgPSB3cml0ZXI7XG4gICAgICAgIC8vIGJpbmQgdGhlIGxvZ2dpbmcgbWV0aG9kcyB0byBhdm9pZCBsb3NpbmcgY29udGV4dFxuICAgICAgICB0aGlzLmRlYnVnID0gdGhpcy5kZWJ1Zy5iaW5kKHRoaXMpO1xuICAgICAgICB0aGlzLmluZm8gPSB0aGlzLmluZm8uYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy53YXJuID0gdGhpcy53YXJuLmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMuZXJyb3IgPSB0aGlzLmVycm9yLmJpbmQodGhpcyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByaW50IGRlYnVnIG1lc3NhZ2VzLiBVc3VhbGx5IHVzZWQgZm9yIHRlY2huaWNhbCBpbmZvcm1hdGlvbi5cbiAgICAgKiBXaWxsIGJlIHByaW50ZWQgaW4gJ2xvZycgY2hhbm5lbC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcmdzIFByaW50ZWQgYXJndW1lbnRzLlxuICAgICAqL1xuICAgIGRlYnVnKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5wcmludCg0IC8qIExvZ0xldmVsTnVtZXJpYy5EZWJ1ZyAqLywgXCJsb2dcIiAvKiBMb2dNZXRob2QuTG9nICovLCBhcmdzKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHJpbnQgbWVzc2FnZXMgeW91IHdhbnQgdG8gZGlzY2xvc2UgdG8gdXNlcnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYXJncyBQcmludGVkIGFyZ3VtZW50cy5cbiAgICAgKi9cbiAgICBpbmZvKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5wcmludCgzIC8qIExvZ0xldmVsTnVtZXJpYy5JbmZvICovLCBcImluZm9cIiAvKiBMb2dNZXRob2QuSW5mbyAqLywgYXJncyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByaW50IHdhcm4gbWVzc2FnZXMuXG4gICAgICogTk9URTogV2UgZG8gbm90IHVzZSAnd2FybicgY2hhbm5lbCwgc2luY2UgaW4gdGhlIGV4dGVuc2lvbnMgd2FybiBpc1xuICAgICAqIGNvdW50ZWQgYXMgZXJyb3IuIEluc3RlYWQgb2YgdGhpcyB3ZSB1c2UgJ2luZm8nIGNoYW5uZWwuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYXJncyBQcmludGVkIGFyZ3VtZW50cy5cbiAgICAgKi9cbiAgICB3YXJuKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5wcmludCgyIC8qIExvZ0xldmVsTnVtZXJpYy5XYXJuICovLCBcImluZm9cIiAvKiBMb2dNZXRob2QuSW5mbyAqLywgYXJncyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByaW50IGVycm9yIG1lc3NhZ2VzLlxuICAgICAqXG4gICAgICogQHBhcmFtIGFyZ3MgUHJpbnRlZCBhcmd1bWVudHMuXG4gICAgICovXG4gICAgZXJyb3IoLi4uYXJncykge1xuICAgICAgICB0aGlzLnByaW50KDEgLyogTG9nTGV2ZWxOdW1lcmljLkVycm9yICovLCBcImVycm9yXCIgLyogTG9nTWV0aG9kLkVycm9yICovLCBhcmdzKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0dGVyIGZvciBsb2cgbGV2ZWwuXG4gICAgICogQHJldHVybnMgTG9nZ2VyIGxldmVsLlxuICAgICAqL1xuICAgIGdldCBjdXJyZW50TGV2ZWwoKSB7XG4gICAgICAgIHJldHVybiBsZXZlbE1hcE51bVRvU3RyaW5nW3RoaXMuY3VycmVudExldmVsVmFsdWVdO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTZXR0ZXIgZm9yIGxvZyBsZXZlbC4gV2l0aCB0aGlzIG1ldGhvZCBsb2cgbGV2ZWwgY2FuIGJlIHVwZGF0ZWQgZHluYW1pY2FsbHkuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbG9nTGV2ZWwgTG9nZ2VyIGxldmVsLlxuICAgICAqIEB0aHJvd3MgRXJyb3IgaWYgbG9nIGxldmVsIGlzIG5vdCBzdXBwb3J0ZWQuXG4gICAgICovXG4gICAgc2V0IGN1cnJlbnRMZXZlbChsb2dMZXZlbCkge1xuICAgICAgICBjb25zdCBsZXZlbCA9IGxldmVsTWFwU3RyaW5nVG9OdW1bbG9nTGV2ZWxdO1xuICAgICAgICBpZiAobGV2ZWwgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBMb2dnZXIgc3VwcG9ydHMgb25seSB0aGUgZm9sbG93aW5nIGxldmVsczogJHtbT2JqZWN0LnZhbHVlcyhMb2dMZXZlbCkuam9pbignLCAnKV19YCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jdXJyZW50TGV2ZWxWYWx1ZSA9IGxldmVsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0cyBlcnJvciB0byBzdHJpbmcsIGFuZCBhZGRzIHN0YWNrIHRyYWNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIGVycm9yIEVycm9yIHRvIHByaW50LlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQHJldHVybnMgRXJyb3IgbWVzc2FnZS5cbiAgICAgKi9cbiAgICBzdGF0aWMgZXJyb3JUb1N0cmluZyhlcnJvcikge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gZ2V0RXJyb3JNZXNzYWdlKGVycm9yKTtcbiAgICAgICAgcmV0dXJuIGAke21lc3NhZ2V9XFxuU3RhY2sgdHJhY2U6XFxuJHtlcnJvci5zdGFja31gO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBXcmFwcGVyIG92ZXIgbG9nIG1ldGhvZHMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbGV2ZWwgTG9nZ2VyIGxldmVsLlxuICAgICAqIEBwYXJhbSBtZXRob2QgTG9nZ2VyIG1ldGhvZC5cbiAgICAgKiBAcGFyYW0gYXJncyBQcmludGVkIGFyZ3VtZW50cy5cbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIHByaW50KGxldmVsLCBtZXRob2QsIGFyZ3MpIHtcbiAgICAgICAgLy8gc2tpcCB3cml0aW5nIGlmIHRoZSBiYXNpYyBjb25kaXRpb25zIGFyZSBub3QgbWV0XG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnRMZXZlbFZhbHVlIDwgbGV2ZWwpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWFyZ3MgfHwgYXJncy5sZW5ndGggPT09IDAgfHwgIWFyZ3NbMF0pIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmb3JtYXR0ZWRBcmdzID0gYXJncy5tYXAoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgICAgIHJldHVybiBMb2dnZXIuZXJyb3JUb1N0cmluZyh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlLm1lc3NhZ2UgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlLm1lc3NhZ2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZFRpbWUgPSBgJHtmb3JtYXRUaW1lKG5ldyBEYXRlKCkpfTpgO1xuICAgICAgICAvKipcbiAgICAgICAgICogQ29uZGl0aW9ucyBpbiB3aGljaCB0cmFjZSBjYW4gaGFwcGVuOlxuICAgICAgICAgKiAxLiBNZXRob2QgaXMgbm90IGVycm9yIChiZWNhdXNlIGNvbnNvbGUuZXJyb3IgcHJvdmlkZXMgY2FsbCBzdGFjayB0cmFjZSlcbiAgICAgICAgICogMi4gTG9nIGxldmVsIGlzIGVxdWFsIG9yIGhpZ2hlciB0aGF0IGBMb2dMZXZlbC5UcmFjZWAuXG4gICAgICAgICAqIDMuIFdyaXRlciBoYXMgYHRyYWNlYCBtZXRob2QuXG4gICAgICAgICAqL1xuICAgICAgICBpZiAobWV0aG9kID09PSBcImVycm9yXCIgLyogTG9nTWV0aG9kLkVycm9yICovXG4gICAgICAgICAgICB8fCB0aGlzLmN1cnJlbnRMZXZlbFZhbHVlIDwgbGV2ZWxNYXBTdHJpbmdUb051bVtMb2dMZXZlbC5UcmFjZV1cbiAgICAgICAgICAgIHx8ICF0aGlzLndyaXRlci50cmFjZSkge1xuICAgICAgICAgICAgLy8gUHJpbnQgd2l0aCByZWd1bGFyIG1ldGhvZFxuICAgICAgICAgICAgdGhpcy53cml0ZXJbbWV0aG9kXShmb3JtYXR0ZWRUaW1lLCAuLi5mb3JtYXR0ZWRBcmdzKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMud3JpdGVyLmdyb3VwQ29sbGFwc2VkIHx8ICF0aGlzLndyaXRlci5ncm91cEVuZCkge1xuICAgICAgICAgICAgLy8gUHJpbnQgZXhwYW5kZWQgdHJhY2VcbiAgICAgICAgICAgIHRoaXMud3JpdGVyLnRyYWNlKGZvcm1hdHRlZFRpbWUsIC4uLmZvcm1hdHRlZEFyZ3MpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIFByaW50IGNvbGxhcHNlZCB0cmFjZVxuICAgICAgICB0aGlzLndyaXRlci5ncm91cENvbGxhcHNlZChmb3JtYXR0ZWRUaW1lLCAuLi5mb3JtYXR0ZWRBcmdzKTtcbiAgICAgICAgdGhpcy53cml0ZXIudHJhY2UoKTtcbiAgICAgICAgdGhpcy53cml0ZXIuZ3JvdXBFbmQoKTtcbiAgICB9XG59XG5cbmV4cG9ydCB7IExvZ0xldmVsLCBMb2dnZXIgfTtcbiIsImltcG9ydCB7IHVybEFscGhhYmV0IH0gZnJvbSAnLi91cmwtYWxwaGFiZXQvaW5kZXguanMnXG5sZXQgcmFuZG9tID0gYnl0ZXMgPT4gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheShieXRlcykpXG5sZXQgY3VzdG9tUmFuZG9tID0gKGFscGhhYmV0LCBkZWZhdWx0U2l6ZSwgZ2V0UmFuZG9tKSA9PiB7XG4gIGxldCBtYXNrID0gKDIgPDwgKE1hdGgubG9nKGFscGhhYmV0Lmxlbmd0aCAtIDEpIC8gTWF0aC5MTjIpKSAtIDFcbiAgbGV0IHN0ZXAgPSAtfigoMS42ICogbWFzayAqIGRlZmF1bHRTaXplKSAvIGFscGhhYmV0Lmxlbmd0aClcbiAgcmV0dXJuIChzaXplID0gZGVmYXVsdFNpemUpID0+IHtcbiAgICBsZXQgaWQgPSAnJ1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBsZXQgYnl0ZXMgPSBnZXRSYW5kb20oc3RlcClcbiAgICAgIGxldCBqID0gc3RlcFxuICAgICAgd2hpbGUgKGotLSkge1xuICAgICAgICBpZCArPSBhbHBoYWJldFtieXRlc1tqXSAmIG1hc2tdIHx8ICcnXG4gICAgICAgIGlmIChpZC5sZW5ndGggPT09IHNpemUpIHJldHVybiBpZFxuICAgICAgfVxuICAgIH1cbiAgfVxufVxubGV0IGN1c3RvbUFscGhhYmV0ID0gKGFscGhhYmV0LCBzaXplID0gMjEpID0+XG4gIGN1c3RvbVJhbmRvbShhbHBoYWJldCwgc2l6ZSwgcmFuZG9tKVxubGV0IG5hbm9pZCA9IChzaXplID0gMjEpID0+XG4gIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoc2l6ZSkpLnJlZHVjZSgoaWQsIGJ5dGUpID0+IHtcbiAgICBieXRlICY9IDYzXG4gICAgaWYgKGJ5dGUgPCAzNikge1xuICAgICAgaWQgKz0gYnl0ZS50b1N0cmluZygzNilcbiAgICB9IGVsc2UgaWYgKGJ5dGUgPCA2Mikge1xuICAgICAgaWQgKz0gKGJ5dGUgLSAyNikudG9TdHJpbmcoMzYpLnRvVXBwZXJDYXNlKClcbiAgICB9IGVsc2UgaWYgKGJ5dGUgPiA2Mikge1xuICAgICAgaWQgKz0gJy0nXG4gICAgfSBlbHNlIHtcbiAgICAgIGlkICs9ICdfJ1xuICAgIH1cbiAgICByZXR1cm4gaWRcbiAgfSwgJycpXG5leHBvcnQgeyBuYW5vaWQsIGN1c3RvbUFscGhhYmV0LCBjdXN0b21SYW5kb20sIHVybEFscGhhYmV0LCByYW5kb20gfVxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5nID0gKGZ1bmN0aW9uKCkge1xuXHRpZiAodHlwZW9mIGdsb2JhbFRoaXMgPT09ICdvYmplY3QnKSByZXR1cm4gZ2xvYmFsVGhpcztcblx0dHJ5IHtcblx0XHRyZXR1cm4gdGhpcyB8fCBuZXcgRnVuY3Rpb24oJ3JldHVybiB0aGlzJykoKTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdGlmICh0eXBlb2Ygd2luZG93ID09PSAnb2JqZWN0JykgcmV0dXJuIHdpbmRvdztcblx0fVxufSkoKTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuaW1wb3J0IHsgSTE4biB9IGZyb20gJy4uLy4uL3NyYy9jb21tb24vaTE4bic7XG5pbXBvcnQgeyBQb3N0SW5zdGFsbCB9IGZyb20gJy4uLy4uL3NyYy9wYWdlcy9wb3N0LWluc3RhbGwnO1xuXG5JMThuLmluaXQoKTtcblBvc3RJbnN0YWxsLmluaXQoKTtcbiJdLCJuYW1lcyI6WyJicm93c2VyIiwiSTE4biIsImluaXQiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJ0cmFuc2xhdGUiLCJ0cmFuc2xhdGVFbGVtZW50cyIsInRyYW5zbGF0ZUF0dHJpYnV0ZXMiLCJpMThuQXR0cmlidXRlTmFtZSIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJmb3JFYWNoIiwiZWwiLCJtZXNzYWdlIiwiZ2V0STE4bk1lc3NhZ2UiLCJ0cmFuc2xhdGVFbGVtZW50IiwiZWxlbWVudCIsImxhc3RDaGlsZCIsInJlbW92ZUNoaWxkIiwicHJvY2Vzc1N0cmluZyIsImV4IiwiaHRtbCIsIm1hdGNoMSIsImV4ZWMiLCJtYXRjaDIiLCJjcmVhdGVFbGVtZW50IiwiYXBwZW5kQ2hpbGQiLCJjcmVhdGVUZXh0Tm9kZSIsInJlcGxhY2UiLCJ0YWdOYW1lIiwiYXR0cmlidXRlcyIsInNwbGl0IiwiYXR0ciIsImluZGV4IiwiaW5kZXhPZiIsImF0dHJOYW1lIiwiYXR0clZhbHVlIiwic3Vic3RyaW5nIiwibGVuZ3RoIiwic2V0QXR0cmlidXRlIiwiYXR0cmlidXRlTmFtZSIsImF0dHJpYnV0ZSIsImdldEF0dHJpYnV0ZSIsImkxOG4iLCJnZXRNZXNzYWdlIiwiTG9nZ2VyIiwiTG9nTGV2ZWwiLCJFeHRlbmRlZExvZ2dlciIsImlzVmVyYm9zZSIsImN1cnJlbnRMZXZlbCIsIkRlYnVnIiwiVHJhY2UiLCJsb2dnZXIiLCJJU19SRUxFQVNFIiwiSVNfQkVUQSIsIkluZm8iLCJPYmplY3QiLCJhc3NpZ24iLCJzZWxmIiwiYWRndWFyZCIsIkFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSIsIk1lc3NhZ2VUeXBlIiwibWVzc2FnZUhhc1R5cGVGaWVsZCIsIm1lc3NhZ2VIYXNUeXBlQW5kRGF0YUZpZWxkcyIsIk1lc3NhZ2VIYW5kbGVyIiwicnVudGltZSIsIm9uTWVzc2FnZSIsImFkZExpc3RlbmVyIiwiaGFuZGxlTWVzc2FnZSIsInR5cGUiLCJsaXN0ZW5lciIsImxpc3RlbmVycyIsImhhcyIsIkVycm9yIiwic2V0IiwicmVtb3ZlTGlzdGVuZXIiLCJkZWxldGUiLCJyZW1vdmVMaXN0ZW5lcnMiLCJjbGVhciIsImlzVmFsaWRNZXNzYWdlVHlwZSIsImhhbmRsZXJOYW1lIiwiY29uc3RydWN0b3IiLCJNYXAiLCJiaW5kIiwic2VuZE1lc3NhZ2UiLCJlIiwic2VuZFRhYk1lc3NhZ2UiLCJ0YWJJZCIsInRhYnMiLCJOYW5vYmFyIiwibWVzc2VuZ2VyIiwiUG9zdEluc3RhbGwiLCJvbkRPTUNvbnRlbnRMb2FkZWQiLCJuYW5vYmFyIiwiZ28iLCJjaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSIsInJlYWR5Iiwib25FbmdpbmVMb2FkZWQiLCJzZXRUaW1lb3V0IiwiY2hlY2tSZXF1ZXN0VGltZW91dE1zIiwiZXJyb3IiLCJ3aW5kb3ciLCJvcGVuVGhhbmt5b3VQYWdlIiwib3BlblRoYW5reW91UGFnZVRpbWVvdXRNcyIsImNsYXNzbmFtZSIsIm5hbm9pZCIsIlBhZ2UiLCJNZXNzZW5nZXIiLCJkYXRhIiwicmVzcG9uc2UiLCJ1cGRhdGVMaXN0ZW5lcnMiLCJVcGRhdGVMaXN0ZW5lcnMiLCJnZXRPcHRpb25zRGF0YSIsIkdldE9wdGlvbnNEYXRhIiwiY2hhbmdlVXNlclNldHRpbmciLCJzZXR0aW5nSWQiLCJ2YWx1ZSIsIkNoYW5nZVVzZXJTZXR0aW5ncyIsImtleSIsIm9wZW5FeHRlbnNpb25TdG9yZSIsIk9wZW5FeHRlbnNpb25TdG9yZSIsIm9wZW5Db21wYXJlUGFnZSIsIk9wZW5Db21wYXJlUGFnZSIsImVuYWJsZUZpbHRlciIsImZpbHRlcklkIiwiQWRkQW5kRW5hYmxlRmlsdGVyIiwiZGlzYWJsZUZpbHRlciIsIkRpc2FibGVGaWx0ZXIiLCJhcHBseVNldHRpbmdzSnNvbiIsImpzb24iLCJBcHBseVNldHRpbmdzSnNvbiIsIm9wZW5GaWx0ZXJpbmdMb2ciLCJPcGVuRmlsdGVyaW5nTG9nIiwicmVzZXRTdGF0aXN0aWNzIiwiUmVzZXRCbG9ja2VkQWRzQ291bnQiLCJzZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZSIsIndpbmRvd1N0YXRlIiwiU2V0RmlsdGVyaW5nTG9nV2luZG93U3RhdGUiLCJyZXNldFNldHRpbmdzIiwiUmVzZXRTZXR0aW5ncyIsImdldFVzZXJSdWxlcyIsIkdldFVzZXJSdWxlcyIsInNhdmVVc2VyUnVsZXMiLCJTYXZlVXNlclJ1bGVzIiwib3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXMiLCJPcGVuRnVsbHNjcmVlblVzZXJSdWxlcyIsImdldEFsbG93bGlzdCIsIkdldEFsbG93bGlzdERvbWFpbnMiLCJzYXZlQWxsb3dsaXN0IiwiU2F2ZUFsbG93bGlzdERvbWFpbnMiLCJzZXROb3RpZmljYXRpb25WaWV3ZWQiLCJ3aXRoRGVsYXkiLCJTZXROb3RpZmljYXRpb25WaWV3ZWQiLCJ1cGRhdGVGaWx0ZXJzIiwiX19JU19NVjNfXyIsImRlYnVnIiwiQ2hlY2tGaWx0ZXJzVXBkYXRlIiwidXBkYXRlR3JvdXBTdGF0dXMiLCJpZCIsImVuYWJsZWQiLCJFbmFibGVGaWx0ZXJzR3JvdXAiLCJEaXNhYmxlRmlsdGVyc0dyb3VwIiwiZ3JvdXBJZCIsIk51bWJlciIsInBhcnNlSW50Iiwic2V0Q29uc2VudGVkRmlsdGVycyIsImZpbHRlcklkcyIsIlNldENvbnNlbnRlZEZpbHRlcnMiLCJnZXRJc0NvbnNlbnRlZEZpbHRlciIsIkdldElzQ29uc2VudGVkRmlsdGVyIiwiY2hlY2tDdXN0b21VcmwiLCJ1cmwiLCJMb2FkQ3VzdG9tRmlsdGVySW5mbyIsImFkZEN1c3RvbUZpbHRlciIsImZpbHRlciIsIlN1YnNjcmliZVRvQ3VzdG9tRmlsdGVyIiwicmVtb3ZlQ3VzdG9tRmlsdGVyIiwiUmVtb3ZlQW50aUJhbm5lckZpbHRlciIsImdldElzRW5naW5lU3RhcnRlZCIsIkdldElzRW5naW5lU3RhcnRlZCIsImdldFRhYkluZm9Gb3JQb3B1cCIsIkdldFRhYkluZm9Gb3JQb3B1cCIsImNoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkIiwic3RhdGUiLCJDaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZCIsInVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZSIsInRoZW1lIiwiVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lIiwib3BlblJ1bGVzTGltaXRzVGFiIiwiT3BlblJ1bGVzTGltaXRzVGFiIiwib3BlblNldHRpbmdzVGFiIiwiT3BlblNldHRpbmdzVGFiIiwib3BlbkFzc2lzdGFudCIsIk9wZW5Bc3Npc3RhbnQiLCJvcGVuQWJ1c2VTaXRlIiwiZnJvbSIsIk9wZW5BYnVzZVRhYiIsImNoZWNrU2l0ZVNlY3VyaXR5IiwiT3BlblNpdGVSZXBvcnRUYWIiLCJyZXNldFVzZXJSdWxlc0ZvclBhZ2UiLCJjdXJyZW50VGFiIiwicXVlcnkiLCJhY3RpdmUiLCJjdXJyZW50V2luZG93IiwiUmVzZXRVc2VyUnVsZXNGb3JQYWdlIiwicmVtb3ZlQWxsb3dsaXN0RG9tYWluIiwidGFiUmVmcmVzaCIsIlJlbW92ZUFsbG93bGlzdERvbWFpbiIsImFkZEFsbG93bGlzdERvbWFpbiIsIkFkZEFsbG93bGlzdERvbWFpbiIsIm9uT3BlbkZpbHRlcmluZ0xvZ1BhZ2UiLCJPbk9wZW5GaWx0ZXJpbmdMb2dQYWdlIiwiZ2V0RmlsdGVyaW5nTG9nRGF0YSIsIkdldEZpbHRlcmluZ0xvZ0RhdGEiLCJvbkNsb3NlRmlsdGVyaW5nTG9nUGFnZSIsIk9uQ2xvc2VGaWx0ZXJpbmdMb2dQYWdlIiwiZ2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQiLCJHZXRGaWx0ZXJpbmdJbmZvQnlUYWJJZCIsInN5bmNocm9uaXplT3BlblRhYnMiLCJTeW5jaHJvbml6ZU9wZW5UYWJzIiwiY2xlYXJFdmVudHNCeVRhYklkIiwiaWdub3JlUHJlc2VydmVMb2ciLCJDbGVhckV2ZW50c0J5VGFiSWQiLCJyZWZyZXNoUGFnZSIsIlJlZnJlc2hQYWdlIiwiYWRkVXNlclJ1bGUiLCJydWxlVGV4dCIsIkFkZFVzZXJSdWxlIiwicmVtb3ZlVXNlclJ1bGUiLCJSZW1vdmVVc2VyUnVsZSIsInNldFByZXNlcnZlTG9nU3RhdGUiLCJTZXRQcmVzZXJ2ZUxvZ1N0YXRlIiwiZ2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQiLCJHZXRFZGl0b3JTdG9yYWdlQ29udGVudCIsInNldEVkaXRvclN0b3JhZ2VDb250ZW50IiwiY29udGVudCIsIlNldEVkaXRvclN0b3JhZ2VDb250ZW50IiwiZ2V0UnVsZXNMaW1pdHNDb3VudGVycyIsIkdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjMiLCJjYW5FbmFibGVTdGF0aWNGaWx0ZXIiLCJDYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjMiLCJjYW5FbmFibGVTdGF0aWNHcm91cCIsIkNhbkVuYWJsZVN0YXRpY0dyb3VwTXYzIiwiZ2V0Q3VycmVudExpbWl0cyIsIkN1cnJlbnRMaW1pdHNNdjMiLCJDaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSIsImFkZFVybFRvVHJ1c3RlZCIsIkFkZFVybFRvVHJ1c3RlZCIsImdldFVzZXJSdWxlc0VkaXRvckRhdGEiLCJHZXRVc2VyUnVsZXNFZGl0b3JEYXRhIiwicmVzdG9yZUZpbHRlcnNNdjMiLCJSZXN0b3JlRmlsdGVyc012MyIsImNsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzIiwiQ2xlYXJSdWxlc0xpbWl0c1dhcm5pbmdNdjMiLCJnZXRBbGxvd2xpc3REb21haW5zIiwibG9hZFNldHRpbmdzSnNvbiIsIkxvYWRTZXR0aW5nc0pzb24iLCJPcGVuVGhhbmt5b3VQYWdlIiwiaW5pdGlhbGl6ZUZyYW1lU2NyaXB0IiwiSW5pdGlhbGl6ZUZyYW1lU2NyaXB0Iiwib3BlblNhZmVicm93c2luZ1RydXN0ZWQiLCJPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCIsImNyZWF0ZUV2ZW50TGlzdGVuZXIiLCJldmVudHMiLCJjYWxsYmFjayIsIm9uVW5sb2FkQ2FsbGJhY2siLCJsaXN0ZW5lcklkIiwiQ3JlYXRlRXZlbnRMaXN0ZW5lciIsIm9uVXBkYXRlTGlzdGVuZXJzIiwidXBkYXRlZFJlc3BvbnNlIiwidW5kZWZpbmVkIiwiTm90aWZ5TGlzdGVuZXJzIiwiY2FzdGVkTWVzc2FnZSIsImluY2x1ZGVzIiwib25VbmxvYWQiLCJSZW1vdmVMaXN0ZW5lciIsImNyZWF0ZUxvbmdMaXZlZENvbm5lY3Rpb24iLCJwYWdlIiwicG9ydCIsImZvcmNlRGlzY29ubmVjdGVkIiwiY29ubmVjdCIsIm5hbWUiLCJwb3N0TWVzc2FnZSIsIkFkZExvbmdMaXZlZENvbm5lY3Rpb24iLCJvbkRpc2Nvbm5lY3QiLCJsYXN0RXJyb3IiLCJkaXNjb25uZWN0Il0sInNvdXJjZVJvb3QiOiIifQ==