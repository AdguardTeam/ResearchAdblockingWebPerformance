/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/.pnpm/ua-parser-js@1.0.36/node_modules/ua-parser-js/src/ua-parser.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/ua-parser-js@1.0.36/node_modules/ua-parser-js/src/ua-parser.js ***!
  \*******************************************************************************************/
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/////////////////////////////////////////////////////////////////////////////////
/* UAParser.js v1.0.36
   Copyright © 2012-2021 Faisal Salman <f@faisalman.com>
   MIT License *//*
   Detect Browser, Engine, OS, CPU, and Device type/model from User-Agent data.
   Supports browser & node.js environment. 
   Demo   : https://faisalman.github.io/ua-parser-js
   Source : https://github.com/faisalman/ua-parser-js */
/////////////////////////////////////////////////////////////////////////////////

(function (window, undefined) {

    'use strict';

    //////////////
    // Constants
    /////////////


    var LIBVERSION  = '1.0.36',
        EMPTY       = '',
        UNKNOWN     = '?',
        FUNC_TYPE   = 'function',
        UNDEF_TYPE  = 'undefined',
        OBJ_TYPE    = 'object',
        STR_TYPE    = 'string',
        MAJOR       = 'major',
        MODEL       = 'model',
        NAME        = 'name',
        TYPE        = 'type',
        VENDOR      = 'vendor',
        VERSION     = 'version',
        ARCHITECTURE= 'architecture',
        CONSOLE     = 'console',
        MOBILE      = 'mobile',
        TABLET      = 'tablet',
        SMARTTV     = 'smarttv',
        WEARABLE    = 'wearable',
        EMBEDDED    = 'embedded',
        UA_MAX_LENGTH = 350;

    var AMAZON  = 'Amazon',
        APPLE   = 'Apple',
        ASUS    = 'ASUS',
        BLACKBERRY = 'BlackBerry',
        BROWSER = 'Browser',
        CHROME  = 'Chrome',
        EDGE    = 'Edge',
        FIREFOX = 'Firefox',
        GOOGLE  = 'Google',
        HUAWEI  = 'Huawei',
        LG      = 'LG',
        MICROSOFT = 'Microsoft',
        MOTOROLA  = 'Motorola',
        OPERA   = 'Opera',
        SAMSUNG = 'Samsung',
        SHARP   = 'Sharp',
        SONY    = 'Sony',
        VIERA   = 'Viera',
        XIAOMI  = 'Xiaomi',
        ZEBRA   = 'Zebra',
        FACEBOOK    = 'Facebook',
        CHROMIUM_OS = 'Chromium OS',
        MAC_OS  = 'Mac OS';

    ///////////
    // Helper
    //////////

    var extend = function (regexes, extensions) {
            var mergedRegexes = {};
            for (var i in regexes) {
                if (extensions[i] && extensions[i].length % 2 === 0) {
                    mergedRegexes[i] = extensions[i].concat(regexes[i]);
                } else {
                    mergedRegexes[i] = regexes[i];
                }
            }
            return mergedRegexes;
        },
        enumerize = function (arr) {
            var enums = {};
            for (var i=0; i<arr.length; i++) {
                enums[arr[i].toUpperCase()] = arr[i];
            }
            return enums;
        },
        has = function (str1, str2) {
            return typeof str1 === STR_TYPE ? lowerize(str2).indexOf(lowerize(str1)) !== -1 : false;
        },
        lowerize = function (str) {
            return str.toLowerCase();
        },
        majorize = function (version) {
            return typeof(version) === STR_TYPE ? version.replace(/[^\d\.]/g, EMPTY).split('.')[0] : undefined;
        },
        trim = function (str, len) {
            if (typeof(str) === STR_TYPE) {
                str = str.replace(/^\s\s*/, EMPTY);
                return typeof(len) === UNDEF_TYPE ? str : str.substring(0, UA_MAX_LENGTH);
            }
    };

    ///////////////
    // Map helper
    //////////////

    var rgxMapper = function (ua, arrays) {

            var i = 0, j, k, p, q, matches, match;

            // loop through all regexes maps
            while (i < arrays.length && !matches) {

                var regex = arrays[i],       // even sequence (0,2,4,..)
                    props = arrays[i + 1];   // odd sequence (1,3,5,..)
                j = k = 0;

                // try matching uastring with regexes
                while (j < regex.length && !matches) {

                    if (!regex[j]) { break; }
                    matches = regex[j++].exec(ua);

                    if (!!matches) {
                        for (p = 0; p < props.length; p++) {
                            match = matches[++k];
                            q = props[p];
                            // check if given property is actually array
                            if (typeof q === OBJ_TYPE && q.length > 0) {
                                if (q.length === 2) {
                                    if (typeof q[1] == FUNC_TYPE) {
                                        // assign modified match
                                        this[q[0]] = q[1].call(this, match);
                                    } else {
                                        // assign given value, ignore regex match
                                        this[q[0]] = q[1];
                                    }
                                } else if (q.length === 3) {
                                    // check whether function or regex
                                    if (typeof q[1] === FUNC_TYPE && !(q[1].exec && q[1].test)) {
                                        // call function (usually string mapper)
                                        this[q[0]] = match ? q[1].call(this, match, q[2]) : undefined;
                                    } else {
                                        // sanitize match using given regex
                                        this[q[0]] = match ? match.replace(q[1], q[2]) : undefined;
                                    }
                                } else if (q.length === 4) {
                                        this[q[0]] = match ? q[3].call(this, match.replace(q[1], q[2])) : undefined;
                                }
                            } else {
                                this[q] = match ? match : undefined;
                            }
                        }
                    }
                }
                i += 2;
            }
        },

        strMapper = function (str, map) {

            for (var i in map) {
                // check if current value is array
                if (typeof map[i] === OBJ_TYPE && map[i].length > 0) {
                    for (var j = 0; j < map[i].length; j++) {
                        if (has(map[i][j], str)) {
                            return (i === UNKNOWN) ? undefined : i;
                        }
                    }
                } else if (has(map[i], str)) {
                    return (i === UNKNOWN) ? undefined : i;
                }
            }
            return str;
    };

    ///////////////
    // String map
    //////////////

    // Safari < 3.0
    var oldSafariMap = {
            '1.0'   : '/8',
            '1.2'   : '/1',
            '1.3'   : '/3',
            '2.0'   : '/412',
            '2.0.2' : '/416',
            '2.0.3' : '/417',
            '2.0.4' : '/419',
            '?'     : '/'
        },
        windowsVersionMap = {
            'ME'        : '4.90',
            'NT 3.11'   : 'NT3.51',
            'NT 4.0'    : 'NT4.0',
            '2000'      : 'NT 5.0',
            'XP'        : ['NT 5.1', 'NT 5.2'],
            'Vista'     : 'NT 6.0',
            '7'         : 'NT 6.1',
            '8'         : 'NT 6.2',
            '8.1'       : 'NT 6.3',
            '10'        : ['NT 6.4', 'NT 10.0'],
            'RT'        : 'ARM'
    };

    //////////////
    // Regex map
    /////////////

    var regexes = {

        browser : [[

            /\b(?:crmo|crios)\/([\w\.]+)/i                                      // Chrome for Android/iOS
            ], [VERSION, [NAME, 'Chrome']], [
            /edg(?:e|ios|a)?\/([\w\.]+)/i                                       // Microsoft Edge
            ], [VERSION, [NAME, 'Edge']], [

            // Presto based
            /(opera mini)\/([-\w\.]+)/i,                                        // Opera Mini
            /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,                 // Opera Mobi/Tablet
            /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i                           // Opera
            ], [NAME, VERSION], [
            /opios[\/ ]+([\w\.]+)/i                                             // Opera mini on iphone >= 8.0
            ], [VERSION, [NAME, OPERA+' Mini']], [
            /\bopr\/([\w\.]+)/i                                                 // Opera Webkit
            ], [VERSION, [NAME, OPERA]], [

            // Mixed
            /(kindle)\/([\w\.]+)/i,                                             // Kindle
            /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,      // Lunascape/Maxthon/Netfront/Jasmine/Blazer
            // Trident based
            /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i,               // Avant/IEMobile/SlimBrowser
            /(ba?idubrowser)[\/ ]?([\w\.]+)/i,                                  // Baidu Browser
            /(?:ms|\()(ie) ([\w\.]+)/i,                                         // Internet Explorer

            // Webkit/KHTML based                                               // Flock/RockMelt/Midori/Epiphany/Silk/Skyfire/Bolt/Iron/Iridium/PhantomJS/Bowser/QupZilla/Falkon
            /(flock|rockmelt|midori|epiphany|silk|skyfire|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i,
                                                                                // Rekonq/Puffin/Brave/Whale/QQBrowserLite/QQ, aka ShouQ
            /(heytap|ovi)browser\/([\d\.]+)/i,                                  // Heytap/Ovi
            /(weibo)__([\d\.]+)/i                                               // Weibo
            ], [NAME, VERSION], [
            /(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i                 // UCBrowser
            ], [VERSION, [NAME, 'UC'+BROWSER]], [
            /microm.+\bqbcore\/([\w\.]+)/i,                                     // WeChat Desktop for Windows Built-in Browser
            /\bqbcore\/([\w\.]+).+microm/i
            ], [VERSION, [NAME, 'WeChat(Win) Desktop']], [
            /micromessenger\/([\w\.]+)/i                                        // WeChat
            ], [VERSION, [NAME, 'WeChat']], [
            /konqueror\/([\w\.]+)/i                                             // Konqueror
            ], [VERSION, [NAME, 'Konqueror']], [
            /trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i                       // IE11
            ], [VERSION, [NAME, 'IE']], [
            /ya(?:search)?browser\/([\w\.]+)/i                                  // Yandex
            ], [VERSION, [NAME, 'Yandex']], [
            /(avast|avg)\/([\w\.]+)/i                                           // Avast/AVG Secure Browser
            ], [[NAME, /(.+)/, '$1 Secure '+BROWSER], VERSION], [
            /\bfocus\/([\w\.]+)/i                                               // Firefox Focus
            ], [VERSION, [NAME, FIREFOX+' Focus']], [
            /\bopt\/([\w\.]+)/i                                                 // Opera Touch
            ], [VERSION, [NAME, OPERA+' Touch']], [
            /coc_coc\w+\/([\w\.]+)/i                                            // Coc Coc Browser
            ], [VERSION, [NAME, 'Coc Coc']], [
            /dolfin\/([\w\.]+)/i                                                // Dolphin
            ], [VERSION, [NAME, 'Dolphin']], [
            /coast\/([\w\.]+)/i                                                 // Opera Coast
            ], [VERSION, [NAME, OPERA+' Coast']], [
            /miuibrowser\/([\w\.]+)/i                                           // MIUI Browser
            ], [VERSION, [NAME, 'MIUI '+BROWSER]], [
            /fxios\/([-\w\.]+)/i                                                // Firefox for iOS
            ], [VERSION, [NAME, FIREFOX]], [
            /\bqihu|(qi?ho?o?|360)browser/i                                     // 360
            ], [[NAME, '360 '+BROWSER]], [
            /(oculus|samsung|sailfish|huawei)browser\/([\w\.]+)/i
            ], [[NAME, /(.+)/, '$1 '+BROWSER], VERSION], [                      // Oculus/Samsung/Sailfish/Huawei Browser
            /(comodo_dragon)\/([\w\.]+)/i                                       // Comodo Dragon
            ], [[NAME, /_/g, ' '], VERSION], [
            /(electron)\/([\w\.]+) safari/i,                                    // Electron-based App
            /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,                   // Tesla
            /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i            // QQBrowser/Baidu App/2345 Browser
            ], [NAME, VERSION], [
            /(metasr)[\/ ]?([\w\.]+)/i,                                         // SouGouBrowser
            /(lbbrowser)/i,                                                     // LieBao Browser
            /\[(linkedin)app\]/i                                                // LinkedIn App for iOS & Android
            ], [NAME], [

            // WebView
            /((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i       // Facebook App for iOS & Android
            ], [[NAME, FACEBOOK], VERSION], [
            /(kakao(?:talk|story))[\/ ]([\w\.]+)/i,                             // Kakao App
            /(naver)\(.*?(\d+\.[\w\.]+).*\)/i,                                  // Naver InApp
            /safari (line)\/([\w\.]+)/i,                                        // Line App for iOS
            /\b(line)\/([\w\.]+)\/iab/i,                                        // Line App for Android
            /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i                     // Chromium/Instagram/Snapchat
            ], [NAME, VERSION], [
            /\bgsa\/([\w\.]+) .*safari\//i                                      // Google Search Appliance on iOS
            ], [VERSION, [NAME, 'GSA']], [
            /musical_ly(?:.+app_?version\/|_)([\w\.]+)/i                        // TikTok
            ], [VERSION, [NAME, 'TikTok']], [

            /headlesschrome(?:\/([\w\.]+)| )/i                                  // Chrome Headless
            ], [VERSION, [NAME, CHROME+' Headless']], [

            / wv\).+(chrome)\/([\w\.]+)/i                                       // Chrome WebView
            ], [[NAME, CHROME+' WebView'], VERSION], [

            /droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i           // Android Browser
            ], [VERSION, [NAME, 'Android '+BROWSER]], [

            /(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i       // Chrome/OmniWeb/Arora/Tizen/Nokia
            ], [NAME, VERSION], [

            /version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i                      // Mobile Safari
            ], [VERSION, [NAME, 'Mobile Safari']], [
            /version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i                // Safari & Safari Mobile
            ], [VERSION, NAME], [
            /webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i                      // Safari < 3.0
            ], [NAME, [VERSION, strMapper, oldSafariMap]], [

            /(webkit|khtml)\/([\w\.]+)/i
            ], [NAME, VERSION], [

            // Gecko based
            /(navigator|netscape\d?)\/([-\w\.]+)/i                              // Netscape
            ], [[NAME, 'Netscape'], VERSION], [
            /mobile vr; rv:([\w\.]+)\).+firefox/i                               // Firefox Reality
            ], [VERSION, [NAME, FIREFOX+' Reality']], [
            /ekiohf.+(flow)\/([\w\.]+)/i,                                       // Flow
            /(swiftfox)/i,                                                      // Swiftfox
            /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,
                                                                                // IceDragon/Iceweasel/Camino/Chimera/Fennec/Maemo/Minimo/Conkeror/Klar
            /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                                                                                // Firefox/SeaMonkey/K-Meleon/IceCat/IceApe/Firebird/Phoenix
            /(firefox)\/([\w\.]+)/i,                                            // Other Firefox-based
            /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,                         // Mozilla

            // Other
            /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                                                                                // Polaris/Lynx/Dillo/iCab/Doris/Amaya/w3m/NetSurf/Sleipnir/Obigo/Mosaic/Go/ICE/UP.Browser
            /(links) \(([\w\.]+)/i,                                             // Links
            /panasonic;(viera)/i                                                // Panasonic Viera
            ], [NAME, VERSION], [
            
            /(cobalt)\/([\w\.]+)/i                                              // Cobalt
            ], [NAME, [VERSION, /master.|lts./, ""]]
        ],

        cpu : [[

            /(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i                     // AMD64 (x64)
            ], [[ARCHITECTURE, 'amd64']], [

            /(ia32(?=;))/i                                                      // IA32 (quicktime)
            ], [[ARCHITECTURE, lowerize]], [

            /((?:i[346]|x)86)[;\)]/i                                            // IA32 (x86)
            ], [[ARCHITECTURE, 'ia32']], [

            /\b(aarch64|arm(v?8e?l?|_?64))\b/i                                 // ARM64
            ], [[ARCHITECTURE, 'arm64']], [

            /\b(arm(?:v[67])?ht?n?[fl]p?)\b/i                                   // ARMHF
            ], [[ARCHITECTURE, 'armhf']], [

            // PocketPC mistakenly identified as PowerPC
            /windows (ce|mobile); ppc;/i
            ], [[ARCHITECTURE, 'arm']], [

            /((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i                            // PowerPC
            ], [[ARCHITECTURE, /ower/, EMPTY, lowerize]], [

            /(sun4\w)[;\)]/i                                                    // SPARC
            ], [[ARCHITECTURE, 'sparc']], [

            /((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i
                                                                                // IA64, 68K, ARM/64, AVR/32, IRIX/64, MIPS/64, SPARC/64, PA-RISC
            ], [[ARCHITECTURE, lowerize]]
        ],

        device : [[

            //////////////////////////
            // MOBILES & TABLETS
            /////////////////////////

            // Samsung
            /\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i
            ], [MODEL, [VENDOR, SAMSUNG], [TYPE, TABLET]], [
            /\b((?:s[cgp]h|gt|sm)-\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,
            /samsung[- ]([-\w]+)/i,
            /sec-(sgh\w+)/i
            ], [MODEL, [VENDOR, SAMSUNG], [TYPE, MOBILE]], [

            // Apple
            /(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i                          // iPod/iPhone
            ], [MODEL, [VENDOR, APPLE], [TYPE, MOBILE]], [
            /\((ipad);[-\w\),; ]+apple/i,                                       // iPad
            /applecoremedia\/[\w\.]+ \((ipad)/i,
            /\b(ipad)\d\d?,\d\d?[;\]].+ios/i
            ], [MODEL, [VENDOR, APPLE], [TYPE, TABLET]], [
            /(macintosh);/i
            ], [MODEL, [VENDOR, APPLE]], [

            // Sharp
            /\b(sh-?[altvz]?\d\d[a-ekm]?)/i
            ], [MODEL, [VENDOR, SHARP], [TYPE, MOBILE]], [

            // Huawei
            /\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i
            ], [MODEL, [VENDOR, HUAWEI], [TYPE, TABLET]], [
            /(?:huawei|honor)([-\w ]+)[;\)]/i,
            /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i
            ], [MODEL, [VENDOR, HUAWEI], [TYPE, MOBILE]], [

            // Xiaomi
            /\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i,                  // Xiaomi POCO
            /\b; (\w+) build\/hm\1/i,                                           // Xiaomi Hongmi 'numeric' models
            /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,                             // Xiaomi Hongmi
            /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,                   // Xiaomi Redmi
            /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i // Xiaomi Mi
            ], [[MODEL, /_/g, ' '], [VENDOR, XIAOMI], [TYPE, MOBILE]], [
            /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i                        // Mi Pad tablets
            ],[[MODEL, /_/g, ' '], [VENDOR, XIAOMI], [TYPE, TABLET]], [

            // OPPO
            /; (\w+) bui.+ oppo/i,
            /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i
            ], [MODEL, [VENDOR, 'OPPO'], [TYPE, MOBILE]], [

            // Vivo
            /vivo (\w+)(?: bui|\))/i,
            /\b(v[12]\d{3}\w?[at])(?: bui|;)/i
            ], [MODEL, [VENDOR, 'Vivo'], [TYPE, MOBILE]], [

            // Realme
            /\b(rmx[12]\d{3})(?: bui|;|\))/i
            ], [MODEL, [VENDOR, 'Realme'], [TYPE, MOBILE]], [

            // Motorola
            /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
            /\bmot(?:orola)?[- ](\w*)/i,
            /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i
            ], [MODEL, [VENDOR, MOTOROLA], [TYPE, MOBILE]], [
            /\b(mz60\d|xoom[2 ]{0,2}) build\//i
            ], [MODEL, [VENDOR, MOTOROLA], [TYPE, TABLET]], [

            // LG
            /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i
            ], [MODEL, [VENDOR, LG], [TYPE, TABLET]], [
            /(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
            /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,
            /\blg-?([\d\w]+) bui/i
            ], [MODEL, [VENDOR, LG], [TYPE, MOBILE]], [

            // Lenovo
            /(ideatab[-\w ]+)/i,
            /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i
            ], [MODEL, [VENDOR, 'Lenovo'], [TYPE, TABLET]], [

            // Nokia
            /(?:maemo|nokia).*(n900|lumia \d+)/i,
            /nokia[-_ ]?([-\w\.]*)/i
            ], [[MODEL, /_/g, ' '], [VENDOR, 'Nokia'], [TYPE, MOBILE]], [

            // Google
            /(pixel c)\b/i                                                      // Google Pixel C
            ], [MODEL, [VENDOR, GOOGLE], [TYPE, TABLET]], [
            /droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i                         // Google Pixel
            ], [MODEL, [VENDOR, GOOGLE], [TYPE, MOBILE]], [

            // Sony
            /droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i
            ], [MODEL, [VENDOR, SONY], [TYPE, MOBILE]], [
            /sony tablet [ps]/i,
            /\b(?:sony)?sgp\w+(?: bui|\))/i
            ], [[MODEL, 'Xperia Tablet'], [VENDOR, SONY], [TYPE, TABLET]], [

            // OnePlus
            / (kb2005|in20[12]5|be20[12][59])\b/i,
            /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i
            ], [MODEL, [VENDOR, 'OnePlus'], [TYPE, MOBILE]], [

            // Amazon
            /(alexa)webm/i,
            /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i,                             // Kindle Fire without Silk / Echo Show
            /(kf[a-z]+)( bui|\)).+silk\//i                                      // Kindle Fire HD
            ], [MODEL, [VENDOR, AMAZON], [TYPE, TABLET]], [
            /((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i                     // Fire Phone
            ], [[MODEL, /(.+)/g, 'Fire Phone $1'], [VENDOR, AMAZON], [TYPE, MOBILE]], [

            // BlackBerry
            /(playbook);[-\w\),; ]+(rim)/i                                      // BlackBerry PlayBook
            ], [MODEL, VENDOR, [TYPE, TABLET]], [
            /\b((?:bb[a-f]|st[hv])100-\d)/i,
            /\(bb10; (\w+)/i                                                    // BlackBerry 10
            ], [MODEL, [VENDOR, BLACKBERRY], [TYPE, MOBILE]], [

            // Asus
            /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i
            ], [MODEL, [VENDOR, ASUS], [TYPE, TABLET]], [
            / (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i
            ], [MODEL, [VENDOR, ASUS], [TYPE, MOBILE]], [

            // HTC
            /(nexus 9)/i                                                        // HTC Nexus 9
            ], [MODEL, [VENDOR, 'HTC'], [TYPE, TABLET]], [
            /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,                         // HTC

            // ZTE
            /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
            /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i         // Alcatel/GeeksPhone/Nexian/Panasonic/Sony
            ], [VENDOR, [MODEL, /_/g, ' '], [TYPE, MOBILE]], [

            // Acer
            /droid.+; ([ab][1-7]-?[0178a]\d\d?)/i
            ], [MODEL, [VENDOR, 'Acer'], [TYPE, TABLET]], [

            // Meizu
            /droid.+; (m[1-5] note) bui/i,
            /\bmz-([-\w]{2,})/i
            ], [MODEL, [VENDOR, 'Meizu'], [TYPE, MOBILE]], [

            // MIXED
            /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron|infinix|tecno)[-_ ]?([-\w]*)/i,
                                                                                // BlackBerry/BenQ/Palm/Sony-Ericsson/Acer/Asus/Dell/Meizu/Motorola/Polytron
            /(hp) ([\w ]+\w)/i,                                                 // HP iPAQ
            /(asus)-?(\w+)/i,                                                   // Asus
            /(microsoft); (lumia[\w ]+)/i,                                      // Microsoft Lumia
            /(lenovo)[-_ ]?([-\w]+)/i,                                          // Lenovo
            /(jolla)/i,                                                         // Jolla
            /(oppo) ?([\w ]+) bui/i                                             // OPPO
            ], [VENDOR, MODEL, [TYPE, MOBILE]], [

            /(kobo)\s(ereader|touch)/i,                                         // Kobo
            /(archos) (gamepad2?)/i,                                            // Archos
            /(hp).+(touchpad(?!.+tablet)|tablet)/i,                             // HP TouchPad
            /(kindle)\/([\w\.]+)/i,                                             // Kindle
            /(nook)[\w ]+build\/(\w+)/i,                                        // Nook
            /(dell) (strea[kpr\d ]*[\dko])/i,                                   // Dell Streak
            /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,                                  // Le Pan Tablets
            /(trinity)[- ]*(t\d{3}) bui/i,                                      // Trinity Tablets
            /(gigaset)[- ]+(q\w{1,9}) bui/i,                                    // Gigaset Tablets
            /(vodafone) ([\w ]+)(?:\)| bui)/i                                   // Vodafone
            ], [VENDOR, MODEL, [TYPE, TABLET]], [

            /(surface duo)/i                                                    // Surface Duo
            ], [MODEL, [VENDOR, MICROSOFT], [TYPE, TABLET]], [
            /droid [\d\.]+; (fp\du?)(?: b|\))/i                                 // Fairphone
            ], [MODEL, [VENDOR, 'Fairphone'], [TYPE, MOBILE]], [
            /(u304aa)/i                                                         // AT&T
            ], [MODEL, [VENDOR, 'AT&T'], [TYPE, MOBILE]], [
            /\bsie-(\w*)/i                                                      // Siemens
            ], [MODEL, [VENDOR, 'Siemens'], [TYPE, MOBILE]], [
            /\b(rct\w+) b/i                                                     // RCA Tablets
            ], [MODEL, [VENDOR, 'RCA'], [TYPE, TABLET]], [
            /\b(venue[\d ]{2,7}) b/i                                            // Dell Venue Tablets
            ], [MODEL, [VENDOR, 'Dell'], [TYPE, TABLET]], [
            /\b(q(?:mv|ta)\w+) b/i                                              // Verizon Tablet
            ], [MODEL, [VENDOR, 'Verizon'], [TYPE, TABLET]], [
            /\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i                       // Barnes & Noble Tablet
            ], [MODEL, [VENDOR, 'Barnes & Noble'], [TYPE, TABLET]], [
            /\b(tm\d{3}\w+) b/i
            ], [MODEL, [VENDOR, 'NuVision'], [TYPE, TABLET]], [
            /\b(k88) b/i                                                        // ZTE K Series Tablet
            ], [MODEL, [VENDOR, 'ZTE'], [TYPE, TABLET]], [
            /\b(nx\d{3}j) b/i                                                   // ZTE Nubia
            ], [MODEL, [VENDOR, 'ZTE'], [TYPE, MOBILE]], [
            /\b(gen\d{3}) b.+49h/i                                              // Swiss GEN Mobile
            ], [MODEL, [VENDOR, 'Swiss'], [TYPE, MOBILE]], [
            /\b(zur\d{3}) b/i                                                   // Swiss ZUR Tablet
            ], [MODEL, [VENDOR, 'Swiss'], [TYPE, TABLET]], [
            /\b((zeki)?tb.*\b) b/i                                              // Zeki Tablets
            ], [MODEL, [VENDOR, 'Zeki'], [TYPE, TABLET]], [
            /\b([yr]\d{2}) b/i,
            /\b(dragon[- ]+touch |dt)(\w{5}) b/i                                // Dragon Touch Tablet
            ], [[VENDOR, 'Dragon Touch'], MODEL, [TYPE, TABLET]], [
            /\b(ns-?\w{0,9}) b/i                                                // Insignia Tablets
            ], [MODEL, [VENDOR, 'Insignia'], [TYPE, TABLET]], [
            /\b((nxa|next)-?\w{0,9}) b/i                                        // NextBook Tablets
            ], [MODEL, [VENDOR, 'NextBook'], [TYPE, TABLET]], [
            /\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i                  // Voice Xtreme Phones
            ], [[VENDOR, 'Voice'], MODEL, [TYPE, MOBILE]], [
            /\b(lvtel\-)?(v1[12]) b/i                                           // LvTel Phones
            ], [[VENDOR, 'LvTel'], MODEL, [TYPE, MOBILE]], [
            /\b(ph-1) /i                                                        // Essential PH-1
            ], [MODEL, [VENDOR, 'Essential'], [TYPE, MOBILE]], [
            /\b(v(100md|700na|7011|917g).*\b) b/i                               // Envizen Tablets
            ], [MODEL, [VENDOR, 'Envizen'], [TYPE, TABLET]], [
            /\b(trio[-\w\. ]+) b/i                                              // MachSpeed Tablets
            ], [MODEL, [VENDOR, 'MachSpeed'], [TYPE, TABLET]], [
            /\btu_(1491) b/i                                                    // Rotor Tablets
            ], [MODEL, [VENDOR, 'Rotor'], [TYPE, TABLET]], [
            /(shield[\w ]+) b/i                                                 // Nvidia Shield Tablets
            ], [MODEL, [VENDOR, 'Nvidia'], [TYPE, TABLET]], [
            /(sprint) (\w+)/i                                                   // Sprint Phones
            ], [VENDOR, MODEL, [TYPE, MOBILE]], [
            /(kin\.[onetw]{3})/i                                                // Microsoft Kin
            ], [[MODEL, /\./g, ' '], [VENDOR, MICROSOFT], [TYPE, MOBILE]], [
            /droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i             // Zebra
            ], [MODEL, [VENDOR, ZEBRA], [TYPE, TABLET]], [
            /droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i
            ], [MODEL, [VENDOR, ZEBRA], [TYPE, MOBILE]], [

            ///////////////////
            // SMARTTVS
            ///////////////////

            /smart-tv.+(samsung)/i                                              // Samsung
            ], [VENDOR, [TYPE, SMARTTV]], [
            /hbbtv.+maple;(\d+)/i
            ], [[MODEL, /^/, 'SmartTV'], [VENDOR, SAMSUNG], [TYPE, SMARTTV]], [
            /(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i        // LG SmartTV
            ], [[VENDOR, LG], [TYPE, SMARTTV]], [
            /(apple) ?tv/i                                                      // Apple TV
            ], [VENDOR, [MODEL, APPLE+' TV'], [TYPE, SMARTTV]], [
            /crkey/i                                                            // Google Chromecast
            ], [[MODEL, CHROME+'cast'], [VENDOR, GOOGLE], [TYPE, SMARTTV]], [
            /droid.+aft(\w+)( bui|\))/i                                         // Fire TV
            ], [MODEL, [VENDOR, AMAZON], [TYPE, SMARTTV]], [
            /\(dtv[\);].+(aquos)/i,
            /(aquos-tv[\w ]+)\)/i                                               // Sharp
            ], [MODEL, [VENDOR, SHARP], [TYPE, SMARTTV]],[
            /(bravia[\w ]+)( bui|\))/i                                              // Sony
            ], [MODEL, [VENDOR, SONY], [TYPE, SMARTTV]], [
            /(mitv-\w{5}) bui/i                                                 // Xiaomi
            ], [MODEL, [VENDOR, XIAOMI], [TYPE, SMARTTV]], [
            /Hbbtv.*(technisat) (.*);/i                                         // TechniSAT
            ], [VENDOR, MODEL, [TYPE, SMARTTV]], [
            /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,                          // Roku
            /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i         // HbbTV devices
            ], [[VENDOR, trim], [MODEL, trim], [TYPE, SMARTTV]], [
            /\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i                   // SmartTV from Unidentified Vendors
            ], [[TYPE, SMARTTV]], [

            ///////////////////
            // CONSOLES
            ///////////////////

            /(ouya)/i,                                                          // Ouya
            /(nintendo) ([wids3utch]+)/i                                        // Nintendo
            ], [VENDOR, MODEL, [TYPE, CONSOLE]], [
            /droid.+; (shield) bui/i                                            // Nvidia
            ], [MODEL, [VENDOR, 'Nvidia'], [TYPE, CONSOLE]], [
            /(playstation [345portablevi]+)/i                                   // Playstation
            ], [MODEL, [VENDOR, SONY], [TYPE, CONSOLE]], [
            /\b(xbox(?: one)?(?!; xbox))[\); ]/i                                // Microsoft Xbox
            ], [MODEL, [VENDOR, MICROSOFT], [TYPE, CONSOLE]], [

            ///////////////////
            // WEARABLES
            ///////////////////

            /((pebble))app/i                                                    // Pebble
            ], [VENDOR, MODEL, [TYPE, WEARABLE]], [
            /(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i                              // Apple Watch
            ], [MODEL, [VENDOR, APPLE], [TYPE, WEARABLE]], [
            /droid.+; (glass) \d/i                                              // Google Glass
            ], [MODEL, [VENDOR, GOOGLE], [TYPE, WEARABLE]], [
            /droid.+; (wt63?0{2,3})\)/i
            ], [MODEL, [VENDOR, ZEBRA], [TYPE, WEARABLE]], [
            /(quest( 2| pro)?)/i                                                // Oculus Quest
            ], [MODEL, [VENDOR, FACEBOOK], [TYPE, WEARABLE]], [

            ///////////////////
            // EMBEDDED
            ///////////////////

            /(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i                              // Tesla
            ], [VENDOR, [TYPE, EMBEDDED]], [
            /(aeobc)\b/i                                                        // Echo Dot
            ], [MODEL, [VENDOR, AMAZON], [TYPE, EMBEDDED]], [

            ////////////////////
            // MIXED (GENERIC)
            ///////////////////

            /droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i           // Android Phones from Unidentified Vendors
            ], [MODEL, [TYPE, MOBILE]], [
            /droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i       // Android Tablets from Unidentified Vendors
            ], [MODEL, [TYPE, TABLET]], [
            /\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i                      // Unidentifiable Tablet
            ], [[TYPE, TABLET]], [
            /(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i    // Unidentifiable Mobile
            ], [[TYPE, MOBILE]], [
            /(android[-\w\. ]{0,9});.+buil/i                                    // Generic Android Device
            ], [MODEL, [VENDOR, 'Generic']]
        ],

        engine : [[

            /windows.+ edge\/([\w\.]+)/i                                       // EdgeHTML
            ], [VERSION, [NAME, EDGE+'HTML']], [

            /webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i                         // Blink
            ], [VERSION, [NAME, 'Blink']], [

            /(presto)\/([\w\.]+)/i,                                             // Presto
            /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, // WebKit/Trident/NetFront/NetSurf/Amaya/Lynx/w3m/Goanna
            /ekioh(flow)\/([\w\.]+)/i,                                          // Flow
            /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,                           // KHTML/Tasman/Links
            /(icab)[\/ ]([23]\.[\d\.]+)/i,                                      // iCab
            /\b(libweb)/i
            ], [NAME, VERSION], [

            /rv\:([\w\.]{1,9})\b.+(gecko)/i                                     // Gecko
            ], [VERSION, NAME]
        ],

        os : [[

            // Windows
            /microsoft (windows) (vista|xp)/i                                   // Windows (iTunes)
            ], [NAME, VERSION], [
            /(windows) nt 6\.2; (arm)/i,                                        // Windows RT
            /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,            // Windows Phone
            /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i
            ], [NAME, [VERSION, strMapper, windowsVersionMap]], [
            /(win(?=3|9|n)|win 9x )([nt\d\.]+)/i
            ], [[NAME, 'Windows'], [VERSION, strMapper, windowsVersionMap]], [

            // iOS/macOS
            /ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,              // iOS
            /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i,
            /cfnetwork\/.+darwin/i
            ], [[VERSION, /_/g, '.'], [NAME, 'iOS']], [
            /(mac os x) ?([\w\. ]*)/i,
            /(macintosh|mac_powerpc\b)(?!.+haiku)/i                             // Mac OS
            ], [[NAME, MAC_OS], [VERSION, /_/g, '.']], [

            // Mobile OSes
            /droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i                    // Android-x86/HarmonyOS
            ], [VERSION, NAME], [                                               // Android/WebOS/QNX/Bada/RIM/Maemo/MeeGo/Sailfish OS
            /(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,
            /(blackberry)\w*\/([\w\.]*)/i,                                      // Blackberry
            /(tizen|kaios)[\/ ]([\w\.]+)/i,                                     // Tizen/KaiOS
            /\((series40);/i                                                    // Series 40
            ], [NAME, VERSION], [
            /\(bb(10);/i                                                        // BlackBerry 10
            ], [VERSION, [NAME, BLACKBERRY]], [
            /(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i         // Symbian
            ], [VERSION, [NAME, 'Symbian']], [
            /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i // Firefox OS
            ], [VERSION, [NAME, FIREFOX+' OS']], [
            /web0s;.+rt(tv)/i,
            /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i                              // WebOS
            ], [VERSION, [NAME, 'webOS']], [
            /watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i                              // watchOS
            ], [VERSION, [NAME, 'watchOS']], [

            // Google Chromecast
            /crkey\/([\d\.]+)/i                                                 // Google Chromecast
            ], [VERSION, [NAME, CHROME+'cast']], [
            /(cros) [\w]+(?:\)| ([\w\.]+)\b)/i                                  // Chromium OS
            ], [[NAME, CHROMIUM_OS], VERSION],[

            // Smart TVs
            /panasonic;(viera)/i,                                               // Panasonic Viera
            /(netrange)mmh/i,                                                   // Netrange
            /(nettv)\/(\d+\.[\w\.]+)/i,                                         // NetTV

            // Console
            /(nintendo|playstation) ([wids345portablevuch]+)/i,                 // Nintendo/Playstation
            /(xbox); +xbox ([^\);]+)/i,                                         // Microsoft Xbox (360, One, X, S, Series X, Series S)

            // Other
            /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,                            // Joli/Palm
            /(mint)[\/\(\) ]?(\w*)/i,                                           // Mint
            /(mageia|vectorlinux)[; ]/i,                                        // Mageia/VectorLinux
            /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                                                                                // Ubuntu/Debian/SUSE/Gentoo/Arch/Slackware/Fedora/Mandriva/CentOS/PCLinuxOS/RedHat/Zenwalk/Linpus/Raspbian/Plan9/Minix/RISCOS/Contiki/Deepin/Manjaro/elementary/Sabayon/Linspire
            /(hurd|linux) ?([\w\.]*)/i,                                         // Hurd/Linux
            /(gnu) ?([\w\.]*)/i,                                                // GNU
            /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, // FreeBSD/NetBSD/OpenBSD/PC-BSD/GhostBSD/DragonFly
            /(haiku) (\w+)/i                                                    // Haiku
            ], [NAME, VERSION], [
            /(sunos) ?([\w\.\d]*)/i                                             // Solaris
            ], [[NAME, 'Solaris'], VERSION], [
            /((?:open)?solaris)[-\/ ]?([\w\.]*)/i,                              // Solaris
            /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,                                  // AIX
            /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i, // BeOS/OS2/AmigaOS/MorphOS/OpenVMS/Fuchsia/HP-UX/SerenityOS
            /(unix) ?([\w\.]*)/i                                                // UNIX
            ], [NAME, VERSION]
        ]
    };

    /////////////////
    // Constructor
    ////////////////

    var UAParser = function (ua, extensions) {

        if (typeof ua === OBJ_TYPE) {
            extensions = ua;
            ua = undefined;
        }

        if (!(this instanceof UAParser)) {
            return new UAParser(ua, extensions).getResult();
        }

        var _navigator = (typeof window !== UNDEF_TYPE && window.navigator) ? window.navigator : undefined;
        var _ua = ua || ((_navigator && _navigator.userAgent) ? _navigator.userAgent : EMPTY);
        var _uach = (_navigator && _navigator.userAgentData) ? _navigator.userAgentData : undefined;
        var _rgxmap = extensions ? extend(regexes, extensions) : regexes;
        var _isSelfNav = _navigator && _navigator.userAgent == _ua;

        this.getBrowser = function () {
            var _browser = {};
            _browser[NAME] = undefined;
            _browser[VERSION] = undefined;
            rgxMapper.call(_browser, _ua, _rgxmap.browser);
            _browser[MAJOR] = majorize(_browser[VERSION]);
            // Brave-specific detection
            if (_isSelfNav && _navigator && _navigator.brave && typeof _navigator.brave.isBrave == FUNC_TYPE) {
                _browser[NAME] = 'Brave';
            }
            return _browser;
        };
        this.getCPU = function () {
            var _cpu = {};
            _cpu[ARCHITECTURE] = undefined;
            rgxMapper.call(_cpu, _ua, _rgxmap.cpu);
            return _cpu;
        };
        this.getDevice = function () {
            var _device = {};
            _device[VENDOR] = undefined;
            _device[MODEL] = undefined;
            _device[TYPE] = undefined;
            rgxMapper.call(_device, _ua, _rgxmap.device);
            if (_isSelfNav && !_device[TYPE] && _uach && _uach.mobile) {
                _device[TYPE] = MOBILE;
            }
            // iPadOS-specific detection: identified as Mac, but has some iOS-only properties
            if (_isSelfNav && _device[MODEL] == 'Macintosh' && _navigator && typeof _navigator.standalone !== UNDEF_TYPE && _navigator.maxTouchPoints && _navigator.maxTouchPoints > 2) {
                _device[MODEL] = 'iPad';
                _device[TYPE] = TABLET;
            }
            return _device;
        };
        this.getEngine = function () {
            var _engine = {};
            _engine[NAME] = undefined;
            _engine[VERSION] = undefined;
            rgxMapper.call(_engine, _ua, _rgxmap.engine);
            return _engine;
        };
        this.getOS = function () {
            var _os = {};
            _os[NAME] = undefined;
            _os[VERSION] = undefined;
            rgxMapper.call(_os, _ua, _rgxmap.os);
            if (_isSelfNav && !_os[NAME] && _uach && _uach.platform != 'Unknown') {
                _os[NAME] = _uach.platform  
                                    .replace(/chrome os/i, CHROMIUM_OS)
                                    .replace(/macos/i, MAC_OS);           // backward compatibility
            }
            return _os;
        };
        this.getResult = function () {
            return {
                ua      : this.getUA(),
                browser : this.getBrowser(),
                engine  : this.getEngine(),
                os      : this.getOS(),
                device  : this.getDevice(),
                cpu     : this.getCPU()
            };
        };
        this.getUA = function () {
            return _ua;
        };
        this.setUA = function (ua) {
            _ua = (typeof ua === STR_TYPE && ua.length > UA_MAX_LENGTH) ? trim(ua, UA_MAX_LENGTH) : ua;
            return this;
        };
        this.setUA(_ua);
        return this;
    };

    UAParser.VERSION = LIBVERSION;
    UAParser.BROWSER =  enumerize([NAME, VERSION, MAJOR]);
    UAParser.CPU = enumerize([ARCHITECTURE]);
    UAParser.DEVICE = enumerize([MODEL, VENDOR, TYPE, CONSOLE, MOBILE, SMARTTV, TABLET, WEARABLE, EMBEDDED]);
    UAParser.ENGINE = UAParser.OS = enumerize([NAME, VERSION]);

    ///////////
    // Export
    //////////

    // check js environment
    if (typeof(exports) !== UNDEF_TYPE) {
        // nodejs env
        if ("object" !== UNDEF_TYPE && module.exports) {
            exports = module.exports = UAParser;
        }
        exports.UAParser = UAParser;
    } else {
        // requirejs env (optional)
        if ("function" === FUNC_TYPE && __webpack_require__.amdO) {
            !(__WEBPACK_AMD_DEFINE_RESULT__ = (function () {
                return UAParser;
            }).call(exports, __webpack_require__, exports, module),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
        } else if (typeof window !== UNDEF_TYPE) {
            // browser env
            window.UAParser = UAParser;
        }
    }

    // jQuery/Zepto specific (optional)
    // Note:
    //   In AMD env the global scope should be kept clean, but jQuery is an exception.
    //   jQuery always exports to global scope, unless jQuery.noConflict(true) is used,
    //   and we should catch that.
    var $ = typeof window !== UNDEF_TYPE && (window.jQuery || window.Zepto);
    if ($ && !$.ua) {
        var parser = new UAParser();
        $.ua = parser.getResult();
        $.ua.get = function () {
            return parser.getUA();
        };
        $.ua.set = function (ua) {
            parser.setUA(ua);
            var result = parser.getResult();
            for (var prop in result) {
                $.ua[prop] = result[prop];
            }
        };
    }

})(typeof window === 'object' ? window : this);


/***/ }),

/***/ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.12.0 - Tue May 14 2024 18:01:29 */
  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
  /* vim: set sts=2 sw=2 et tw=80: */
  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
    throw new Error("This script should only be loaded in a browser extension.");
  }
  if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";

    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }

      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }

      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };

      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);

                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };

      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },
          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }
            if (!(prop in target)) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.

              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };

        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };

      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */
        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {} /* wrappers */, {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);

          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }

          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };

          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }

          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "./Extension/src/common/logger.ts":
/*!****************************************!*\
  !*** ./Extension/src/common/logger.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   logger: () => (/* binding */ logger)
/* harmony export */ });
/* harmony import */ var core_js_modules_web_self_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/web.self.js */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/web.self.js");
/* harmony import */ var core_js_modules_web_self_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_self_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _adguard_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @adguard/logger */ "./node_modules/.pnpm/@adguard+logger@1.1.1/node_modules/@adguard/logger/dist/es/index.mjs");
/**
 * @file
 *
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

class ExtendedLogger extends _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.Logger {
    isVerbose() {
        return this.currentLevel === _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.LogLevel.Debug || this.currentLevel === _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.LogLevel.Trace;
    }
}
const logger = new ExtendedLogger();
logger.currentLevel =  false ? 0 : _adguard_logger__WEBPACK_IMPORTED_MODULE_1__.LogLevel.Trace;
// Expose logger to the window object,
// to have possibility to switch log level from the console.
// Example: adguard.logger.currentLevel = 'debug'
// eslint-disable-next-line no-restricted-globals
Object.assign(self, {
    adguard: {
        ...self.adguard,
        logger
    }
});



/***/ }),

/***/ "./Extension/src/common/messages/constants.ts":
/*!****************************************************!*\
  !*** ./Extension/src/common/messages/constants.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   APP_MESSAGE_HANDLER_NAME: () => (/* binding */ APP_MESSAGE_HANDLER_NAME),
/* harmony export */   MessageType: () => (/* binding */ MessageType)
/* harmony export */ });
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Important: do not use z.inferOf, because it brings a lot of side effects with
 * many dependencies to the bundle.
 *
 * Also please try, if possible, to not import here external modules
 * other that types.
 */ const APP_MESSAGE_HANDLER_NAME = 'app';
/**
 * Message types used for message passing between extension contexts
 * (popup, filtering log, content scripts, background)
 */ var MessageType = /*#__PURE__*/ function(MessageType) {
    MessageType["CreateEventListener"] = "createEventListener";
    MessageType["RemoveListener"] = "removeListener";
    MessageType["OpenExtensionStore"] = "openExtensionStore";
    MessageType["AddAndEnableFilter"] = "addAndEnableFilter";
    MessageType["ApplySettingsJson"] = "applySettingsJson";
    MessageType["OpenFilteringLog"] = "openFilteringLog";
    MessageType["OpenFullscreenUserRules"] = "openFullscreenUserRules";
    MessageType["UpdateFullscreenUserRulesTheme"] = "updateFullscreenUserRulesTheme";
    MessageType["ResetBlockedAdsCount"] = "resetBlockedAdsCount";
    MessageType["ResetSettings"] = "resetSettings";
    MessageType["GetUserRules"] = "getUserRules";
    MessageType["SaveUserRules"] = "saveUserRules";
    MessageType["GetAllowlistDomains"] = "getAllowlistDomains";
    MessageType["SaveAllowlistDomains"] = "saveAllowlistDomains";
    MessageType["CheckFiltersUpdate"] = "checkFiltersUpdate";
    MessageType["DisableFiltersGroup"] = "disableFiltersGroup";
    MessageType["DisableFilter"] = "disableFilter";
    MessageType["LoadCustomFilterInfo"] = "loadCustomFilterInfo";
    MessageType["SubscribeToCustomFilter"] = "subscribeToCustomFilter";
    MessageType["RemoveAntiBannerFilter"] = "removeAntiBannerFilter";
    MessageType["GetIsEngineStarted"] = "getIsEngineStarted";
    MessageType["GetTabInfoForPopup"] = "getTabInfoForPopup";
    MessageType["ChangeApplicationFilteringPaused"] = "changeApplicationFilteringPaused";
    MessageType["OpenRulesLimitsTab"] = "openRulesLimitsTab";
    MessageType["OpenSettingsTab"] = "openSettingsTab";
    MessageType["OpenAssistant"] = "openAssistant";
    MessageType["OpenAbuseTab"] = "openAbuseTab";
    MessageType["OpenSiteReportTab"] = "openSiteReportTab";
    MessageType["OpenComparePage"] = "openComparePage";
    MessageType["ResetUserRulesForPage"] = "resetUserRulesForPage";
    MessageType["RemoveAllowlistDomain"] = "removeAllowlistDomain";
    MessageType["AddAllowlistDomain"] = "addAllowlistDomain";
    MessageType["OnOpenFilteringLogPage"] = "onOpenFilteringLogPage";
    MessageType["GetFilteringLogData"] = "getFilteringLogData";
    MessageType["InitializeFrameScript"] = "initializeFrameScript";
    MessageType["OnCloseFilteringLogPage"] = "onCloseFilteringLogPage";
    MessageType["GetFilteringInfoByTabId"] = "getFilteringInfoByTabId";
    MessageType["SynchronizeOpenTabs"] = "synchronizeOpenTabs";
    MessageType["ClearEventsByTabId"] = "clearEventsByTabId";
    MessageType["RefreshPage"] = "refreshPage";
    MessageType["AddUserRule"] = "addUserRule";
    MessageType["RemoveUserRule"] = "removeUserRule";
    MessageType["EnableFiltersGroup"] = "enableFiltersGroup";
    MessageType["NotifyListeners"] = "notifyListeners";
    MessageType["AddLongLivedConnection"] = "addLongLivedConnection";
    MessageType["GetOptionsData"] = "getOptionsData";
    MessageType["ChangeUserSettings"] = "changeUserSetting";
    MessageType["CheckRequestFilterReady"] = "checkRequestFilterReady";
    MessageType["OpenThankyouPage"] = "openThankYouPage";
    MessageType["OpenSafebrowsingTrusted"] = "openSafebrowsingTrusted";
    MessageType["GetSelectorsAndScripts"] = "getSelectorsAndScripts";
    MessageType["CheckPageScriptWrapperRequest"] = "checkPageScriptWrapperRequest";
    MessageType["ProcessShouldCollapse"] = "processShouldCollapse";
    MessageType["ProcessShouldCollapseMany"] = "processShouldCollapseMany";
    MessageType["AddFilteringSubscription"] = "addFilterSubscription";
    MessageType["SetNotificationViewed"] = "setNotificationViewed";
    MessageType["SaveCssHitsStats"] = "saveCssHitStats";
    MessageType["GetCookieRules"] = "getCookieRules";
    MessageType["SaveCookieLogEvent"] = "saveCookieRuleEvent";
    MessageType["LoadSettingsJson"] = "loadSettingsJson";
    MessageType["AddUrlToTrusted"] = "addUrlToTrusted";
    MessageType["SetPreserveLogState"] = "setPreserveLogState";
    MessageType["GetUserRulesEditorData"] = "getUserRulesEditorData";
    MessageType["GetEditorStorageContent"] = "getEditorStorageContent";
    MessageType["SetEditorStorageContent"] = "setEditorStorageContent";
    MessageType["SetFilteringLogWindowState"] = "setFilteringLogWindowState";
    MessageType["AppInitialized"] = "appInitialized";
    MessageType["UpdateTotalBlocked"] = "updateTotalBlocked";
    MessageType["ScriptletCloseWindow"] = "scriptletCloseWindow";
    MessageType["ShowRuleLimitsAlert"] = "showRuleLimitsAlert";
    MessageType["ShowAlertPopup"] = "showAlertPopup";
    MessageType["ShowVersionUpdatedPopup"] = "showVersionUpdatedPopup";
    MessageType["UpdateListeners"] = "updateListeners";
    MessageType["SetConsentedFilters"] = "setConsentedFilters";
    MessageType["GetIsConsentedFilter"] = "getIsConsentedFilter";
    MessageType["GetRulesLimitsCountersMv3"] = "getRulesLimitsCountersMv3";
    MessageType["CanEnableStaticFilterMv3"] = "canEnableStaticFilterMv3";
    MessageType["CanEnableStaticGroupMv3"] = "canEnableStaticGroupMv3";
    MessageType["ClearRulesLimitsWarningMv3"] = "clearRulesLimitsWarningMv3";
    MessageType["RestoreFiltersMv3"] = "restoreFiltersMv3";
    MessageType["CurrentLimitsMv3"] = "currentLimitsMv3";
    return MessageType;
}({});


/***/ }),

/***/ "./Extension/src/common/messages/index.ts":
/*!************************************************!*\
  !*** ./Extension/src/common/messages/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   APP_MESSAGE_HANDLER_NAME: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.APP_MESSAGE_HANDLER_NAME),
/* harmony export */   MessageType: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.MessageType),
/* harmony export */   messageHasTypeAndDataFields: () => (/* reexport safe */ _message_handler__WEBPACK_IMPORTED_MODULE_2__.messageHasTypeAndDataFields),
/* harmony export */   messageHasTypeField: () => (/* reexport safe */ _message_handler__WEBPACK_IMPORTED_MODULE_2__.messageHasTypeField)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./Extension/src/common/messages/constants.ts");
/* harmony import */ var _send_message__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./send-message */ "./Extension/src/common/messages/send-message.ts");
/* harmony import */ var _message_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./message-handler */ "./Extension/src/common/messages/message-handler.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 




/***/ }),

/***/ "./Extension/src/common/messages/message-handler.ts":
/*!**********************************************************!*\
  !*** ./Extension/src/common/messages/message-handler.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   messageHasTypeAndDataFields: () => (/* binding */ messageHasTypeAndDataFields),
/* harmony export */   messageHasTypeField: () => (/* binding */ messageHasTypeField)
/* harmony export */ });
/* unused harmony export MessageHandler */
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.error.cause.js");
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./Extension/src/common/messages/constants.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}



/**
 * Type guard for messages that have a 'type' field with possible {@link MessageType}.
 *
 * @note Added to no bring here huge zod library.
 *
 * @param message Unknown message.
 *
 * @returns True if message has 'type' field with possible {@link MessageType}.
 */ const messageHasTypeField = (message)=>{
    return typeof message === 'object' && message !== null && 'type' in message;
};
/**
 * Type guard for messages that have a 'type' field and 'data' field and looks like {@link Message}.
 *
 * @note Added to no bring here huge zod library.
 *
 * @param message Unknown message.
 *
 * @returns True if message has 'type' and 'data' fields and looks like {@link Message}.
 */ const messageHasTypeAndDataFields = (message)=>{
    return messageHasTypeField(message) && 'data' in message;
};
/**
 * API for handling Messages via {@link browser.runtime.onMessage}
 */ class MessageHandler {
    init() {
        webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.onMessage.addListener(this.handleMessage);
    }
    /**
     * Add message listener.
     * Listeners limited to 1 per message type to prevent race
     * condition while response processing.
     *
     * TODO: implement listeners priority execution strategy
     *
     * @param type - {@link ValidMessageTypes}
     * @param listener - {@link MessageListener}
     *
     * @throws error, if message listener already added
     */ addListener(type, listener) {
        if (this.listeners.has(type)) {
            throw new Error(`Message handler: ${type} listener has already been registered`);
        }
        // Cast through unknown to help TS understand that the listener is of
        // the correct type. It will check types at compile time.
        this.listeners.set(type, listener);
    }
    /**
     * Removes message listener.
     *
     * @param type - {@link ValidMessageTypes}
     */ removeListener(type) {
        this.listeners.delete(type);
    }
    /**
     * Removes all listeners
     */ removeListeners() {
        this.listeners.clear();
    }
    /**
     * Check if the message is of type {@link Message}.
     *
     * @param message Message of basic type {@link Message} or {@link EngineMessage}.
     *
     * @returns True if the message is of type {@link Message}.
     */ static isValidMessageType(message) {
        return message.handlerName === _constants__WEBPACK_IMPORTED_MODULE_2__.APP_MESSAGE_HANDLER_NAME && 'type' in message;
    }
    constructor(){
        _define_property(this, "listeners", new Map());
        this.handleMessage = this.handleMessage.bind(this);
    }
}


/***/ }),

/***/ "./Extension/src/common/messages/send-message.ts":
/*!*******************************************************!*\
  !*** ./Extension/src/common/messages/send-message.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports sendMessage, sendTabMessage */
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./Extension/src/common/messages/constants.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

/**
 * TODO: Consider moving this file to the background folder, because all messages
 * from the UI should be send via methods of Messenger class instead of using
 * directly sendMessage to proper types checking.
 *
 * {@link sendMessage} sends app message via {@link browser.runtime.sendMessage} and
 * gets response from another extension page message handler
 *
 * @param message - partial {@link Message} record without {@link Message.handlerName} field
 *
 * @returns message handler response
 */ async function sendMessage(message) {
    try {
        return await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime.sendMessage({
            handlerName: _constants__WEBPACK_IMPORTED_MODULE_1__.APP_MESSAGE_HANDLER_NAME,
            ...message
        });
    } catch (e) {
    // do nothing
    }
}
/**
 * {@link sendTabMessage} sends message to specified tab via {@link browser.tabs.sendMessage} and
 * gets response from it
 *
 * @param tabId - tab id
 * @param message - partial {@link Message} record without {@link Message.handlerName} field
 *
 * @returns tab message handler response
 */ async function sendTabMessage(tabId, message) {
    return webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.sendMessage(tabId, {
        handlerName: _constants__WEBPACK_IMPORTED_MODULE_1__.APP_MESSAGE_HANDLER_NAME,
        ...message
    });
}


/***/ }),

/***/ "./Extension/src/common/user-agent.ts":
/*!********************************************!*\
  !*** ./Extension/src/common/user-agent.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserAgent: () => (/* binding */ UserAgent)
/* harmony export */ });
/* harmony import */ var ua_parser_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ua-parser-js */ "./node_modules/.pnpm/ua-parser-js@1.0.36/node_modules/ua-parser-js/src/ua-parser.js");
/* harmony import */ var ua_parser_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ua_parser_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../constants */ "./constants.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}


/**
 * Helper class for user agent data.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/User-Agent_Client_Hints_API#browser_compatibility
 */ class UserAgent {
    /**
     * Returns current browser name.
     *
     * @returns user agent browser name.
     */ static getBrowserName() {
        return UserAgent.isFirefoxMobile ? 'Firefox Mobile' : UserAgent.parser.getBrowser().name;
    }
    /**
     * Returns current OS name.
     *
     * @returns OS name as string if possible to detect, undefined otherwise.
     */ static getSystemName() {
        return UserAgent.parser.getOS().name;
    }
    /**
     * Returns current OS version.
     *
     * @returns OS version as string if possible to detect, undefined otherwise.
     */ static getSystemVersion() {
        return UserAgent.parser.getOS().version;
    }
    /**
     * Returns current platform version.
     * Uses NavigatorUAData.getHighEntropyValues() to get platform version.
     *
     * @returns Actual platform version as string if possible to detect, undefined otherwise.
     */ static async getPlatformVersion() {
        let platformVersion;
        try {
            // @ts-ignore
            const ua = await navigator.userAgentData.getHighEntropyValues([
                UserAgent.PLATFORM_VERSION
            ]);
            platformVersion = ua[UserAgent.PLATFORM_VERSION];
        } catch (e) {
        // do nothing
        }
        return platformVersion;
    }
    /**
     * Returns actual Windows version if it is parsed from user agent as Windows 10.
     *
     * @see {@link https://learn.microsoft.com/en-us/microsoft-edge/web-platform/how-to-detect-win11#sample-code-for-detecting-windows-11}.
     *
     * @returns Actual Windows version.
     */ static async getActualWindowsVersion(version) {
        let actualVersion = version;
        const platformVersion = await UserAgent.getPlatformVersion();
        if (typeof platformVersion !== 'undefined') {
            const rawMajorPlatformVersion = platformVersion.split('.')[0];
            const majorPlatformVersion = rawMajorPlatformVersion && parseInt(rawMajorPlatformVersion, 10);
            if (!majorPlatformVersion || Number.isNaN(majorPlatformVersion)) {
                return actualVersion;
            }
            if (majorPlatformVersion >= UserAgent.MIN_WINDOWS_11_PLATFORM_VERSION) {
                actualVersion = UserAgent.WINDOWS_11_OS_VERSION;
            }
        }
        return actualVersion;
    }
    /**
     * Returns actual MacOS version if it is possible to detect, otherwise returns passed `version`.
     *
     * @param version MacOS version parsed from user agent.
     *
     * @returns Actual MacOS version.
     */ static async getActualMacosVersion(version) {
        let actualVersion = version;
        const platformVersion = await UserAgent.getPlatformVersion();
        if (typeof platformVersion !== 'undefined') {
            actualVersion = platformVersion;
        }
        return actualVersion;
    }
    /**
     * Returns current system info — OS name and version.
     *
     * @returns System info as string if possible to detect, undefined otherwise.
     */ static async getSystemInfo() {
        let systemInfo = '';
        const osName = UserAgent.getSystemName();
        let osVersion = UserAgent.getSystemVersion();
        if (typeof osName !== 'undefined') {
            systemInfo += osName;
        }
        if (typeof osVersion !== 'undefined') {
            // windows 11 is parsed as windows 10 from user agent
            if (UserAgent.isWindows && osVersion === UserAgent.WINDOWS_10_OS_VERSION) {
                osVersion = await UserAgent.getActualWindowsVersion(osVersion);
            } else if (UserAgent.isMacOs) {
                // mac os version can be parsed from user agent as 10.15.7
                // so it also might be more specific version like 13.5.2
                osVersion = await UserAgent.getActualMacosVersion(osVersion);
            }
            systemInfo += ` ${osVersion}`;
        }
        if (systemInfo.length === 0) {
            return undefined;
        }
        return systemInfo;
    }
    /**
     * Check if the current browser is as given.
     *
     * @param browserName Browser Name.
     *
     * @returns true, if current browser has specified name.
     */ static isTargetBrowser(browserName) {
        return UserAgent.parser.getBrowser().name === browserName;
    }
    /**
     * Check if current platform is as given.
     *
     * @param platformName Platform name.
     *
     * @returns true, if current browser has specified name.
     */ static isTargetPlatform(platformName) {
        return UserAgent.getSystemName() === platformName;
    }
    /**
     * Check if current engine is as given.
     *
     * @param engineName Engine name.
     *
     * @returns true, if current engine has specified name.
     */ static isTargetEngine(engineName) {
        return UserAgent.parser.getEngine().name === engineName;
    }
    static isTargetDeviceType(deviceType) {
        return UserAgent.parser.getDevice().type === deviceType;
    }
    /**
     * Returns a major browser version.
     *
     * @returns browser version number or undefined.
     */ static getVersion() {
        var _browser_version;
        const browser = this.parser.getBrowser();
        const versionNumber = Number((_browser_version = browser.version) === null || _browser_version === void 0 ? void 0 : _browser_version.split('.')[0]);
        return Number.isNaN(versionNumber) ? undefined : versionNumber;
    }
}
_define_property(UserAgent, "WINDOWS_10_OS_VERSION", '10');
_define_property(UserAgent, "WINDOWS_11_OS_VERSION", '11');
_define_property(UserAgent, "PLATFORM_VERSION", 'platformVersion');
_define_property(UserAgent, "MIN_WINDOWS_11_PLATFORM_VERSION", 13);
_define_property(UserAgent, "parser", new (ua_parser_js__WEBPACK_IMPORTED_MODULE_0___default())(navigator.userAgent));
_define_property(UserAgent, "version", UserAgent.getVersion());
_define_property(UserAgent, "isChrome", UserAgent.isTargetBrowser('Chrome'));
_define_property(UserAgent, "isFirefox", UserAgent.isTargetBrowser('Firefox'));
_define_property(UserAgent, "isOpera", UserAgent.isTargetBrowser('Opera'));
_define_property(UserAgent, "isYandex", UserAgent.isTargetBrowser('Yandex'));
_define_property(UserAgent, "isEdge", UserAgent.isTargetBrowser('Edge'));
_define_property(UserAgent, "isEdgeChromium", UserAgent.isEdge && !!(UserAgent.version && UserAgent.version >= 79));
_define_property(UserAgent, "isMacOs", UserAgent.isTargetPlatform('Mac OS'));
_define_property(UserAgent, "isWindows", UserAgent.isTargetPlatform('Windows'));
_define_property(UserAgent, "isAndroid", UserAgent.isTargetPlatform('Android'));
_define_property(UserAgent, "isChromium", UserAgent.isTargetEngine('Blink'));
_define_property(UserAgent, "isMobileDevice", UserAgent.isTargetDeviceType('mobile'));
_define_property(UserAgent, "isFirefoxMobile", UserAgent.isFirefox && UserAgent.isMobileDevice);
_define_property(UserAgent, "isSupportedBrowser", UserAgent.isChrome && Number(UserAgent.version) >= _constants__WEBPACK_IMPORTED_MODULE_1__.MIN_SUPPORTED_VERSION.CHROMIUM_MV2 || UserAgent.isEdgeChromium && Number(UserAgent.version) >= _constants__WEBPACK_IMPORTED_MODULE_1__.MIN_SUPPORTED_VERSION.EDGE_CHROMIUM || UserAgent.isFirefox && Number(UserAgent.version) >= _constants__WEBPACK_IMPORTED_MODULE_1__.MIN_SUPPORTED_VERSION.FIREFOX || UserAgent.isFirefoxMobile && Number(UserAgent.version) >= _constants__WEBPACK_IMPORTED_MODULE_1__.MIN_SUPPORTED_VERSION.FIREFOX_MOBILE || UserAgent.isOpera && Number(UserAgent.version) >= _constants__WEBPACK_IMPORTED_MODULE_1__.MIN_SUPPORTED_VERSION.OPERA);
_define_property(UserAgent, "browserName", UserAgent.getBrowserName());


/***/ }),

/***/ "./Extension/src/pages/services/messenger.ts":
/*!***************************************************!*\
  !*** ./Extension/src/pages/services/messenger.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   messenger: () => (/* binding */ messenger)
/* harmony export */ });
/* unused harmony exports Page, Messenger */
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! nanoid */ "./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js");
/* harmony import */ var _common_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/logger */ "./Extension/src/common/logger.ts");
/* harmony import */ var _common_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/messages */ "./Extension/src/common/messages/index.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}





var Page = /*#__PURE__*/ function(Page) {
    Page["FullscreenUserRules"] = "fullscreen-user-rules";
    Page["FilteringLog"] = "filtering-log";
    return Page;
}({});
/**
 * Messenger class, used to communicate with the background page from the UI.
 * Actually, it's a wrapper around the browser.runtime.sendMessage method.
 */ class Messenger {
    /**
     * Sends a message to the background page.
     *
     * All messages described in the {@link MessageType} enum.
     * All answers described in the {@link MessageMap} type.
     *
     * @param type Message type.
     * @param data Message data. Optional because not all messages have data.
     *
     * @returns Promise that resolves with the response from the background page.
     * Type of the response depends on the message type. Go to {@link MessageMap}
     * to see all possible message types and their responses.
     */ // eslint-disable-next-line class-methods-use-this
    async sendMessage(type, data) {
        const response = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.sendMessage({
            handlerName: _common_messages__WEBPACK_IMPORTED_MODULE_3__.APP_MESSAGE_HANDLER_NAME,
            type,
            data
        });
        return response;
    }
    /**
     * Sends a message from background page to update listeners on the UI.
     *
     * @returns Promise that resolves when the message is sent.
     */ async updateListeners() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.UpdateListeners);
    }
    /**
     * Sends a message to the background page to get the settings data for
     * the options page with some additional info.
     *
     * @returns Promise that resolves with the settings data for
     * the options page with some additional info.
     */ async getOptionsData() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetOptionsData);
    }
    /**
     * Sends a message to the background page to change the user setting.
     *
     * @param settingId Setting identifier.
     * @param value Setting value.
     *
     * @returns Promise that resolves after the message is sent.
     */ async changeUserSetting(settingId, value) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ChangeUserSettings, {
            key: settingId,
            value
        });
    }
    /**
     * Sends a message to the background page to open the extension store.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openExtensionStore() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenExtensionStore);
    }
    /**
     * Sends a message to the background page to open the compare page.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openComparePage() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenComparePage);
    }
    /**
     * Sends a message to the background page to enable a filter by filter id.
     *
     * @param filterId Filter identifier.
     *
     * @returns Promise that resolves after the message is sent.
     */ async enableFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddAndEnableFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to disable a filter by filter id.
     *
     * @param filterId Filter identifier.
     *
     * @returns Promise that resolves after the message is sent.
     */ async disableFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.DisableFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to apply settings from a JSON object.
     *
     * @param json JSON object representing the settings to apply.
     *
     * @returns Promise that resolves after the message is sent.
     */ async applySettingsJson(json) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ApplySettingsJson, {
            json
        });
    }
    /**
     * Sends a message to the background page to open the filtering log.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openFilteringLog() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenFilteringLog);
    }
    /**
     * Sends a message to the background page to reset the blocked ads statistics.
     *
     * @returns Promise that resolves after the message is sent.
     */ async resetStatistics() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ResetBlockedAdsCount);
    }
    /**
     * Sends a message to the background page to set the filtering log window state.
     *
     * @param windowState State of the filtering log window.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setFilteringLogWindowState(windowState) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetFilteringLogWindowState, {
            windowState
        });
    }
    /**
     * Sends a message to the background page to reset the settings.
     *
     * @returns Promise that resolves after the message is sent.
     */ async resetSettings() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ResetSettings);
    }
    /**
     * Sends a message to the background page to get the user rules.
     *
     * @returns Promise that resolves with the user rules.
     */ async getUserRules() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetUserRules);
    }
    /**
     * Sends a message to the background page to save user rules.
     *
     * @param value User rules value to save.
     *
     * @returns Promise that resolves after the message is sent.
     */ async saveUserRules(value) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SaveUserRules, {
            value
        });
    }
    /**
     * Sends a message to the background page to open user rules editor in fullscreen.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openFullscreenUserRules() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenFullscreenUserRules);
    }
    /**
     * Sends a message to the background page to get the allowlist domains.
     *
     * @returns Promise that resolves with the list of allowlist domains.
     */ async getAllowlist() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetAllowlistDomains);
    }
    /**
     * Sends a message to the background page to save the allowlist domains.
     *
     * @param value Allowlist domains value to save.
     *
     * @returns Promise that resolves after the message is sent.
     */ async saveAllowlist(value) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SaveAllowlistDomains, {
            value
        });
    }
    /**
     * Sends a message to the background page to mark a notification as viewed.
     *
     * @param withDelay Whether the notification should be marked as viewed after a delay.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setNotificationViewed(withDelay) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetNotificationViewed, {
            withDelay
        });
    }
    /**
     * Sends a message to the background page to update filters.
     *
     * @returns Promise that resolves with the list of filters.
     */ async updateFilters() {
        if (true) {
            _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.debug('Filters update is not supported in MV3');
            return [];
        }
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CheckFiltersUpdate);
    }
    /**
     * Sends a message to the background page to update the status of a filter group.
     *
     * @param id Group identifier.
     * @param enabled Whether the group should be enabled or disabled.
     *
     * @returns Promise that resolves after the message is sent.
     */ async updateGroupStatus(id, enabled) {
        const type = enabled ? _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.EnableFiltersGroup : _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.DisableFiltersGroup;
        const groupId = Number.parseInt(id, 10);
        return this.sendMessage(type, {
            groupId
        });
    }
    /**
     * Sends a message to the background page to set consented filters.
     *
     * @param filterIds List of filter identifiers.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setConsentedFilters(filterIds) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetConsentedFilters, {
            filterIds
        });
    }
    /**
     * Sends a message to the background page to check if a filter is consented.
     *
     * @param filterId Filter identifier.
     *
     * @returns Promise that resolves with the result of the check.
     */ async getIsConsentedFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetIsConsentedFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to check a custom filter URL.
     *
     * @param url Custom filter URL.
     *
     * @returns Promise that resolves with the result of the check.
     */ async checkCustomUrl(url) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.LoadCustomFilterInfo, {
            url
        });
    }
    /**
     * Sends a message to the background page to add a custom filter.
     *
     * @param {CustomFilterSubscriptionData} filter Custom filter data.
     *
     * @returns {Promise<CustomFilterMetadata>} Custom filter metadata.
     */ async addCustomFilter(filter) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SubscribeToCustomFilter, {
            filter
        });
    }
    /**
     * Sends a message to the background page to remove a custom filter.
     *
     * @param filterId Custom filter ID.
     *
     * @returns Promise that resolves after the filter is removed.
     */ async removeCustomFilter(filterId) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveAntiBannerFilter, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to check if the engine is started.
     *
     * @returns Promise that resolves to a boolean value:
     * true if the engine is started, false otherwise.
     */ async getIsEngineStarted() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetIsEngineStarted);
    }
    /**
     * Sends a message to the background to get the tab info for the popup.
     *
     * @param tabId Tab ID.
     *
     * @returns Promise that resolves with the tab info or undefined.
     */ async getTabInfoForPopup(tabId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetTabInfoForPopup, {
            tabId
        });
    }
    /**
     * Sends a message to the background page to change application filtering state.
     *
     * @param state Application filtering state.
     *
     * @returns Promise that resolves after the state is changed.
     */ async changeApplicationFilteringPaused(state) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ChangeApplicationFilteringPaused, {
            state
        });
    }
    /**
     * Sends a message to the background page to update the theme of the fullscreen user rules.
     *
     * @param theme Theme to set.
     *
     * @returns Promise that resolves after the theme is updated.
     */ async updateFullscreenUserRulesTheme(theme) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.UpdateFullscreenUserRulesTheme, {
            theme
        });
    }
    /**
     * Sends a message to the background page to open the rules limits tab.
     *
     * @returns Promise that resolves after the tab is opened.
     */ async openRulesLimitsTab() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenRulesLimitsTab);
    }
    /**
     * Sends a message to the background page to open the settings tab.
     *
     * @returns Promise that resolves after the tab is opened.
     */ async openSettingsTab() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenSettingsTab);
    }
    /**
     * Sends a message to the background page to open the assistant.
     *
     * @returns Promise that resolves after the assistant is opened.
     */ async openAssistant() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenAssistant);
    }
    /**
     * Sends a message to the background page to open the abuse reporting tab for a site.
     *
     * @param url The URL of the site to report abuse for.
     * @param from The source of the request.
     *
     * @returns Promise that resolves after the tab is opened.
     */ async openAbuseSite(url, from) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenAbuseTab, {
            url,
            from
        });
    }
    /**
     * Sends a message to the background page to check site security.
     *
     * @param url The URL of the site to check.
     * @param from The source of the request.
     *
     * @returns Promise that resolves with the site security info.
     */ async checkSiteSecurity(url, from) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenSiteReportTab, {
            url,
            from
        });
    }
    /**
     * Sends a message to the background page to reset user rules for a specific page.
     *
     * @param url The URL of the page.
     *
     * @returns Promise that resolves after the user rules are reset.
     */ async resetUserRulesForPage(url) {
        const [currentTab] = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().tabs.query({
            active: true,
            currentWindow: true
        });
        if (!(currentTab === null || currentTab === void 0 ? void 0 : currentTab.id)) {
            _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.debug('[resetUserRulesForPage]: cannot get current tab id');
            return;
        }
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ResetUserRulesForPage, {
            url,
            tabId: currentTab === null || currentTab === void 0 ? void 0 : currentTab.id
        });
    }
    /**
     * Sends a message to the background page to remove an allowlist domain.
     *
     * @param tabId The ID of the tab.
     * @param tabRefresh Whether the tab should be refreshed.
     *
     * @returns Promise that resolves after the domain is removed.
     */ async removeAllowlistDomain(tabId, tabRefresh) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveAllowlistDomain, {
            tabId,
            tabRefresh
        });
    }
    /**
     * Sends a message to the background page to add an allowlist domain.
     *
     * @param tabId The ID of the tab.
     *
     * @returns Promise that resolves after the domain is added.
     */ async addAllowlistDomain(tabId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddAllowlistDomain, {
            tabId
        });
    }
    /**
     * Works only in MV2, since MV3 doesn't support filtering log yet.
     *
     * @returns Promise that resolves after the filtering log page is opened.
     */ async onOpenFilteringLogPage() {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OnOpenFilteringLogPage);
    }
    /**
     * Sends a message to the background page to get filtering log data.
     *
     * @returns Promise that resolves with filtering log data.
     */ async getFilteringLogData() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetFilteringLogData);
    }
    /**
     * Sends a message to the background page to close the filtering log page.
     *
     * @returns Promise that resolves after the page is closed.
     */ async onCloseFilteringLogPage() {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OnCloseFilteringLogPage);
    }
    /**
     * Sends a message to the background page to get filtering info by tab ID.
     *
     * @param tabId The ID of the tab.
     *
     * @returns Promise that resolves with filtering info about the tab.
     */ async getFilteringInfoByTabId(tabId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetFilteringInfoByTabId, {
            tabId
        });
    }
    /**
     * Sends a message to the background page to synchronize the list of open tabs.
     *
     * @returns Promise that resolves with an array of filtering info about open tabs.
     */ async synchronizeOpenTabs() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SynchronizeOpenTabs);
    }
    /**
     * Sends a message to the background page to clear events by tab ID.
     *
     * @param tabId The ID of the tab.
     * @param ignorePreserveLog Optional flag to ignore the preserve log state.
     *
     * @returns Promise that resolves after the events are cleared.
     */ async clearEventsByTabId(tabId, ignorePreserveLog) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ClearEventsByTabId, {
            tabId,
            ignorePreserveLog
        });
    }
    /**
     * Sends a message to the background page to refresh the current page by tab ID.
     *
     * @param tabId The ID of the tab.
     *
     * @returns Promise that resolves after the page is refreshed.
     */ async refreshPage(tabId) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RefreshPage, {
            tabId
        });
    }
    /**
     * Sends a message to the background page to add a user rule.
     *
     * @param ruleText User rule text to be added.
     *
     * @returns Promise that resolves after the message is sent.
     */ async addUserRule(ruleText) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddUserRule, {
            ruleText
        });
    }
    /**
     * Sends a message to the background page to remove a user rule.
     *
     * @param ruleText User rule text to be removed.
     *
     * @returns Promise that resolves after the message is sent.
     */ async removeUserRule(ruleText) {
        await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveUserRule, {
            ruleText
        });
    }
    /**
     * Sends a message to the background page to set the preserve log state.
     *
     * @param state State indicating whether to preserve the log.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setPreserveLogState(state) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetPreserveLogState, {
            state
        });
    }
    /**
     * Sends a message to the background page to get the editor storage content.
     *
     * @returns Promise that resolves with the editor storage content.
     */ async getEditorStorageContent() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetEditorStorageContent);
    }
    /**
     * Sends a message to the background page to set the editor storage content.
     *
     * @param content Content to be stored in the editor.
     *
     * @returns Promise that resolves after the message is sent.
     */ async setEditorStorageContent(content) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.SetEditorStorageContent, {
            content
        });
    }
    /**
     * Sends a message to the background page to get the rules limits counters for MV3.
     *
     * @returns Promise that resolves with the rules limits counters for MV3.
     */ async getRulesLimitsCounters() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetRulesLimitsCountersMv3);
    }
    /**
     * Sends a message to the background page to check if it is possible to enable a static filter.
     *
     * @param filterId Filter ID to check.
     *
     * @returns Promise that resolves with the result of the static filter check.
     *
     * @throws Error If the filter is not static.
     */ async canEnableStaticFilter(filterId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CanEnableStaticFilterMv3, {
            filterId
        });
    }
    /**
     * Sends a message to the background page to check if all dynamic rules for a user rules' group can be enabled.
     *
     * @param groupId Group identifier to check.
     *
     * @returns Promise that resolves with the result of the static group check.
     */ async canEnableStaticGroup(groupId) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CanEnableStaticGroupMv3, {
            groupId
        });
    }
    /**
     * Sends a message to the background page to get the current static filters limits.
     *
     * @returns Promise that resolves with the current static filters limits.
     */ async getCurrentLimits() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CurrentLimitsMv3);
    }
    /**
     * Sends a message to the background page to check if the request filter is ready.
     *
     * @returns Promise that resolves to a boolean indicating if the request filter is ready.
     */ async checkRequestFilterReady() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CheckRequestFilterReady);
    }
    /**
     * Sends a message to the background page to add a URL to the trusted list.
     *
     * @param url URL to be added to the trusted list.
     *
     * @returns Promise that resolves after the message is sent.
     */ async addUrlToTrusted(url) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddUrlToTrusted, {
            url
        });
    }
    /**
     * Sends a message to the background page to get user rules editor data.
     *
     * @returns Promise that resolves with the user rules editor data.
     */ async getUserRulesEditorData() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetUserRulesEditorData);
    }
    /**
     * Sends a message to the background page to restore filters in MV3.
     *
     * @returns Promise that resolves after the message is sent.
     */ async restoreFiltersMv3() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RestoreFiltersMv3);
    }
    /**
     * Sends a message to the background page to clear the rules limits warning in MV3.
     *
     * @returns Promise that resolves after the message is sent.
     */ async clearRulesLimitsWarningMv3() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.ClearRulesLimitsWarningMv3);
    }
    /**
     * Sends a message to the background page to get the allowlist domains.
     *
     * @returns Promise that resolves with the allowlist domains.
     */ async getAllowlistDomains() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.GetAllowlistDomains);
    }
    /**
     * Sends a message to the background page to load the settings JSON.
     *
     * @returns Promise that resolves with the loaded settings JSON.
     */ async loadSettingsJson() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.LoadSettingsJson);
    }
    /**
     * Sends a message to the background page to open the thank you page.
     *
     * @returns Promise that resolves after the message is sent.
     */ async openThankyouPage() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenThankyouPage);
    }
    /**
     * Sends a message to the background page to initialize the frame script.
     *
     * @returns Promise that resolves with the initialization data for the frame script.
     */ async initializeFrameScript() {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.InitializeFrameScript);
    }
    /**
     * Sends a message to the background page to mark url as trusted and ignore
     * safebrowsing checks for it.
     *
     * @returns Promise that resolves with the initialization data for the frame script.
     */ async openSafebrowsingTrusted(url) {
        return this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.OpenSafebrowsingTrusted, {
            url
        });
    }
    /**
     * Creates an instance of the Messenger class.
     */ constructor(){
        _define_property(this, "onMessage", (webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime).onMessage);
        /**
     * Method subscribes to notifier module events.
     *
     * @param events List of events to which subscribe.
     * @param callback Callback called when event fires.
     * @param onUnloadCallback Callback used to remove listener on unload.
     *
     * @returns Function to remove listener on unload.
     */ _define_property(this, "createEventListener", async (events, callback, onUnloadCallback)=>{
            let listenerId;
            const response = await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CreateEventListener, {
                events
            });
            listenerId = response.listenerId;
            const onUpdateListeners = async ()=>{
                const updatedResponse = await this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.CreateEventListener, {
                    events
                });
                listenerId = updatedResponse.listenerId;
            };
            webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.onMessage.addListener((message)=>{
                if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeField)(message)) {
                    _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message in Messenger.createEventListener has no type field: ', message);
                    return undefined;
                }
                if (message.type === _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.NotifyListeners) {
                    if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeAndDataFields)(message)) {
                        _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message with type MessageType.NotifyListeners has no data: ', message);
                        return undefined;
                    }
                    const castedMessage = message;
                    const [type, ...data] = castedMessage.data;
                    if (events.includes(type)) {
                        callback({
                            type,
                            data
                        });
                    }
                }
                if (message.type === _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.UpdateListeners) {
                    onUpdateListeners();
                }
            });
            const onUnload = ()=>{
                if (!listenerId) {
                    return;
                }
                this.sendMessage(_common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.RemoveListener, {
                    listenerId
                });
                listenerId = null;
                if (typeof onUnloadCallback === 'function') {
                    onUnloadCallback();
                }
            };
            window.addEventListener('beforeunload', onUnload);
            window.addEventListener('unload', onUnload);
            return onUnload;
        });
        this.resetUserRulesForPage = this.resetUserRulesForPage.bind(this);
        this.updateFilters = this.updateFilters.bind(this);
        this.removeAllowlistDomain = this.removeAllowlistDomain.bind(this);
        this.addAllowlistDomain = this.addAllowlistDomain.bind(this);
    }
}
/**
     * Creates long-lived connections between popup and background page.
     *
     * @param page Page name.
     * @param events List of events to which subscribe.
     * @param callback Callback called when event fires.
     *
     * @returns Function to remove listener on unload.
     */ _define_property(Messenger, "createLongLivedConnection", (page, events, callback)=>{
    let port;
    let forceDisconnected = false;
    const connect = ()=>{
        port = webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime.connect({
            name: `${page}_${(0,nanoid__WEBPACK_IMPORTED_MODULE_4__.nanoid)()}`
        });
        port.postMessage({
            type: _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.AddLongLivedConnection,
            data: {
                events
            }
        });
        port.onMessage.addListener((message)=>{
            if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeField)(message)) {
                _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message in Messenger.createLongLivedConnection has no type field: ', message);
                return;
            }
            if (message.type === _common_messages__WEBPACK_IMPORTED_MODULE_3__.MessageType.NotifyListeners) {
                if (!(0,_common_messages__WEBPACK_IMPORTED_MODULE_3__.messageHasTypeAndDataFields)(message)) {
                    _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error('Received message with type MessageType.NotifyListeners has no data: ', message);
                    return;
                }
                const castedMessage = message;
                const [type, ...data] = castedMessage.data;
                callback({
                    type,
                    data
                });
            }
        });
        port.onDisconnect.addListener(()=>{
            if ((webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime).lastError) {
                _common_logger__WEBPACK_IMPORTED_MODULE_2__.logger.error((webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().runtime).lastError.message);
            }
            // we try to connect again if the background page was terminated
            if (!forceDisconnected) {
                connect();
            }
        });
    };
    connect();
    const onUnload = ()=>{
        if (port) {
            forceDisconnected = true;
            port.disconnect();
        }
    };
    window.addEventListener('beforeunload', onUnload);
    window.addEventListener('unload', onUnload);
    return onUnload;
});
const messenger = new Messenger();



/***/ }),

/***/ "./Extension/src/pages/thankyou.ts":
/*!*****************************************!*\
  !*** ./Extension/src/pages/thankyou.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   thankyou: () => (/* binding */ thankyou)
/* harmony export */ });
/* harmony import */ var _common_user_agent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../common/user-agent */ "./Extension/src/common/user-agent.ts");
/* harmony import */ var _services_messenger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/messenger */ "./Extension/src/pages/services/messenger.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

const PageController = (response)=>{
    const { userSettings, enabledFilters, constants: { AntiBannerFiltersId } } = response;
    let safebrowsingEnabledCheckbox = null;
    let trackingFilterEnabledCheckbox = null;
    let socialFilterEnabledCheckbox = null;
    let sendStatsCheckbox = null;
    let allowAcceptableAdsCheckbox = null;
    const safebrowsingEnabledChange = (e)=>{
        const checkbox = e.currentTarget;
        _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.changeUserSetting(userSettings.names.DisableSafebrowsing, !checkbox.checked);
    };
    const trackingFilterEnabledChange = (e)=>{
        const checkbox = e.currentTarget;
        if (checkbox.checked) {
            _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.enableFilter(AntiBannerFiltersId.TrackingFilterId);
        } else {
            _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.disableFilter(AntiBannerFiltersId.TrackingFilterId);
        }
    };
    const socialFilterEnabledChange = (e)=>{
        const checkbox = e.currentTarget;
        if (checkbox.checked) {
            _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.enableFilter(AntiBannerFiltersId.SocialFilterId);
        } else {
            _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.disableFilter(AntiBannerFiltersId.SocialFilterId);
        }
    };
    const sendStatsCheckboxChange = (e)=>{
        const checkbox = e.currentTarget;
        _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.changeUserSetting(userSettings.names.DisableCollectHits, !checkbox.checked);
    };
    const allowAcceptableAdsChange = (e)=>{
        const checkbox = e.currentTarget;
        if (checkbox.checked) {
            _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.enableFilter(AntiBannerFiltersId.SearchAndSelfPromoFilterId);
        } else {
            _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.disableFilter(AntiBannerFiltersId.SearchAndSelfPromoFilterId);
        }
    };
    const bindEvents = ()=>{
        safebrowsingEnabledCheckbox = document.getElementById('safebrowsingEnabledCheckbox');
        trackingFilterEnabledCheckbox = document.getElementById('trackingFilterEnabledCheckbox');
        socialFilterEnabledCheckbox = document.getElementById('socialFilterEnabledCheckbox');
        // sendSafebrowsingStatsCheckbox - id saved, because it should be changed on thankyou page
        sendStatsCheckbox = document.getElementById('sendSafebrowsingStatsCheckbox');
        allowAcceptableAdsCheckbox = document.getElementById('allowAcceptableAds');
        safebrowsingEnabledCheckbox === null || safebrowsingEnabledCheckbox === void 0 ? void 0 : safebrowsingEnabledCheckbox.addEventListener('change', safebrowsingEnabledChange);
        trackingFilterEnabledCheckbox === null || trackingFilterEnabledCheckbox === void 0 ? void 0 : trackingFilterEnabledCheckbox.addEventListener('change', trackingFilterEnabledChange);
        socialFilterEnabledCheckbox === null || socialFilterEnabledCheckbox === void 0 ? void 0 : socialFilterEnabledCheckbox.addEventListener('change', socialFilterEnabledChange);
        // ignore Firefox, see task AG-2322
        if (!_common_user_agent__WEBPACK_IMPORTED_MODULE_0__.UserAgent.isFirefox) {
            sendStatsCheckbox === null || sendStatsCheckbox === void 0 ? void 0 : sendStatsCheckbox.addEventListener('change', sendStatsCheckboxChange);
        }
        allowAcceptableAdsCheckbox === null || allowAcceptableAdsCheckbox === void 0 ? void 0 : allowAcceptableAdsCheckbox.addEventListener('change', allowAcceptableAdsChange);
        const openExtensionStoreBtns = [].slice.call(document.querySelectorAll('.openExtensionStore'));
        openExtensionStoreBtns.forEach((openExtensionStoreBtn)=>{
            openExtensionStoreBtn.addEventListener('click', (e)=>{
                e.preventDefault();
                _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.openExtensionStore();
            });
        });
        const openSettingsBtns = [].slice.call(document.querySelectorAll('.openSettings'));
        openSettingsBtns.forEach((openSettingsBtn)=>{
            openSettingsBtn.addEventListener('click', (e)=>{
                e.preventDefault();
                _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.openSettingsTab();
            });
        });
    };
    const updateCheckbox = (checkbox, enabled)=>{
        if (!checkbox) {
            return;
        }
        if (enabled) {
            checkbox.setAttribute('checked', 'checked');
        } else {
            checkbox.removeAttribute('checked');
        }
    };
    const render = ()=>{
        const trackingFilterEnabled = AntiBannerFiltersId.TrackingFilterId in enabledFilters;
        const socialFilterEnabled = AntiBannerFiltersId.SocialFilterId in enabledFilters;
        const allowAcceptableAdsEnabled = AntiBannerFiltersId.SearchAndSelfPromoFilterId in enabledFilters;
        const collectHitsCount = !userSettings.values[userSettings.names.DisableCollectHits];
        if (false) {}
        updateCheckbox(trackingFilterEnabledCheckbox, trackingFilterEnabled);
        updateCheckbox(socialFilterEnabledCheckbox, socialFilterEnabled);
        updateCheckbox(allowAcceptableAdsCheckbox, allowAcceptableAdsEnabled);
        updateCheckbox(sendStatsCheckbox, collectHitsCount);
    };
    const init = ()=>{
        bindEvents();
        render();
    };
    return {
        init
    };
};
let timeoutId;
let counter = 0;
const MAX_WAIT_RETRY = 10;
const RETRY_TIMEOUT_MS = 100;
const init = async ()=>{
    if (typeof _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger === 'undefined') {
        if (counter > MAX_WAIT_RETRY) {
            window.clearTimeout(timeoutId);
            return;
        }
        timeoutId = window.setTimeout(init, RETRY_TIMEOUT_MS);
        counter += 1;
        return;
    }
    window.clearTimeout(timeoutId);
    const response = await _services_messenger__WEBPACK_IMPORTED_MODULE_1__.messenger.initializeFrameScript();
    const controller = PageController(response);
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', ()=>{
            controller.init();
        });
    } else {
        controller.init();
    }
};
const thankyou = {
    init
};


/***/ }),

/***/ "./constants.ts":
/*!**********************!*\
  !*** ./constants.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MIN_SUPPORTED_VERSION: () => (/* binding */ MIN_SUPPORTED_VERSION)
/* harmony export */ });
/* unused harmony exports WEB_ACCESSIBLE_RESOURCES_OUTPUT, WEB_ACCESSIBLE_RESOURCES_OUTPUT_REDIRECTS, BACKGROUND_OUTPUT, OPTIONS_OUTPUT, POPUP_OUTPUT, FILTERING_LOG_OUTPUT, POST_INSTALL_OUTPUT, FULLSCREEN_USER_RULES_OUTPUT, SAFEBROWSING_OUTPUT, DOCUMENT_BLOCK_OUTPUT, SUBSCRIBE_OUTPUT, CONTENT_SCRIPT_START_OUTPUT, CONTENT_SCRIPT_END_OUTPUT, THANKYOU_OUTPUT, ASSISTANT_INJECT_OUTPUT, GPC_SCRIPT_OUTPUT, HIDE_DOCUMENT_REFERRER_OUTPUT, DEVTOOLS_OUTPUT, DEVTOOLS_ELEMENT_SIDEBAR_OUTPUT, SHARED_EDITOR_OUTPUT, REACT_VENDOR_OUTPUT, MOBX_VENDOR_OUTPUT, XSTATE_VENDOR_OUTPUT, TSURLFILTER_VENDOR_OUTPUT, AGTREE_VENDOR_OUTPUT, CSS_TOKENIZER_VENDOR_OUTPUT, TSWEBEXTENSION_VENDOR_OUTPUT, TEXT_ENCODING_POLYFILL_VENDOR_OUTPUT, SCRIPTLETS_VENDOR_OUTPUT, REMOTE_METADATA_FILE_NAME, REMOTE_I18N_METADATA_FILE_NAME, LOCAL_METADATA_FILE_NAME, LOCAL_I18N_METADATA_FILE_NAME, ADGUARD_FILTERS_IDS */
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ // TODO: generate tools/bundle/manifest.common.json with this constants
const WEB_ACCESSIBLE_RESOURCES_OUTPUT = 'web-accessible-resources';
const WEB_ACCESSIBLE_RESOURCES_OUTPUT_REDIRECTS = `${WEB_ACCESSIBLE_RESOURCES_OUTPUT}/redirects`;
const BACKGROUND_OUTPUT = 'pages/background';
const OPTIONS_OUTPUT = 'pages/options';
const POPUP_OUTPUT = 'pages/popup';
const FILTERING_LOG_OUTPUT = 'pages/filtering-log';
const POST_INSTALL_OUTPUT = 'pages/post-install';
const FULLSCREEN_USER_RULES_OUTPUT = 'pages/fullscreen-user-rules';
const SAFEBROWSING_OUTPUT = 'pages/safebrowsing';
const DOCUMENT_BLOCK_OUTPUT = 'pages/ad-blocked';
const SUBSCRIBE_OUTPUT = 'pages/subscribe';
const CONTENT_SCRIPT_START_OUTPUT = 'pages/content-script-start';
const CONTENT_SCRIPT_END_OUTPUT = 'pages/content-script-end';
const THANKYOU_OUTPUT = 'pages/thankyou';
const ASSISTANT_INJECT_OUTPUT = 'pages/assistant-inject';
const GPC_SCRIPT_OUTPUT = 'pages/gpc';
const HIDE_DOCUMENT_REFERRER_OUTPUT = 'pages/hide-document-referrer';
const DEVTOOLS_OUTPUT = 'pages/devtools';
const DEVTOOLS_ELEMENT_SIDEBAR_OUTPUT = 'pages/devtools-elements-sidebar';
const SHARED_EDITOR_OUTPUT = 'shared/editor';
const REACT_VENDOR_OUTPUT = 'vendors/react';
const MOBX_VENDOR_OUTPUT = 'vendors/mobx';
const XSTATE_VENDOR_OUTPUT = 'vendors/xstate';
const TSURLFILTER_VENDOR_OUTPUT = 'vendors/tsurlfilter';
const AGTREE_VENDOR_OUTPUT = 'vendors/agtree';
const CSS_TOKENIZER_VENDOR_OUTPUT = 'vendors/css-tokenizer';
const TSWEBEXTENSION_VENDOR_OUTPUT = 'vendors/tswebextension';
const TEXT_ENCODING_POLYFILL_VENDOR_OUTPUT = 'vendors/text-encoding-polyfill';
const SCRIPTLETS_VENDOR_OUTPUT = 'vendors/scriptlets';
// Placed here to use in the node environment and in the browser
// Important: extensions '.js' used for correct work of Cloudflare cache, but
// real format of these files is JSON.
// See AG-1901 for details.
const REMOTE_METADATA_FILE_NAME = 'filters.js';
const REMOTE_I18N_METADATA_FILE_NAME = 'filters_i18n.js';
// But locally we prefer to use '.json' extension.
const LOCAL_METADATA_FILE_NAME = 'filters.json';
const LOCAL_I18N_METADATA_FILE_NAME = 'filters_i18n.json';
/**
 * List of AdGuard filters IDs.
 *
 * `12` is absent because Safari filter if obsolete and not used anymore.
 */ const ADGUARD_FILTERS_IDS = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    224
];
/**
 * Minimum supported browser versions.
 *
 * IMPORTANT! Update browser compatibility in the README.md file when changing the versions.
 */ const MIN_SUPPORTED_VERSION = {
    CHROMIUM_MV2: 79,
    CHROMIUM_MV3: 121,
    FIREFOX: 78,
    FIREFOX_MOBILE: 113,
    OPERA: 67,
    EDGE_CHROMIUM: 80
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/try-to-string.js");

var $TypeError = TypeError;

// `Assert: IsCallable(argument) is true`
module.exports = function (argument) {
  if (isCallable(argument)) return argument;
  throw new $TypeError(tryToString(argument) + ' is not a function');
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-possible-prototype.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-possible-prototype.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isPossiblePrototype = __webpack_require__(/*! ../internals/is-possible-prototype */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-possible-prototype.js");

var $String = String;
var $TypeError = TypeError;

module.exports = function (argument) {
  if (isPossiblePrototype(argument)) return argument;
  throw new $TypeError("Can't set " + $String(argument) + ' as a prototype');
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/add-to-unscopables.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/add-to-unscopables.js ***!
  \************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");
var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-create.js");
var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js").f);

var UNSCOPABLES = wellKnownSymbol('unscopables');
var ArrayPrototype = Array.prototype;

// Array.prototype[@@unscopables]
// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
if (ArrayPrototype[UNSCOPABLES] === undefined) {
  defineProperty(ArrayPrototype, UNSCOPABLES, {
    configurable: true,
    value: create(null)
  });
}

// add a key to Array.prototype[@@unscopables]
module.exports = function (key) {
  ArrayPrototype[UNSCOPABLES][key] = true;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

var $String = String;
var $TypeError = TypeError;

// `Assert: Type(argument) is Object`
module.exports = function (argument) {
  if (isObject(argument)) return argument;
  throw new $TypeError($String(argument) + ' is not an object');
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ../internals/to-absolute-index */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-absolute-index.js");
var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/length-of-array-like.js");

// `Array.prototype.{ indexOf, includes }` methods implementation
var createMethod = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIndexedObject($this);
    var length = lengthOfArrayLike(O);
    if (length === 0) return !IS_INCLUDES && -1;
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare -- NaN check
    if (IS_INCLUDES && el !== el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare -- NaN check
      if (value !== value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) {
      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};

module.exports = {
  // `Array.prototype.includes` method
  // https://tc39.es/ecma262/#sec-array.prototype.includes
  includes: createMethod(true),
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: createMethod(false)
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

var toString = uncurryThis({}.toString);
var stringSlice = uncurryThis(''.slice);

module.exports = function (it) {
  return stringSlice(toString(it), 8, -1);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof.js ***!
  \*************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var TO_STRING_TAG_SUPPORT = __webpack_require__(/*! ../internals/to-string-tag-support */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string-tag-support.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var classofRaw = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");

var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Object = Object;

// ES3 wrong here
var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) === 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (error) { /* empty */ }
};

// getting tag from ES6+ `Object.prototype.toString`
module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function (it) {
  var O, tag, result;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG)) == 'string' ? tag
    // builtinTag case
    : CORRECT_ARGUMENTS ? classofRaw(O)
    // ES3 arguments fallback
    : (result = classofRaw(O)) === 'Object' && isCallable(O.callee) ? 'Arguments' : result;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js ***!
  \*********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var ownKeys = __webpack_require__(/*! ../internals/own-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/own-keys.js");
var getOwnPropertyDescriptorModule = __webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");

module.exports = function (target, source, exceptions) {
  var keys = ownKeys(source);
  var defineProperty = definePropertyModule.f;
  var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (!hasOwn(target, key) && !(exceptions && hasOwn(exceptions, key))) {
      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
    }
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js":
/*!************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js ***!
  \************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");
var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js");

module.exports = DESCRIPTORS ? function (object, key, value) {
  return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js":
/*!********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in-accessor.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in-accessor.js ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var makeBuiltIn = __webpack_require__(/*! ../internals/make-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js");
var defineProperty = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");

module.exports = function (target, name, descriptor) {
  if (descriptor.get) makeBuiltIn(descriptor.get, name, { getter: true });
  if (descriptor.set) makeBuiltIn(descriptor.set, name, { setter: true });
  return defineProperty.f(target, name, descriptor);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in.js ***!
  \*********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");
var makeBuiltIn = __webpack_require__(/*! ../internals/make-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js");
var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js");

module.exports = function (O, key, value, options) {
  if (!options) options = {};
  var simple = options.enumerable;
  var name = options.name !== undefined ? options.name : key;
  if (isCallable(value)) makeBuiltIn(value, name, options);
  if (options.global) {
    if (simple) O[key] = value;
    else defineGlobalProperty(key, value);
  } else {
    try {
      if (!options.unsafe) delete O[key];
      else if (O[key]) simple = true;
    } catch (error) { /* empty */ }
    if (simple) O[key] = value;
    else definePropertyModule.f(O, key, {
      value: value,
      enumerable: false,
      configurable: !options.nonConfigurable,
      writable: !options.nonWritable
    });
  } return O;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");

// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;

module.exports = function (key, value) {
  try {
    defineProperty(globalThis, key, { value: value, configurable: true, writable: true });
  } catch (error) {
    globalThis[key] = value;
  } return value;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");

// Detect IE8's incomplete defineProperty implementation
module.exports = !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] !== 7;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

var document = globalThis.document;
// typeof document.createElement is 'object' in old IE
var EXISTS = isObject(document) && isObject(document.createElement);

module.exports = function (it) {
  return EXISTS ? document.createElement(it) : {};
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js ***!
  \*******************************************************************************************/
/***/ ((module) => {

"use strict";

// IE8- don't enum bug keys
module.exports = [
  'constructor',
  'hasOwnProperty',
  'isPrototypeOf',
  'propertyIsEnumerable',
  'toLocaleString',
  'toString',
  'valueOf'
];


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-user-agent.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-user-agent.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");

var navigator = globalThis.navigator;
var userAgent = navigator && navigator.userAgent;

module.exports = userAgent ? String(userAgent) : '';


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-v8-version.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-v8-version.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-user-agent.js");

var process = globalThis.process;
var Deno = globalThis.Deno;
var versions = process && process.versions || Deno && Deno.version;
var v8 = versions && versions.v8;
var match, version;

if (v8) {
  match = v8.split('.');
  // in old Chrome, versions of V8 isn't V8 = Chrome / 10
  // but their correct versions are not interesting for us
  version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
}

// BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
// so check `userAgent` even if `.v8` exists, but 0
if (!version && userAgent) {
  match = userAgent.match(/Edge\/(\d+)/);
  if (!match || match[1] >= 74) {
    match = userAgent.match(/Chrome\/(\d+)/);
    if (match) version = +match[1];
  }
}

module.exports = version;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-clear.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-clear.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

var $Error = Error;
var replace = uncurryThis(''.replace);

var TEST = (function (arg) { return String(new $Error(arg).stack); })('zxcasd');
// eslint-disable-next-line redos/no-vulnerable, sonarjs/slow-regex -- safe
var V8_OR_CHAKRA_STACK_ENTRY = /\n\s*at [^:]*:[^\n]*/;
var IS_V8_OR_CHAKRA_STACK = V8_OR_CHAKRA_STACK_ENTRY.test(TEST);

module.exports = function (stack, dropEntries) {
  if (IS_V8_OR_CHAKRA_STACK && typeof stack == 'string' && !$Error.prepareStackTrace) {
    while (dropEntries--) stack = replace(stack, V8_OR_CHAKRA_STACK_ENTRY, '');
  } return stack;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-install.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-install.js ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var clearErrorStack = __webpack_require__(/*! ../internals/error-stack-clear */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-clear.js");
var ERROR_STACK_INSTALLABLE = __webpack_require__(/*! ../internals/error-stack-installable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-installable.js");

// non-standard V8
var captureStackTrace = Error.captureStackTrace;

module.exports = function (error, C, stack, dropEntries) {
  if (ERROR_STACK_INSTALLABLE) {
    if (captureStackTrace) captureStackTrace(error, C);
    else createNonEnumerableProperty(error, 'stack', clearErrorStack(stack, dropEntries));
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-installable.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-installable.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js");

module.exports = !fails(function () {
  var error = new Error('a');
  if (!('stack' in error)) return true;
  // eslint-disable-next-line es/no-object-defineproperty -- safe
  Object.defineProperty(error, 'stack', createPropertyDescriptor(1, 7));
  return error.stack !== 7;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js":
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var getOwnPropertyDescriptor = (__webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js").f);
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in.js");
var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js");
var copyConstructorProperties = __webpack_require__(/*! ../internals/copy-constructor-properties */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js");
var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-forced.js");

/*
  options.target         - name of the target object
  options.global         - target is the global object
  options.stat           - export as static methods of target
  options.proto          - export as prototype methods of target
  options.real           - real prototype method for the `pure` version
  options.forced         - export even if the native feature is available
  options.bind           - bind methods to the target, required for the `pure` version
  options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
  options.unsafe         - use the simple assignment of property instead of delete + defineProperty
  options.sham           - add a flag to not completely full polyfills
  options.enumerable     - export as enumerable property
  options.dontCallGetSet - prevent calling a getter on target
  options.name           - the .name of the function if it does not match the key
*/
module.exports = function (options, source) {
  var TARGET = options.target;
  var GLOBAL = options.global;
  var STATIC = options.stat;
  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
  if (GLOBAL) {
    target = globalThis;
  } else if (STATIC) {
    target = globalThis[TARGET] || defineGlobalProperty(TARGET, {});
  } else {
    target = globalThis[TARGET] && globalThis[TARGET].prototype;
  }
  if (target) for (key in source) {
    sourceProperty = source[key];
    if (options.dontCallGetSet) {
      descriptor = getOwnPropertyDescriptor(target, key);
      targetProperty = descriptor && descriptor.value;
    } else targetProperty = target[key];
    FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
    // contained in target
    if (!FORCED && targetProperty !== undefined) {
      if (typeof sourceProperty == typeof targetProperty) continue;
      copyConstructorProperties(sourceProperty, targetProperty);
    }
    // add a flag to not completely full polyfills
    if (options.sham || (targetProperty && targetProperty.sham)) {
      createNonEnumerableProperty(sourceProperty, 'sham', true);
    }
    defineBuiltIn(target, key, sourceProperty, options);
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (error) {
    return true;
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-apply.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-apply.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js");

var FunctionPrototype = Function.prototype;
var apply = FunctionPrototype.apply;
var call = FunctionPrototype.call;

// eslint-disable-next-line es/no-function-prototype-bind, es/no-reflect -- safe
module.exports = typeof Reflect == 'object' && Reflect.apply || (NATIVE_BIND ? call.bind(apply) : function () {
  return call.apply(apply, arguments);
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");

module.exports = !fails(function () {
  // eslint-disable-next-line es/no-function-prototype-bind -- safe
  var test = (function () { /* empty */ }).bind();
  // eslint-disable-next-line no-prototype-builtins -- safe
  return typeof test != 'function' || test.hasOwnProperty('prototype');
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js");

var call = Function.prototype.call;
// eslint-disable-next-line es/no-function-prototype-bind -- safe
module.exports = NATIVE_BIND ? call.bind(call) : function () {
  return call.apply(call, arguments);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-name.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-name.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");

var FunctionPrototype = Function.prototype;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getDescriptor = DESCRIPTORS && Object.getOwnPropertyDescriptor;

var EXISTS = hasOwn(FunctionPrototype, 'name');
// additional protection from minified / mangled / dropped function names
var PROPER = EXISTS && (function something() { /* empty */ }).name === 'something';
var CONFIGURABLE = EXISTS && (!DESCRIPTORS || (DESCRIPTORS && getDescriptor(FunctionPrototype, 'name').configurable));

module.exports = {
  EXISTS: EXISTS,
  PROPER: PROPER,
  CONFIGURABLE: CONFIGURABLE
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this-accessor.js":
/*!************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this-accessor.js ***!
  \************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js");

module.exports = function (object, key, method) {
  try {
    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
    return uncurryThis(aCallable(Object.getOwnPropertyDescriptor(object, key)[method]));
  } catch (error) { /* empty */ }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-bind-native.js");

var FunctionPrototype = Function.prototype;
var call = FunctionPrototype.call;
// eslint-disable-next-line es/no-function-prototype-bind -- safe
var uncurryThisWithBind = NATIVE_BIND && FunctionPrototype.bind.bind(call, call);

module.exports = NATIVE_BIND ? uncurryThisWithBind : function (fn) {
  return function () {
    return call.apply(fn, arguments);
  };
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js ***!
  \******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

var aFunction = function (argument) {
  return isCallable(argument) ? argument : undefined;
};

module.exports = function (namespace, method) {
  return arguments.length < 2 ? aFunction(globalThis[namespace]) : globalThis[namespace] && globalThis[namespace][method];
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-method.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-method.js ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-callable.js");
var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js");

// `GetMethod` abstract operation
// https://tc39.es/ecma262/#sec-getmethod
module.exports = function (V, P) {
  var func = V[P];
  return isNullOrUndefined(func) ? undefined : aCallable(func);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js ***!
  \*****************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var check = function (it) {
  return it && it.Math === Math && it;
};

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
module.exports =
  // eslint-disable-next-line es/no-global-this -- safe
  check(typeof globalThis == 'object' && globalThis) ||
  check(typeof window == 'object' && window) ||
  // eslint-disable-next-line no-restricted-globals -- safe
  check(typeof self == 'object' && self) ||
  check(typeof __webpack_require__.g == 'object' && __webpack_require__.g) ||
  check(typeof this == 'object' && this) ||
  // eslint-disable-next-line no-new-func -- fallback
  (function () { return this; })() || Function('return this')();


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js":
/*!**********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js ***!
  \**********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-object.js");

var hasOwnProperty = uncurryThis({}.hasOwnProperty);

// `HasOwnProperty` abstract operation
// https://tc39.es/ecma262/#sec-hasownproperty
// eslint-disable-next-line es/no-object-hasown -- safe
module.exports = Object.hasOwn || function hasOwn(it, key) {
  return hasOwnProperty(toObject(it), key);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = {};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/html.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/html.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");

module.exports = getBuiltIn('document', 'documentElement');


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var createElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js");

// Thanks to IE8 for its funny defineProperty
module.exports = !DESCRIPTORS && !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(createElement('div'), 'a', {
    get: function () { return 7; }
  }).a !== 7;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/indexed-object.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/indexed-object.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof-raw.js");

var $Object = Object;
var split = uncurryThis(''.split);

// fallback for non-array-like ES3 and non-enumerable old V8 strings
module.exports = fails(function () {
  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
  // eslint-disable-next-line no-prototype-builtins -- safe
  return !$Object('z').propertyIsEnumerable(0);
}) ? function (it) {
  return classof(it) === 'String' ? split(it, '') : $Object(it);
} : $Object;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inherit-if-required.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inherit-if-required.js ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js");

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
    // it can work only with native `setPrototypeOf`
    setPrototypeOf &&
    // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
    isCallable(NewTarget = dummy.constructor) &&
    NewTarget !== Wrapper &&
    isObject(NewTargetPrototype = NewTarget.prototype) &&
    NewTargetPrototype !== Wrapper.prototype
  ) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inspect-source.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inspect-source.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var store = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js");

var functionToString = uncurryThis(Function.toString);

// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
if (!isCallable(store.inspectSource)) {
  store.inspectSource = function (it) {
    return functionToString(it);
  };
}

module.exports = store.inspectSource;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/install-error-cause.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/install-error-cause.js ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");

// `InstallErrorCause` abstract operation
// https://tc39.es/proposal-error-cause/#sec-errorobjects-install-error-cause
module.exports = function (O, options) {
  if (isObject(options) && 'cause' in options) {
    createNonEnumerableProperty(O, 'cause', options.cause);
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/internal-state.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/internal-state.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var NATIVE_WEAK_MAP = __webpack_require__(/*! ../internals/weak-map-basic-detection */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/weak-map-basic-detection.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var shared = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js");
var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js");
var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js");

var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
var TypeError = globalThis.TypeError;
var WeakMap = globalThis.WeakMap;
var set, get, has;

var enforce = function (it) {
  return has(it) ? get(it) : set(it, {});
};

var getterFor = function (TYPE) {
  return function (it) {
    var state;
    if (!isObject(it) || (state = get(it)).type !== TYPE) {
      throw new TypeError('Incompatible receiver, ' + TYPE + ' required');
    } return state;
  };
};

if (NATIVE_WEAK_MAP || shared.state) {
  var store = shared.state || (shared.state = new WeakMap());
  /* eslint-disable no-self-assign -- prototype methods protection */
  store.get = store.get;
  store.has = store.has;
  store.set = store.set;
  /* eslint-enable no-self-assign -- prototype methods protection */
  set = function (it, metadata) {
    if (store.has(it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    store.set(it, metadata);
    return metadata;
  };
  get = function (it) {
    return store.get(it) || {};
  };
  has = function (it) {
    return store.has(it);
  };
} else {
  var STATE = sharedKey('state');
  hiddenKeys[STATE] = true;
  set = function (it, metadata) {
    if (hasOwn(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    createNonEnumerableProperty(it, STATE, metadata);
    return metadata;
  };
  get = function (it) {
    return hasOwn(it, STATE) ? it[STATE] : {};
  };
  has = function (it) {
    return hasOwn(it, STATE);
  };
}

module.exports = {
  set: set,
  get: get,
  has: has,
  enforce: enforce,
  getterFor: getterFor
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";

// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
var documentAll = typeof document == 'object' && document.all;

// `IsCallable` abstract operation
// https://tc39.es/ecma262/#sec-iscallable
// eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
module.exports = typeof documentAll == 'undefined' && documentAll !== undefined ? function (argument) {
  return typeof argument == 'function' || argument === documentAll;
} : function (argument) {
  return typeof argument == 'function';
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-forced.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-forced.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

var replacement = /#|\.prototype\./;

var isForced = function (feature, detection) {
  var value = data[normalize(feature)];
  return value === POLYFILL ? true
    : value === NATIVE ? false
    : isCallable(detection) ? fails(detection)
    : !!detection;
};

var normalize = isForced.normalize = function (string) {
  return String(string).replace(replacement, '.').toLowerCase();
};

var data = isForced.data = {};
var NATIVE = isForced.NATIVE = 'N';
var POLYFILL = isForced.POLYFILL = 'P';

module.exports = isForced;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";

// we can't use just `it == null` since of `document.all` special case
// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
module.exports = function (it) {
  return it === null || it === undefined;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

module.exports = function (it) {
  return typeof it == 'object' ? it !== null : isCallable(it);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-possible-prototype.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-possible-prototype.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

module.exports = function (argument) {
  return isObject(argument) || argument === null;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js ***!
  \*************************************************************************************/
/***/ ((module) => {

"use strict";

module.exports = false;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js");
var USE_SYMBOL_AS_UID = __webpack_require__(/*! ../internals/use-symbol-as-uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js");

var $Object = Object;

module.exports = USE_SYMBOL_AS_UID ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  var $Symbol = getBuiltIn('Symbol');
  return isCallable($Symbol) && isPrototypeOf($Symbol.prototype, $Object(it));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/length-of-array-like.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/length-of-array-like.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-length.js");

// `LengthOfArrayLike` abstract operation
// https://tc39.es/ecma262/#sec-lengthofarraylike
module.exports = function (obj) {
  return toLength(obj.length);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/make-built-in.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var CONFIGURABLE_FUNCTION_NAME = (__webpack_require__(/*! ../internals/function-name */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-name.js").CONFIGURABLE);
var inspectSource = __webpack_require__(/*! ../internals/inspect-source */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inspect-source.js");
var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/internal-state.js");

var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var $String = String;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var stringSlice = uncurryThis(''.slice);
var replace = uncurryThis(''.replace);
var join = uncurryThis([].join);

var CONFIGURABLE_LENGTH = DESCRIPTORS && !fails(function () {
  return defineProperty(function () { /* empty */ }, 'length', { value: 8 }).length !== 8;
});

var TEMPLATE = String(String).split('String');

var makeBuiltIn = module.exports = function (value, name, options) {
  if (stringSlice($String(name), 0, 7) === 'Symbol(') {
    name = '[' + replace($String(name), /^Symbol\(([^)]*)\).*$/, '$1') + ']';
  }
  if (options && options.getter) name = 'get ' + name;
  if (options && options.setter) name = 'set ' + name;
  if (!hasOwn(value, 'name') || (CONFIGURABLE_FUNCTION_NAME && value.name !== name)) {
    if (DESCRIPTORS) defineProperty(value, 'name', { value: name, configurable: true });
    else value.name = name;
  }
  if (CONFIGURABLE_LENGTH && options && hasOwn(options, 'arity') && value.length !== options.arity) {
    defineProperty(value, 'length', { value: options.arity });
  }
  try {
    if (options && hasOwn(options, 'constructor') && options.constructor) {
      if (DESCRIPTORS) defineProperty(value, 'prototype', { writable: false });
    // in V8 ~ Chrome 53, prototypes of some methods, like `Array.prototype.values`, are non-writable
    } else if (value.prototype) value.prototype = undefined;
  } catch (error) { /* empty */ }
  var state = enforceInternalState(value);
  if (!hasOwn(state, 'source')) {
    state.source = join(TEMPLATE, typeof name == 'string' ? name : '');
  } return value;
};

// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
// eslint-disable-next-line no-extend-native -- required
Function.prototype.toString = makeBuiltIn(function toString() {
  return isCallable(this) && getInternalState(this).source || inspectSource(this);
}, 'toString');


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/math-trunc.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/math-trunc.js ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";

var ceil = Math.ceil;
var floor = Math.floor;

// `Math.trunc` method
// https://tc39.es/ecma262/#sec-math.trunc
// eslint-disable-next-line es/no-math-trunc -- safe
module.exports = Math.trunc || function trunc(x) {
  var n = +x;
  return (n > 0 ? floor : ceil)(n);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/normalize-string-argument.js":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/normalize-string-argument.js ***!
  \*******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string.js");

module.exports = function (argument, $default) {
  return argument === undefined ? arguments.length < 2 ? '' : $default : toString(argument);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-create.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-create.js ***!
  \*******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* global ActiveXObject -- old IE, WSH */
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");
var definePropertiesModule = __webpack_require__(/*! ../internals/object-define-properties */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-properties.js");
var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js");
var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js");
var html = __webpack_require__(/*! ../internals/html */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/html.js");
var documentCreateElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/document-create-element.js");
var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js");

var GT = '>';
var LT = '<';
var PROTOTYPE = 'prototype';
var SCRIPT = 'script';
var IE_PROTO = sharedKey('IE_PROTO');

var EmptyConstructor = function () { /* empty */ };

var scriptTag = function (content) {
  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
};

// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
var NullProtoObjectViaActiveX = function (activeXDocument) {
  activeXDocument.write(scriptTag(''));
  activeXDocument.close();
  var temp = activeXDocument.parentWindow.Object;
  // eslint-disable-next-line no-useless-assignment -- avoid memory leak
  activeXDocument = null;
  return temp;
};

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var NullProtoObjectViaIFrame = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = documentCreateElement('iframe');
  var JS = 'java' + SCRIPT + ':';
  var iframeDocument;
  iframe.style.display = 'none';
  html.appendChild(iframe);
  // https://github.com/zloirock/core-js/issues/475
  iframe.src = String(JS);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(scriptTag('document.F=Object'));
  iframeDocument.close();
  return iframeDocument.F;
};

// Check for document.domain and active x support
// No need to use active x approach when document.domain is not set
// see https://github.com/es-shims/es5-shim/issues/150
// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
// avoid IE GC bug
var activeXDocument;
var NullProtoObject = function () {
  try {
    activeXDocument = new ActiveXObject('htmlfile');
  } catch (error) { /* ignore */ }
  NullProtoObject = typeof document != 'undefined'
    ? document.domain && activeXDocument
      ? NullProtoObjectViaActiveX(activeXDocument) // old IE
      : NullProtoObjectViaIFrame()
    : NullProtoObjectViaActiveX(activeXDocument); // WSH
  var length = enumBugKeys.length;
  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
  return NullProtoObject();
};

hiddenKeys[IE_PROTO] = true;

// `Object.create` method
// https://tc39.es/ecma262/#sec-object.create
// eslint-disable-next-line es/no-object-create -- safe
module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    EmptyConstructor[PROTOTYPE] = anObject(O);
    result = new EmptyConstructor();
    EmptyConstructor[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = NullProtoObject();
  return Properties === undefined ? result : definePropertiesModule.f(result, Properties);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-properties.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-properties.js ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(/*! ../internals/v8-prototype-define-bug */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js");
var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var objectKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys.js");

// `Object.defineProperties` method
// https://tc39.es/ecma262/#sec-object.defineproperties
// eslint-disable-next-line es/no-object-defineproperties -- safe
exports.f = DESCRIPTORS && !V8_PROTOTYPE_DEFINE_BUG ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var props = toIndexedObject(Properties);
  var keys = objectKeys(Properties);
  var length = keys.length;
  var index = 0;
  var key;
  while (length > index) definePropertyModule.f(O, key = keys[index++], props[key]);
  return O;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ../internals/ie8-dom-define */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js");
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(/*! ../internals/v8-prototype-define-bug */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");
var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js");

var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var $defineProperty = Object.defineProperty;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ENUMERABLE = 'enumerable';
var CONFIGURABLE = 'configurable';
var WRITABLE = 'writable';

// `Object.defineProperty` method
// https://tc39.es/ecma262/#sec-object.defineproperty
exports.f = DESCRIPTORS ? V8_PROTOTYPE_DEFINE_BUG ? function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (typeof O === 'function' && P === 'prototype' && 'value' in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
    var current = $getOwnPropertyDescriptor(O, P);
    if (current && current[WRITABLE]) {
      O[P] = Attributes.value;
      Attributes = {
        configurable: CONFIGURABLE in Attributes ? Attributes[CONFIGURABLE] : current[CONFIGURABLE],
        enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
        writable: false
      };
    }
  } return $defineProperty(O, P, Attributes);
} : $defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return $defineProperty(O, P, Attributes);
  } catch (error) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw new $TypeError('Accessors not supported');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-descriptor.js ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js");
var propertyIsEnumerableModule = __webpack_require__(/*! ../internals/object-property-is-enumerable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-property-is-enumerable.js");
var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-property-descriptor.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ../internals/ie8-dom-define */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ie8-dom-define.js");

// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
  O = toIndexedObject(O);
  P = toPropertyKey(P);
  if (IE8_DOM_DEFINE) try {
    return $getOwnPropertyDescriptor(O, P);
  } catch (error) { /* empty */ }
  if (hasOwn(O, P)) return createPropertyDescriptor(!call(propertyIsEnumerableModule.f, O, P), O[P]);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-names.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-names.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var internalObjectKeys = __webpack_require__(/*! ../internals/object-keys-internal */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js");
var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js");

var hiddenKeys = enumBugKeys.concat('length', 'prototype');

// `Object.getOwnPropertyNames` method
// https://tc39.es/ecma262/#sec-object.getownpropertynames
// eslint-disable-next-line es/no-object-getownpropertynames -- safe
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return internalObjectKeys(O, hiddenKeys);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-symbols.js":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-symbols.js ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
exports.f = Object.getOwnPropertySymbols;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

module.exports = uncurryThis({}.isPrototypeOf);


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js");
var indexOf = (__webpack_require__(/*! ../internals/array-includes */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js").indexOf);
var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/hidden-keys.js");

var push = uncurryThis([].push);

module.exports = function (object, names) {
  var O = toIndexedObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) !hasOwn(hiddenKeys, key) && hasOwn(O, key) && push(result, key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (hasOwn(O, key = names[i++])) {
    ~indexOf(result, key) || push(result, key);
  }
  return result;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys.js ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var internalObjectKeys = __webpack_require__(/*! ../internals/object-keys-internal */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-keys-internal.js");
var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/enum-bug-keys.js");

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
// eslint-disable-next-line es/no-object-keys -- safe
module.exports = Object.keys || function keys(O) {
  return internalObjectKeys(O, enumBugKeys);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-property-is-enumerable.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-property-is-enumerable.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

var $propertyIsEnumerable = {}.propertyIsEnumerable;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Nashorn ~ JDK8 bug
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({ 1: 2 }, 1);

// `Object.prototype.propertyIsEnumerable` method implementation
// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
  var descriptor = getOwnPropertyDescriptor(this, V);
  return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable no-proto -- safe */
var uncurryThisAccessor = __webpack_require__(/*! ../internals/function-uncurry-this-accessor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this-accessor.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js");
var aPossiblePrototype = __webpack_require__(/*! ../internals/a-possible-prototype */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/a-possible-prototype.js");

// `Object.setPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.setprototypeof
// Works with __proto__ only. Old v8 can't work with null proto objects.
// eslint-disable-next-line es/no-object-setprototypeof -- safe
module.exports = Object.setPrototypeOf || ('__proto__' in {} ? function () {
  var CORRECT_SETTER = false;
  var test = {};
  var setter;
  try {
    setter = uncurryThisAccessor(Object.prototype, '__proto__', 'set');
    setter(test, []);
    CORRECT_SETTER = test instanceof Array;
  } catch (error) { /* empty */ }
  return function setPrototypeOf(O, proto) {
    requireObjectCoercible(O);
    aPossiblePrototype(proto);
    if (!isObject(O)) return O;
    if (CORRECT_SETTER) setter(O, proto);
    else O.__proto__ = proto;
    return O;
  };
}() : undefined);


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ordinary-to-primitive.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ordinary-to-primitive.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");

var $TypeError = TypeError;

// `OrdinaryToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-ordinarytoprimitive
module.exports = function (input, pref) {
  var fn, val;
  if (pref === 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  if (isCallable(fn = input.valueOf) && !isObject(val = call(fn, input))) return val;
  if (pref !== 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  throw new $TypeError("Can't convert object to primitive value");
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/own-keys.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/own-keys.js ***!
  \**************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");
var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");
var getOwnPropertyNamesModule = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-names.js");
var getOwnPropertySymbolsModule = __webpack_require__(/*! ../internals/object-get-own-property-symbols */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-get-own-property-symbols.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/an-object.js");

var concat = uncurryThis([].concat);

// all object keys, includes non-enumerable and symbols
module.exports = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
  var keys = getOwnPropertyNamesModule.f(anObject(it));
  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
  return getOwnPropertySymbols ? concat(keys, getOwnPropertySymbols(it)) : keys;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/proxy-accessor.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/proxy-accessor.js ***!
  \********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-define-property.js").f);

module.exports = function (Target, Source, key) {
  key in Target || defineProperty(Target, key, {
    configurable: true,
    get: function () { return Source[key]; },
    set: function (it) { Source[key] = it; }
  });
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-null-or-undefined.js");

var $TypeError = TypeError;

// `RequireObjectCoercible` abstract operation
// https://tc39.es/ecma262/#sec-requireobjectcoercible
module.exports = function (it) {
  if (isNullOrUndefined(it)) throw new $TypeError("Can't call method on " + it);
  return it;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-key.js ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js");
var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js");

var keys = shared('keys');

module.exports = function (key) {
  return keys[key] || (keys[key] = uid(key));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js ***!
  \******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-global-property.js");

var SHARED = '__core-js_shared__';
var store = module.exports = globalThis[SHARED] || defineGlobalProperty(SHARED, {});

(store.versions || (store.versions = [])).push({
  version: '3.40.0',
  mode: IS_PURE ? 'pure' : 'global',
  copyright: '© 2014-2025 Denis Pushkarev (zloirock.ru)',
  license: 'https://github.com/zloirock/core-js/blob/v3.40.0/LICENSE',
  source: 'https://github.com/zloirock/core-js'
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js":
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var store = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared-store.js");

module.exports = function (key, value) {
  return store[key] || (store[key] = value || {});
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js ***!
  \**********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable es/no-symbol -- required for testing */
var V8_VERSION = __webpack_require__(/*! ../internals/environment-v8-version */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/environment-v8-version.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");

var $String = globalThis.String;

// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
module.exports = !!Object.getOwnPropertySymbols && !fails(function () {
  var symbol = Symbol('symbol detection');
  // Chrome 38 Symbol has incorrect toString conversion
  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
  // nb: Do not call `String` directly to avoid this being optimized out to `symbol+''` which will,
  // of course, fail.
  return !$String(symbol) || !(Object(symbol) instanceof Symbol) ||
    // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
    !Symbol.sham && V8_VERSION && V8_VERSION < 41;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-absolute-index.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-absolute-index.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js");

var max = Math.max;
var min = Math.min;

// Helper for a popular repeating case of the spec:
// Let integer be ? ToInteger(index).
// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
module.exports = function (index, length) {
  var integer = toIntegerOrInfinity(index);
  return integer < 0 ? max(integer + length, 0) : min(integer, length);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-indexed-object.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

// toObject with fallback for non-array-like ES3 strings
var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/indexed-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js");

module.exports = function (it) {
  return IndexedObject(requireObjectCoercible(it));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js ***!
  \****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var trunc = __webpack_require__(/*! ../internals/math-trunc */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/math-trunc.js");

// `ToIntegerOrInfinity` abstract operation
// https://tc39.es/ecma262/#sec-tointegerorinfinity
module.exports = function (argument) {
  var number = +argument;
  // eslint-disable-next-line no-self-compare -- NaN check
  return number !== number || number === 0 ? 0 : trunc(number);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-length.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-length.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-integer-or-infinity.js");

var min = Math.min;

// `ToLength` abstract operation
// https://tc39.es/ecma262/#sec-tolength
module.exports = function (argument) {
  var len = toIntegerOrInfinity(argument);
  return len > 0 ? min(len, 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-object.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-object.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/require-object-coercible.js");

var $Object = Object;

// `ToObject` abstract operation
// https://tc39.es/ecma262/#sec-toobject
module.exports = function (argument) {
  return $Object(requireObjectCoercible(argument));
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-primitive.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-primitive.js ***!
  \******************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-call.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-object.js");
var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js");
var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-method.js");
var ordinaryToPrimitive = __webpack_require__(/*! ../internals/ordinary-to-primitive */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/ordinary-to-primitive.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");

var $TypeError = TypeError;
var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

// `ToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-toprimitive
module.exports = function (input, pref) {
  if (!isObject(input) || isSymbol(input)) return input;
  var exoticToPrim = getMethod(input, TO_PRIMITIVE);
  var result;
  if (exoticToPrim) {
    if (pref === undefined) pref = 'default';
    result = call(exoticToPrim, input, pref);
    if (!isObject(result) || isSymbol(result)) return result;
    throw new $TypeError("Can't convert object to primitive value");
  }
  if (pref === undefined) pref = 'number';
  return ordinaryToPrimitive(input, pref);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-property-key.js ***!
  \*********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toPrimitive = __webpack_require__(/*! ../internals/to-primitive */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-primitive.js");
var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-symbol.js");

// `ToPropertyKey` abstract operation
// https://tc39.es/ecma262/#sec-topropertykey
module.exports = function (argument) {
  var key = toPrimitive(argument, 'string');
  return isSymbol(key) ? key : key + '';
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string-tag-support.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string-tag-support.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js");

var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var test = {};

test[TO_STRING_TAG] = 'z';

module.exports = String(test) === '[object z]';


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/to-string.js ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/classof.js");

var $String = String;

module.exports = function (argument) {
  if (classof(argument) === 'Symbol') throw new TypeError('Cannot convert a Symbol value to a string');
  return $String(argument);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/try-to-string.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/try-to-string.js ***!
  \*******************************************************************************************/
/***/ ((module) => {

"use strict";

var $String = String;

module.exports = function (argument) {
  try {
    return $String(argument);
  } catch (error) {
    return 'Object';
  }
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js ***!
  \*********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-uncurry-this.js");

var id = 0;
var postfix = Math.random();
var toString = uncurryThis(1.0.toString);

module.exports = function (key) {
  return 'Symbol(' + (key === undefined ? '' : key) + ')_' + toString(++id + postfix, 36);
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable es/no-symbol -- required for testing */
var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js");

module.exports = NATIVE_SYMBOL &&
  !Symbol.sham &&
  typeof Symbol.iterator == 'symbol';


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/v8-prototype-define-bug.js ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");

// V8 ~ Chrome 36-
// https://bugs.chromium.org/p/v8/issues/detail?id=3334
module.exports = DESCRIPTORS && fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(function () { /* empty */ }, 'prototype', {
    value: 42,
    writable: false
  }).prototype !== 42;
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/weak-map-basic-detection.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/weak-map-basic-detection.js ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-callable.js");

var WeakMap = globalThis.WeakMap;

module.exports = isCallable(WeakMap) && /native code/.test(String(WeakMap));


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/well-known-symbol.js ***!
  \***********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/shared.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/uid.js");
var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/symbol-constructor-detection.js");
var USE_SYMBOL_AS_UID = __webpack_require__(/*! ../internals/use-symbol-as-uid */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/use-symbol-as-uid.js");

var Symbol = globalThis.Symbol;
var WellKnownSymbolsStore = shared('wks');
var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol['for'] || Symbol : Symbol && Symbol.withoutSetter || uid;

module.exports = function (name) {
  if (!hasOwn(WellKnownSymbolsStore, name)) {
    WellKnownSymbolsStore[name] = NATIVE_SYMBOL && hasOwn(Symbol, name)
      ? Symbol[name]
      : createWellKnownSymbol('Symbol.' + name);
  } return WellKnownSymbolsStore[name];
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/wrap-error-constructor-with-cause.js":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/wrap-error-constructor-with-cause.js ***!
  \***************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/get-built-in.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/has-own-property.js");
var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/create-non-enumerable-property.js");
var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-is-prototype-of.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/object-set-prototype-of.js");
var copyConstructorProperties = __webpack_require__(/*! ../internals/copy-constructor-properties */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/copy-constructor-properties.js");
var proxyAccessor = __webpack_require__(/*! ../internals/proxy-accessor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/proxy-accessor.js");
var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/inherit-if-required.js");
var normalizeStringArgument = __webpack_require__(/*! ../internals/normalize-string-argument */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/normalize-string-argument.js");
var installErrorCause = __webpack_require__(/*! ../internals/install-error-cause */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/install-error-cause.js");
var installErrorStack = __webpack_require__(/*! ../internals/error-stack-install */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/error-stack-install.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");
var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/is-pure.js");

module.exports = function (FULL_NAME, wrapper, FORCED, IS_AGGREGATE_ERROR) {
  var STACK_TRACE_LIMIT = 'stackTraceLimit';
  var OPTIONS_POSITION = IS_AGGREGATE_ERROR ? 2 : 1;
  var path = FULL_NAME.split('.');
  var ERROR_NAME = path[path.length - 1];
  var OriginalError = getBuiltIn.apply(null, path);

  if (!OriginalError) return;

  var OriginalErrorPrototype = OriginalError.prototype;

  // V8 9.3- bug https://bugs.chromium.org/p/v8/issues/detail?id=12006
  if (!IS_PURE && hasOwn(OriginalErrorPrototype, 'cause')) delete OriginalErrorPrototype.cause;

  if (!FORCED) return OriginalError;

  var BaseError = getBuiltIn('Error');

  var WrappedError = wrapper(function (a, b) {
    var message = normalizeStringArgument(IS_AGGREGATE_ERROR ? b : a, undefined);
    var result = IS_AGGREGATE_ERROR ? new OriginalError(a) : new OriginalError();
    if (message !== undefined) createNonEnumerableProperty(result, 'message', message);
    installErrorStack(result, WrappedError, result.stack, 2);
    if (this && isPrototypeOf(OriginalErrorPrototype, this)) inheritIfRequired(result, this, WrappedError);
    if (arguments.length > OPTIONS_POSITION) installErrorCause(result, arguments[OPTIONS_POSITION]);
    return result;
  });

  WrappedError.prototype = OriginalErrorPrototype;

  if (ERROR_NAME !== 'Error') {
    if (setPrototypeOf) setPrototypeOf(WrappedError, BaseError);
    else copyConstructorProperties(WrappedError, BaseError, { name: true });
  } else if (DESCRIPTORS && STACK_TRACE_LIMIT in OriginalError) {
    proxyAccessor(WrappedError, OriginalError, STACK_TRACE_LIMIT);
    proxyAccessor(WrappedError, OriginalError, 'prepareStackTrace');
  }

  copyConstructorProperties(WrappedError, OriginalError);

  if (!IS_PURE) try {
    // Safari 13- bug: WebAssembly errors does not have a proper `.name`
    if (OriginalErrorPrototype.name !== ERROR_NAME) {
      createNonEnumerableProperty(OriginalErrorPrototype, 'name', ERROR_NAME);
    }
    OriginalErrorPrototype.constructor = WrappedError;
  } catch (error) { /* empty */ }

  return WrappedError;
};


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.array.includes.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.array.includes.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js");
var $includes = (__webpack_require__(/*! ../internals/array-includes */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/array-includes.js").includes);
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/fails.js");
var addToUnscopables = __webpack_require__(/*! ../internals/add-to-unscopables */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/add-to-unscopables.js");

// FF99+ bug
var BROKEN_ON_SPARSE = fails(function () {
  // eslint-disable-next-line es/no-array-prototype-includes -- detection
  return !Array(1).includes();
});

// `Array.prototype.includes` method
// https://tc39.es/ecma262/#sec-array.prototype.includes
$({ target: 'Array', proto: true, forced: BROKEN_ON_SPARSE }, {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables('includes');


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.error.cause.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/es.error.cause.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

/* eslint-disable no-unused-vars -- required for functions `.length` */
var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var apply = __webpack_require__(/*! ../internals/function-apply */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/function-apply.js");
var wrapErrorConstructorWithCause = __webpack_require__(/*! ../internals/wrap-error-constructor-with-cause */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/wrap-error-constructor-with-cause.js");

var WEB_ASSEMBLY = 'WebAssembly';
var WebAssembly = globalThis[WEB_ASSEMBLY];

// eslint-disable-next-line es/no-error-cause -- feature detection
var FORCED = new Error('e', { cause: 7 }).cause !== 7;

var exportGlobalErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  var O = {};
  O[ERROR_NAME] = wrapErrorConstructorWithCause(ERROR_NAME, wrapper, FORCED);
  $({ global: true, constructor: true, arity: 1, forced: FORCED }, O);
};

var exportWebAssemblyErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  if (WebAssembly && WebAssembly[ERROR_NAME]) {
    var O = {};
    O[ERROR_NAME] = wrapErrorConstructorWithCause(WEB_ASSEMBLY + '.' + ERROR_NAME, wrapper, FORCED);
    $({ target: WEB_ASSEMBLY, stat: true, constructor: true, arity: 1, forced: FORCED }, O);
  }
};

// https://tc39.es/ecma262/#sec-nativeerror
exportGlobalErrorCauseWrapper('Error', function (init) {
  return function Error(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('EvalError', function (init) {
  return function EvalError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('RangeError', function (init) {
  return function RangeError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('ReferenceError', function (init) {
  return function ReferenceError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('SyntaxError', function (init) {
  return function SyntaxError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('TypeError', function (init) {
  return function TypeError(message) { return apply(init, this, arguments); };
});
exportGlobalErrorCauseWrapper('URIError', function (init) {
  return function URIError(message) { return apply(init, this, arguments); };
});
exportWebAssemblyErrorCauseWrapper('CompileError', function (init) {
  return function CompileError(message) { return apply(init, this, arguments); };
});
exportWebAssemblyErrorCauseWrapper('LinkError', function (init) {
  return function LinkError(message) { return apply(init, this, arguments); };
});
exportWebAssemblyErrorCauseWrapper('RuntimeError', function (init) {
  return function RuntimeError(message) { return apply(init, this, arguments); };
});


/***/ }),

/***/ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/web.self.js":
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/modules/web.self.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/export.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/global-this.js");
var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/define-built-in-accessor.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/.pnpm/core-js@3.40.0/node_modules/core-js/internals/descriptors.js");

var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var INCORRECT_VALUE = globalThis.self !== globalThis;

// `self` getter
// https://html.spec.whatwg.org/multipage/window-object.html#dom-self
try {
  if (DESCRIPTORS) {
    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
    var descriptor = Object.getOwnPropertyDescriptor(globalThis, 'self');
    // some engines have `self`, but with incorrect descriptor
    // https://github.com/denoland/deno/issues/15765
    if (INCORRECT_VALUE || !descriptor || !descriptor.get || !descriptor.enumerable) {
      defineBuiltInAccessor(globalThis, 'self', {
        get: function self() {
          return globalThis;
        },
        set: function self(value) {
          if (this !== globalThis) throw new $TypeError('Illegal invocation');
          defineProperty(globalThis, 'self', {
            value: value,
            writable: true,
            configurable: true,
            enumerable: true
          });
        },
        configurable: true,
        enumerable: true
      });
    }
  } else $({ global: true, simple: true, forced: INCORRECT_VALUE }, {
    self: globalThis
  });
} catch (error) { /* empty */ }


/***/ }),

/***/ "./node_modules/.pnpm/@adguard+logger@1.1.1/node_modules/@adguard/logger/dist/es/index.mjs":
/*!*************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@adguard+logger@1.1.1/node_modules/@adguard/logger/dist/es/index.mjs ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LogLevel: () => (/* binding */ LogLevel),
/* harmony export */   Logger: () => (/* binding */ Logger)
/* harmony export */ });
/**
 * Checks if error has message.
 *
 * @param error Error object.
 * @returns True if error has message.
 */
function isErrorWithMessage(error) {
    return (typeof error === 'object'
        && error !== null
        && 'message' in error
        && typeof error.message === 'string');
}
/**
 * Converts error to the error with a message.
 *
 * @param maybeError Possible error.
 * @returns Error with a message.
 */
function toErrorWithMessage(maybeError) {
    if (isErrorWithMessage(maybeError)) {
        return maybeError;
    }
    try {
        return new Error(JSON.stringify(maybeError));
    }
    catch {
        // fallback in case there's an error stringifying the maybeError
        // like with circular references, for example.
        return new Error(String(maybeError));
    }
}
/**
 * Converts an error object to an error with a message. This method might be helpful to handle thrown errors.
 *
 * @param error Error object.
 *
 * @returns Message of the error.
 */
function getErrorMessage(error) {
    return toErrorWithMessage(error).message;
}

/**
 * Pads a number with leading zeros.
 * @param num The number to pad.
 * @param size The number of digits to pad to.
 * @returns The padded number.
 */
const pad = (num, size = 2) => {
    return num.toString().padStart(size, '0');
};
/**
 * Formats a date into an ISO 8601-like string with milliseconds.
 *
 * @param {Date|number} date The date object or timestamp to format.
 * @returns {string} The formatted date string.
 */
const formatTime = (date) => {
    const d = (date instanceof Date) ? date : new Date(date);
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1); // Months are 0-based
    const day = pad(d.getDate());
    const hour = pad(d.getHours());
    const minute = pad(d.getMinutes());
    const second = pad(d.getSeconds());
    const millisecond = pad(d.getMilliseconds(), 3); // Milliseconds are 3 digits
    return `${year}-${month}-${day}T${hour}:${minute}:${second}:${millisecond}`;
};

/**
 * String presentation of log levels, for convenient users usage.
 */
var LogLevel;
(function (LogLevel) {
    LogLevel["Error"] = "error";
    LogLevel["Warn"] = "warn";
    LogLevel["Info"] = "info";
    LogLevel["Debug"] = "debug";
    LogLevel["Trace"] = "trace";
})(LogLevel || (LogLevel = {}));
/**
 * Log levels map, which maps number level to string level.
 */
const levelMapNumToString = {
    [1 /* LogLevelNumeric.Error */]: LogLevel.Error,
    [2 /* LogLevelNumeric.Warn */]: LogLevel.Warn,
    [3 /* LogLevelNumeric.Info */]: LogLevel.Info,
    [4 /* LogLevelNumeric.Debug */]: LogLevel.Debug,
    [5 /* LogLevelNumeric.Trace */]: LogLevel.Trace,
};
/**
 * Log levels map, which maps string level to number level.
 */
const levelMapStringToNum = Object.entries(levelMapNumToString)
    .reduce((acc, [key, value]) => {
    // Here, key is originally a string since Object.entries() returns [string, string][].
    // We need to cast the key to LogLevelNumeric correctly without causing type mismatches.
    const numericKey = Number(key);
    if (!Number.isNaN(numericKey)) {
        acc[value] = numericKey;
    }
    return acc;
}, {});
/**
 * Simple logger with log levels.
 */
class Logger {
    currentLevelValue = 3 /* LogLevelNumeric.Info */;
    writer;
    /**
     * Constructor.
     * @param writer Writer object.
     */
    constructor(writer = console) {
        this.writer = writer;
        // bind the logging methods to avoid losing context
        this.debug = this.debug.bind(this);
        this.info = this.info.bind(this);
        this.warn = this.warn.bind(this);
        this.error = this.error.bind(this);
    }
    /**
     * Print debug messages. Usually used for technical information.
     * Will be printed in 'log' channel.
     *
     * @param args Printed arguments.
     */
    debug(...args) {
        this.print(4 /* LogLevelNumeric.Debug */, "log" /* LogMethod.Log */, args);
    }
    /**
     * Print messages you want to disclose to users.
     *
     * @param args Printed arguments.
     */
    info(...args) {
        this.print(3 /* LogLevelNumeric.Info */, "info" /* LogMethod.Info */, args);
    }
    /**
     * Print warn messages.
     * NOTE: We do not use 'warn' channel, since in the extensions warn is
     * counted as error. Instead of this we use 'info' channel.
     *
     * @param args Printed arguments.
     */
    warn(...args) {
        this.print(2 /* LogLevelNumeric.Warn */, "info" /* LogMethod.Info */, args);
    }
    /**
     * Print error messages.
     *
     * @param args Printed arguments.
     */
    error(...args) {
        this.print(1 /* LogLevelNumeric.Error */, "error" /* LogMethod.Error */, args);
    }
    /**
     * Getter for log level.
     * @returns Logger level.
     */
    get currentLevel() {
        return levelMapNumToString[this.currentLevelValue];
    }
    /**
     * Setter for log level. With this method log level can be updated dynamically.
     *
     * @param logLevel Logger level.
     * @throws Error if log level is not supported.
     */
    set currentLevel(logLevel) {
        const level = levelMapStringToNum[logLevel];
        if (level === undefined) {
            throw new Error(`Logger supports only the following levels: ${[Object.values(LogLevel).join(', ')]}`);
        }
        this.currentLevelValue = level;
    }
    /**
     * Converts error to string, and adds stack trace.
     *
     * @param error Error to print.
     * @private
     * @returns Error message.
     */
    static errorToString(error) {
        const message = getErrorMessage(error);
        return `${message}\nStack trace:\n${error.stack}`;
    }
    /**
     * Wrapper over log methods.
     *
     * @param level Logger level.
     * @param method Logger method.
     * @param args Printed arguments.
     * @private
     */
    print(level, method, args) {
        // skip writing if the basic conditions are not met
        if (this.currentLevelValue < level) {
            return;
        }
        if (!args || args.length === 0 || !args[0]) {
            return;
        }
        const formattedArgs = args.map((value) => {
            if (value instanceof Error) {
                return Logger.errorToString(value);
            }
            if (value && typeof value.message === 'string') {
                return value.message;
            }
            if (typeof value === 'object' && value !== null) {
                return JSON.stringify(value);
            }
            return String(value);
        });
        const formattedTime = `${formatTime(new Date())}:`;
        /**
         * Conditions in which trace can happen:
         * 1. Method is not error (because console.error provides call stack trace)
         * 2. Log level is equal or higher that `LogLevel.Trace`.
         * 3. Writer has `trace` method.
         */
        if (method === "error" /* LogMethod.Error */
            || this.currentLevelValue < levelMapStringToNum[LogLevel.Trace]
            || !this.writer.trace) {
            // Print with regular method
            this.writer[method](formattedTime, ...formattedArgs);
            return;
        }
        if (!this.writer.groupCollapsed || !this.writer.groupEnd) {
            // Print expanded trace
            this.writer.trace(formattedTime, ...formattedArgs);
            return;
        }
        // Print collapsed trace
        this.writer.groupCollapsed(formattedTime, ...formattedArgs);
        this.writer.trace();
        this.writer.groupEnd();
    }
}




/***/ }),

/***/ "./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js":
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   nanoid: () => (/* binding */ nanoid)
/* harmony export */ });
/* unused harmony exports customAlphabet, customRandom, random */

let random = bytes => crypto.getRandomValues(new Uint8Array(bytes))
let customRandom = (alphabet, defaultSize, getRandom) => {
  let mask = (2 << (Math.log(alphabet.length - 1) / Math.LN2)) - 1
  let step = -~((1.6 * mask * defaultSize) / alphabet.length)
  return (size = defaultSize) => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      let j = step
      while (j--) {
        id += alphabet[bytes[j] & mask] || ''
        if (id.length === size) return id
      }
    }
  }
}
let customAlphabet = (alphabet, size = 21) =>
  customRandom(alphabet, size, random)
let nanoid = (size = 21) =>
  crypto.getRandomValues(new Uint8Array(size)).reduce((id, byte) => {
    byte &= 63
    if (byte < 36) {
      id += byte.toString(36)
    } else if (byte < 62) {
      id += (byte - 26).toString(36).toUpperCase()
    } else if (byte > 62) {
      id += '-'
    } else {
      id += '_'
    }
    return id
  }, '')



/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/amd options */
/******/ 	(() => {
/******/ 		__webpack_require__.amdO = {};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!*******************************************!*\
  !*** ./Extension/pages/thankyou/index.js ***!
  \*******************************************/
/* harmony import */ var _src_pages_thankyou__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../src/pages/thankyou */ "./Extension/src/pages/thankyou.ts");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 
_src_pages_thankyou__WEBPACK_IMPORTED_MODULE_0__.thankyou.init();

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvdGhhbmt5b3UuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLDBCQUEwQixjQUFjO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSw2Q0FBNkM7QUFDN0M7O0FBRUE7QUFDQTs7QUFFQSxxQ0FBcUM7QUFDckM7O0FBRUE7QUFDQSxvQ0FBb0Msa0JBQWtCO0FBQ3REO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzs7QUFFVDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsbUJBQW1CO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsZ0NBQWdDLElBQUk7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxJQUFJO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHNEQUFzRCxnQkFBZ0I7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSw4Q0FBOEMsR0FBRztBQUNqRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0I7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUEsc0RBQXNEO0FBQ3REOztBQUVBLHNCQUFzQjtBQUN0Qjs7QUFFQSwrQkFBK0I7QUFDL0I7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0Esa0NBQWtDLElBQUk7QUFDdEM7O0FBRUEsOENBQThDO0FBQzlDOztBQUVBLHVCQUF1QjtBQUN2Qjs7QUFFQSwrQkFBK0IsMENBQTBDO0FBQ3pFO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxrREFBa0QsSUFBSSxXQUFXLElBQUk7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLG1EQUFtRDtBQUNuRDtBQUNBLHNCQUFzQixTQUFTO0FBQy9CO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0EseUJBQXlCO0FBQ3pCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHdEQUF3RCxFQUFFO0FBQzFEO0FBQ0Esd0NBQXdDO0FBQ3hDLDRCQUE0QixJQUFJO0FBQ2hDOztBQUVBO0FBQ0EsZ0NBQWdDLEVBQUUsV0FBVyxFQUFFO0FBQy9DLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxlQUFlO0FBQ2YsMEJBQTBCLEVBQUU7QUFDNUI7O0FBRUE7QUFDQTtBQUNBLHdCQUF3QixFQUFFLGlCQUFpQjtBQUMzQzs7QUFFQTtBQUNBLDBCQUEwQixFQUFFLFVBQVU7QUFDdEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLElBQUk7QUFDekM7QUFDQSxnQ0FBZ0MsSUFBSTtBQUNwQzs7QUFFQTtBQUNBLGdDQUFnQyxFQUFFLGdCQUFnQixFQUFFLEdBQUcsYUFBYSxJQUFJO0FBQ3hFO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsNkRBQTZELEVBQUUsV0FBVyxFQUFFO0FBQzVFOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixlQUFlLElBQUk7QUFDekM7O0FBRUE7QUFDQSxnQ0FBZ0MsRUFBRSxXQUFXLEVBQUUseURBQXlELElBQUk7QUFDNUc7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHNCQUFzQixFQUFFLFlBQVksRUFBRTtBQUN0QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHdCQUF3QixTQUFTO0FBQ2pDO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7O0FBRUE7QUFDQSwwQ0FBMEMsTUFBTTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLElBQUksSUFBSTs7QUFFN0I7QUFDQTtBQUNBLHdEQUF3RDtBQUN4RDs7QUFFQTtBQUNBLHNCQUFzQjtBQUN0Qjs7QUFFQTtBQUNBLHNCQUFzQjtBQUN0Qix5QkFBeUIsR0FBRztBQUM1Qjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxJQUFJO0FBQ3RDLGdDQUFnQyxFQUFFO0FBQ2xDLGdDQUFnQyxJQUFJO0FBQ3BDO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixJQUFJO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsRUFBRTtBQUN2QjtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsRUFBRTtBQUN2QjtBQUNBLHNCQUFzQixFQUFFO0FBQ3hCO0FBQ0Esc0JBQXNCLEVBQUU7QUFDeEI7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLEVBQUU7QUFDekIseUNBQXlDLEVBQUU7QUFDM0M7QUFDQSx1QkFBdUIsSUFBSTtBQUMzQjtBQUNBLCtCQUErQixJQUFJO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsRUFBRTtBQUM3QjtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBLHNCQUFzQjtBQUN0Qjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixFQUFFO0FBQ3hCO0FBQ0EscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQSwrQ0FBK0MsV0FBVyxJQUFJLElBQUk7QUFDbEU7QUFDQSxxREFBcUQ7QUFDckQ7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsV0FBVztBQUM3Qzs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQSxzQkFBc0IsUUFBUSxJQUFJO0FBQ2xDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLHdCQUF3QixJQUFJO0FBQzVCO0FBQ0Esd0JBQXdCLElBQUk7QUFDNUI7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQSw4QkFBOEIsSUFBSSxFQUFFO0FBQ3BDO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHlCQUF5QixJQUFJO0FBQzdCO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSx3QkFBd0IsSUFBSSw2QkFBNkI7QUFDekQsb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0EsMENBQTBDO0FBQzFDO0FBQ0EsNERBQTRELFNBQVM7QUFDckU7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBOztBQUVBO0FBQ0E7QUFDQSxxQkFBcUIsWUFBWTs7QUFFakM7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLElBQUksbUNBQW1DLElBQUk7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwRUFBMEU7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFFBQWE7QUFDekI7QUFDQTtBQUNBLFFBQVEsZ0JBQWdCO0FBQ3hCLE1BQU07QUFDTjtBQUNBLFlBQVksVUFBYyxrQkFBa0Isd0JBQVU7QUFDdEQsWUFBWSxtQ0FBTztBQUNuQjtBQUNBLGFBQWE7QUFBQSxrR0FBQztBQUNkLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLENBQUM7Ozs7Ozs7Ozs7O0FDbjZCRDtBQUNBLE1BQU0sSUFBMEM7QUFDaEQsSUFBSSxpQ0FBZ0MsQ0FBQyxNQUFRLENBQUMsb0NBQUUsT0FBTztBQUFBO0FBQUE7QUFBQSxrR0FBQztBQUN4RCxJQUFJLEtBQUssWUFRTjtBQUNILENBQUM7QUFDRDtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsVUFBVTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixHQUFHO0FBQ3BCLG1CQUFtQixTQUFTO0FBQzVCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsUUFBUTtBQUN6QjtBQUNBO0FBQ0EsaUJBQWlCLFVBQVU7QUFDM0I7QUFDQSxpQkFBaUIsVUFBVTtBQUMzQjtBQUNBLGlCQUFpQixRQUFRO0FBQ3pCO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQSxpQkFBaUIsUUFBUTtBQUN6QjtBQUNBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsa0JBQWtCLEVBQUUsc0NBQXNDLE1BQU0sS0FBSyxVQUFVLFlBQVk7QUFDNUk7QUFDQTtBQUNBLGdEQUFnRCxrQkFBa0IsRUFBRSxzQ0FBc0MsTUFBTSxLQUFLLFVBQVUsWUFBWTtBQUMzSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixnQkFBZ0I7QUFDaEIsZ0NBQWdDLE1BQU07QUFDdEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0EsV0FBVztBQUNYO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQSxpQkFBaUIsVUFBVTtBQUMzQjtBQUNBO0FBQ0EsaUJBQWlCLFVBQVU7QUFDM0I7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixRQUFRO0FBQ3pCO0FBQ0E7QUFDQSxpQkFBaUIsUUFBUSxjQUFjO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RCxnQkFBZ0I7QUFDN0U7QUFDQSxpQkFBaUIsUUFBUSxjQUFjO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQSwrQ0FBK0MsZUFBZTtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLG9DQUFvQztBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLFFBQVE7QUFDM0I7QUFDQTtBQUNBO0FBQ0EsZ0RBQWdEO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLEdBQUc7QUFDdEI7QUFDQSxtQkFBbUIsUUFBUTtBQUMzQjtBQUNBLG1CQUFtQixhQUFhO0FBQ2hDO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxrQkFBa0IsRUFBRSxzQ0FBc0MsTUFBTSxLQUFLLFVBQVUsWUFBWTtBQUMxSTtBQUNBO0FBQ0EsOENBQThDLGtCQUFrQixFQUFFLHNDQUFzQyxNQUFNLEtBQUssVUFBVSxZQUFZO0FBQ3pJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hzQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJDLEdBd0IyQjtBQXRCdUI7QUFFbkQsTUFBTUUsdUJBQXVCRixtREFBTUE7SUFDL0JHLFlBQXFCO1FBQ2pCLE9BQU8sSUFBSSxDQUFDQyxZQUFZLEtBQUtILHFEQUFRQSxDQUFDSSxLQUFLLElBQ25DLElBQUksQ0FBQ0QsWUFBWSxLQUFLSCxxREFBUUEsQ0FBQ0ssS0FBSztJQUNoRDtBQUNKO0FBRUEsTUFBTUMsU0FBUyxJQUFJTDtBQUVuQkssT0FBT0gsWUFBWSxHQUFHSSxNQUFxQkMsR0FDckNSLENBQWEsR0FDYkEscURBQVFBLENBQUNLLEtBQUs7QUFFcEIsc0NBQXNDO0FBQ3RDLDREQUE0RDtBQUM1RCxpREFBaUQ7QUFFakQsaURBQWlEO0FBQ2pESyxPQUFPQyxNQUFNLENBQUNDLE1BQU07SUFBRUMsU0FBUztRQUFFLEdBQUdELEtBQUtDLE9BQU87UUFBRVA7SUFBTztBQUFFO0FBRS9COzs7Ozs7Ozs7Ozs7Ozs7O0FDekM1Qjs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUVEOzs7Ozs7Q0FNQyxHQTJCTSxNQUFNUSwyQkFBMkIsTUFBTTtBQU05Qzs7O0NBR0MsR0FDTSx5Q0FBS0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7V0FBQUE7TUFrRlg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9JRDs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUUyQjtBQUNHO0FBQ0c7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQmxDOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JDOzs7Ozs7Ozs7Ozs7O0FBeUhBO0FBeEh3RDtBQVdwQztBQU9yQjs7Ozs7Ozs7Q0FRQyxHQUNNLE1BQU1FLHNCQUFzQixDQUFDQztJQUNoQyxPQUFPLE9BQU9BLFlBQVksWUFBWUEsWUFBWSxRQUFRLFVBQVVBO0FBQ3hFLEVBQUU7QUFFRjs7Ozs7Ozs7Q0FRQyxHQUNNLE1BQU1DLDhCQUE4QixDQUFDRDtJQUN4QyxPQUFPRCxvQkFBb0JDLFlBQVksVUFBVUE7QUFDckQsRUFBRTtBQUVGOztDQUVDLEdBQ00sTUFBZUU7SUFPWEMsT0FBYTtRQUNoQkwsb0VBQWUsQ0FBQ08sU0FBUyxDQUFDQyxXQUFXLENBQUMsSUFBSSxDQUFDQyxhQUFhO0lBQzVEO0lBRUE7Ozs7Ozs7Ozs7O0tBV0MsR0FDRCxZQUNJQyxJQUFPLEVBQ1BDLFFBQTRCLEVBQ3hCO1FBQ0osSUFBSSxJQUFJLENBQUNDLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDSCxPQUFPO1lBQzFCLE1BQU0sSUFBSUksTUFBTSxDQUFDLGlCQUFpQixFQUFFSixLQUFLLHFDQUFxQyxDQUFDO1FBQ25GO1FBRUEscUVBQXFFO1FBQ3JFLHlEQUF5RDtRQUN6RCxJQUFJLENBQUNFLFNBQVMsQ0FBQ0csR0FBRyxDQUFDTCxNQUFNQztJQUM3QjtJQUVBOzs7O0tBSUMsR0FDRCxlQUFtREQsSUFBTyxFQUFRO1FBQzlELElBQUksQ0FBQ0UsU0FBUyxDQUFDSyxNQUFNLENBQUNQO0lBQzFCO0lBRUE7O0tBRUMsR0FDRCxrQkFBK0I7UUFDM0IsSUFBSSxDQUFDRSxTQUFTLENBQUNPLEtBQUs7SUFDeEI7SUFFQTs7Ozs7O0tBTUMsR0FDRCxPQUFpQkMsbUJBQW1CbEIsT0FBZ0MsRUFBc0I7UUFDdEYsT0FBT0EsUUFBUW1CLFdBQVcsS0FBS3ZCLGdFQUF3QkEsSUFBSSxVQUFVSTtJQUN6RTtJQTFEQW9CLGFBQWM7UUFGZCx1QkFBVVYsYUFBWSxJQUFJVztRQUd0QixJQUFJLENBQUNkLGFBQWEsR0FBRyxJQUFJLENBQUNBLGFBQWEsQ0FBQ2UsSUFBSSxDQUFDLElBQUk7SUFDckQ7QUFvRUo7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6SUE7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FFMkM7QUFNdkI7QUFFckI7Ozs7Ozs7Ozs7O0NBV0MsR0FDTSxlQUFlQyxZQUNsQnZCLE9BQXFDO0lBRXJDLElBQUk7UUFDQSxPQUFPLE1BQU1GLG9FQUFlLENBQUN5QixXQUFXLENBQUM7WUFDckNKLGFBQWF2QixnRUFBd0JBO1lBQ3JDLEdBQUdJLE9BQU87UUFDZDtJQUNKLEVBQUUsT0FBT3dCLEdBQUc7SUFDUixhQUFhO0lBQ2pCO0FBQ0o7QUFFQTs7Ozs7Ozs7Q0FRQyxHQUNNLGVBQWVDLGVBQ2xCQyxLQUFhLEVBQ2IxQixPQUFxQztJQUVyQyxPQUFPRixpRUFBWSxDQUFDeUIsV0FBVyxDQUFDRyxPQUFPO1FBQ25DUCxhQUFhdkIsZ0VBQXdCQTtRQUNyQyxHQUFHSSxPQUFPO0lBQ2Q7QUFDSjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEVBOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JDOzs7Ozs7Ozs7Ozs7O0FBRW1DO0FBRXVCO0FBRTNEOzs7O0NBSUMsR0FDTSxNQUFNOEI7SUFXVDs7OztLQUlDLEdBQ0QsT0FBT0MsaUJBQXFDO1FBQ3hDLE9BQU9ELFVBQVVFLGVBQWUsR0FFMUIsbUJBQ0FGLFVBQVVHLE1BQU0sQ0FBQ0MsVUFBVSxHQUFHQyxJQUFJO0lBQzVDO0lBRUE7Ozs7S0FJQyxHQUNELE9BQU9DLGdCQUFvQztRQUN2QyxPQUFPTixVQUFVRyxNQUFNLENBQUNJLEtBQUssR0FBR0YsSUFBSTtJQUN4QztJQUVBOzs7O0tBSUMsR0FDRCxPQUFPRyxtQkFBdUM7UUFDMUMsT0FBT1IsVUFBVUcsTUFBTSxDQUFDSSxLQUFLLEdBQUdFLE9BQU87SUFDM0M7SUFFQTs7Ozs7S0FLQyxHQUNELGFBQWFDLHFCQUFrRDtRQUMzRCxJQUFJQztRQUNKLElBQUk7WUFDQSxhQUFhO1lBQ2IsTUFBTUMsS0FBSyxNQUFNQyxVQUFVQyxhQUFhLENBQUNDLG9CQUFvQixDQUFDO2dCQUFDZixVQUFVZ0IsZ0JBQWdCO2FBQUM7WUFDMUZMLGtCQUFrQkMsRUFBRSxDQUFDWixVQUFVZ0IsZ0JBQWdCLENBQUM7UUFDcEQsRUFBRSxPQUFPdEIsR0FBRztRQUNSLGFBQWE7UUFDakI7UUFDQSxPQUFPaUI7SUFDWDtJQUVBOzs7Ozs7S0FNQyxHQUNELGFBQWFNLHdCQUF3QlIsT0FBZSxFQUFtQjtRQUNuRSxJQUFJUyxnQkFBZ0JUO1FBQ3BCLE1BQU1FLGtCQUFrQixNQUFNWCxVQUFVVSxrQkFBa0I7UUFFMUQsSUFBSSxPQUFPQyxvQkFBb0IsYUFBYTtZQUN4QyxNQUFNUSwwQkFBMEJSLGdCQUFnQlMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdELE1BQU1DLHVCQUF1QkYsMkJBQTJCRyxTQUFTSCx5QkFBeUI7WUFFMUYsSUFBSSxDQUFDRSx3QkFDRUUsT0FBT0MsS0FBSyxDQUFDSCx1QkFBdUI7Z0JBQ3ZDLE9BQU9IO1lBQ1g7WUFFQSxJQUFJRyx3QkFBd0JyQixVQUFVeUIsK0JBQStCLEVBQUU7Z0JBQ25FUCxnQkFBZ0JsQixVQUFVMEIscUJBQXFCO1lBQ25EO1FBQ0o7UUFFQSxPQUFPUjtJQUNYO0lBRUE7Ozs7OztLQU1DLEdBQ0QsYUFBYVMsc0JBQXNCbEIsT0FBZSxFQUFtQjtRQUNqRSxJQUFJUyxnQkFBZ0JUO1FBQ3BCLE1BQU1FLGtCQUFrQixNQUFNWCxVQUFVVSxrQkFBa0I7UUFFMUQsSUFBSSxPQUFPQyxvQkFBb0IsYUFBYTtZQUN4Q08sZ0JBQWdCUDtRQUNwQjtRQUVBLE9BQU9PO0lBQ1g7SUFFQTs7OztLQUlDLEdBQ0QsYUFBYVUsZ0JBQTZDO1FBQ3RELElBQUlDLGFBQXFCO1FBQ3pCLE1BQU1DLFNBQVM5QixVQUFVTSxhQUFhO1FBQ3RDLElBQUl5QixZQUFZL0IsVUFBVVEsZ0JBQWdCO1FBRTFDLElBQUksT0FBT3NCLFdBQVcsYUFBYTtZQUMvQkQsY0FBY0M7UUFDbEI7UUFFQSxJQUFJLE9BQU9DLGNBQWMsYUFBYTtZQUNsQyxxREFBcUQ7WUFDckQsSUFBSS9CLFVBQVVnQyxTQUFTLElBQUlELGNBQWMvQixVQUFVaUMscUJBQXFCLEVBQUU7Z0JBQ3RFRixZQUFZLE1BQU0vQixVQUFVaUIsdUJBQXVCLENBQUNjO1lBQ3hELE9BQU8sSUFBSS9CLFVBQVVrQyxPQUFPLEVBQUU7Z0JBQzFCLDBEQUEwRDtnQkFDMUQsd0RBQXdEO2dCQUN4REgsWUFBWSxNQUFNL0IsVUFBVTJCLHFCQUFxQixDQUFDSTtZQUN0RDtZQUNBRixjQUFjLENBQUMsQ0FBQyxFQUFFRSxXQUFXO1FBQ2pDO1FBRUEsSUFBSUYsV0FBV00sTUFBTSxLQUFLLEdBQUc7WUFDekIsT0FBT0M7UUFDWDtRQUVBLE9BQU9QO0lBQ1g7SUFFQTs7Ozs7O0tBTUMsR0FDRCxPQUFPUSxnQkFBZ0JDLFdBQW1CLEVBQVc7UUFDakQsT0FBT3RDLFVBQVVHLE1BQU0sQ0FBQ0MsVUFBVSxHQUFHQyxJQUFJLEtBQUtpQztJQUNsRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE9BQU9DLGlCQUFpQkMsWUFBb0IsRUFBVztRQUNuRCxPQUFPeEMsVUFBVU0sYUFBYSxPQUFPa0M7SUFDekM7SUFFQTs7Ozs7O0tBTUMsR0FDRCxPQUFPQyxlQUFlQyxVQUFrQixFQUFXO1FBQy9DLE9BQU8xQyxVQUFVRyxNQUFNLENBQUN3QyxTQUFTLEdBQUd0QyxJQUFJLEtBQUtxQztJQUNqRDtJQUVBLE9BQU9FLG1CQUFtQkMsVUFBa0IsRUFBVztRQUNuRCxPQUFPN0MsVUFBVUcsTUFBTSxDQUFDMkMsU0FBUyxHQUFHcEUsSUFBSSxLQUFLbUU7SUFDakQ7SUFFQTs7OztLQUlDLEdBQ0QsT0FBT0UsYUFBaUM7WUFFUC9FO1FBRDdCLE1BQU1BLFVBQVUsSUFBSSxDQUFDbUMsTUFBTSxDQUFDQyxVQUFVO1FBQ3RDLE1BQU00QyxnQkFBZ0J6QixRQUFPdkQsbUJBQUFBLFFBQVF5QyxPQUFPLGNBQWZ6Qyx1Q0FBQUEsaUJBQWlCb0QsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQzNELE9BQU9HLE9BQU9DLEtBQUssQ0FBQ3dCLGlCQUFpQlosWUFBWVk7SUFDckQ7QUFtQ0o7QUExTkksaUJBRFNoRCxXQUNGaUMseUJBQXdCO0FBRS9CLGlCQUhTakMsV0FHRjBCLHlCQUF3QjtBQUUvQixpQkFMUzFCLFdBS0ZnQixvQkFBbUI7QUFFMUIsaUJBUFNoQixXQU9GeUIsbUNBQWtDO0FBRXpDLGlCQVRTekIsV0FTRkcsVUFBUyxJQUFJTCxxREFBUUEsQ0FBQ2UsVUFBVW9DLFNBQVM7QUFpTGhELGlCQTFMU2pELFdBMExGUyxXQUFVVCxVQUFVK0MsVUFBVTtBQUVyQyxpQkE1TFMvQyxXQTRMRmtELFlBQVdsRCxVQUFVcUMsZUFBZSxDQUFDO0FBRTVDLGlCQTlMU3JDLFdBOExGbUQsYUFBWW5ELFVBQVVxQyxlQUFlLENBQUM7QUFFN0MsaUJBaE1TckMsV0FnTUZvRCxXQUFVcEQsVUFBVXFDLGVBQWUsQ0FBQztBQUUzQyxpQkFsTVNyQyxXQWtNRnFELFlBQVdyRCxVQUFVcUMsZUFBZSxDQUFDO0FBRTVDLGlCQXBNU3JDLFdBb01Gc0QsVUFBU3RELFVBQVVxQyxlQUFlLENBQUM7QUFFMUMsaUJBdE1TckMsV0FzTUZ1RCxrQkFBaUJ2RCxVQUFVc0QsTUFBTSxJQUFJLENBQUMsQ0FBRXRELENBQUFBLFVBQVVTLE9BQU8sSUFBSVQsVUFBVVMsT0FBTyxJQUFJLEVBQUM7QUFFMUYsaUJBeE1TVCxXQXdNRmtDLFdBQVVsQyxVQUFVdUMsZ0JBQWdCLENBQUM7QUFFNUMsaUJBMU1TdkMsV0EwTUZnQyxhQUFZaEMsVUFBVXVDLGdCQUFnQixDQUFDO0FBRTlDLGlCQTVNU3ZDLFdBNE1Gd0QsYUFBWXhELFVBQVV1QyxnQkFBZ0IsQ0FBQztBQUU5QyxpQkE5TVN2QyxXQThNRnlELGNBQWF6RCxVQUFVeUMsY0FBYyxDQUFDO0FBRTdDLGlCQWhOU3pDLFdBZ05GMEQsa0JBQWlCMUQsVUFBVTRDLGtCQUFrQixDQUFDO0FBRXJELGlCQWxOUzVDLFdBa05GRSxtQkFBa0JGLFVBQVVtRCxTQUFTLElBQUluRCxVQUFVMEQsY0FBYztBQUV4RSxpQkFwTlMxRCxXQW9ORjJELHNCQUFxQixVQUFXVCxRQUFRLElBQUkzQixPQUFPdkIsVUFBVVMsT0FBTyxLQUFLViw2REFBcUJBLENBQUM2RCxZQUFZLElBQzFHNUQsVUFBVXVELGNBQWMsSUFBSWhDLE9BQU92QixVQUFVUyxPQUFPLEtBQUtWLDZEQUFxQkEsQ0FBQzhELGFBQWEsSUFDNUY3RCxVQUFVbUQsU0FBUyxJQUFJNUIsT0FBT3ZCLFVBQVVTLE9BQU8sS0FBS1YsNkRBQXFCQSxDQUFDK0QsT0FBTyxJQUNqRjlELFVBQVVFLGVBQWUsSUFBSXFCLE9BQU92QixVQUFVUyxPQUFPLEtBQUtWLDZEQUFxQkEsQ0FBQ2dFLGNBQWMsSUFDOUYvRCxVQUFVb0QsT0FBTyxJQUFJN0IsT0FBT3ZCLFVBQVVTLE9BQU8sS0FBS1YsNkRBQXFCQSxDQUFDaUUsS0FBSztBQUVyRixpQkExTlNoRSxXQTBORnNDLGVBQWN0QyxVQUFVQyxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JQakQ7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkM7Ozs7Ozs7Ozs7Ozs7QUFnL0IrQjtBQTkrQlk7QUFDWjtBQUVhO0FBTWQ7QUE0RHhCLGtDQUFXaUU7OztXQUFBQTtNQUdqQjtBQUlEOzs7Q0FHQyxHQUNELE1BQU1DO0lBYUY7Ozs7Ozs7Ozs7OztLQVlDLEdBQ0Qsa0RBQWtEO0lBQ2xELE1BQWMxRSxZQUNWZixJQUEwQyxFQUMxQzBGLElBQTJHLEVBQ3pFO1FBQ2xDLE1BQU1DLFdBQVcsTUFBTXJHLG9FQUFlLENBQUN5QixXQUFXLENBQUM7WUFDL0NKLGFBQWF2QixzRUFBd0JBO1lBQ3JDWTtZQUNBMEY7UUFDSjtRQUVBLE9BQU9DO0lBQ1g7SUFvSkE7Ozs7S0FJQyxHQUNELE1BQU1DLGtCQUFnRjtRQUNsRixPQUFPLElBQUksQ0FBQzdFLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDd0csZUFBZTtJQUN2RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGlCQUE4RTtRQUNoRixPQUFPLElBQUksQ0FBQy9FLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDMEcsY0FBYztJQUN0RDtJQUVBOzs7Ozs7O0tBT0MsR0FDRCxNQUFNQyxrQkFDRkMsU0FBa0QsRUFDbERDLEtBQWdELEVBQ2U7UUFDL0QsTUFBTSxJQUFJLENBQUNuRixXQUFXLENBQ2xCMUIseURBQVdBLENBQUM4RyxrQkFBa0IsRUFDOUI7WUFDSUMsS0FBS0g7WUFDTEM7UUFDSjtJQUVSO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1HLHFCQUFzRjtRQUN4RixPQUFPLElBQUksQ0FBQ3RGLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDaUgsa0JBQWtCO0lBQzFEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLGtCQUFnRjtRQUNsRixPQUFPLElBQUksQ0FBQ3hGLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDbUgsZUFBZTtJQUN2RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGFBQ0ZDLFFBQXVELEVBQ1E7UUFDL0QsT0FBTyxJQUFJLENBQUMzRixXQUFXLENBQUMxQix5REFBV0EsQ0FBQ3NILGtCQUFrQixFQUFFO1lBQUVEO1FBQVM7SUFDdkU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNRSxjQUNGRixRQUFrRCxFQUNRO1FBQzFELE9BQU8sSUFBSSxDQUFDM0YsV0FBVyxDQUFDMUIseURBQVdBLENBQUN3SCxhQUFhLEVBQUU7WUFBRUg7UUFBUztJQUNsRTtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1JLGtCQUNGQyxJQUE4QyxFQUNnQjtRQUM5RCxPQUFPLElBQUksQ0FBQ2hHLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDMkgsaUJBQWlCLEVBQUU7WUFBRUQ7UUFBSztJQUNsRTtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNRSxtQkFBa0Y7UUFDcEYsT0FBTyxJQUFJLENBQUNsRyxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzZILGdCQUFnQjtJQUN4RDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxrQkFBcUY7UUFDdkYsT0FBTyxJQUFJLENBQUNwRyxXQUFXLENBQUMxQix5REFBV0EsQ0FBQytILG9CQUFvQjtJQUM1RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLDJCQUNGQyxXQUFxRSxFQUNFO1FBQ3ZFLE9BQU8sSUFBSSxDQUFDdkcsV0FBVyxDQUFDMUIseURBQVdBLENBQUNrSSwwQkFBMEIsRUFBRTtZQUFFRDtRQUFZO0lBQ2xGO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1FLGdCQUE0RTtRQUM5RSxPQUFPLElBQUksQ0FBQ3pHLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDb0ksYUFBYTtJQUNyRDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxlQUEwRTtRQUM1RSxPQUFPLElBQUksQ0FBQzNHLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDc0ksWUFBWTtJQUNwRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLGNBQ0YxQixLQUE0QyxFQUNjO1FBQzFELE1BQU0sSUFBSSxDQUFDbkYsV0FBVyxDQUFDMUIseURBQVdBLENBQUN3SSxhQUFhLEVBQUU7WUFBRTNCO1FBQU07SUFDOUQ7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTTRCLDBCQUFnRztRQUNsRyxPQUFPLElBQUksQ0FBQy9HLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDMEksdUJBQXVCO0lBQy9EO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLGVBQWlGO1FBQ25GLE9BQU8sSUFBSSxDQUFDakgsV0FBVyxDQUFDMUIseURBQVdBLENBQUM0SSxtQkFBbUI7SUFDM0Q7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNQyxjQUNGaEMsS0FBNEMsRUFDcUI7UUFDakUsTUFBTSxJQUFJLENBQUNuRixXQUFXLENBQUMxQix5REFBV0EsQ0FBQzhJLG9CQUFvQixFQUFFO1lBQUVqQztRQUFNO0lBQ3JFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTWtDLHNCQUNGQyxTQUE0RCxFQUNNO1FBQ2xFLE1BQU0sSUFBSSxDQUFDdEgsV0FBVyxDQUFDMUIseURBQVdBLENBQUNpSixxQkFBcUIsRUFBRTtZQUFFRDtRQUFVO0lBQzFFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1FLGdCQUFpRjtRQUNuRixJQUFJQyxJQUFVQSxFQUFFO1lBQ1o1SixrREFBTUEsQ0FBQzZKLEtBQUssQ0FBQztZQUNiLE9BQU8sRUFBRTtRQUNiO1FBRUEsT0FBTyxJQUFJLENBQUMxSCxXQUFXLENBQUMxQix5REFBV0EsQ0FBQ3FKLGtCQUFrQjtJQUMxRDtJQUVBOzs7Ozs7O0tBT0MsR0FDRCxNQUFNQyxrQkFDRkMsRUFBVSxFQUNWQyxPQUFnQixFQUNpRjtRQUNqRyxNQUFNN0ksT0FBTzZJLFVBQVV4Six5REFBV0EsQ0FBQ3lKLGtCQUFrQixHQUFHekoseURBQVdBLENBQUMwSixtQkFBbUI7UUFDdkYsTUFBTUMsVUFBVW5HLE9BQU9ELFFBQVEsQ0FBQ2dHLElBQUk7UUFFcEMsT0FBTyxJQUFJLENBQUM3SCxXQUFXLENBQUNmLE1BQU07WUFBRWdKO1FBQVE7SUFDNUM7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNQyxvQkFDRkMsU0FBMEQsRUFDTTtRQUNoRSxPQUFPLElBQUksQ0FBQ25JLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDOEosbUJBQW1CLEVBQUU7WUFBRUQ7UUFBVTtJQUN6RTtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1FLHFCQUNGMUMsUUFBeUQsRUFDUTtRQUNqRSxPQUFPLElBQUksQ0FBQzNGLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDZ0ssb0JBQW9CLEVBQUU7WUFBRTNDO1FBQVM7SUFDekU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNNEMsZUFDRkMsR0FBK0MsRUFDa0I7UUFDakUsT0FBTyxJQUFJLENBQUN4SSxXQUFXLENBQUMxQix5REFBV0EsQ0FBQ21LLG9CQUFvQixFQUFFO1lBQUVEO1FBQUk7SUFDcEU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNRSxnQkFDRkMsTUFBd0QsRUFDWTtRQUNwRSxPQUFPLElBQUksQ0FBQzNJLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDc0ssdUJBQXVCLEVBQUU7WUFBRUQ7UUFBTztJQUMxRTtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1FLG1CQUNGbEQsUUFBMkQsRUFDUTtRQUNuRSxNQUFNLElBQUksQ0FBQzNGLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDd0ssc0JBQXNCLEVBQUU7WUFBRW5EO1FBQVM7SUFDMUU7SUFFQTs7Ozs7S0FLQyxHQUNELE1BQU1vRCxxQkFBc0Y7UUFDeEYsT0FBTyxJQUFJLENBQUMvSSxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzBLLGtCQUFrQjtJQUMxRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLG1CQUNGOUksS0FBaUQsRUFDYztRQUMvRCxPQUFPLElBQUksQ0FBQ0gsV0FBVyxDQUFDMUIseURBQVdBLENBQUM0SyxrQkFBa0IsRUFBRTtZQUFFL0k7UUFBTTtJQUNwRTtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1nSixpQ0FDRkMsS0FBK0QsRUFDYztRQUM3RSxPQUFPLElBQUksQ0FBQ3BKLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDK0ssZ0NBQWdDLEVBQUU7WUFBRUQ7UUFBTTtJQUNsRjtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1FLCtCQUNGQyxLQUE2RCxFQUNjO1FBQzNFLE9BQU8sSUFBSSxDQUFDdkosV0FBVyxDQUFDMUIseURBQVdBLENBQUNrTCw4QkFBOEIsRUFBRTtZQUFFRDtRQUFNO0lBQ2hGO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1FLHFCQUFzRjtRQUN4RixPQUFPLElBQUksQ0FBQ3pKLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDb0wsa0JBQWtCO0lBQzFEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLGtCQUFnRjtRQUNsRixPQUFPLElBQUksQ0FBQzNKLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDc0wsZUFBZTtJQUN2RDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxnQkFBNEU7UUFDOUUsT0FBTyxJQUFJLENBQUM3SixXQUFXLENBQUMxQix5REFBV0EsQ0FBQ3dMLGFBQWE7SUFDckQ7SUFFQTs7Ozs7OztLQU9DLEdBQ0QsTUFBTUMsY0FDRnZCLEdBQXVDLEVBQ3ZDd0IsSUFBeUMsRUFDZ0I7UUFDekQsT0FBTyxJQUFJLENBQUNoSyxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzJMLFlBQVksRUFBRTtZQUFFekI7WUFBS3dCO1FBQUs7SUFDbEU7SUFFQTs7Ozs7OztLQU9DLEdBQ0QsTUFBTUUsa0JBQ0YxQixHQUE0QyxFQUM1Q3dCLElBQThDLEVBQ2dCO1FBQzlELE9BQU8sSUFBSSxDQUFDaEssV0FBVyxDQUFDMUIseURBQVdBLENBQUM2TCxpQkFBaUIsRUFBRTtZQUFFM0I7WUFBS3dCO1FBQUs7SUFDdkU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNSSxzQkFDRjVCLEdBQWdELEVBQ2tCO1FBQ2xFLE1BQU0sQ0FBQzZCLFdBQVcsR0FBRyxNQUFNOUwsaUVBQVksQ0FBQytMLEtBQUssQ0FBQztZQUFFQyxRQUFRO1lBQU1DLGVBQWU7UUFBSztRQUVsRixJQUFJLEVBQUNILHVCQUFBQSxpQ0FBQUEsV0FBWXhDLEVBQUUsR0FBRTtZQUNqQmhLLGtEQUFNQSxDQUFDNkosS0FBSyxDQUFDO1lBQ2I7UUFDSjtRQUVBLE9BQU8sSUFBSSxDQUFDMUgsV0FBVyxDQUNuQjFCLHlEQUFXQSxDQUFDbU0scUJBQXFCLEVBQ2pDO1lBQUVqQztZQUFLckksS0FBSyxFQUFFa0ssdUJBQUFBLGlDQUFBQSxXQUFZeEMsRUFBRTtRQUFDO0lBRXJDO0lBRUE7Ozs7Ozs7S0FPQyxHQUNELE1BQU02QyxzQkFDRnZLLEtBQW9ELEVBQ3BEd0ssVUFBOEQsRUFDSTtRQUNsRSxPQUFPLElBQUksQ0FBQzNLLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDc00scUJBQXFCLEVBQUU7WUFBRXpLO1lBQU93SztRQUFXO0lBQ25GO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUUsbUJBQ0YxSyxLQUFpRCxFQUNjO1FBQy9ELE9BQU8sSUFBSSxDQUFDSCxXQUFXLENBQUMxQix5REFBV0EsQ0FBQ3dNLGtCQUFrQixFQUFFO1lBQUUzSztRQUFNO0lBQ3BFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU00Syx5QkFBOEY7UUFDaEcsTUFBTSxJQUFJLENBQUMvSyxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzBNLHNCQUFzQjtJQUM3RDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQyxzQkFBd0Y7UUFDMUYsT0FBTyxJQUFJLENBQUNqTCxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzRNLG1CQUFtQjtJQUMzRDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNQywwQkFBZ0c7UUFDbEcsTUFBTSxJQUFJLENBQUNuTCxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzhNLHVCQUF1QjtJQUM5RDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLHdCQUNGbEwsS0FBc0QsRUFDYztRQUNwRSxPQUFPLElBQUksQ0FBQ0gsV0FBVyxDQUFDMUIseURBQVdBLENBQUNnTix1QkFBdUIsRUFBRTtZQUFFbkw7UUFBTTtJQUN6RTtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNb0wsc0JBQXdGO1FBQzFGLE9BQU8sSUFBSSxDQUFDdkwsV0FBVyxDQUFDMUIseURBQVdBLENBQUNrTixtQkFBbUI7SUFDM0Q7SUFFQTs7Ozs7OztLQU9DLEdBQ0QsTUFBTUMsbUJBQ0Z0TCxLQUFpRCxFQUNqRHVMLGlCQUEwRSxFQUNYO1FBQy9ELE9BQU8sSUFBSSxDQUFDMUwsV0FBVyxDQUFDMUIseURBQVdBLENBQUNxTixrQkFBa0IsRUFBRTtZQUFFeEw7WUFBT3VMO1FBQWtCO0lBQ3ZGO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUUsWUFDRnpMLEtBQTBDLEVBQ2M7UUFDeEQsTUFBTSxJQUFJLENBQUNILFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDdU4sV0FBVyxFQUFFO1lBQUUxTDtRQUFNO0lBQzVEO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTTJMLFlBQ0ZDLFFBQWdELEVBQ1E7UUFDeEQsTUFBTSxJQUFJLENBQUMvTCxXQUFXLENBQUMxQix5REFBV0EsQ0FBQzBOLFdBQVcsRUFBRTtZQUFFRDtRQUFTO0lBQy9EO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUUsZUFDRkYsUUFBbUQsRUFDUTtRQUMzRCxNQUFNLElBQUksQ0FBQy9MLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDNE4sY0FBYyxFQUFFO1lBQUVIO1FBQVM7SUFDbEU7SUFFQTs7Ozs7O0tBTUMsR0FDRCxNQUFNSSxvQkFDRi9DLEtBQWtELEVBQ2M7UUFDaEUsT0FBTyxJQUFJLENBQUNwSixXQUFXLENBQUMxQix5REFBV0EsQ0FBQzhOLG1CQUFtQixFQUFFO1lBQUVoRDtRQUFNO0lBQ3JFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1pRCwwQkFBZ0c7UUFDbEcsT0FBTyxJQUFJLENBQUNyTSxXQUFXLENBQUMxQix5REFBV0EsQ0FBQ2dPLHVCQUF1QjtJQUMvRDtJQUVBOzs7Ozs7S0FNQyxHQUNELE1BQU1DLHdCQUNGQyxPQUEwRCxFQUNVO1FBQ3BFLE9BQU8sSUFBSSxDQUFDeE0sV0FBVyxDQUFDMUIseURBQVdBLENBQUNtTyx1QkFBdUIsRUFBRTtZQUFFRDtRQUFRO0lBQzNFO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1FLHlCQUFpRztRQUNuRyxPQUFPLElBQUksQ0FBQzFNLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDcU8seUJBQXlCO0lBQ2pFO0lBRUE7Ozs7Ozs7O0tBUUMsR0FDRCxNQUFNQyxzQkFDRmpILFFBQTZELEVBQ1E7UUFDckUsT0FBTyxJQUFJLENBQUMzRixXQUFXLENBQUMxQix5REFBV0EsQ0FBQ3VPLHdCQUF3QixFQUFFO1lBQUVsSDtRQUFTO0lBQzdFO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTW1ILHFCQUNGN0UsT0FBMEQsRUFDVTtRQUNwRSxPQUFPLElBQUksQ0FBQ2pJLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDeU8sdUJBQXVCLEVBQUU7WUFBRTlFO1FBQVE7SUFDM0U7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTStFLG1CQUFrRjtRQUNwRixPQUFPLElBQUksQ0FBQ2hOLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDMk8sZ0JBQWdCO0lBQ3hEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLDBCQUFnRztRQUNsRyxPQUFPLElBQUksQ0FBQ2xOLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDNk8sdUJBQXVCO0lBQy9EO0lBRUE7Ozs7OztLQU1DLEdBQ0QsTUFBTUMsZ0JBQWdCNUUsR0FBMEMsRUFBZ0U7UUFDNUgsT0FBTyxJQUFJLENBQUN4SSxXQUFXLENBQUMxQix5REFBV0EsQ0FBQytPLGVBQWUsRUFBRTtZQUFFN0U7UUFBSTtJQUMvRDtJQUVBOzs7O0tBSUMsR0FDRCxNQUFNOEUseUJBQThGO1FBQ2hHLE9BQU8sSUFBSSxDQUFDdE4sV0FBVyxDQUFDMUIseURBQVdBLENBQUNpUCxzQkFBc0I7SUFDOUQ7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsb0JBQW9GO1FBQ3RGLE9BQU8sSUFBSSxDQUFDeE4sV0FBVyxDQUFDMUIseURBQVdBLENBQUNtUCxpQkFBaUI7SUFDekQ7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsNkJBQXNHO1FBQ3hHLE9BQU8sSUFBSSxDQUFDMU4sV0FBVyxDQUFDMUIseURBQVdBLENBQUNxUCwwQkFBMEI7SUFDbEU7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTUMsc0JBQXdGO1FBQzFGLE9BQU8sSUFBSSxDQUFDNU4sV0FBVyxDQUFDMUIseURBQVdBLENBQUM0SSxtQkFBbUI7SUFDM0Q7SUFFQTs7OztLQUlDLEdBQ0QsTUFBTTJHLG1CQUFrRjtRQUNwRixPQUFPLElBQUksQ0FBQzdOLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDd1AsZ0JBQWdCO0lBQ3hEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLG1CQUFrRjtRQUNwRixPQUFPLElBQUksQ0FBQy9OLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDMFAsZ0JBQWdCO0lBQ3hEO0lBRUE7Ozs7S0FJQyxHQUNELE1BQU1DLHdCQUE0RjtRQUM5RixPQUFPLElBQUksQ0FBQ2pPLFdBQVcsQ0FBQzFCLHlEQUFXQSxDQUFDNFAscUJBQXFCO0lBQzdEO0lBRUE7Ozs7O0tBS0MsR0FDRCxNQUFNQyx3QkFDRjNGLEdBQWtELEVBQ2tCO1FBQ3BFLE9BQU8sSUFBSSxDQUFDeEksV0FBVyxDQUFDMUIseURBQVdBLENBQUM4UCx1QkFBdUIsRUFBRTtZQUFFNUY7UUFBSTtJQUN2RTtJQXQ1QkE7O0tBRUMsR0FDRDNJLGFBQWM7UUFMZGYsdUJBQUFBLGFBQVlQLHNFQUFlLENBQUNPLFNBQVM7UUF5R3JDOzs7Ozs7OztLQVFDLEdBQ0R1UCx1QkFBQUEsdUJBQXNCLE9BQ2xCQyxRQUNBQyxVQUNBQztZQUVBLElBQUlDO1lBRUosTUFBTTdKLFdBQXdDLE1BQU0sSUFBSSxDQUFDNUUsV0FBVyxDQUNoRTFCLHlEQUFXQSxDQUFDb1EsbUJBQW1CLEVBQy9CO2dCQUFFSjtZQUFPO1lBR2JHLGFBQWE3SixTQUFTNkosVUFBVTtZQUVoQyxNQUFNRSxvQkFBb0I7Z0JBQ3RCLE1BQU1DLGtCQUErQyxNQUFNLElBQUksQ0FBQzVPLFdBQVcsQ0FDdkUxQix5REFBV0EsQ0FBQ29RLG1CQUFtQixFQUMvQjtvQkFBRUo7Z0JBQU87Z0JBR2JHLGFBQWFHLGdCQUFnQkgsVUFBVTtZQUMzQztZQUVBbFEsb0VBQWUsQ0FBQ08sU0FBUyxDQUFDQyxXQUFXLENBQUMsQ0FBQ047Z0JBQ25DLElBQUksQ0FBQ0QscUVBQW1CQSxDQUFDQyxVQUFVO29CQUMvQlosa0RBQU1BLENBQUNnUixLQUFLLENBQUMseUVBQXlFcFE7b0JBQ3RGLE9BQU9rRTtnQkFDWDtnQkFFQSxJQUFJbEUsUUFBUVEsSUFBSSxLQUFLWCx5REFBV0EsQ0FBQ3dRLGVBQWUsRUFBRTtvQkFDOUMsSUFBSSxDQUFDcFEsNkVBQTJCQSxDQUFDRCxVQUFVO3dCQUN2Q1osa0RBQU1BLENBQUNnUixLQUFLLENBQUMsd0VBQXdFcFE7d0JBQ3JGLE9BQU9rRTtvQkFDWDtvQkFFQSxNQUFNb00sZ0JBQWdCdFE7b0JBRXRCLE1BQU0sQ0FBQ1EsTUFBTSxHQUFHMEYsS0FBSyxHQUFHb0ssY0FBY3BLLElBQUk7b0JBRTFDLElBQUkySixPQUFPVSxRQUFRLENBQUMvUCxPQUFPO3dCQUN2QnNQLFNBQVM7NEJBQUV0UDs0QkFBTTBGO3dCQUFLO29CQUMxQjtnQkFDSjtnQkFDQSxJQUFJbEcsUUFBUVEsSUFBSSxLQUFLWCx5REFBV0EsQ0FBQ3dHLGVBQWUsRUFBRTtvQkFDOUM2SjtnQkFDSjtZQUNKO1lBRUEsTUFBTU0sV0FBVztnQkFDYixJQUFJLENBQUNSLFlBQVk7b0JBQ2I7Z0JBQ0o7Z0JBRUEsSUFBSSxDQUFDek8sV0FBVyxDQUNaMUIseURBQVdBLENBQUM0USxjQUFjLEVBQzFCO29CQUFFVDtnQkFBVztnQkFHakJBLGFBQWE7Z0JBRWIsSUFBSSxPQUFPRCxxQkFBcUIsWUFBWTtvQkFDeENBO2dCQUNKO1lBQ0o7WUFFQVcsT0FBT0MsZ0JBQWdCLENBQUMsZ0JBQWdCSDtZQUN4Q0UsT0FBT0MsZ0JBQWdCLENBQUMsVUFBVUg7WUFFbEMsT0FBT0E7UUFDWDtRQWpMSSxJQUFJLENBQUM3RSxxQkFBcUIsR0FBRyxJQUFJLENBQUNBLHFCQUFxQixDQUFDckssSUFBSSxDQUFDLElBQUk7UUFDakUsSUFBSSxDQUFDeUgsYUFBYSxHQUFHLElBQUksQ0FBQ0EsYUFBYSxDQUFDekgsSUFBSSxDQUFDLElBQUk7UUFDakQsSUFBSSxDQUFDMksscUJBQXFCLEdBQUcsSUFBSSxDQUFDQSxxQkFBcUIsQ0FBQzNLLElBQUksQ0FBQyxJQUFJO1FBQ2pFLElBQUksQ0FBQzhLLGtCQUFrQixHQUFHLElBQUksQ0FBQ0Esa0JBQWtCLENBQUM5SyxJQUFJLENBQUMsSUFBSTtJQUMvRDtBQSs0Qko7QUFsM0JJOzs7Ozs7OztLQVFDLEdBQ0QsaUJBakRFMkUsV0FpREsySyw2QkFBNEIsQ0FDL0JDLE1BQ0FoQixRQUNBQztJQUVBLElBQUlnQjtJQUNKLElBQUlDLG9CQUFvQjtJQUV4QixNQUFNQyxVQUFVO1FBQ1pGLE9BQU9oUixvRUFBZSxDQUFDa1IsT0FBTyxDQUFDO1lBQUU3TyxNQUFNLEdBQUcwTyxLQUFLLENBQUMsRUFBRTlLLDhDQUFNQSxJQUFJO1FBQUM7UUFDN0QrSyxLQUFLRyxXQUFXLENBQUM7WUFBRXpRLE1BQU1YLHlEQUFXQSxDQUFDcVIsc0JBQXNCO1lBQUVoTCxNQUFNO2dCQUFFMko7WUFBTztRQUFFO1FBRTlFaUIsS0FBS3pRLFNBQVMsQ0FBQ0MsV0FBVyxDQUFDLENBQUNOO1lBQ3hCLElBQUksQ0FBQ0QscUVBQW1CQSxDQUFDQyxVQUFVO2dCQUMvQlosa0RBQU1BLENBQUNnUixLQUFLLENBQUMsK0VBQStFcFE7Z0JBQzVGO1lBQ0o7WUFFQSxJQUFJQSxRQUFRUSxJQUFJLEtBQUtYLHlEQUFXQSxDQUFDd1EsZUFBZSxFQUFFO2dCQUM5QyxJQUFJLENBQUNwUSw2RUFBMkJBLENBQUNELFVBQVU7b0JBQ3ZDWixrREFBTUEsQ0FBQ2dSLEtBQUssQ0FBQyx3RUFBd0VwUTtvQkFDckY7Z0JBQ0o7Z0JBRUEsTUFBTXNRLGdCQUFnQnRRO2dCQUV0QixNQUFNLENBQUNRLE1BQU0sR0FBRzBGLEtBQUssR0FBR29LLGNBQWNwSyxJQUFJO2dCQUMxQzRKLFNBQVM7b0JBQUV0UDtvQkFBTTBGO2dCQUFLO1lBQzFCO1FBQ0o7UUFFQTRLLEtBQUtLLFlBQVksQ0FBQzdRLFdBQVcsQ0FBQztZQUMxQixJQUFJUixzRUFBZSxDQUFDc1IsU0FBUyxFQUFFO2dCQUMzQmhTLGtEQUFNQSxDQUFDZ1IsS0FBSyxDQUFDdFEsc0VBQWUsQ0FBQ3NSLFNBQVMsQ0FBQ3BSLE9BQU87WUFDbEQ7WUFDQSxnRUFBZ0U7WUFDaEUsSUFBSSxDQUFDK1EsbUJBQW1CO2dCQUNwQkM7WUFDSjtRQUNKO0lBQ0o7SUFFQUE7SUFFQSxNQUFNUixXQUFXO1FBQ2IsSUFBSU0sTUFBTTtZQUNOQyxvQkFBb0I7WUFDcEJELEtBQUtPLFVBQVU7UUFDbkI7SUFDSjtJQUVBWCxPQUFPQyxnQkFBZ0IsQ0FBQyxnQkFBZ0JIO0lBQ3hDRSxPQUFPQyxnQkFBZ0IsQ0FBQyxVQUFVSDtJQUVsQyxPQUFPQTtBQUNYO0FBb3pCSixNQUFNYyxZQUFZLElBQUlyTDtBQUVVOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2hnQ2hDOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JDLEdBRWdEO0FBR0E7QUFFakQsTUFBTXNMLGlCQUFpQixDQUFDcEw7SUFDcEIsTUFBTSxFQUNGcUwsWUFBWSxFQUNaQyxjQUFjLEVBQ2RDLFdBQVcsRUFBRUMsbUJBQW1CLEVBQUUsRUFDckMsR0FBR3hMO0lBRUosSUFBSXlMLDhCQUFrRDtJQUN0RCxJQUFJQyxnQ0FBb0Q7SUFDeEQsSUFBSUMsOEJBQWtEO0lBQ3RELElBQUlDLG9CQUF3QztJQUM1QyxJQUFJQyw2QkFBaUQ7SUFFckQsTUFBTUMsNEJBQTRCLENBQUN6UTtRQUMvQixNQUFNMFEsV0FBVzFRLEVBQUUyUSxhQUFhO1FBQ2hDYiwwREFBU0EsQ0FBQzlLLGlCQUFpQixDQUN2QmdMLGFBQWFZLEtBQUssQ0FBQ0MsbUJBQW1CLEVBQ3RDLENBQUNILFNBQVNJLE9BQU87SUFFekI7SUFFQSxNQUFNQyw4QkFBOEIsQ0FBQy9RO1FBQ2pDLE1BQU0wUSxXQUFXMVEsRUFBRTJRLGFBQWE7UUFDaEMsSUFBSUQsU0FBU0ksT0FBTyxFQUFFO1lBQ2xCaEIsMERBQVNBLENBQUNySyxZQUFZLENBQUMwSyxvQkFBb0JhLGdCQUFnQjtRQUMvRCxPQUFPO1lBQ0hsQiwwREFBU0EsQ0FBQ2xLLGFBQWEsQ0FBQ3VLLG9CQUFvQmEsZ0JBQWdCO1FBQ2hFO0lBQ0o7SUFFQSxNQUFNQyw0QkFBNEIsQ0FBQ2pSO1FBQy9CLE1BQU0wUSxXQUFXMVEsRUFBRTJRLGFBQWE7UUFDaEMsSUFBSUQsU0FBU0ksT0FBTyxFQUFFO1lBQ2xCaEIsMERBQVNBLENBQUNySyxZQUFZLENBQUMwSyxvQkFBb0JlLGNBQWM7UUFDN0QsT0FBTztZQUNIcEIsMERBQVNBLENBQUNsSyxhQUFhLENBQUN1SyxvQkFBb0JlLGNBQWM7UUFDOUQ7SUFDSjtJQUVBLE1BQU1DLDBCQUEwQixDQUFDblI7UUFDN0IsTUFBTTBRLFdBQVcxUSxFQUFFMlEsYUFBYTtRQUNoQ2IsMERBQVNBLENBQUM5SyxpQkFBaUIsQ0FDdkJnTCxhQUFhWSxLQUFLLENBQUNRLGtCQUFrQixFQUNyQyxDQUFDVixTQUFTSSxPQUFPO0lBRXpCO0lBRUEsTUFBTU8sMkJBQTJCLENBQUNyUjtRQUM5QixNQUFNMFEsV0FBVzFRLEVBQUUyUSxhQUFhO1FBQ2hDLElBQUlELFNBQVNJLE9BQU8sRUFBRTtZQUNsQmhCLDBEQUFTQSxDQUFDckssWUFBWSxDQUFDMEssb0JBQW9CbUIsMEJBQTBCO1FBQ3pFLE9BQU87WUFDSHhCLDBEQUFTQSxDQUFDbEssYUFBYSxDQUFDdUssb0JBQW9CbUIsMEJBQTBCO1FBQzFFO0lBQ0o7SUFFQSxNQUFNQyxhQUFhO1FBQ2ZuQiw4QkFBOEJvQixTQUFTQyxjQUFjLENBQUM7UUFDdERwQixnQ0FBZ0NtQixTQUFTQyxjQUFjLENBQUM7UUFDeERuQiw4QkFBOEJrQixTQUFTQyxjQUFjLENBQUM7UUFDdEQsMEZBQTBGO1FBQzFGbEIsb0JBQW9CaUIsU0FBU0MsY0FBYyxDQUFDO1FBQzVDakIsNkJBQTZCZ0IsU0FBU0MsY0FBYyxDQUFDO1FBRXJEckIsd0NBQUFBLGtEQUFBQSw0QkFBNkJqQixnQkFBZ0IsQ0FBQyxVQUFVc0I7UUFDeERKLDBDQUFBQSxvREFBQUEsOEJBQStCbEIsZ0JBQWdCLENBQUMsVUFBVTRCO1FBQzFEVCx3Q0FBQUEsa0RBQUFBLDRCQUE2Qm5CLGdCQUFnQixDQUFDLFVBQVU4QjtRQUN4RCxtQ0FBbUM7UUFDbkMsSUFBSSxDQUFDM1EseURBQVNBLENBQUNtRCxTQUFTLEVBQUU7WUFDdEI4TSw4QkFBQUEsd0NBQUFBLGtCQUFtQnBCLGdCQUFnQixDQUFDLFVBQVVnQztRQUNsRDtRQUNBWCx1Q0FBQUEsaURBQUFBLDJCQUE0QnJCLGdCQUFnQixDQUFDLFVBQVVrQztRQUV2RCxNQUFNSyx5QkFBd0MsRUFBRSxDQUFDQyxLQUFLLENBQUNDLElBQUksQ0FBQ0osU0FBU0ssZ0JBQWdCLENBQUM7UUFDdEZILHVCQUF1QkksT0FBTyxDQUFDLENBQUNDO1lBQzVCQSxzQkFBc0I1QyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUNuUDtnQkFDN0NBLEVBQUVnUyxjQUFjO2dCQUNoQmxDLDBEQUFTQSxDQUFDekssa0JBQWtCO1lBQ2hDO1FBQ0o7UUFFQSxNQUFNNE0sbUJBQWtDLEVBQUUsQ0FBQ04sS0FBSyxDQUFDQyxJQUFJLENBQUNKLFNBQVNLLGdCQUFnQixDQUFDO1FBQ2hGSSxpQkFBaUJILE9BQU8sQ0FBQyxDQUFDSTtZQUN0QkEsZ0JBQWdCL0MsZ0JBQWdCLENBQUMsU0FBUyxDQUFDblA7Z0JBQ3ZDQSxFQUFFZ1MsY0FBYztnQkFDaEJsQywwREFBU0EsQ0FBQ3BHLGVBQWU7WUFDN0I7UUFDSjtJQUNKO0lBRUEsTUFBTXlJLGlCQUFpQixDQUFDekIsVUFBOEI3STtRQUNsRCxJQUFJLENBQUM2SSxVQUFVO1lBQ1g7UUFDSjtRQUNBLElBQUk3SSxTQUFTO1lBQ1Q2SSxTQUFTMEIsWUFBWSxDQUFDLFdBQVc7UUFDckMsT0FBTztZQUNIMUIsU0FBUzJCLGVBQWUsQ0FBQztRQUM3QjtJQUNKO0lBRUEsTUFBTUMsU0FBUztRQUNYLE1BQU1DLHdCQUF3QnBDLG9CQUFvQmEsZ0JBQWdCLElBQUlmO1FBQ3RFLE1BQU11QyxzQkFBc0JyQyxvQkFBb0JlLGNBQWMsSUFBSWpCO1FBQ2xFLE1BQU13Qyw0QkFBNEJ0QyxvQkFBb0JtQiwwQkFBMEIsSUFBSXJCO1FBQ3BGLE1BQU15QyxtQkFBbUIsQ0FBQzFDLGFBQWEyQyxNQUFNLENBQUMzQyxhQUFhWSxLQUFLLENBQUNRLGtCQUFrQixDQUFDO1FBRXBGLElBQUksS0FBVzVKLEVBQUUsRUFHaEI7UUFFRDJLLGVBQWU5QiwrQkFBK0JrQztRQUM5Q0osZUFBZTdCLDZCQUE2QmtDO1FBQzVDTCxlQUFlM0IsNEJBQTRCaUM7UUFDM0NOLGVBQWU1QixtQkFBbUJtQztJQUN0QztJQUVBLE1BQU0vVCxPQUFPO1FBQ1Q0UztRQUNBZTtJQUNKO0lBRUEsT0FBTztRQUNIM1Q7SUFDSjtBQUNKO0FBRUEsSUFBSWtVO0FBQ0osSUFBSUMsVUFBVTtBQUNkLE1BQU1DLGlCQUFpQjtBQUN2QixNQUFNQyxtQkFBbUI7QUFDekIsTUFBTXJVLE9BQU87SUFDVCxJQUFJLE9BQU9tUiwwREFBU0EsS0FBSyxhQUFhO1FBQ2xDLElBQUlnRCxVQUFVQyxnQkFBZ0I7WUFDMUI3RCxPQUFPK0QsWUFBWSxDQUFDSjtZQUNwQjtRQUNKO1FBQ0FBLFlBQVkzRCxPQUFPZ0UsVUFBVSxDQUFDdlUsTUFBTXFVO1FBQ3BDRixXQUFXO1FBQ1g7SUFDSjtJQUVBNUQsT0FBTytELFlBQVksQ0FBQ0o7SUFFcEIsTUFBTWxPLFdBQVcsTUFBTW1MLDBEQUFTQSxDQUFDOUIscUJBQXFCO0lBQ3RELE1BQU1tRixhQUFhcEQsZUFBZXBMO0lBRWxDLElBQUk2TSxTQUFTNEIsVUFBVSxLQUFLLFdBQVc7UUFDbkM1QixTQUFTckMsZ0JBQWdCLENBQUMsb0JBQW9CO1lBQzFDZ0UsV0FBV3hVLElBQUk7UUFDbkI7SUFDSixPQUFPO1FBQ0h3VSxXQUFXeFUsSUFBSTtJQUNuQjtBQUNKO0FBRU8sTUFBTTBVLFdBQVc7SUFDcEIxVTtBQUNKLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0TEY7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FFRCx1RUFBdUU7QUFFaEUsTUFBTTJVLGtDQUFrQywyQkFBMkI7QUFDbkUsTUFBTUMsNENBQTRDLEdBQUdELGdDQUFnQyxVQUFVLENBQUMsQ0FBQztBQUVqRyxNQUFNRSxvQkFBb0IsbUJBQW1CO0FBQzdDLE1BQU1DLGlCQUFpQixnQkFBZ0I7QUFDdkMsTUFBTUMsZUFBZSxjQUFjO0FBQ25DLE1BQU1DLHVCQUF1QixzQkFBc0I7QUFDbkQsTUFBTUMsc0JBQXNCLHFCQUFxQjtBQUNqRCxNQUFNQywrQkFBK0IsOEJBQThCO0FBQ25FLE1BQU1DLHNCQUFzQixxQkFBcUI7QUFDakQsTUFBTUMsd0JBQXdCLG1CQUFtQjtBQUNqRCxNQUFNQyxtQkFBbUIsa0JBQWtCO0FBQzNDLE1BQU1DLDhCQUE4Qiw2QkFBNkI7QUFDakUsTUFBTUMsNEJBQTRCLDJCQUEyQjtBQUM3RCxNQUFNQyxrQkFBa0IsaUJBQWlCO0FBQ3pDLE1BQU1DLDBCQUEwQix5QkFBeUI7QUFDekQsTUFBTUMsb0JBQW9CLFlBQVk7QUFDdEMsTUFBTUMsZ0NBQWdDLCtCQUErQjtBQUNyRSxNQUFNQyxrQkFBa0IsaUJBQWlCO0FBQ3pDLE1BQU1DLGtDQUFrQyxrQ0FBa0M7QUFFMUUsTUFBTUMsdUJBQXVCLGdCQUFnQjtBQUU3QyxNQUFNQyxzQkFBc0IsZ0JBQWdCO0FBQzVDLE1BQU1DLHFCQUFxQixlQUFlO0FBQzFDLE1BQU1DLHVCQUF1QixpQkFBaUI7QUFDOUMsTUFBTUMsNEJBQTRCLHNCQUFzQjtBQUN4RCxNQUFNQyx1QkFBdUIsaUJBQWlCO0FBQzlDLE1BQU1DLDhCQUE4Qix3QkFBd0I7QUFDNUQsTUFBTUMsK0JBQStCLHlCQUF5QjtBQUM5RCxNQUFNQyx1Q0FBdUMsaUNBQWlDO0FBQzlFLE1BQU1DLDJCQUEyQixxQkFBcUI7QUFFN0QsZ0VBQWdFO0FBQ2hFLDZFQUE2RTtBQUM3RSxzQ0FBc0M7QUFDdEMsMkJBQTJCO0FBQ3BCLE1BQU1DLDRCQUE0QixhQUFhO0FBQy9DLE1BQU1DLGlDQUFpQyxrQkFBa0I7QUFDaEUsa0RBQWtEO0FBQzNDLE1BQU1DLDJCQUEyQixlQUFlO0FBQ2hELE1BQU1DLGdDQUFnQyxvQkFBb0I7QUFFakU7Ozs7Q0FJQyxHQUNNLE1BQU1DLHNCQUFzQjtJQUFDO0lBQUc7SUFBRztJQUFHO0lBQUc7SUFBRztJQUFHO0lBQUc7SUFBRztJQUFHO0lBQUk7SUFBSTtJQUFJO0lBQUk7SUFBSTtJQUFJO0lBQUk7SUFBSTtJQUFJO0lBQUk7SUFBSTtJQUFJO0lBQUk7Q0FBSSxDQUFDO0FBRXhIOzs7O0NBSUMsR0FDTSxNQUFNbFYsd0JBQXdCO0lBQ2pDNkQsY0FBYztJQUNkc1IsY0FBYztJQUNkcFIsU0FBUztJQUNUQyxnQkFBZ0I7SUFDaEJDLE9BQU87SUFDUEgsZUFBZTtBQUNuQixFQUFFOzs7Ozs7Ozs7Ozs7QUNsRlc7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsa0JBQWtCLG1CQUFPLENBQUMsdUhBQTRCOztBQUV0RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLDBCQUEwQixtQkFBTyxDQUFDLHVJQUFvQzs7QUFFdEU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVGE7QUFDYixzQkFBc0IsbUJBQU8sQ0FBQywrSEFBZ0M7QUFDOUQsYUFBYSxtQkFBTyxDQUFDLHVIQUE0QjtBQUNqRCxxQkFBcUIsa0tBQWdEOztBQUVyRTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDcEJhO0FBQ2IsZUFBZSxtQkFBTyxDQUFDLCtHQUF3Qjs7QUFFL0M7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQztBQUM5RCxzQkFBc0IsbUJBQU8sQ0FBQywrSEFBZ0M7QUFDOUQsd0JBQXdCLG1CQUFPLENBQUMscUlBQW1DOztBQUVuRSxzQkFBc0IsbUJBQW1CO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLFdBQVcsZ0JBQWdCO0FBQ2pDO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDakNhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DOztBQUU5RCw2QkFBNkI7QUFDN0I7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNSYTtBQUNiLDRCQUE0QixtQkFBTyxDQUFDLHVJQUFvQztBQUN4RSxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQzs7QUFFOUQ7QUFDQTs7QUFFQTtBQUNBLGlEQUFpRCxtQkFBbUI7O0FBRXBFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDN0JhO0FBQ2IsYUFBYSxtQkFBTyxDQUFDLDZIQUErQjtBQUNwRCxjQUFjLG1CQUFPLENBQUMsNkdBQXVCO0FBQzdDLHFDQUFxQyxtQkFBTyxDQUFDLGlLQUFpRDtBQUM5RiwyQkFBMkIsbUJBQU8sQ0FBQyx5SUFBcUM7O0FBRXhFO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGlCQUFpQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2hCYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCwyQkFBMkIsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDeEUsK0JBQStCLG1CQUFPLENBQUMsaUpBQXlDOztBQUVoRjtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVmE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNSYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVIQUE0QjtBQUN0RCxxQkFBcUIsbUJBQU8sQ0FBQyx5SUFBcUM7O0FBRWxFO0FBQ0EsMERBQTBELGNBQWM7QUFDeEUsMERBQTBELGNBQWM7QUFDeEU7QUFDQTs7Ozs7Ozs7Ozs7O0FDUmE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsMkJBQTJCLG1CQUFPLENBQUMseUlBQXFDO0FBQ3hFLGtCQUFrQixtQkFBTyxDQUFDLHVIQUE0QjtBQUN0RCwyQkFBMkIsbUJBQU8sQ0FBQyx5SUFBcUM7O0FBRXhFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsTUFBTSxnQkFBZ0I7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLElBQUk7QUFDSjs7Ozs7Ozs7Ozs7O0FDM0JhO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDtBQUNBOztBQUVBO0FBQ0E7QUFDQSxzQ0FBc0Msa0RBQWtEO0FBQ3hGLElBQUk7QUFDSjtBQUNBLElBQUk7QUFDSjs7Ozs7Ozs7Ozs7O0FDWmE7QUFDYixZQUFZLG1CQUFPLENBQUMsdUdBQW9COztBQUV4QztBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsT0FBTyxtQkFBbUIsYUFBYTtBQUN4RSxDQUFDOzs7Ozs7Ozs7Ozs7QUNQWTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjs7QUFFbkQ7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDTmE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsZ0JBQWdCLG1CQUFPLENBQUMseUlBQXFDOztBQUU3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQzNCYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQzs7QUFFOUQ7QUFDQTs7QUFFQSw2QkFBNkIsdUNBQXVDO0FBQ3BFO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7Ozs7Ozs7Ozs7OztBQ2ZhO0FBQ2Isa0NBQWtDLG1CQUFPLENBQUMseUpBQTZDO0FBQ3ZGLHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQztBQUM5RCw4QkFBOEIsbUJBQU8sQ0FBQywySUFBc0M7O0FBRTVFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNiYTtBQUNiLFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7QUFDeEMsK0JBQStCLG1CQUFPLENBQUMsaUpBQXlDOztBQUVoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7QUNWWTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCwrQkFBK0IsMExBQTREO0FBQzNGLGtDQUFrQyxtQkFBTyxDQUFDLHlKQUE2QztBQUN2RixvQkFBb0IsbUJBQU8sQ0FBQywySEFBOEI7QUFDMUQsMkJBQTJCLG1CQUFPLENBQUMseUlBQXFDO0FBQ3hFLGdDQUFnQyxtQkFBTyxDQUFDLG1KQUEwQztBQUNsRixlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixrRUFBa0U7QUFDbEUsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUN0RGE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNQYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHFJQUFtQzs7QUFFN0Q7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7OztBQ1ZZO0FBQ2IsWUFBWSxtQkFBTyxDQUFDLHVHQUFvQjs7QUFFeEM7QUFDQTtBQUNBLDRCQUE0QixhQUFhO0FBQ3pDO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7QUNSWTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHFJQUFtQzs7QUFFN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDUGE7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDcEQsYUFBYSxtQkFBTyxDQUFDLDZIQUErQjs7QUFFcEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSwrQ0FBK0MsYUFBYTtBQUM1RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNqQmE7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyx1SUFBb0M7QUFDOUQsZ0JBQWdCLG1CQUFPLENBQUMsaUhBQXlCOztBQUVqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0JBQWdCO0FBQ3BCOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHFJQUFtQzs7QUFFN0Q7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDWmE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLGdCQUFnQixtQkFBTyxDQUFDLGlIQUF5QjtBQUNqRCx3QkFBd0IsbUJBQU8sQ0FBQyxxSUFBbUM7O0FBRW5FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVGE7QUFDYjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHFCQUFNLGdCQUFnQixxQkFBTTtBQUMzQztBQUNBO0FBQ0EsaUJBQWlCLGNBQWM7Ozs7Ozs7Ozs7OztBQ2ZsQjtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQztBQUM5RCxlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQyxtQ0FBbUM7O0FBRW5DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDWGE7QUFDYjs7Ozs7Ozs7Ozs7O0FDRGE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxxSEFBMkI7O0FBRXBEOzs7Ozs7Ozs7Ozs7QUNIYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxZQUFZLG1CQUFPLENBQUMsdUdBQW9CO0FBQ3hDLG9CQUFvQixtQkFBTyxDQUFDLDJJQUFzQzs7QUFFbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkIsR0FBRztBQUNILENBQUM7Ozs7Ozs7Ozs7OztBQ1hZO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsdUlBQW9DO0FBQzlELFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7QUFDeEMsY0FBYyxtQkFBTyxDQUFDLG1IQUEwQjs7QUFFaEQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0EsRUFBRTs7Ozs7Ozs7Ozs7O0FDZlc7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyxxQkFBcUIsbUJBQU8sQ0FBQywySUFBc0M7O0FBRW5FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2xCYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQztBQUM5RCxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsWUFBWSxtQkFBTyxDQUFDLHFIQUEyQjs7QUFFL0M7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNkYTtBQUNiLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7QUFDL0Msa0NBQWtDLG1CQUFPLENBQUMseUpBQTZDOztBQUV2RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVmE7QUFDYixzQkFBc0IsbUJBQU8sQ0FBQyw2SUFBdUM7QUFDckUsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7QUFDL0Msa0NBQWtDLG1CQUFPLENBQUMseUpBQTZDO0FBQ3ZGLGFBQWEsbUJBQU8sQ0FBQyw2SEFBK0I7QUFDcEQsYUFBYSxtQkFBTyxDQUFDLHFIQUEyQjtBQUNoRCxnQkFBZ0IsbUJBQU8sQ0FBQyxpSEFBeUI7QUFDakQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHVDQUF1QztBQUN2Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUN0RWE7QUFDYjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTs7Ozs7Ozs7Ozs7O0FDWGE7QUFDYixZQUFZLG1CQUFPLENBQUMsdUdBQW9CO0FBQ3hDLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjs7QUFFbkQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDdEJhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDTGE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDTGE7QUFDYixlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ0xhO0FBQ2I7Ozs7Ozs7Ozs7OztBQ0RhO0FBQ2IsaUJBQWlCLG1CQUFPLENBQUMscUhBQTJCO0FBQ3BELGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxvQkFBb0IsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDakUsd0JBQXdCLG1CQUFPLENBQUMsK0hBQWdDOztBQUVoRTs7QUFFQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDYmE7QUFDYixlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQztBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNQYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQztBQUM5RCxZQUFZLG1CQUFPLENBQUMsdUdBQW9CO0FBQ3hDLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxhQUFhLG1CQUFPLENBQUMsNkhBQStCO0FBQ3BELGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxpQ0FBaUMsMkpBQWtEO0FBQ25GLG9CQUFvQixtQkFBTyxDQUFDLHlIQUE2QjtBQUN6RCwwQkFBMEIsbUJBQU8sQ0FBQyx5SEFBNkI7O0FBRS9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxzQ0FBc0MsYUFBYSxjQUFjLFVBQVU7QUFDM0UsQ0FBQzs7QUFFRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxpQ0FBaUM7QUFDdEY7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLHNCQUFzQjtBQUM1RDtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsaUJBQWlCO0FBQzdFO0FBQ0EsTUFBTTtBQUNOLElBQUksZ0JBQWdCO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7OztBQ3REWTtBQUNiO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1ZhO0FBQ2IsZUFBZSxtQkFBTyxDQUFDLCtHQUF3Qjs7QUFFL0M7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNMYTtBQUNiO0FBQ0EsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyw2QkFBNkIsbUJBQU8sQ0FBQyw2SUFBdUM7QUFDNUUsa0JBQWtCLG1CQUFPLENBQUMsdUhBQTRCO0FBQ3RELGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxXQUFXLG1CQUFPLENBQUMscUdBQW1CO0FBQ3RDLDRCQUE0QixtQkFBTyxDQUFDLDJJQUFzQztBQUMxRSxnQkFBZ0IsbUJBQU8sQ0FBQyxpSEFBeUI7O0FBRWpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEscUNBQXFDOztBQUVyQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0JBQWdCO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtEO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTs7Ozs7Ozs7Ozs7O0FDcEZhO0FBQ2Isa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ3BELDhCQUE4QixtQkFBTyxDQUFDLDJJQUFzQztBQUM1RSwyQkFBMkIsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDeEUsZUFBZSxtQkFBTyxDQUFDLCtHQUF3QjtBQUMvQyxzQkFBc0IsbUJBQU8sQ0FBQywrSEFBZ0M7QUFDOUQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNwQmE7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDcEQscUJBQXFCLG1CQUFPLENBQUMseUhBQTZCO0FBQzFELDhCQUE4QixtQkFBTyxDQUFDLDJJQUFzQztBQUM1RSxlQUFlLG1CQUFPLENBQUMsK0dBQXdCO0FBQy9DLG9CQUFvQixtQkFBTyxDQUFDLDJIQUE4Qjs7QUFFMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLEVBQUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQzNDYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxXQUFXLG1CQUFPLENBQUMsdUhBQTRCO0FBQy9DLGlDQUFpQyxtQkFBTyxDQUFDLHVKQUE0QztBQUNyRiwrQkFBK0IsbUJBQU8sQ0FBQyxpSkFBeUM7QUFDaEYsc0JBQXNCLG1CQUFPLENBQUMsK0hBQWdDO0FBQzlELG9CQUFvQixtQkFBTyxDQUFDLDJIQUE4QjtBQUMxRCxhQUFhLG1CQUFPLENBQUMsNkhBQStCO0FBQ3BELHFCQUFxQixtQkFBTyxDQUFDLHlIQUE2Qjs7QUFFMUQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEI7QUFDQTs7Ozs7Ozs7Ozs7O0FDdEJhO0FBQ2IseUJBQXlCLG1CQUFPLENBQUMscUlBQW1DO0FBQ3BFLGtCQUFrQixtQkFBTyxDQUFDLHVIQUE0Qjs7QUFFdEQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1hhO0FBQ2I7QUFDQSxTQUFTOzs7Ozs7Ozs7Ozs7QUNGSTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQzs7QUFFOUQsK0JBQStCOzs7Ozs7Ozs7Ozs7QUNIbEI7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyx1SUFBb0M7QUFDOUQsYUFBYSxtQkFBTyxDQUFDLDZIQUErQjtBQUNwRCxzQkFBc0IsbUJBQU8sQ0FBQywrSEFBZ0M7QUFDOUQsY0FBYyx3SkFBOEM7QUFDNUQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3BCYTtBQUNiLHlCQUF5QixtQkFBTyxDQUFDLHFJQUFtQztBQUNwRSxrQkFBa0IsbUJBQU8sQ0FBQyx1SEFBNEI7O0FBRXREO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVGE7QUFDYiw4QkFBOEI7QUFDOUI7QUFDQTs7QUFFQTtBQUNBLDRFQUE0RSxNQUFNOztBQUVsRjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxFQUFFOzs7Ozs7Ozs7Ozs7QUNiVztBQUNiO0FBQ0EsMEJBQTBCLG1CQUFPLENBQUMseUpBQTZDO0FBQy9FLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7QUFDL0MsNkJBQTZCLG1CQUFPLENBQUMsNklBQXVDO0FBQzVFLHlCQUF5QixtQkFBTyxDQUFDLHFJQUFtQzs7QUFFcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQ7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7O0FDNUJZO0FBQ2IsV0FBVyxtQkFBTyxDQUFDLHVIQUE0QjtBQUMvQyxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsZUFBZSxtQkFBTyxDQUFDLCtHQUF3Qjs7QUFFL0M7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNmYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLHFIQUEyQjtBQUNwRCxrQkFBa0IsbUJBQU8sQ0FBQyx1SUFBb0M7QUFDOUQsZ0NBQWdDLG1CQUFPLENBQUMsdUpBQTRDO0FBQ3BGLGtDQUFrQyxtQkFBTyxDQUFDLDJKQUE4QztBQUN4RixlQUFlLG1CQUFPLENBQUMsK0dBQXdCOztBQUUvQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2RhO0FBQ2IscUJBQXFCLGtLQUFnRDs7QUFFckU7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLHFCQUFxQjtBQUM1Qyx5QkFBeUI7QUFDekIsR0FBRztBQUNIOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiLHdCQUF3QixtQkFBTyxDQUFDLHFJQUFtQzs7QUFFbkU7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTtBQUNiLGFBQWEsbUJBQU8sQ0FBQyx5R0FBcUI7QUFDMUMsVUFBVSxtQkFBTyxDQUFDLG1HQUFrQjs7QUFFcEM7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNSYTtBQUNiLGNBQWMsbUJBQU8sQ0FBQywyR0FBc0I7QUFDNUMsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCO0FBQ25ELDJCQUEyQixtQkFBTyxDQUFDLHlJQUFxQzs7QUFFeEU7QUFDQSxrRkFBa0Y7O0FBRWxGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7OztBQ2RZO0FBQ2IsWUFBWSxtQkFBTyxDQUFDLHFIQUEyQjs7QUFFL0M7QUFDQSxnREFBZ0Q7QUFDaEQ7Ozs7Ozs7Ozs7OztBQ0xhO0FBQ2I7QUFDQSxpQkFBaUIsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDOUQsWUFBWSxtQkFBTyxDQUFDLHVHQUFvQjtBQUN4QyxpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7O0FBRW5EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7O0FDbEJZO0FBQ2IsMEJBQTBCLG1CQUFPLENBQUMseUlBQXFDOztBQUV2RTtBQUNBOztBQUVBO0FBQ0E7QUFDQSw2REFBNkQ7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1phO0FBQ2I7QUFDQSxvQkFBb0IsbUJBQU8sQ0FBQyx5SEFBNkI7QUFDekQsNkJBQTZCLG1CQUFPLENBQUMsNklBQXVDOztBQUU1RTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1BhO0FBQ2IsWUFBWSxtQkFBTyxDQUFDLGlIQUF5Qjs7QUFFN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1RhO0FBQ2IsMEJBQTBCLG1CQUFPLENBQUMseUlBQXFDOztBQUV2RTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRDtBQUNuRDs7Ozs7Ozs7Ozs7O0FDVmE7QUFDYiw2QkFBNkIsbUJBQU8sQ0FBQyw2SUFBdUM7O0FBRTVFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ1RhO0FBQ2IsV0FBVyxtQkFBTyxDQUFDLHVIQUE0QjtBQUMvQyxlQUFlLG1CQUFPLENBQUMsK0dBQXdCO0FBQy9DLGVBQWUsbUJBQU8sQ0FBQywrR0FBd0I7QUFDL0MsZ0JBQWdCLG1CQUFPLENBQUMsaUhBQXlCO0FBQ2pELDBCQUEwQixtQkFBTyxDQUFDLHVJQUFvQztBQUN0RSxzQkFBc0IsbUJBQU8sQ0FBQywrSEFBZ0M7O0FBRTlEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUN6QmE7QUFDYixrQkFBa0IsbUJBQU8sQ0FBQyxxSEFBMkI7QUFDckQsZUFBZSxtQkFBTyxDQUFDLCtHQUF3Qjs7QUFFL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiLHNCQUFzQixtQkFBTyxDQUFDLCtIQUFnQzs7QUFFOUQ7QUFDQTs7QUFFQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDUmE7QUFDYixjQUFjLG1CQUFPLENBQUMsMkdBQXNCOztBQUU1Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDUmE7QUFDYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNUYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLHVJQUFvQzs7QUFFOUQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDVGE7QUFDYjtBQUNBLG9CQUFvQixtQkFBTyxDQUFDLHFKQUEyQzs7QUFFdkU7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNOYTtBQUNiLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxZQUFZLG1CQUFPLENBQUMsdUdBQW9COztBQUV4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QyxhQUFhO0FBQzFEO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQzs7Ozs7Ozs7Ozs7O0FDWlk7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsaUJBQWlCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVuRDs7QUFFQTs7Ozs7Ozs7Ozs7O0FDTmE7QUFDYixpQkFBaUIsbUJBQU8sQ0FBQyxtSEFBMEI7QUFDbkQsYUFBYSxtQkFBTyxDQUFDLHlHQUFxQjtBQUMxQyxhQUFhLG1CQUFPLENBQUMsNkhBQStCO0FBQ3BELFVBQVUsbUJBQU8sQ0FBQyxtR0FBa0I7QUFDcEMsb0JBQW9CLG1CQUFPLENBQUMscUpBQTJDO0FBQ3ZFLHdCQUF3QixtQkFBTyxDQUFDLCtIQUFnQzs7QUFFaEU7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7Ozs7Ozs7Ozs7OztBQ2xCYTtBQUNiLGlCQUFpQixtQkFBTyxDQUFDLHFIQUEyQjtBQUNwRCxhQUFhLG1CQUFPLENBQUMsNkhBQStCO0FBQ3BELGtDQUFrQyxtQkFBTyxDQUFDLHlKQUE2QztBQUN2RixvQkFBb0IsbUJBQU8sQ0FBQyx5SUFBcUM7QUFDakUscUJBQXFCLG1CQUFPLENBQUMsMklBQXNDO0FBQ25FLGdDQUFnQyxtQkFBTyxDQUFDLG1KQUEwQztBQUNsRixvQkFBb0IsbUJBQU8sQ0FBQyx5SEFBNkI7QUFDekQsd0JBQXdCLG1CQUFPLENBQUMsbUlBQWtDO0FBQ2xFLDhCQUE4QixtQkFBTyxDQUFDLCtJQUF3QztBQUM5RSx3QkFBd0IsbUJBQU8sQ0FBQyxtSUFBa0M7QUFDbEUsd0JBQXdCLG1CQUFPLENBQUMsbUlBQWtDO0FBQ2xFLGtCQUFrQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNwRCxjQUFjLG1CQUFPLENBQUMsMkdBQXNCOztBQUU1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDs7QUFFQTtBQUNBO0FBQ0EsOERBQThELFlBQVk7QUFDMUUsSUFBSTtBQUNKO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGdCQUFnQjs7QUFFcEI7QUFDQTs7Ozs7Ozs7Ozs7O0FDaEVhO0FBQ2IsUUFBUSxtQkFBTyxDQUFDLHlHQUFxQjtBQUNyQyxnQkFBZ0IseUpBQStDO0FBQy9ELFlBQVksbUJBQU8sQ0FBQyx1R0FBb0I7QUFDeEMsdUJBQXVCLG1CQUFPLENBQUMsaUlBQWlDOztBQUVoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBLElBQUksd0RBQXdEO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTs7Ozs7Ozs7Ozs7O0FDckJhO0FBQ2I7QUFDQSxRQUFRLG1CQUFPLENBQUMseUdBQXFCO0FBQ3JDLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCxZQUFZLG1CQUFPLENBQUMseUhBQTZCO0FBQ2pELG9DQUFvQyxtQkFBTyxDQUFDLCtKQUFnRDs7QUFFNUY7QUFDQTs7QUFFQTtBQUNBLDhCQUE4QixVQUFVOztBQUV4QztBQUNBO0FBQ0E7QUFDQSxNQUFNLDJEQUEyRDtBQUNqRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsK0VBQStFO0FBQ3ZGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG1DQUFtQztBQUNuQyxDQUFDO0FBQ0Q7QUFDQSx1Q0FBdUM7QUFDdkMsQ0FBQztBQUNEO0FBQ0Esd0NBQXdDO0FBQ3hDLENBQUM7QUFDRDtBQUNBLDRDQUE0QztBQUM1QyxDQUFDO0FBQ0Q7QUFDQSx5Q0FBeUM7QUFDekMsQ0FBQztBQUNEO0FBQ0EsdUNBQXVDO0FBQ3ZDLENBQUM7QUFDRDtBQUNBLHNDQUFzQztBQUN0QyxDQUFDO0FBQ0Q7QUFDQSwwQ0FBMEM7QUFDMUMsQ0FBQztBQUNEO0FBQ0EsdUNBQXVDO0FBQ3ZDLENBQUM7QUFDRDtBQUNBLDBDQUEwQztBQUMxQyxDQUFDOzs7Ozs7Ozs7Ozs7QUN6RFk7QUFDYixRQUFRLG1CQUFPLENBQUMseUdBQXFCO0FBQ3JDLGlCQUFpQixtQkFBTyxDQUFDLG1IQUEwQjtBQUNuRCw0QkFBNEIsbUJBQU8sQ0FBQyw2SUFBdUM7QUFDM0Usa0JBQWtCLG1CQUFPLENBQUMsbUhBQTBCOztBQUVwRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1gsU0FBUztBQUNUO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxJQUFJLFNBQVMscURBQXFEO0FBQ2xFO0FBQ0EsR0FBRztBQUNILEVBQUUsZ0JBQWdCOzs7Ozs7Ozs7Ozs7Ozs7O0FDeENsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsYUFBYTtBQUN4QixhQUFhLFFBQVE7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUM7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQ7QUFDckQsY0FBYyxLQUFLLEdBQUcsTUFBTSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsT0FBTyxHQUFHLE9BQU8sR0FBRyxZQUFZO0FBQzlFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyw0QkFBNEI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLElBQUk7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwRUFBMEUscUNBQXFDO0FBQy9HO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixRQUFRLGtCQUFrQixZQUFZO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULGlDQUFpQyx1QkFBdUI7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUU0Qjs7Ozs7Ozs7Ozs7Ozs7OztBQ2pQeUI7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLE1BQU07QUFDTjtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ2lFOzs7Ozs7O1VDakNwRTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQ3RCQTs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsR0FBRztXQUNIO1dBQ0E7V0FDQSxDQUFDOzs7OztXQ1BEOzs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUVtRDtBQUVwRGtQLHlEQUFRQSxDQUFDMVUsSUFBSSIsInNvdXJjZXMiOlsid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL3VhLXBhcnNlci1qc0AxLjAuMzYvbm9kZV9tb2R1bGVzL3VhLXBhcnNlci1qcy9zcmMvdWEtcGFyc2VyLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbEAwLjEyLjAvbm9kZV9tb2R1bGVzL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9kaXN0L2Jyb3dzZXItcG9seWZpbGwuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vc3JjL2NvbW1vbi9sb2dnZXIudHMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vc3JjL2NvbW1vbi9tZXNzYWdlcy9jb25zdGFudHMudHMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vc3JjL2NvbW1vbi9tZXNzYWdlcy9pbmRleC50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvY29tbW9uL21lc3NhZ2VzL21lc3NhZ2UtaGFuZGxlci50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvY29tbW9uL21lc3NhZ2VzL3NlbmQtbWVzc2FnZS50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvY29tbW9uL3VzZXItYWdlbnQudHMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vc3JjL3BhZ2VzL3NlcnZpY2VzL21lc3Nlbmdlci50cyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL0V4dGVuc2lvbi9zcmMvcGFnZXMvdGhhbmt5b3UudHMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9jb25zdGFudHMudHMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2EtY2FsbGFibGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2EtcG9zc2libGUtcHJvdG90eXBlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9hZGQtdG8tdW5zY29wYWJsZXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2FuLW9iamVjdC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvYXJyYXktaW5jbHVkZXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2NsYXNzb2YtcmF3LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9jbGFzc29mLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9jb3B5LWNvbnN0cnVjdG9yLXByb3BlcnRpZXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2NyZWF0ZS1ub24tZW51bWVyYWJsZS1wcm9wZXJ0eS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3IuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2RlZmluZS1idWlsdC1pbi1hY2Nlc3Nvci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZGVmaW5lLWJ1aWx0LWluLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9kZWZpbmUtZ2xvYmFsLXByb3BlcnR5LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9kZXNjcmlwdG9ycy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZG9jdW1lbnQtY3JlYXRlLWVsZW1lbnQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2VudW0tYnVnLWtleXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Vudmlyb25tZW50LXVzZXItYWdlbnQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Vudmlyb25tZW50LXY4LXZlcnNpb24uanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Vycm9yLXN0YWNrLWNsZWFyLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9lcnJvci1zdGFjay1pbnN0YWxsLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9lcnJvci1zdGFjay1pbnN0YWxsYWJsZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZXhwb3J0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9mYWlscy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZnVuY3Rpb24tYXBwbHkuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Z1bmN0aW9uLWJpbmQtbmF0aXZlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9mdW5jdGlvbi1jYWxsLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9mdW5jdGlvbi1uYW1lLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9mdW5jdGlvbi11bmN1cnJ5LXRoaXMtYWNjZXNzb3IuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvZ2V0LWJ1aWx0LWluLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9nZXQtbWV0aG9kLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9nbG9iYWwtdGhpcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaGFzLW93bi1wcm9wZXJ0eS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaGlkZGVuLWtleXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2h0bWwuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2llOC1kb20tZGVmaW5lLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pbmRleGVkLW9iamVjdC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaW5oZXJpdC1pZi1yZXF1aXJlZC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaW5zcGVjdC1zb3VyY2UuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2luc3RhbGwtZXJyb3ItY2F1c2UuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2ludGVybmFsLXN0YXRlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pcy1jYWxsYWJsZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaXMtZm9yY2VkLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pcy1udWxsLW9yLXVuZGVmaW5lZC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvaXMtb2JqZWN0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9pcy1wb3NzaWJsZS1wcm90b3R5cGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2lzLXB1cmUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL2lzLXN5bWJvbC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvbGVuZ3RoLW9mLWFycmF5LWxpa2UuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL21ha2UtYnVpbHQtaW4uanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL21hdGgtdHJ1bmMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL25vcm1hbGl6ZS1zdHJpbmctYXJndW1lbnQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1jcmVhdGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1kZWZpbmUtcHJvcGVydGllcy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWdldC1vd24tcHJvcGVydHktZGVzY3JpcHRvci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LWdldC1vd24tcHJvcGVydHktbmFtZXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1nZXQtb3duLXByb3BlcnR5LXN5bWJvbHMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1pcy1wcm90b3R5cGUtb2YuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1rZXlzLWludGVybmFsLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9vYmplY3Qta2V5cy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvb2JqZWN0LXByb3BlcnR5LWlzLWVudW1lcmFibGUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL29iamVjdC1zZXQtcHJvdG90eXBlLW9mLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9vcmRpbmFyeS10by1wcmltaXRpdmUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL293bi1rZXlzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9wcm94eS1hY2Nlc3Nvci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvcmVxdWlyZS1vYmplY3QtY29lcmNpYmxlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9zaGFyZWQta2V5LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy9zaGFyZWQtc3RvcmUuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3NoYXJlZC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvc3ltYm9sLWNvbnN0cnVjdG9yLWRldGVjdGlvbi5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdG8tYWJzb2x1dGUtaW5kZXguanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RvLWluZGV4ZWQtb2JqZWN0LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90by1pbnRlZ2VyLW9yLWluZmluaXR5LmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90by1sZW5ndGguanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RvLW9iamVjdC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdG8tcHJpbWl0aXZlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90by1wcm9wZXJ0eS1rZXkuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3RvLXN0cmluZy10YWctc3VwcG9ydC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvdG8tc3RyaW5nLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy90cnktdG8tc3RyaW5nLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy91aWQuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvaW50ZXJuYWxzL3VzZS1zeW1ib2wtYXMtdWlkLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy92OC1wcm90b3R5cGUtZGVmaW5lLWJ1Zy5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvd2Vhay1tYXAtYmFzaWMtZGV0ZWN0aW9uLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL2ludGVybmFscy93ZWxsLWtub3duLXN5bWJvbC5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9pbnRlcm5hbHMvd3JhcC1lcnJvci1jb25zdHJ1Y3Rvci13aXRoLWNhdXNlLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL2NvcmUtanNAMy40MC4wL25vZGVfbW9kdWxlcy9jb3JlLWpzL21vZHVsZXMvZXMuYXJyYXkuaW5jbHVkZXMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vY29yZS1qc0AzLjQwLjAvbm9kZV9tb2R1bGVzL2NvcmUtanMvbW9kdWxlcy9lcy5lcnJvci5jYXVzZS5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3JlLWpzQDMuNDAuMC9ub2RlX21vZHVsZXMvY29yZS1qcy9tb2R1bGVzL3dlYi5zZWxmLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhZGd1YXJkK2xvZ2dlckAxLjEuMS9ub2RlX21vZHVsZXMvQGFkZ3VhcmQvbG9nZ2VyL2Rpc3QvZXMvaW5kZXgubWpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL25hbm9pZEAzLjMuNi9ub2RlX21vZHVsZXMvbmFub2lkL2luZGV4LmJyb3dzZXIuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2FtZCBvcHRpb25zIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vcGFnZXMvdGhhbmt5b3UvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vKiBVQVBhcnNlci5qcyB2MS4wLjM2XG4gICBDb3B5cmlnaHQgwqkgMjAxMi0yMDIxIEZhaXNhbCBTYWxtYW4gPGZAZmFpc2FsbWFuLmNvbT5cbiAgIE1JVCBMaWNlbnNlICovLypcbiAgIERldGVjdCBCcm93c2VyLCBFbmdpbmUsIE9TLCBDUFUsIGFuZCBEZXZpY2UgdHlwZS9tb2RlbCBmcm9tIFVzZXItQWdlbnQgZGF0YS5cbiAgIFN1cHBvcnRzIGJyb3dzZXIgJiBub2RlLmpzIGVudmlyb25tZW50LiBcbiAgIERlbW8gICA6IGh0dHBzOi8vZmFpc2FsbWFuLmdpdGh1Yi5pby91YS1wYXJzZXItanNcbiAgIFNvdXJjZSA6IGh0dHBzOi8vZ2l0aHViLmNvbS9mYWlzYWxtYW4vdWEtcGFyc2VyLWpzICovXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuKGZ1bmN0aW9uICh3aW5kb3csIHVuZGVmaW5lZCkge1xuXG4gICAgJ3VzZSBzdHJpY3QnO1xuXG4gICAgLy8vLy8vLy8vLy8vLy9cbiAgICAvLyBDb25zdGFudHNcbiAgICAvLy8vLy8vLy8vLy8vXG5cblxuICAgIHZhciBMSUJWRVJTSU9OICA9ICcxLjAuMzYnLFxuICAgICAgICBFTVBUWSAgICAgICA9ICcnLFxuICAgICAgICBVTktOT1dOICAgICA9ICc/JyxcbiAgICAgICAgRlVOQ19UWVBFICAgPSAnZnVuY3Rpb24nLFxuICAgICAgICBVTkRFRl9UWVBFICA9ICd1bmRlZmluZWQnLFxuICAgICAgICBPQkpfVFlQRSAgICA9ICdvYmplY3QnLFxuICAgICAgICBTVFJfVFlQRSAgICA9ICdzdHJpbmcnLFxuICAgICAgICBNQUpPUiAgICAgICA9ICdtYWpvcicsXG4gICAgICAgIE1PREVMICAgICAgID0gJ21vZGVsJyxcbiAgICAgICAgTkFNRSAgICAgICAgPSAnbmFtZScsXG4gICAgICAgIFRZUEUgICAgICAgID0gJ3R5cGUnLFxuICAgICAgICBWRU5ET1IgICAgICA9ICd2ZW5kb3InLFxuICAgICAgICBWRVJTSU9OICAgICA9ICd2ZXJzaW9uJyxcbiAgICAgICAgQVJDSElURUNUVVJFPSAnYXJjaGl0ZWN0dXJlJyxcbiAgICAgICAgQ09OU09MRSAgICAgPSAnY29uc29sZScsXG4gICAgICAgIE1PQklMRSAgICAgID0gJ21vYmlsZScsXG4gICAgICAgIFRBQkxFVCAgICAgID0gJ3RhYmxldCcsXG4gICAgICAgIFNNQVJUVFYgICAgID0gJ3NtYXJ0dHYnLFxuICAgICAgICBXRUFSQUJMRSAgICA9ICd3ZWFyYWJsZScsXG4gICAgICAgIEVNQkVEREVEICAgID0gJ2VtYmVkZGVkJyxcbiAgICAgICAgVUFfTUFYX0xFTkdUSCA9IDM1MDtcblxuICAgIHZhciBBTUFaT04gID0gJ0FtYXpvbicsXG4gICAgICAgIEFQUExFICAgPSAnQXBwbGUnLFxuICAgICAgICBBU1VTICAgID0gJ0FTVVMnLFxuICAgICAgICBCTEFDS0JFUlJZID0gJ0JsYWNrQmVycnknLFxuICAgICAgICBCUk9XU0VSID0gJ0Jyb3dzZXInLFxuICAgICAgICBDSFJPTUUgID0gJ0Nocm9tZScsXG4gICAgICAgIEVER0UgICAgPSAnRWRnZScsXG4gICAgICAgIEZJUkVGT1ggPSAnRmlyZWZveCcsXG4gICAgICAgIEdPT0dMRSAgPSAnR29vZ2xlJyxcbiAgICAgICAgSFVBV0VJICA9ICdIdWF3ZWknLFxuICAgICAgICBMRyAgICAgID0gJ0xHJyxcbiAgICAgICAgTUlDUk9TT0ZUID0gJ01pY3Jvc29mdCcsXG4gICAgICAgIE1PVE9ST0xBICA9ICdNb3Rvcm9sYScsXG4gICAgICAgIE9QRVJBICAgPSAnT3BlcmEnLFxuICAgICAgICBTQU1TVU5HID0gJ1NhbXN1bmcnLFxuICAgICAgICBTSEFSUCAgID0gJ1NoYXJwJyxcbiAgICAgICAgU09OWSAgICA9ICdTb255JyxcbiAgICAgICAgVklFUkEgICA9ICdWaWVyYScsXG4gICAgICAgIFhJQU9NSSAgPSAnWGlhb21pJyxcbiAgICAgICAgWkVCUkEgICA9ICdaZWJyYScsXG4gICAgICAgIEZBQ0VCT09LICAgID0gJ0ZhY2Vib29rJyxcbiAgICAgICAgQ0hST01JVU1fT1MgPSAnQ2hyb21pdW0gT1MnLFxuICAgICAgICBNQUNfT1MgID0gJ01hYyBPUyc7XG5cbiAgICAvLy8vLy8vLy8vL1xuICAgIC8vIEhlbHBlclxuICAgIC8vLy8vLy8vLy9cblxuICAgIHZhciBleHRlbmQgPSBmdW5jdGlvbiAocmVnZXhlcywgZXh0ZW5zaW9ucykge1xuICAgICAgICAgICAgdmFyIG1lcmdlZFJlZ2V4ZXMgPSB7fTtcbiAgICAgICAgICAgIGZvciAodmFyIGkgaW4gcmVnZXhlcykge1xuICAgICAgICAgICAgICAgIGlmIChleHRlbnNpb25zW2ldICYmIGV4dGVuc2lvbnNbaV0ubGVuZ3RoICUgMiA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBtZXJnZWRSZWdleGVzW2ldID0gZXh0ZW5zaW9uc1tpXS5jb25jYXQocmVnZXhlc1tpXSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbWVyZ2VkUmVnZXhlc1tpXSA9IHJlZ2V4ZXNbaV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lcmdlZFJlZ2V4ZXM7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcml6ZSA9IGZ1bmN0aW9uIChhcnIpIHtcbiAgICAgICAgICAgIHZhciBlbnVtcyA9IHt9O1xuICAgICAgICAgICAgZm9yICh2YXIgaT0wOyBpPGFyci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGVudW1zW2FycltpXS50b1VwcGVyQ2FzZSgpXSA9IGFycltpXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBlbnVtcztcbiAgICAgICAgfSxcbiAgICAgICAgaGFzID0gZnVuY3Rpb24gKHN0cjEsIHN0cjIpIHtcbiAgICAgICAgICAgIHJldHVybiB0eXBlb2Ygc3RyMSA9PT0gU1RSX1RZUEUgPyBsb3dlcml6ZShzdHIyKS5pbmRleE9mKGxvd2VyaXplKHN0cjEpKSAhPT0gLTEgOiBmYWxzZTtcbiAgICAgICAgfSxcbiAgICAgICAgbG93ZXJpemUgPSBmdW5jdGlvbiAoc3RyKSB7XG4gICAgICAgICAgICByZXR1cm4gc3RyLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIH0sXG4gICAgICAgIG1ham9yaXplID0gZnVuY3Rpb24gKHZlcnNpb24pIHtcbiAgICAgICAgICAgIHJldHVybiB0eXBlb2YodmVyc2lvbikgPT09IFNUUl9UWVBFID8gdmVyc2lvbi5yZXBsYWNlKC9bXlxcZFxcLl0vZywgRU1QVFkpLnNwbGl0KCcuJylbMF0gOiB1bmRlZmluZWQ7XG4gICAgICAgIH0sXG4gICAgICAgIHRyaW0gPSBmdW5jdGlvbiAoc3RyLCBsZW4pIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Yoc3RyKSA9PT0gU1RSX1RZUEUpIHtcbiAgICAgICAgICAgICAgICBzdHIgPSBzdHIucmVwbGFjZSgvXlxcc1xccyovLCBFTVBUWSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZihsZW4pID09PSBVTkRFRl9UWVBFID8gc3RyIDogc3RyLnN1YnN0cmluZygwLCBVQV9NQVhfTEVOR1RIKTtcbiAgICAgICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8vLy8vLy8vLy8vLy8vXG4gICAgLy8gTWFwIGhlbHBlclxuICAgIC8vLy8vLy8vLy8vLy8vXG5cbiAgICB2YXIgcmd4TWFwcGVyID0gZnVuY3Rpb24gKHVhLCBhcnJheXMpIHtcblxuICAgICAgICAgICAgdmFyIGkgPSAwLCBqLCBrLCBwLCBxLCBtYXRjaGVzLCBtYXRjaDtcblxuICAgICAgICAgICAgLy8gbG9vcCB0aHJvdWdoIGFsbCByZWdleGVzIG1hcHNcbiAgICAgICAgICAgIHdoaWxlIChpIDwgYXJyYXlzLmxlbmd0aCAmJiAhbWF0Y2hlcykge1xuXG4gICAgICAgICAgICAgICAgdmFyIHJlZ2V4ID0gYXJyYXlzW2ldLCAgICAgICAvLyBldmVuIHNlcXVlbmNlICgwLDIsNCwuLilcbiAgICAgICAgICAgICAgICAgICAgcHJvcHMgPSBhcnJheXNbaSArIDFdOyAgIC8vIG9kZCBzZXF1ZW5jZSAoMSwzLDUsLi4pXG4gICAgICAgICAgICAgICAgaiA9IGsgPSAwO1xuXG4gICAgICAgICAgICAgICAgLy8gdHJ5IG1hdGNoaW5nIHVhc3RyaW5nIHdpdGggcmVnZXhlc1xuICAgICAgICAgICAgICAgIHdoaWxlIChqIDwgcmVnZXgubGVuZ3RoICYmICFtYXRjaGVzKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZWdleFtqXSkgeyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBtYXRjaGVzID0gcmVnZXhbaisrXS5leGVjKHVhKTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAoISFtYXRjaGVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHAgPSAwOyBwIDwgcHJvcHMubGVuZ3RoOyBwKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXRjaCA9IG1hdGNoZXNbKytrXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBxID0gcHJvcHNbcF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgZ2l2ZW4gcHJvcGVydHkgaXMgYWN0dWFsbHkgYXJyYXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHEgPT09IE9CSl9UWVBFICYmIHEubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocS5sZW5ndGggPT09IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgcVsxXSA9PSBGVU5DX1RZUEUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhc3NpZ24gbW9kaWZpZWQgbWF0Y2hcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW3FbMF1dID0gcVsxXS5jYWxsKHRoaXMsIG1hdGNoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYXNzaWduIGdpdmVuIHZhbHVlLCBpZ25vcmUgcmVnZXggbWF0Y2hcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW3FbMF1dID0gcVsxXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChxLmxlbmd0aCA9PT0gMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgd2hldGhlciBmdW5jdGlvbiBvciByZWdleFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBxWzFdID09PSBGVU5DX1RZUEUgJiYgIShxWzFdLmV4ZWMgJiYgcVsxXS50ZXN0KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhbGwgZnVuY3Rpb24gKHVzdWFsbHkgc3RyaW5nIG1hcHBlcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW3FbMF1dID0gbWF0Y2ggPyBxWzFdLmNhbGwodGhpcywgbWF0Y2gsIHFbMl0pIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBzYW5pdGl6ZSBtYXRjaCB1c2luZyBnaXZlbiByZWdleFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbcVswXV0gPSBtYXRjaCA/IG1hdGNoLnJlcGxhY2UocVsxXSwgcVsyXSkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocS5sZW5ndGggPT09IDQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW3FbMF1dID0gbWF0Y2ggPyBxWzNdLmNhbGwodGhpcywgbWF0Y2gucmVwbGFjZShxWzFdLCBxWzJdKSkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW3FdID0gbWF0Y2ggPyBtYXRjaCA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaSArPSAyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIHN0ck1hcHBlciA9IGZ1bmN0aW9uIChzdHIsIG1hcCkge1xuXG4gICAgICAgICAgICBmb3IgKHZhciBpIGluIG1hcCkge1xuICAgICAgICAgICAgICAgIC8vIGNoZWNrIGlmIGN1cnJlbnQgdmFsdWUgaXMgYXJyYXlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1hcFtpXSA9PT0gT0JKX1RZUEUgJiYgbWFwW2ldLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBtYXBbaV0ubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoYXMobWFwW2ldW2pdLCBzdHIpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChpID09PSBVTktOT1dOKSA/IHVuZGVmaW5lZCA6IGk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGhhcyhtYXBbaV0sIHN0cikpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChpID09PSBVTktOT1dOKSA/IHVuZGVmaW5lZCA6IGk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHN0cjtcbiAgICB9O1xuXG4gICAgLy8vLy8vLy8vLy8vLy8vXG4gICAgLy8gU3RyaW5nIG1hcFxuICAgIC8vLy8vLy8vLy8vLy8vXG5cbiAgICAvLyBTYWZhcmkgPCAzLjBcbiAgICB2YXIgb2xkU2FmYXJpTWFwID0ge1xuICAgICAgICAgICAgJzEuMCcgICA6ICcvOCcsXG4gICAgICAgICAgICAnMS4yJyAgIDogJy8xJyxcbiAgICAgICAgICAgICcxLjMnICAgOiAnLzMnLFxuICAgICAgICAgICAgJzIuMCcgICA6ICcvNDEyJyxcbiAgICAgICAgICAgICcyLjAuMicgOiAnLzQxNicsXG4gICAgICAgICAgICAnMi4wLjMnIDogJy80MTcnLFxuICAgICAgICAgICAgJzIuMC40JyA6ICcvNDE5JyxcbiAgICAgICAgICAgICc/JyAgICAgOiAnLydcbiAgICAgICAgfSxcbiAgICAgICAgd2luZG93c1ZlcnNpb25NYXAgPSB7XG4gICAgICAgICAgICAnTUUnICAgICAgICA6ICc0LjkwJyxcbiAgICAgICAgICAgICdOVCAzLjExJyAgIDogJ05UMy41MScsXG4gICAgICAgICAgICAnTlQgNC4wJyAgICA6ICdOVDQuMCcsXG4gICAgICAgICAgICAnMjAwMCcgICAgICA6ICdOVCA1LjAnLFxuICAgICAgICAgICAgJ1hQJyAgICAgICAgOiBbJ05UIDUuMScsICdOVCA1LjInXSxcbiAgICAgICAgICAgICdWaXN0YScgICAgIDogJ05UIDYuMCcsXG4gICAgICAgICAgICAnNycgICAgICAgICA6ICdOVCA2LjEnLFxuICAgICAgICAgICAgJzgnICAgICAgICAgOiAnTlQgNi4yJyxcbiAgICAgICAgICAgICc4LjEnICAgICAgIDogJ05UIDYuMycsXG4gICAgICAgICAgICAnMTAnICAgICAgICA6IFsnTlQgNi40JywgJ05UIDEwLjAnXSxcbiAgICAgICAgICAgICdSVCcgICAgICAgIDogJ0FSTSdcbiAgICB9O1xuXG4gICAgLy8vLy8vLy8vLy8vLy9cbiAgICAvLyBSZWdleCBtYXBcbiAgICAvLy8vLy8vLy8vLy8vXG5cbiAgICB2YXIgcmVnZXhlcyA9IHtcblxuICAgICAgICBicm93c2VyIDogW1tcblxuICAgICAgICAgICAgL1xcYig/OmNybW98Y3Jpb3MpXFwvKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2hyb21lIGZvciBBbmRyb2lkL2lPU1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCAnQ2hyb21lJ11dLCBbXG4gICAgICAgICAgICAvZWRnKD86ZXxpb3N8YSk/XFwvKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1pY3Jvc29mdCBFZGdlXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdFZGdlJ11dLCBbXG5cbiAgICAgICAgICAgIC8vIFByZXN0byBiYXNlZFxuICAgICAgICAgICAgLyhvcGVyYSBtaW5pKVxcLyhbLVxcd1xcLl0rKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPcGVyYSBNaW5pXG4gICAgICAgICAgICAvKG9wZXJhIFttb2JpbGV0YWJdezMsNn0pXFxiLit2ZXJzaW9uXFwvKFstXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAvLyBPcGVyYSBNb2JpL1RhYmxldFxuICAgICAgICAgICAgLyhvcGVyYSkoPzouK3ZlcnNpb25cXC98W1xcLyBdKykoW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gT3BlcmFcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgL29waW9zW1xcLyBdKyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPcGVyYSBtaW5pIG9uIGlwaG9uZSA+PSA4LjBcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgT1BFUkErJyBNaW5pJ11dLCBbXG4gICAgICAgICAgICAvXFxib3ByXFwvKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPcGVyYSBXZWJraXRcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgT1BFUkFdXSwgW1xuXG4gICAgICAgICAgICAvLyBNaXhlZFxuICAgICAgICAgICAgLyhraW5kbGUpXFwvKFtcXHdcXC5dKykvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBLaW5kbGVcbiAgICAgICAgICAgIC8obHVuYXNjYXBlfG1heHRob258bmV0ZnJvbnR8amFzbWluZXxibGF6ZXIpW1xcLyBdPyhbXFx3XFwuXSopL2ksICAgICAgLy8gTHVuYXNjYXBlL01heHRob24vTmV0ZnJvbnQvSmFzbWluZS9CbGF6ZXJcbiAgICAgICAgICAgIC8vIFRyaWRlbnQgYmFzZWRcbiAgICAgICAgICAgIC8oYXZhbnQgfGllbW9iaWxlfHNsaW0pKD86YnJvd3Nlcik/W1xcLyBdPyhbXFx3XFwuXSopL2ksICAgICAgICAgICAgICAgLy8gQXZhbnQvSUVNb2JpbGUvU2xpbUJyb3dzZXJcbiAgICAgICAgICAgIC8oYmE/aWR1YnJvd3NlcilbXFwvIF0/KFtcXHdcXC5dKykvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQmFpZHUgQnJvd3NlclxuICAgICAgICAgICAgLyg/Om1zfFxcKCkoaWUpIChbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJbnRlcm5ldCBFeHBsb3JlclxuXG4gICAgICAgICAgICAvLyBXZWJraXQvS0hUTUwgYmFzZWQgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZsb2NrL1JvY2tNZWx0L01pZG9yaS9FcGlwaGFueS9TaWxrL1NreWZpcmUvQm9sdC9Jcm9uL0lyaWRpdW0vUGhhbnRvbUpTL0Jvd3Nlci9RdXBaaWxsYS9GYWxrb25cbiAgICAgICAgICAgIC8oZmxvY2t8cm9ja21lbHR8bWlkb3JpfGVwaXBoYW55fHNpbGt8c2t5ZmlyZXxib2x0fGlyb258dml2YWxkaXxpcmlkaXVtfHBoYW50b21qc3xib3dzZXJ8cXVhcmt8cXVwemlsbGF8ZmFsa29ufHJla29ucXxwdWZmaW58YnJhdmV8d2hhbGUoPyEuK25hdmVyKXxxcWJyb3dzZXJsaXRlfHFxfGR1Y2tkdWNrZ28pXFwvKFstXFx3XFwuXSspL2ksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJla29ucS9QdWZmaW4vQnJhdmUvV2hhbGUvUVFCcm93c2VyTGl0ZS9RUSwgYWthIFNob3VRXG4gICAgICAgICAgICAvKGhleXRhcHxvdmkpYnJvd3NlclxcLyhbXFxkXFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhleXRhcC9PdmlcbiAgICAgICAgICAgIC8od2VpYm8pX18oW1xcZFxcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBXZWlib1xuICAgICAgICAgICAgXSwgW05BTUUsIFZFUlNJT05dLCBbXG4gICAgICAgICAgICAvKD86XFxidWM/ID9icm93c2VyfCg/Omp1Yy4rKXVjd2ViKVtcXC8gXT8oW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAvLyBVQ0Jyb3dzZXJcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgJ1VDJytCUk9XU0VSXV0sIFtcbiAgICAgICAgICAgIC9taWNyb20uK1xcYnFiY29yZVxcLyhbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFdlQ2hhdCBEZXNrdG9wIGZvciBXaW5kb3dzIEJ1aWx0LWluIEJyb3dzZXJcbiAgICAgICAgICAgIC9cXGJxYmNvcmVcXC8oW1xcd1xcLl0rKS4rbWljcm9tL2lcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgJ1dlQ2hhdChXaW4pIERlc2t0b3AnXV0sIFtcbiAgICAgICAgICAgIC9taWNyb21lc3NlbmdlclxcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gV2VDaGF0XG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdXZUNoYXQnXV0sIFtcbiAgICAgICAgICAgIC9rb25xdWVyb3JcXC8oW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gS29ucXVlcm9yXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdLb25xdWVyb3InXV0sIFtcbiAgICAgICAgICAgIC90cmlkZW50Litydls6IF0oW1xcd1xcLl17MSw5fSlcXGIuK2xpa2UgZ2Vja28vaSAgICAgICAgICAgICAgICAgICAgICAgLy8gSUUxMVxuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCAnSUUnXV0sIFtcbiAgICAgICAgICAgIC95YSg/OnNlYXJjaCk/YnJvd3NlclxcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gWWFuZGV4XG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdZYW5kZXgnXV0sIFtcbiAgICAgICAgICAgIC8oYXZhc3R8YXZnKVxcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQXZhc3QvQVZHIFNlY3VyZSBCcm93c2VyXG4gICAgICAgICAgICBdLCBbW05BTUUsIC8oLispLywgJyQxIFNlY3VyZSAnK0JST1dTRVJdLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgL1xcYmZvY3VzXFwvKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmlyZWZveCBGb2N1c1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCBGSVJFRk9YKycgRm9jdXMnXV0sIFtcbiAgICAgICAgICAgIC9cXGJvcHRcXC8oW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE9wZXJhIFRvdWNoXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsIE9QRVJBKycgVG91Y2gnXV0sIFtcbiAgICAgICAgICAgIC9jb2NfY29jXFx3K1xcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENvYyBDb2MgQnJvd3NlclxuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCAnQ29jIENvYyddXSwgW1xuICAgICAgICAgICAgL2RvbGZpblxcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBEb2xwaGluXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdEb2xwaGluJ11dLCBbXG4gICAgICAgICAgICAvY29hc3RcXC8oW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE9wZXJhIENvYXN0XG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsIE9QRVJBKycgQ29hc3QnXV0sIFtcbiAgICAgICAgICAgIC9taXVpYnJvd3NlclxcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTUlVSSBCcm93c2VyXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdNSVVJICcrQlJPV1NFUl1dLCBbXG4gICAgICAgICAgICAvZnhpb3NcXC8oWy1cXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpcmVmb3ggZm9yIGlPU1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCBGSVJFRk9YXV0sIFtcbiAgICAgICAgICAgIC9cXGJxaWh1fChxaT9obz9vP3wzNjApYnJvd3Nlci9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDM2MFxuICAgICAgICAgICAgXSwgW1tOQU1FLCAnMzYwICcrQlJPV1NFUl1dLCBbXG4gICAgICAgICAgICAvKG9jdWx1c3xzYW1zdW5nfHNhaWxmaXNofGh1YXdlaSlicm93c2VyXFwvKFtcXHdcXC5dKykvaVxuICAgICAgICAgICAgXSwgW1tOQU1FLCAvKC4rKS8sICckMSAnK0JST1dTRVJdLCBWRVJTSU9OXSwgWyAgICAgICAgICAgICAgICAgICAgICAvLyBPY3VsdXMvU2Ftc3VuZy9TYWlsZmlzaC9IdWF3ZWkgQnJvd3NlclxuICAgICAgICAgICAgLyhjb21vZG9fZHJhZ29uKVxcLyhbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBDb21vZG8gRHJhZ29uXG4gICAgICAgICAgICBdLCBbW05BTUUsIC9fL2csICcgJ10sIFZFUlNJT05dLCBbXG4gICAgICAgICAgICAvKGVsZWN0cm9uKVxcLyhbXFx3XFwuXSspIHNhZmFyaS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEVsZWN0cm9uLWJhc2VkIEFwcFxuICAgICAgICAgICAgLyh0ZXNsYSkoPzogcXRjYXJicm93c2VyfFxcLygyMFxcZFxcZFxcLlstXFx3XFwuXSspKS9pLCAgICAgICAgICAgICAgICAgICAvLyBUZXNsYVxuICAgICAgICAgICAgL20/KHFxYnJvd3NlcnxiYWlkdWJveGFwcHwyMzQ1RXhwbG9yZXIpW1xcLyBdPyhbXFx3XFwuXSspL2kgICAgICAgICAgICAvLyBRUUJyb3dzZXIvQmFpZHUgQXBwLzIzNDUgQnJvd3NlclxuICAgICAgICAgICAgXSwgW05BTUUsIFZFUlNJT05dLCBbXG4gICAgICAgICAgICAvKG1ldGFzcilbXFwvIF0/KFtcXHdcXC5dKykvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNvdUdvdUJyb3dzZXJcbiAgICAgICAgICAgIC8obGJicm93c2VyKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTGllQmFvIEJyb3dzZXJcbiAgICAgICAgICAgIC9cXFsobGlua2VkaW4pYXBwXFxdL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMaW5rZWRJbiBBcHAgZm9yIGlPUyAmIEFuZHJvaWRcbiAgICAgICAgICAgIF0sIFtOQU1FXSwgW1xuXG4gICAgICAgICAgICAvLyBXZWJWaWV3XG4gICAgICAgICAgICAvKCg/OmZiYW5cXC9mYmlvc3xmYl9pYWJcXC9mYjRhKSg/IS4rZmJhdil8O2ZiYXZcXC8oW1xcd1xcLl0rKTspL2kgICAgICAgLy8gRmFjZWJvb2sgQXBwIGZvciBpT1MgJiBBbmRyb2lkXG4gICAgICAgICAgICBdLCBbW05BTUUsIEZBQ0VCT09LXSwgVkVSU0lPTl0sIFtcbiAgICAgICAgICAgIC8oa2FrYW8oPzp0YWxrfHN0b3J5KSlbXFwvIF0oW1xcd1xcLl0rKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gS2FrYW8gQXBwXG4gICAgICAgICAgICAvKG5hdmVyKVxcKC4qPyhcXGQrXFwuW1xcd1xcLl0rKS4qXFwpL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5hdmVyIEluQXBwXG4gICAgICAgICAgICAvc2FmYXJpIChsaW5lKVxcLyhbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIExpbmUgQXBwIGZvciBpT1NcbiAgICAgICAgICAgIC9cXGIobGluZSlcXC8oW1xcd1xcLl0rKVxcL2lhYi9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMaW5lIEFwcCBmb3IgQW5kcm9pZFxuICAgICAgICAgICAgLyhjaHJvbWl1bXxpbnN0YWdyYW18c25hcGNoYXQpW1xcLyBdKFstXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAvLyBDaHJvbWl1bS9JbnN0YWdyYW0vU25hcGNoYXRcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgL1xcYmdzYVxcLyhbXFx3XFwuXSspIC4qc2FmYXJpXFwvL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdvb2dsZSBTZWFyY2ggQXBwbGlhbmNlIG9uIGlPU1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCAnR1NBJ11dLCBbXG4gICAgICAgICAgICAvbXVzaWNhbF9seSg/Oi4rYXBwXz92ZXJzaW9uXFwvfF8pKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRpa1Rva1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCAnVGlrVG9rJ11dLCBbXG5cbiAgICAgICAgICAgIC9oZWFkbGVzc2Nocm9tZSg/OlxcLyhbXFx3XFwuXSspfCApL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2hyb21lIEhlYWRsZXNzXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsIENIUk9NRSsnIEhlYWRsZXNzJ11dLCBbXG5cbiAgICAgICAgICAgIC8gd3ZcXCkuKyhjaHJvbWUpXFwvKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENocm9tZSBXZWJWaWV3XG4gICAgICAgICAgICBdLCBbW05BTUUsIENIUk9NRSsnIFdlYlZpZXcnXSwgVkVSU0lPTl0sIFtcblxuICAgICAgICAgICAgL2Ryb2lkLisgdmVyc2lvblxcLyhbXFx3XFwuXSspXFxiLisoPzptb2JpbGUgc2FmYXJpfHNhZmFyaSkvaSAgICAgICAgICAgLy8gQW5kcm9pZCBCcm93c2VyXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgW05BTUUsICdBbmRyb2lkICcrQlJPV1NFUl1dLCBbXG5cbiAgICAgICAgICAgIC8oY2hyb21lfG9tbml3ZWJ8YXJvcmF8W3RpemVub2thXXs1fSA/YnJvd3NlcilcXC92PyhbXFx3XFwuXSspL2kgICAgICAgLy8gQ2hyb21lL09tbmlXZWIvQXJvcmEvVGl6ZW4vTm9raWFcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuXG4gICAgICAgICAgICAvdmVyc2lvblxcLyhbXFx3XFwuXFwsXSspIC4qbW9iaWxlXFwvXFx3KyAoc2FmYXJpKS9pICAgICAgICAgICAgICAgICAgICAgIC8vIE1vYmlsZSBTYWZhcmlcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgJ01vYmlsZSBTYWZhcmknXV0sIFtcbiAgICAgICAgICAgIC92ZXJzaW9uXFwvKFtcXHcoXFwufFxcLCldKykgLioobW9iaWxlID9zYWZhcml8c2FmYXJpKS9pICAgICAgICAgICAgICAgIC8vIFNhZmFyaSAmIFNhZmFyaSBNb2JpbGVcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBOQU1FXSwgW1xuICAgICAgICAgICAgL3dlYmtpdC4rPyhtb2JpbGUgP3NhZmFyaXxzYWZhcmkpKFxcL1tcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAvLyBTYWZhcmkgPCAzLjBcbiAgICAgICAgICAgIF0sIFtOQU1FLCBbVkVSU0lPTiwgc3RyTWFwcGVyLCBvbGRTYWZhcmlNYXBdXSwgW1xuXG4gICAgICAgICAgICAvKHdlYmtpdHxraHRtbClcXC8oW1xcd1xcLl0rKS9pXG4gICAgICAgICAgICBdLCBbTkFNRSwgVkVSU0lPTl0sIFtcblxuICAgICAgICAgICAgLy8gR2Vja28gYmFzZWRcbiAgICAgICAgICAgIC8obmF2aWdhdG9yfG5ldHNjYXBlXFxkPylcXC8oWy1cXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5ldHNjYXBlXG4gICAgICAgICAgICBdLCBbW05BTUUsICdOZXRzY2FwZSddLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgL21vYmlsZSB2cjsgcnY6KFtcXHdcXC5dKylcXCkuK2ZpcmVmb3gvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBGaXJlZm94IFJlYWxpdHlcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgRklSRUZPWCsnIFJlYWxpdHknXV0sIFtcbiAgICAgICAgICAgIC9la2lvaGYuKyhmbG93KVxcLyhbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmxvd1xuICAgICAgICAgICAgLyhzd2lmdGZveCkvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTd2lmdGZveFxuICAgICAgICAgICAgLyhpY2VkcmFnb258aWNld2Vhc2VsfGNhbWlub3xjaGltZXJhfGZlbm5lY3xtYWVtbyBicm93c2VyfG1pbmltb3xjb25rZXJvcnxrbGFyKVtcXC8gXT8oW1xcd1xcLlxcK10rKS9pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJY2VEcmFnb24vSWNld2Vhc2VsL0NhbWluby9DaGltZXJhL0Zlbm5lYy9NYWVtby9NaW5pbW8vQ29ua2Vyb3IvS2xhclxuICAgICAgICAgICAgLyhzZWFtb25rZXl8ay1tZWxlb258aWNlY2F0fGljZWFwZXxmaXJlYmlyZHxwaG9lbml4fHBhbGVtb29ufGJhc2lsaXNrfHdhdGVyZm94KVxcLyhbLVxcd1xcLl0rKSQvaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmlyZWZveC9TZWFNb25rZXkvSy1NZWxlb24vSWNlQ2F0L0ljZUFwZS9GaXJlYmlyZC9QaG9lbml4XG4gICAgICAgICAgICAvKGZpcmVmb3gpXFwvKFtcXHdcXC5dKykvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE90aGVyIEZpcmVmb3gtYmFzZWRcbiAgICAgICAgICAgIC8obW96aWxsYSlcXC8oW1xcd1xcLl0rKSAuK3J2XFw6LitnZWNrb1xcL1xcZCsvaSwgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTW96aWxsYVxuXG4gICAgICAgICAgICAvLyBPdGhlclxuICAgICAgICAgICAgLyhwb2xhcmlzfGx5bnh8ZGlsbG98aWNhYnxkb3Jpc3xhbWF5YXx3M218bmV0c3VyZnxzbGVpcG5pcnxvYmlnb3xtb3NhaWN8KD86Z298aWNlfHVwKVtcXC4gXT9icm93c2VyKVstXFwvIF0/dj8oW1xcd1xcLl0rKS9pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQb2xhcmlzL0x5bngvRGlsbG8vaUNhYi9Eb3Jpcy9BbWF5YS93M20vTmV0U3VyZi9TbGVpcG5pci9PYmlnby9Nb3NhaWMvR28vSUNFL1VQLkJyb3dzZXJcbiAgICAgICAgICAgIC8obGlua3MpIFxcKChbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTGlua3NcbiAgICAgICAgICAgIC9wYW5hc29uaWM7KHZpZXJhKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUGFuYXNvbmljIFZpZXJhXG4gICAgICAgICAgICBdLCBbTkFNRSwgVkVSU0lPTl0sIFtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLyhjb2JhbHQpXFwvKFtcXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBDb2JhbHRcbiAgICAgICAgICAgIF0sIFtOQU1FLCBbVkVSU0lPTiwgL21hc3Rlci58bHRzLi8sIFwiXCJdXVxuICAgICAgICBdLFxuXG4gICAgICAgIGNwdSA6IFtbXG5cbiAgICAgICAgICAgIC8oPzooYW1kfHgoPzooPzo4Nnw2NClbLV9dKT98d293fHdpbik2NClbO1xcKV0vaSAgICAgICAgICAgICAgICAgICAgIC8vIEFNRDY0ICh4NjQpXG4gICAgICAgICAgICBdLCBbW0FSQ0hJVEVDVFVSRSwgJ2FtZDY0J11dLCBbXG5cbiAgICAgICAgICAgIC8oaWEzMig/PTspKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSUEzMiAocXVpY2t0aW1lKVxuICAgICAgICAgICAgXSwgW1tBUkNISVRFQ1RVUkUsIGxvd2VyaXplXV0sIFtcblxuICAgICAgICAgICAgLygoPzppWzM0Nl18eCk4NilbO1xcKV0vaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSUEzMiAoeDg2KVxuICAgICAgICAgICAgXSwgW1tBUkNISVRFQ1RVUkUsICdpYTMyJ11dLCBbXG5cbiAgICAgICAgICAgIC9cXGIoYWFyY2g2NHxhcm0odj84ZT9sP3xfPzY0KSlcXGIvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFSTTY0XG4gICAgICAgICAgICBdLCBbW0FSQ0hJVEVDVFVSRSwgJ2FybTY0J11dLCBbXG5cbiAgICAgICAgICAgIC9cXGIoYXJtKD86dls2N10pP2h0P24/W2ZsXXA/KVxcYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBUk1IRlxuICAgICAgICAgICAgXSwgW1tBUkNISVRFQ1RVUkUsICdhcm1oZiddXSwgW1xuXG4gICAgICAgICAgICAvLyBQb2NrZXRQQyBtaXN0YWtlbmx5IGlkZW50aWZpZWQgYXMgUG93ZXJQQ1xuICAgICAgICAgICAgL3dpbmRvd3MgKGNlfG1vYmlsZSk7IHBwYzsvaVxuICAgICAgICAgICAgXSwgW1tBUkNISVRFQ1RVUkUsICdhcm0nXV0sIFtcblxuICAgICAgICAgICAgLygoPzpwcGN8cG93ZXJwYykoPzo2NCk/KSg/OiBtYWN8O3xcXCkpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUG93ZXJQQ1xuICAgICAgICAgICAgXSwgW1tBUkNISVRFQ1RVUkUsIC9vd2VyLywgRU1QVFksIGxvd2VyaXplXV0sIFtcblxuICAgICAgICAgICAgLyhzdW40XFx3KVs7XFwpXS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNQQVJDXG4gICAgICAgICAgICBdLCBbW0FSQ0hJVEVDVFVSRSwgJ3NwYXJjJ11dLCBbXG5cbiAgICAgICAgICAgIC8oKD86YXZyMzJ8aWE2NCg/PTspKXw2OGsoPz1cXCkpfFxcYmFybSg/PXYoPzpbMS03XXxbNS03XTEpbD98O3xlYWJpKXwoPz1hdG1lbCApYXZyfCg/OmlyaXh8bWlwc3xzcGFyYykoPzo2NCk/XFxifHBhLXJpc2MpL2lcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSUE2NCwgNjhLLCBBUk0vNjQsIEFWUi8zMiwgSVJJWC82NCwgTUlQUy82NCwgU1BBUkMvNjQsIFBBLVJJU0NcbiAgICAgICAgICAgIF0sIFtbQVJDSElURUNUVVJFLCBsb3dlcml6ZV1dXG4gICAgICAgIF0sXG5cbiAgICAgICAgZGV2aWNlIDogW1tcblxuICAgICAgICAgICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAgICAgICAgIC8vIE1PQklMRVMgJiBUQUJMRVRTXG4gICAgICAgICAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgICAgICAgICAgIC8vIFNhbXN1bmdcbiAgICAgICAgICAgIC9cXGIoc2NoLWlbODldMFxcZHxzaHctbTM4MHN8c20tW3B0eF1cXHd7Miw0fXxndC1bcG5dXFxkezIsNH18c2doLXQ4WzU2XTl8bmV4dXMgMTApL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgU0FNU1VOR10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYigoPzpzW2NncF1ofGd0fHNtKS1cXHcrfHNjW2ctXT9bXFxkXSthP3xnYWxheHkgbmV4dXMpL2ksXG4gICAgICAgICAgICAvc2Ftc3VuZ1stIF0oWy1cXHddKykvaSxcbiAgICAgICAgICAgIC9zZWMtKHNnaFxcdyspL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgU0FNU1VOR10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuXG4gICAgICAgICAgICAvLyBBcHBsZVxuICAgICAgICAgICAgLyg/OlxcL3xcXCgpKGlwKD86aG9uZXxvZClbXFx3LCBdKikoPzpcXC98OykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaVBvZC9pUGhvbmVcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgQVBQTEVdLCBbVFlQRSwgTU9CSUxFXV0sIFtcbiAgICAgICAgICAgIC9cXCgoaXBhZCk7Wy1cXHdcXCksOyBdK2FwcGxlL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaVBhZFxuICAgICAgICAgICAgL2FwcGxlY29yZW1lZGlhXFwvW1xcd1xcLl0rIFxcKChpcGFkKS9pLFxuICAgICAgICAgICAgL1xcYihpcGFkKVxcZFxcZD8sXFxkXFxkP1s7XFxdXS4raW9zL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgQVBQTEVdLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC8obWFjaW50b3NoKTsvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCBBUFBMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIFNoYXJwXG4gICAgICAgICAgICAvXFxiKHNoLT9bYWx0dnpdP1xcZFxcZFthLWVrbV0/KS9pXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIFNIQVJQXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIEh1YXdlaVxuICAgICAgICAgICAgL1xcYigoPzphZ1tyc11bMjNdP3xiYWgyP3xzaHQ/fGJ0diktYT9bbHddXFxkezJ9KVxcYig/IS4rZFxcL3MpL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgSFVBV0VJXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvKD86aHVhd2VpfGhvbm9yKShbLVxcdyBdKylbO1xcKV0vaSxcbiAgICAgICAgICAgIC9cXGIobmV4dXMgNnB8XFx3ezIsNH1lPy1bYXR1XT9bbG5dW1xcZHhdWzAxMjM1OWNdW2Fkbl0/KVxcYig/IS4rZFxcL3MpL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgSFVBV0VJXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIFhpYW9taVxuICAgICAgICAgICAgL1xcYihwb2NvW1xcdyBdK3xtMlxcZHszfWpcXGRcXGRbYS16XXsyfSkoPzogYnVpfFxcKSkvaSwgICAgICAgICAgICAgICAgICAvLyBYaWFvbWkgUE9DT1xuICAgICAgICAgICAgL1xcYjsgKFxcdyspIGJ1aWxkXFwvaG1cXDEvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gWGlhb21pIEhvbmdtaSAnbnVtZXJpYycgbW9kZWxzXG4gICAgICAgICAgICAvXFxiKGhtWy1fIF0/bm90ZT9bXyBdPyg/OlxcZFxcdyk/KSBidWkvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFhpYW9taSBIb25nbWlcbiAgICAgICAgICAgIC9cXGIocmVkbWlbXFwtXyBdPyg/Om5vdGV8ayk/W1xcd18gXSspKD86IGJ1aXxcXCkpL2ksICAgICAgICAgICAgICAgICAgIC8vIFhpYW9taSBSZWRtaVxuICAgICAgICAgICAgL1xcYihtaVstXyBdPyg/OmFcXGR8b25lfG9uZVtfIF1wbHVzfG5vdGUgbHRlfG1heHxjYyk/W18gXT8oPzpcXGQ/XFx3PylbXyBdPyg/OnBsdXN8c2V8bGl0ZSk/KSg/OiBidWl8XFwpKS9pIC8vIFhpYW9taSBNaVxuICAgICAgICAgICAgXSwgW1tNT0RFTCwgL18vZywgJyAnXSwgW1ZFTkRPUiwgWElBT01JXSwgW1RZUEUsIE1PQklMRV1dLCBbXG4gICAgICAgICAgICAvXFxiKG1pWy1fIF0/KD86cGFkKSg/OltcXHdfIF0rKSkoPzogYnVpfFxcKSkvaSAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1pIFBhZCB0YWJsZXRzXG4gICAgICAgICAgICBdLFtbTU9ERUwsIC9fL2csICcgJ10sIFtWRU5ET1IsIFhJQU9NSV0sIFtUWVBFLCBUQUJMRVRdXSwgW1xuXG4gICAgICAgICAgICAvLyBPUFBPXG4gICAgICAgICAgICAvOyAoXFx3KykgYnVpLisgb3Bwby9pLFxuICAgICAgICAgICAgL1xcYihjcGhbMTJdXFxkezN9fHAoPzphZnxjW2FsXXxkXFx3fGVbYXJdKVttdF1cXGQwfHg5MDA3fGExMDFvcClcXGIvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnT1BQTyddLCBbVFlQRSwgTU9CSUxFXV0sIFtcblxuICAgICAgICAgICAgLy8gVml2b1xuICAgICAgICAgICAgL3Zpdm8gKFxcdyspKD86IGJ1aXxcXCkpL2ksXG4gICAgICAgICAgICAvXFxiKHZbMTJdXFxkezN9XFx3P1thdF0pKD86IGJ1aXw7KS9pXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdWaXZvJ10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuXG4gICAgICAgICAgICAvLyBSZWFsbWVcbiAgICAgICAgICAgIC9cXGIocm14WzEyXVxcZHszfSkoPzogYnVpfDt8XFwpKS9pXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdSZWFsbWUnXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIE1vdG9yb2xhXG4gICAgICAgICAgICAvXFxiKG1pbGVzdG9uZXxkcm9pZCg/OlsyLTR4XXwgKD86YmlvbmljfHgyfHByb3xyYXpyKSk/Oj8oIDRnKT8pXFxiW1xcdyBdK2J1aWxkXFwvL2ksXG4gICAgICAgICAgICAvXFxibW90KD86b3JvbGEpP1stIF0oXFx3KikvaSxcbiAgICAgICAgICAgIC8oKD86bW90b1tcXHdcXChcXCkgXSt8eHRcXGR7Myw0fXxuZXh1cyA2KSg/PSBidWl8XFwpKSkvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCBNT1RPUk9MQV0sIFtUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgL1xcYihtejYwXFxkfHhvb21bMiBdezAsMn0pIGJ1aWxkXFwvL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgTU9UT1JPTEFdLCBbVFlQRSwgVEFCTEVUXV0sIFtcblxuICAgICAgICAgICAgLy8gTEdcbiAgICAgICAgICAgIC8oKD89bGcpP1t2bF1rXFwtP1xcZHszfSkgYnVpfCAzXFwuWy1cXHc7IF17MTB9bGc/LShbMDZjdjldezMsNH0pL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgTEddLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC8obG0oPzotP2YxMDBbbnZdP3wtW1xcd1xcLl0rKSg/PSBidWl8XFwpKXxuZXh1cyBbNDVdKS9pLFxuICAgICAgICAgICAgL1xcYmxnWy1lO1xcLyBdKygoPyFicm93c2VyfG5ldGNhc3R8YW5kcm9pZCB0dilcXHcrKS9pLFxuICAgICAgICAgICAgL1xcYmxnLT8oW1xcZFxcd10rKSBidWkvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCBMR10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuXG4gICAgICAgICAgICAvLyBMZW5vdm9cbiAgICAgICAgICAgIC8oaWRlYXRhYlstXFx3IF0rKS9pLFxuICAgICAgICAgICAgL2xlbm92byA/KHNbNTZdMDAwWy1cXHddK3x0YWIoPzpbXFx3IF0rKXx5dFstXFxkXFx3XXs2fXx0YlstXFxkXFx3XXs2fSkvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnTGVub3ZvJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuXG4gICAgICAgICAgICAvLyBOb2tpYVxuICAgICAgICAgICAgLyg/Om1hZW1vfG5va2lhKS4qKG45MDB8bHVtaWEgXFxkKykvaSxcbiAgICAgICAgICAgIC9ub2tpYVstXyBdPyhbLVxcd1xcLl0qKS9pXG4gICAgICAgICAgICBdLCBbW01PREVMLCAvXy9nLCAnICddLCBbVkVORE9SLCAnTm9raWEnXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIEdvb2dsZVxuICAgICAgICAgICAgLyhwaXhlbCBjKVxcYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gR29vZ2xlIFBpeGVsIENcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgR09PR0xFXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvZHJvaWQuKzsgKHBpeGVsW1xcZGF4bCBdezAsNn0pKD86IGJ1aXxcXCkpL2kgICAgICAgICAgICAgICAgICAgICAgICAgLy8gR29vZ2xlIFBpeGVsXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIEdPT0dMRV0sIFtUWVBFLCBNT0JJTEVdXSwgW1xuXG4gICAgICAgICAgICAvLyBTb255XG4gICAgICAgICAgICAvZHJvaWQuKyAoYT9cXGRbMC0yXXsyfXNvfFtjLWddXFxkezR9fHNvWy1nbF1cXHcrfHhxLWFcXHdbNC03XVsxMl0pKD89IGJ1aXxcXCkuK2Nocm9tZVxcLyg/IVsxLTZdezAsMX1cXGRcXC4pKS9pXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIFNPTlldLCBbVFlQRSwgTU9CSUxFXV0sIFtcbiAgICAgICAgICAgIC9zb255IHRhYmxldCBbcHNdL2ksXG4gICAgICAgICAgICAvXFxiKD86c29ueSk/c2dwXFx3Kyg/OiBidWl8XFwpKS9pXG4gICAgICAgICAgICBdLCBbW01PREVMLCAnWHBlcmlhIFRhYmxldCddLCBbVkVORE9SLCBTT05ZXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG5cbiAgICAgICAgICAgIC8vIE9uZVBsdXNcbiAgICAgICAgICAgIC8gKGtiMjAwNXxpbjIwWzEyXTV8YmUyMFsxMl1bNTldKVxcYi9pLFxuICAgICAgICAgICAgLyg/Om9uZSk/KD86cGx1cyk/IChhXFxkMFxcZFxcZCkoPzogYnxcXCkpL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ09uZVBsdXMnXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIEFtYXpvblxuICAgICAgICAgICAgLyhhbGV4YSl3ZWJtL2ksXG4gICAgICAgICAgICAvKGtmW2Etel17Mn13aXxhZW9bYy1yXXsyfSkoIGJ1aXxcXCkpL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBLaW5kbGUgRmlyZSB3aXRob3V0IFNpbGsgLyBFY2hvIFNob3dcbiAgICAgICAgICAgIC8oa2ZbYS16XSspKCBidWl8XFwpKS4rc2lsa1xcLy9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBLaW5kbGUgRmlyZSBIRFxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCBBTUFaT05dLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC8oKD86c2R8a2YpWzAzNDloaWpvcnN0dXddKykoIGJ1aXxcXCkpLitzaWxrXFwvL2kgICAgICAgICAgICAgICAgICAgICAvLyBGaXJlIFBob25lXG4gICAgICAgICAgICBdLCBbW01PREVMLCAvKC4rKS9nLCAnRmlyZSBQaG9uZSAkMSddLCBbVkVORE9SLCBBTUFaT05dLCBbVFlQRSwgTU9CSUxFXV0sIFtcblxuICAgICAgICAgICAgLy8gQmxhY2tCZXJyeVxuICAgICAgICAgICAgLyhwbGF5Ym9vayk7Wy1cXHdcXCksOyBdKyhyaW0pL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEJsYWNrQmVycnkgUGxheUJvb2tcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgVkVORE9SLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC9cXGIoKD86YmJbYS1mXXxzdFtodl0pMTAwLVxcZCkvaSxcbiAgICAgICAgICAgIC9cXChiYjEwOyAoXFx3KykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBCbGFja0JlcnJ5IDEwXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIEJMQUNLQkVSUlldLCBbVFlQRSwgTU9CSUxFXV0sIFtcblxuICAgICAgICAgICAgLy8gQXN1c1xuICAgICAgICAgICAgLyg/OlxcYnxhc3VzXykodHJhbnNmb1twcmltZSBdezQsMTB9IFxcdyt8ZWVlcGN8c2xpZGVyIFxcdyt8bmV4dXMgN3xwYWRmb25lfHAwMFtjal0pL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgQVNVU10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgLyAoeltiZXNdNlswMjddWzAxMl1ba21dW2xzXXx6ZW5mb25lIFxcZFxcdz8pXFxiL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgQVNVU10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuXG4gICAgICAgICAgICAvLyBIVENcbiAgICAgICAgICAgIC8obmV4dXMgOSkvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSFRDIE5leHVzIDlcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ0hUQyddLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC8oaHRjKVstO18gXXsxLDJ9KFtcXHcgXSsoPz1cXCl8IGJ1aSl8XFx3KykvaSwgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSFRDXG5cbiAgICAgICAgICAgIC8vIFpURVxuICAgICAgICAgICAgLyh6dGUpWy0gXShbXFx3IF0rPykoPzogYnVpfFxcL3xcXCkpL2ksXG4gICAgICAgICAgICAvKGFsY2F0ZWx8Z2Vla3NwaG9uZXxuZXhpYW58cGFuYXNvbmljKD8hKD86O3xcXC4pKXxzb255KD8hLWJyYSkpWy1fIF0/KFstXFx3XSopL2kgICAgICAgICAvLyBBbGNhdGVsL0dlZWtzUGhvbmUvTmV4aWFuL1BhbmFzb25pYy9Tb255XG4gICAgICAgICAgICBdLCBbVkVORE9SLCBbTU9ERUwsIC9fL2csICcgJ10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuXG4gICAgICAgICAgICAvLyBBY2VyXG4gICAgICAgICAgICAvZHJvaWQuKzsgKFthYl1bMS03XS0/WzAxNzhhXVxcZFxcZD8pL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ0FjZXInXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG5cbiAgICAgICAgICAgIC8vIE1laXp1XG4gICAgICAgICAgICAvZHJvaWQuKzsgKG1bMS01XSBub3RlKSBidWkvaSxcbiAgICAgICAgICAgIC9cXGJtei0oWy1cXHddezIsfSkvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnTWVpenUnXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vIE1JWEVEXG4gICAgICAgICAgICAvKGJsYWNrYmVycnl8YmVucXxwYWxtKD89XFwtKXxzb255ZXJpY3Nzb258YWNlcnxhc3VzfGRlbGx8bWVpenV8bW90b3JvbGF8cG9seXRyb258aW5maW5peHx0ZWNubylbLV8gXT8oWy1cXHddKikvaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQmxhY2tCZXJyeS9CZW5RL1BhbG0vU29ueS1Fcmljc3Nvbi9BY2VyL0FzdXMvRGVsbC9NZWl6dS9Nb3Rvcm9sYS9Qb2x5dHJvblxuICAgICAgICAgICAgLyhocCkgKFtcXHcgXStcXHcpL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhQIGlQQVFcbiAgICAgICAgICAgIC8oYXN1cyktPyhcXHcrKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFzdXNcbiAgICAgICAgICAgIC8obWljcm9zb2Z0KTsgKGx1bWlhW1xcdyBdKykvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1pY3Jvc29mdCBMdW1pYVxuICAgICAgICAgICAgLyhsZW5vdm8pWy1fIF0/KFstXFx3XSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTGVub3ZvXG4gICAgICAgICAgICAvKGpvbGxhKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEpvbGxhXG4gICAgICAgICAgICAvKG9wcG8pID8oW1xcdyBdKykgYnVpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPUFBPXG4gICAgICAgICAgICBdLCBbVkVORE9SLCBNT0RFTCwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8oa29ibylcXHMoZXJlYWRlcnx0b3VjaCkvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEtvYm9cbiAgICAgICAgICAgIC8oYXJjaG9zKSAoZ2FtZXBhZDI/KS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQXJjaG9zXG4gICAgICAgICAgICAvKGhwKS4rKHRvdWNocGFkKD8hLit0YWJsZXQpfHRhYmxldCkvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhQIFRvdWNoUGFkXG4gICAgICAgICAgICAvKGtpbmRsZSlcXC8oW1xcd1xcLl0rKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEtpbmRsZVxuICAgICAgICAgICAgLyhub29rKVtcXHcgXStidWlsZFxcLyhcXHcrKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBOb29rXG4gICAgICAgICAgICAvKGRlbGwpIChzdHJlYVtrcHJcXGQgXSpbXFxka29dKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRGVsbCBTdHJlYWtcbiAgICAgICAgICAgIC8obGVbLSBdK3BhbilbLSBdKyhcXHd7MSw5fSkgYnVpL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIExlIFBhbiBUYWJsZXRzXG4gICAgICAgICAgICAvKHRyaW5pdHkpWy0gXSoodFxcZHszfSkgYnVpL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBUcmluaXR5IFRhYmxldHNcbiAgICAgICAgICAgIC8oZ2lnYXNldClbLSBdKyhxXFx3ezEsOX0pIGJ1aS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdpZ2FzZXQgVGFibGV0c1xuICAgICAgICAgICAgLyh2b2RhZm9uZSkgKFtcXHcgXSspKD86XFwpfCBidWkpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZvZGFmb25lXG4gICAgICAgICAgICBdLCBbVkVORE9SLCBNT0RFTCwgW1RZUEUsIFRBQkxFVF1dLCBbXG5cbiAgICAgICAgICAgIC8oc3VyZmFjZSBkdW8pL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU3VyZmFjZSBEdW9cbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgTUlDUk9TT0ZUXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvZHJvaWQgW1xcZFxcLl0rOyAoZnBcXGR1PykoPzogYnxcXCkpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBGYWlycGhvbmVcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ0ZhaXJwaG9uZSddLCBbVFlQRSwgTU9CSUxFXV0sIFtcbiAgICAgICAgICAgIC8odTMwNGFhKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQVQmVFxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnQVQmVCddLCBbVFlQRSwgTU9CSUxFXV0sIFtcbiAgICAgICAgICAgIC9cXGJzaWUtKFxcdyopL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTaWVtZW5zXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdTaWVtZW5zJ10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgL1xcYihyY3RcXHcrKSBiL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJDQSBUYWJsZXRzXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdSQ0EnXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvXFxiKHZlbnVlW1xcZCBdezIsN30pIGIvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRGVsbCBWZW51ZSBUYWJsZXRzXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdEZWxsJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYihxKD86bXZ8dGEpXFx3KykgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZlcml6b24gVGFibGV0XG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdWZXJpem9uJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYig/OmJhcm5lc1smIF0rbm9ibGUgfGJuW3J0XSkoW1xcd1xcKyBdKikgYi9pICAgICAgICAgICAgICAgICAgICAgICAvLyBCYXJuZXMgJiBOb2JsZSBUYWJsZXRcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ0Jhcm5lcyAmIE5vYmxlJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYih0bVxcZHszfVxcdyspIGIvaVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnTnVWaXNpb24nXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvXFxiKGs4OCkgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBaVEUgSyBTZXJpZXMgVGFibGV0XG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdaVEUnXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvXFxiKG54XFxkezN9aikgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gWlRFIE51YmlhXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdaVEUnXSwgW1RZUEUsIE1PQklMRV1dLCBbXG4gICAgICAgICAgICAvXFxiKGdlblxcZHszfSkgYi4rNDloL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU3dpc3MgR0VOIE1vYmlsZVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnU3dpc3MnXSwgW1RZUEUsIE1PQklMRV1dLCBbXG4gICAgICAgICAgICAvXFxiKHp1clxcZHszfSkgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU3dpc3MgWlVSIFRhYmxldFxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnU3dpc3MnXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvXFxiKCh6ZWtpKT90Yi4qXFxiKSBiL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gWmVraSBUYWJsZXRzXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdaZWtpJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYihbeXJdXFxkezJ9KSBiL2ksXG4gICAgICAgICAgICAvXFxiKGRyYWdvblstIF0rdG91Y2ggfGR0KShcXHd7NX0pIGIvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRHJhZ29uIFRvdWNoIFRhYmxldFxuICAgICAgICAgICAgXSwgW1tWRU5ET1IsICdEcmFnb24gVG91Y2gnXSwgTU9ERUwsIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYihucy0/XFx3ezAsOX0pIGIvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEluc2lnbmlhIFRhYmxldHNcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ0luc2lnbmlhJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYigobnhhfG5leHQpLT9cXHd7MCw5fSkgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5leHRCb29rIFRhYmxldHNcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ05leHRCb29rJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgL1xcYih4dHJlbWVcXF8pPyh2KDFbMDQ1XXwyWzAxNV18WzM0NjldMHw3WzA1XSkpIGIvaSAgICAgICAgICAgICAgICAgIC8vIFZvaWNlIFh0cmVtZSBQaG9uZXNcbiAgICAgICAgICAgIF0sIFtbVkVORE9SLCAnVm9pY2UnXSwgTU9ERUwsIFtUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgL1xcYihsdnRlbFxcLSk/KHYxWzEyXSkgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEx2VGVsIFBob25lc1xuICAgICAgICAgICAgXSwgW1tWRU5ET1IsICdMdlRlbCddLCBNT0RFTCwgW1RZUEUsIE1PQklMRV1dLCBbXG4gICAgICAgICAgICAvXFxiKHBoLTEpIC9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBFc3NlbnRpYWwgUEgtMVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnRXNzZW50aWFsJ10sIFtUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgL1xcYih2KDEwMG1kfDcwMG5hfDcwMTF8OTE3ZykuKlxcYikgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEVudml6ZW4gVGFibGV0c1xuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCAnRW52aXplbiddLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC9cXGIodHJpb1stXFx3XFwuIF0rKSBiL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWFjaFNwZWVkIFRhYmxldHNcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ01hY2hTcGVlZCddLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC9cXGJ0dV8oMTQ5MSkgYi9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJvdG9yIFRhYmxldHNcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ1JvdG9yJ10sIFtUWVBFLCBUQUJMRVRdXSwgW1xuICAgICAgICAgICAgLyhzaGllbGRbXFx3IF0rKSBiL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTnZpZGlhIFNoaWVsZCBUYWJsZXRzXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsICdOdmlkaWEnXSwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvKHNwcmludCkgKFxcdyspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTcHJpbnQgUGhvbmVzXG4gICAgICAgICAgICBdLCBbVkVORE9SLCBNT0RFTCwgW1RZUEUsIE1PQklMRV1dLCBbXG4gICAgICAgICAgICAvKGtpblxcLltvbmV0d117M30pL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBNaWNyb3NvZnQgS2luXG4gICAgICAgICAgICBdLCBbW01PREVMLCAvXFwuL2csICcgJ10sIFtWRU5ET1IsIE1JQ1JPU09GVF0sIFtUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgL2Ryb2lkLis7IChjYzY2NjY/fGV0NVsxNl18bWNbMjM5XVsyM114P3x2YzhbMDNdeD8pXFwpL2kgICAgICAgICAgICAgLy8gWmVicmFcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgWkVCUkFdLCBbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC9kcm9pZC4rOyAoZWMzMHxwczIwfHRjWzItOF1cXGRba3hdKVxcKS9pXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIFpFQlJBXSwgW1RZUEUsIE1PQklMRV1dLCBbXG5cbiAgICAgICAgICAgIC8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAgICAgICAgIC8vIFNNQVJUVFZTXG4gICAgICAgICAgICAvLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgICAgICAgICAgIC9zbWFydC10di4rKHNhbXN1bmcpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2Ftc3VuZ1xuICAgICAgICAgICAgXSwgW1ZFTkRPUiwgW1RZUEUsIFNNQVJUVFZdXSwgW1xuICAgICAgICAgICAgL2hiYnR2LittYXBsZTsoXFxkKykvaVxuICAgICAgICAgICAgXSwgW1tNT0RFTCwgL14vLCAnU21hcnRUViddLCBbVkVORE9SLCBTQU1TVU5HXSwgW1RZUEUsIFNNQVJUVFZdXSwgW1xuICAgICAgICAgICAgLyhudXg7IG5ldGNhc3QuK3NtYXJ0dHZ8bGcgKG5ldGNhc3RcXC50di0yMDFcXGR8YW5kcm9pZCB0dikpL2kgICAgICAgIC8vIExHIFNtYXJ0VFZcbiAgICAgICAgICAgIF0sIFtbVkVORE9SLCBMR10sIFtUWVBFLCBTTUFSVFRWXV0sIFtcbiAgICAgICAgICAgIC8oYXBwbGUpID90di9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQXBwbGUgVFZcbiAgICAgICAgICAgIF0sIFtWRU5ET1IsIFtNT0RFTCwgQVBQTEUrJyBUViddLCBbVFlQRSwgU01BUlRUVl1dLCBbXG4gICAgICAgICAgICAvY3JrZXkvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdvb2dsZSBDaHJvbWVjYXN0XG4gICAgICAgICAgICBdLCBbW01PREVMLCBDSFJPTUUrJ2Nhc3QnXSwgW1ZFTkRPUiwgR09PR0xFXSwgW1RZUEUsIFNNQVJUVFZdXSwgW1xuICAgICAgICAgICAgL2Ryb2lkLithZnQoXFx3KykoIGJ1aXxcXCkpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpcmUgVFZcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgQU1BWk9OXSwgW1RZUEUsIFNNQVJUVFZdXSwgW1xuICAgICAgICAgICAgL1xcKGR0dltcXCk7XS4rKGFxdW9zKS9pLFxuICAgICAgICAgICAgLyhhcXVvcy10dltcXHcgXSspXFwpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNoYXJwXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIFNIQVJQXSwgW1RZUEUsIFNNQVJUVFZdXSxbXG4gICAgICAgICAgICAvKGJyYXZpYVtcXHcgXSspKCBidWl8XFwpKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNvbnlcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgU09OWV0sIFtUWVBFLCBTTUFSVFRWXV0sIFtcbiAgICAgICAgICAgIC8obWl0di1cXHd7NX0pIGJ1aS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFhpYW9taVxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCBYSUFPTUldLCBbVFlQRSwgU01BUlRUVl1dLCBbXG4gICAgICAgICAgICAvSGJidHYuKih0ZWNobmlzYXQpICguKik7L2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRlY2huaVNBVFxuICAgICAgICAgICAgXSwgW1ZFTkRPUiwgTU9ERUwsIFtUWVBFLCBTTUFSVFRWXV0sIFtcbiAgICAgICAgICAgIC9cXGIocm9rdSlbXFxkeF0qW1xcKVxcL10oKD86ZHZwLSk/W1xcZFxcLl0qKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUm9rdVxuICAgICAgICAgICAgL2hiYnR2XFwvXFxkK1xcLlxcZCtcXC5cXGQrICtcXChbXFx3XFwrIF0qOyAqKFtcXHdcXGRdW147XSopOyhbXjtdKikvaSAgICAgICAgIC8vIEhiYlRWIGRldmljZXNcbiAgICAgICAgICAgIF0sIFtbVkVORE9SLCB0cmltXSwgW01PREVMLCB0cmltXSwgW1RZUEUsIFNNQVJUVFZdXSwgW1xuICAgICAgICAgICAgL1xcYihhbmRyb2lkIHR2fHNtYXJ0Wy0gXT90dnxvcGVyYSB0dnx0djsgcnY6KVxcYi9pICAgICAgICAgICAgICAgICAgIC8vIFNtYXJ0VFYgZnJvbSBVbmlkZW50aWZpZWQgVmVuZG9yc1xuICAgICAgICAgICAgXSwgW1tUWVBFLCBTTUFSVFRWXV0sIFtcblxuICAgICAgICAgICAgLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgICAgICAgICAgLy8gQ09OU09MRVNcbiAgICAgICAgICAgIC8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICAgICAgICAgICAgLyhvdXlhKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPdXlhXG4gICAgICAgICAgICAvKG5pbnRlbmRvKSAoW3dpZHMzdXRjaF0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5pbnRlbmRvXG4gICAgICAgICAgICBdLCBbVkVORE9SLCBNT0RFTCwgW1RZUEUsIENPTlNPTEVdXSwgW1xuICAgICAgICAgICAgL2Ryb2lkLis7IChzaGllbGQpIGJ1aS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBOdmlkaWFcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ052aWRpYSddLCBbVFlQRSwgQ09OU09MRV1dLCBbXG4gICAgICAgICAgICAvKHBsYXlzdGF0aW9uIFszNDVwb3J0YWJsZXZpXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFBsYXlzdGF0aW9uXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtWRU5ET1IsIFNPTlldLCBbVFlQRSwgQ09OU09MRV1dLCBbXG4gICAgICAgICAgICAvXFxiKHhib3goPzogb25lKT8oPyE7IHhib3gpKVtcXCk7IF0vaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWljcm9zb2Z0IFhib3hcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgTUlDUk9TT0ZUXSwgW1RZUEUsIENPTlNPTEVdXSwgW1xuXG4gICAgICAgICAgICAvLy8vLy8vLy8vLy8vLy8vLy8vXG4gICAgICAgICAgICAvLyBXRUFSQUJMRVNcbiAgICAgICAgICAgIC8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICAgICAgICAgICAgLygocGViYmxlKSlhcHAvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQZWJibGVcbiAgICAgICAgICAgIF0sIFtWRU5ET1IsIE1PREVMLCBbVFlQRSwgV0VBUkFCTEVdXSwgW1xuICAgICAgICAgICAgLyh3YXRjaCkoPzogP29zWyxcXC9dfFxcZCxcXGRcXC8pW1xcZFxcLl0rL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBcHBsZSBXYXRjaFxuICAgICAgICAgICAgXSwgW01PREVMLCBbVkVORE9SLCBBUFBMRV0sIFtUWVBFLCBXRUFSQUJMRV1dLCBbXG4gICAgICAgICAgICAvZHJvaWQuKzsgKGdsYXNzKSBcXGQvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBHb29nbGUgR2xhc3NcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgR09PR0xFXSwgW1RZUEUsIFdFQVJBQkxFXV0sIFtcbiAgICAgICAgICAgIC9kcm9pZC4rOyAod3Q2Mz8wezIsM30pXFwpL2lcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgWkVCUkFdLCBbVFlQRSwgV0VBUkFCTEVdXSwgW1xuICAgICAgICAgICAgLyhxdWVzdCggMnwgcHJvKT8pL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPY3VsdXMgUXVlc3RcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgRkFDRUJPT0tdLCBbVFlQRSwgV0VBUkFCTEVdXSwgW1xuXG4gICAgICAgICAgICAvLy8vLy8vLy8vLy8vLy8vLy8vXG4gICAgICAgICAgICAvLyBFTUJFRERFRFxuICAgICAgICAgICAgLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gICAgICAgICAgICAvKHRlc2xhKSg/OiBxdGNhcmJyb3dzZXJ8XFwvWy1cXHdcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRlc2xhXG4gICAgICAgICAgICBdLCBbVkVORE9SLCBbVFlQRSwgRU1CRURERURdXSwgW1xuICAgICAgICAgICAgLyhhZW9iYylcXGIvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRWNobyBEb3RcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgQU1BWk9OXSwgW1RZUEUsIEVNQkVEREVEXV0sIFtcblxuICAgICAgICAgICAgLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAgICAgICAgIC8vIE1JWEVEIChHRU5FUklDKVxuICAgICAgICAgICAgLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gICAgICAgICAgICAvZHJvaWQgLis/OyAoW147XSs/KSg/OiBidWl8XFwpIGFwcGxldykuKz8gbW9iaWxlIHNhZmFyaS9pICAgICAgICAgICAvLyBBbmRyb2lkIFBob25lcyBmcm9tIFVuaWRlbnRpZmllZCBWZW5kb3JzXG4gICAgICAgICAgICBdLCBbTU9ERUwsIFtUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgL2Ryb2lkIC4rPzsgKFteO10rPykoPzogYnVpfFxcKSBhcHBsZXcpLis/KD8hIG1vYmlsZSkgc2FmYXJpL2kgICAgICAgLy8gQW5kcm9pZCBUYWJsZXRzIGZyb20gVW5pZGVudGlmaWVkIFZlbmRvcnNcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1RZUEUsIFRBQkxFVF1dLCBbXG4gICAgICAgICAgICAvXFxiKCh0YWJsZXR8dGFiKVs7XFwvXXxmb2N1c1xcL1xcZCg/IS4rbW9iaWxlKSkvaSAgICAgICAgICAgICAgICAgICAgICAvLyBVbmlkZW50aWZpYWJsZSBUYWJsZXRcbiAgICAgICAgICAgIF0sIFtbVFlQRSwgVEFCTEVUXV0sIFtcbiAgICAgICAgICAgIC8ocGhvbmV8bW9iaWxlKD86WztcXC9dfCBbIFxcd1xcL1xcLl0qc2FmYXJpKXxwZGEoPz0uK3dpbmRvd3MgY2UpKS9pICAgIC8vIFVuaWRlbnRpZmlhYmxlIE1vYmlsZVxuICAgICAgICAgICAgXSwgW1tUWVBFLCBNT0JJTEVdXSwgW1xuICAgICAgICAgICAgLyhhbmRyb2lkWy1cXHdcXC4gXXswLDl9KTsuK2J1aWwvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdlbmVyaWMgQW5kcm9pZCBEZXZpY2VcbiAgICAgICAgICAgIF0sIFtNT0RFTCwgW1ZFTkRPUiwgJ0dlbmVyaWMnXV1cbiAgICAgICAgXSxcblxuICAgICAgICBlbmdpbmUgOiBbW1xuXG4gICAgICAgICAgICAvd2luZG93cy4rIGVkZ2VcXC8oW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRWRnZUhUTUxcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgRURHRSsnSFRNTCddXSwgW1xuXG4gICAgICAgICAgICAvd2Via2l0XFwvNTM3XFwuMzYuK2Nocm9tZVxcLyg/ITI3KShbXFx3XFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQmxpbmtcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgJ0JsaW5rJ11dLCBbXG5cbiAgICAgICAgICAgIC8ocHJlc3RvKVxcLyhbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJlc3RvXG4gICAgICAgICAgICAvKHdlYmtpdHx0cmlkZW50fG5ldGZyb250fG5ldHN1cmZ8YW1heWF8bHlueHx3M218Z29hbm5hKVxcLyhbXFx3XFwuXSspL2ksIC8vIFdlYktpdC9UcmlkZW50L05ldEZyb250L05ldFN1cmYvQW1heWEvTHlueC93M20vR29hbm5hXG4gICAgICAgICAgICAvZWtpb2goZmxvdylcXC8oW1xcd1xcLl0rKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZsb3dcbiAgICAgICAgICAgIC8oa2h0bWx8dGFzbWFufGxpbmtzKVtcXC8gXVxcKD8oW1xcd1xcLl0rKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEtIVE1ML1Rhc21hbi9MaW5rc1xuICAgICAgICAgICAgLyhpY2FiKVtcXC8gXShbMjNdXFwuW1xcZFxcLl0rKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaUNhYlxuICAgICAgICAgICAgL1xcYihsaWJ3ZWIpL2lcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuXG4gICAgICAgICAgICAvcnZcXDooW1xcd1xcLl17MSw5fSlcXGIuKyhnZWNrbykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBHZWNrb1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIE5BTUVdXG4gICAgICAgIF0sXG5cbiAgICAgICAgb3MgOiBbW1xuXG4gICAgICAgICAgICAvLyBXaW5kb3dzXG4gICAgICAgICAgICAvbWljcm9zb2Z0ICh3aW5kb3dzKSAodmlzdGF8eHApL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFdpbmRvd3MgKGlUdW5lcylcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgLyh3aW5kb3dzKSBudCA2XFwuMjsgKGFybSkvaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gV2luZG93cyBSVFxuICAgICAgICAgICAgLyh3aW5kb3dzICg/OnBob25lKD86IG9zKT98bW9iaWxlKSlbXFwvIF0/KFtcXGRcXC5cXHcgXSopL2ksICAgICAgICAgICAgLy8gV2luZG93cyBQaG9uZVxuICAgICAgICAgICAgLyh3aW5kb3dzKVtcXC8gXT8oW250Y2VcXGRcXC4gXStcXHcpKD8hLit4Ym94KS9pXG4gICAgICAgICAgICBdLCBbTkFNRSwgW1ZFUlNJT04sIHN0ck1hcHBlciwgd2luZG93c1ZlcnNpb25NYXBdXSwgW1xuICAgICAgICAgICAgLyh3aW4oPz0zfDl8bil8d2luIDl4ICkoW250XFxkXFwuXSspL2lcbiAgICAgICAgICAgIF0sIFtbTkFNRSwgJ1dpbmRvd3MnXSwgW1ZFUlNJT04sIHN0ck1hcHBlciwgd2luZG93c1ZlcnNpb25NYXBdXSwgW1xuXG4gICAgICAgICAgICAvLyBpT1MvbWFjT1NcbiAgICAgICAgICAgIC9pcFtob25lYWRdezIsNH1cXGIoPzouKm9zIChbXFx3XSspIGxpa2UgbWFjfDsgb3BlcmEpL2ksICAgICAgICAgICAgICAvLyBpT1NcbiAgICAgICAgICAgIC8oPzppb3M7ZmJzdlxcL3xpcGhvbmUuK2lvc1tcXC8gXSkoW1xcZFxcLl0rKS9pLFxuICAgICAgICAgICAgL2NmbmV0d29ya1xcLy4rZGFyd2luL2lcbiAgICAgICAgICAgIF0sIFtbVkVSU0lPTiwgL18vZywgJy4nXSwgW05BTUUsICdpT1MnXV0sIFtcbiAgICAgICAgICAgIC8obWFjIG9zIHgpID8oW1xcd1xcLiBdKikvaSxcbiAgICAgICAgICAgIC8obWFjaW50b3NofG1hY19wb3dlcnBjXFxiKSg/IS4raGFpa3UpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1hYyBPU1xuICAgICAgICAgICAgXSwgW1tOQU1FLCBNQUNfT1NdLCBbVkVSU0lPTiwgL18vZywgJy4nXV0sIFtcblxuICAgICAgICAgICAgLy8gTW9iaWxlIE9TZXNcbiAgICAgICAgICAgIC9kcm9pZCAoW1xcd1xcLl0rKVxcYi4rKGFuZHJvaWRbLSBdeDg2fGhhcm1vbnlvcykvaSAgICAgICAgICAgICAgICAgICAgLy8gQW5kcm9pZC14ODYvSGFybW9ueU9TXG4gICAgICAgICAgICBdLCBbVkVSU0lPTiwgTkFNRV0sIFsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFuZHJvaWQvV2ViT1MvUU5YL0JhZGEvUklNL01hZW1vL01lZUdvL1NhaWxmaXNoIE9TXG4gICAgICAgICAgICAvKGFuZHJvaWR8d2Vib3N8cW54fGJhZGF8cmltIHRhYmxldCBvc3xtYWVtb3xtZWVnb3xzYWlsZmlzaClbLVxcLyBdPyhbXFx3XFwuXSopL2ksXG4gICAgICAgICAgICAvKGJsYWNrYmVycnkpXFx3KlxcLyhbXFx3XFwuXSopL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBCbGFja2JlcnJ5XG4gICAgICAgICAgICAvKHRpemVufGthaW9zKVtcXC8gXShbXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRpemVuL0thaU9TXG4gICAgICAgICAgICAvXFwoKHNlcmllczQwKTsvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXJpZXMgNDBcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgL1xcKGJiKDEwKTsvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQmxhY2tCZXJyeSAxMFxuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCBCTEFDS0JFUlJZXV0sIFtcbiAgICAgICAgICAgIC8oPzpzeW1iaWFuID9vc3xzeW1ib3N8czYwKD89Oyl8c2VyaWVzNjApWy1cXC8gXT8oW1xcd1xcLl0qKS9pICAgICAgICAgLy8gU3ltYmlhblxuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCAnU3ltYmlhbiddXSwgW1xuICAgICAgICAgICAgL21vemlsbGFcXC9bXFxkXFwuXSsgXFwoKD86bW9iaWxlfHRhYmxldHx0dnxtb2JpbGU7IFtcXHcgXSspOyBydjouKyBnZWNrb1xcLyhbXFx3XFwuXSspL2kgLy8gRmlyZWZveCBPU1xuICAgICAgICAgICAgXSwgW1ZFUlNJT04sIFtOQU1FLCBGSVJFRk9YKycgT1MnXV0sIFtcbiAgICAgICAgICAgIC93ZWIwczsuK3J0KHR2KS9pLFxuICAgICAgICAgICAgL1xcYig/OmhwKT93b3MoPzpicm93c2VyKT9cXC8oW1xcd1xcLl0rKS9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gV2ViT1NcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgJ3dlYk9TJ11dLCBbXG4gICAgICAgICAgICAvd2F0Y2goPzogP29zWyxcXC9dfFxcZCxcXGRcXC8pKFtcXGRcXC5dKykvaSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdhdGNoT1NcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgJ3dhdGNoT1MnXV0sIFtcblxuICAgICAgICAgICAgLy8gR29vZ2xlIENocm9tZWNhc3RcbiAgICAgICAgICAgIC9jcmtleVxcLyhbXFxkXFwuXSspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gR29vZ2xlIENocm9tZWNhc3RcbiAgICAgICAgICAgIF0sIFtWRVJTSU9OLCBbTkFNRSwgQ0hST01FKydjYXN0J11dLCBbXG4gICAgICAgICAgICAvKGNyb3MpIFtcXHddKyg/OlxcKXwgKFtcXHdcXC5dKylcXGIpL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2hyb21pdW0gT1NcbiAgICAgICAgICAgIF0sIFtbTkFNRSwgQ0hST01JVU1fT1NdLCBWRVJTSU9OXSxbXG5cbiAgICAgICAgICAgIC8vIFNtYXJ0IFRWc1xuICAgICAgICAgICAgL3BhbmFzb25pYzsodmllcmEpL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQYW5hc29uaWMgVmllcmFcbiAgICAgICAgICAgIC8obmV0cmFuZ2UpbW1oL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTmV0cmFuZ2VcbiAgICAgICAgICAgIC8obmV0dHYpXFwvKFxcZCtcXC5bXFx3XFwuXSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBOZXRUVlxuXG4gICAgICAgICAgICAvLyBDb25zb2xlXG4gICAgICAgICAgICAvKG5pbnRlbmRvfHBsYXlzdGF0aW9uKSAoW3dpZHMzNDVwb3J0YWJsZXZ1Y2hdKykvaSwgICAgICAgICAgICAgICAgIC8vIE5pbnRlbmRvL1BsYXlzdGF0aW9uXG4gICAgICAgICAgICAvKHhib3gpOyAreGJveCAoW15cXCk7XSspL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBNaWNyb3NvZnQgWGJveCAoMzYwLCBPbmUsIFgsIFMsIFNlcmllcyBYLCBTZXJpZXMgUylcblxuICAgICAgICAgICAgLy8gT3RoZXJcbiAgICAgICAgICAgIC9cXGIoam9saXxwYWxtKVxcYiA/KD86b3MpP1xcLz8oW1xcd1xcLl0qKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBKb2xpL1BhbG1cbiAgICAgICAgICAgIC8obWludClbXFwvXFwoXFwpIF0/KFxcdyopL2ksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1pbnRcbiAgICAgICAgICAgIC8obWFnZWlhfHZlY3RvcmxpbnV4KVs7IF0vaSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWFnZWlhL1ZlY3RvckxpbnV4XG4gICAgICAgICAgICAvKFtreGxuXT91YnVudHV8ZGViaWFufHN1c2V8b3BlbnN1c2V8Z2VudG9vfGFyY2goPz0gbGludXgpfHNsYWNrd2FyZXxmZWRvcmF8bWFuZHJpdmF8Y2VudG9zfHBjbGludXhvc3xyZWQgP2hhdHx6ZW53YWxrfGxpbnB1c3xyYXNwYmlhbnxwbGFuIDl8bWluaXh8cmlzYyBvc3xjb250aWtpfGRlZXBpbnxtYW5qYXJvfGVsZW1lbnRhcnkgb3N8c2FiYXlvbnxsaW5zcGlyZSkoPzogZ251XFwvbGludXgpPyg/OiBlbnRlcnByaXNlKT8oPzpbLSBdbGludXgpPyg/Oi1nbnUpP1stXFwvIF0/KD8hY2hyb218cGFja2FnZSkoWy1cXHdcXC5dKikvaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVWJ1bnR1L0RlYmlhbi9TVVNFL0dlbnRvby9BcmNoL1NsYWNrd2FyZS9GZWRvcmEvTWFuZHJpdmEvQ2VudE9TL1BDTGludXhPUy9SZWRIYXQvWmVud2Fsay9MaW5wdXMvUmFzcGJpYW4vUGxhbjkvTWluaXgvUklTQ09TL0NvbnRpa2kvRGVlcGluL01hbmphcm8vZWxlbWVudGFyeS9TYWJheW9uL0xpbnNwaXJlXG4gICAgICAgICAgICAvKGh1cmR8bGludXgpID8oW1xcd1xcLl0qKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSHVyZC9MaW51eFxuICAgICAgICAgICAgLyhnbnUpID8oW1xcd1xcLl0qKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdOVVxuICAgICAgICAgICAgL1xcYihbLWZyZW50b3BjZ2hzXXswLDV9YnNkfGRyYWdvbmZseSlbXFwvIF0/KD8hYW1kfFtpeDM0Nl17MSwyfTg2KShbXFx3XFwuXSopL2ksIC8vIEZyZWVCU0QvTmV0QlNEL09wZW5CU0QvUEMtQlNEL0dob3N0QlNEL0RyYWdvbkZseVxuICAgICAgICAgICAgLyhoYWlrdSkgKFxcdyspL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSGFpa3VcbiAgICAgICAgICAgIF0sIFtOQU1FLCBWRVJTSU9OXSwgW1xuICAgICAgICAgICAgLyhzdW5vcykgPyhbXFx3XFwuXFxkXSopL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTb2xhcmlzXG4gICAgICAgICAgICBdLCBbW05BTUUsICdTb2xhcmlzJ10sIFZFUlNJT05dLCBbXG4gICAgICAgICAgICAvKCg/Om9wZW4pP3NvbGFyaXMpWy1cXC8gXT8oW1xcd1xcLl0qKS9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNvbGFyaXNcbiAgICAgICAgICAgIC8oYWl4KSAoKFxcZCkoPz1cXC58XFwpfCApW1xcd1xcLl0pKi9pLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBSVhcbiAgICAgICAgICAgIC9cXGIoYmVvc3xvc1xcLzJ8YW1pZ2Fvc3xtb3JwaG9zfG9wZW52bXN8ZnVjaHNpYXxocC11eHxzZXJlbml0eW9zKS9pLCAvLyBCZU9TL09TMi9BbWlnYU9TL01vcnBoT1MvT3BlblZNUy9GdWNoc2lhL0hQLVVYL1NlcmVuaXR5T1NcbiAgICAgICAgICAgIC8odW5peCkgPyhbXFx3XFwuXSopL2kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBVTklYXG4gICAgICAgICAgICBdLCBbTkFNRSwgVkVSU0lPTl1cbiAgICAgICAgXVxuICAgIH07XG5cbiAgICAvLy8vLy8vLy8vLy8vLy8vL1xuICAgIC8vIENvbnN0cnVjdG9yXG4gICAgLy8vLy8vLy8vLy8vLy8vL1xuXG4gICAgdmFyIFVBUGFyc2VyID0gZnVuY3Rpb24gKHVhLCBleHRlbnNpb25zKSB7XG5cbiAgICAgICAgaWYgKHR5cGVvZiB1YSA9PT0gT0JKX1RZUEUpIHtcbiAgICAgICAgICAgIGV4dGVuc2lvbnMgPSB1YTtcbiAgICAgICAgICAgIHVhID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFVBUGFyc2VyKSkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVQVBhcnNlcih1YSwgZXh0ZW5zaW9ucykuZ2V0UmVzdWx0KCk7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgX25hdmlnYXRvciA9ICh0eXBlb2Ygd2luZG93ICE9PSBVTkRFRl9UWVBFICYmIHdpbmRvdy5uYXZpZ2F0b3IpID8gd2luZG93Lm5hdmlnYXRvciA6IHVuZGVmaW5lZDtcbiAgICAgICAgdmFyIF91YSA9IHVhIHx8ICgoX25hdmlnYXRvciAmJiBfbmF2aWdhdG9yLnVzZXJBZ2VudCkgPyBfbmF2aWdhdG9yLnVzZXJBZ2VudCA6IEVNUFRZKTtcbiAgICAgICAgdmFyIF91YWNoID0gKF9uYXZpZ2F0b3IgJiYgX25hdmlnYXRvci51c2VyQWdlbnREYXRhKSA/IF9uYXZpZ2F0b3IudXNlckFnZW50RGF0YSA6IHVuZGVmaW5lZDtcbiAgICAgICAgdmFyIF9yZ3htYXAgPSBleHRlbnNpb25zID8gZXh0ZW5kKHJlZ2V4ZXMsIGV4dGVuc2lvbnMpIDogcmVnZXhlcztcbiAgICAgICAgdmFyIF9pc1NlbGZOYXYgPSBfbmF2aWdhdG9yICYmIF9uYXZpZ2F0b3IudXNlckFnZW50ID09IF91YTtcblxuICAgICAgICB0aGlzLmdldEJyb3dzZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgX2Jyb3dzZXIgPSB7fTtcbiAgICAgICAgICAgIF9icm93c2VyW05BTUVdID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgX2Jyb3dzZXJbVkVSU0lPTl0gPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICByZ3hNYXBwZXIuY2FsbChfYnJvd3NlciwgX3VhLCBfcmd4bWFwLmJyb3dzZXIpO1xuICAgICAgICAgICAgX2Jyb3dzZXJbTUFKT1JdID0gbWFqb3JpemUoX2Jyb3dzZXJbVkVSU0lPTl0pO1xuICAgICAgICAgICAgLy8gQnJhdmUtc3BlY2lmaWMgZGV0ZWN0aW9uXG4gICAgICAgICAgICBpZiAoX2lzU2VsZk5hdiAmJiBfbmF2aWdhdG9yICYmIF9uYXZpZ2F0b3IuYnJhdmUgJiYgdHlwZW9mIF9uYXZpZ2F0b3IuYnJhdmUuaXNCcmF2ZSA9PSBGVU5DX1RZUEUpIHtcbiAgICAgICAgICAgICAgICBfYnJvd3NlcltOQU1FXSA9ICdCcmF2ZSc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gX2Jyb3dzZXI7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZ2V0Q1BVID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIF9jcHUgPSB7fTtcbiAgICAgICAgICAgIF9jcHVbQVJDSElURUNUVVJFXSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHJneE1hcHBlci5jYWxsKF9jcHUsIF91YSwgX3JneG1hcC5jcHUpO1xuICAgICAgICAgICAgcmV0dXJuIF9jcHU7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZ2V0RGV2aWNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIF9kZXZpY2UgPSB7fTtcbiAgICAgICAgICAgIF9kZXZpY2VbVkVORE9SXSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIF9kZXZpY2VbTU9ERUxdID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgX2RldmljZVtUWVBFXSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHJneE1hcHBlci5jYWxsKF9kZXZpY2UsIF91YSwgX3JneG1hcC5kZXZpY2UpO1xuICAgICAgICAgICAgaWYgKF9pc1NlbGZOYXYgJiYgIV9kZXZpY2VbVFlQRV0gJiYgX3VhY2ggJiYgX3VhY2gubW9iaWxlKSB7XG4gICAgICAgICAgICAgICAgX2RldmljZVtUWVBFXSA9IE1PQklMRTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGlQYWRPUy1zcGVjaWZpYyBkZXRlY3Rpb246IGlkZW50aWZpZWQgYXMgTWFjLCBidXQgaGFzIHNvbWUgaU9TLW9ubHkgcHJvcGVydGllc1xuICAgICAgICAgICAgaWYgKF9pc1NlbGZOYXYgJiYgX2RldmljZVtNT0RFTF0gPT0gJ01hY2ludG9zaCcgJiYgX25hdmlnYXRvciAmJiB0eXBlb2YgX25hdmlnYXRvci5zdGFuZGFsb25lICE9PSBVTkRFRl9UWVBFICYmIF9uYXZpZ2F0b3IubWF4VG91Y2hQb2ludHMgJiYgX25hdmlnYXRvci5tYXhUb3VjaFBvaW50cyA+IDIpIHtcbiAgICAgICAgICAgICAgICBfZGV2aWNlW01PREVMXSA9ICdpUGFkJztcbiAgICAgICAgICAgICAgICBfZGV2aWNlW1RZUEVdID0gVEFCTEVUO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIF9kZXZpY2U7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZ2V0RW5naW5lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIF9lbmdpbmUgPSB7fTtcbiAgICAgICAgICAgIF9lbmdpbmVbTkFNRV0gPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBfZW5naW5lW1ZFUlNJT05dID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgcmd4TWFwcGVyLmNhbGwoX2VuZ2luZSwgX3VhLCBfcmd4bWFwLmVuZ2luZSk7XG4gICAgICAgICAgICByZXR1cm4gX2VuZ2luZTtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5nZXRPUyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBfb3MgPSB7fTtcbiAgICAgICAgICAgIF9vc1tOQU1FXSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIF9vc1tWRVJTSU9OXSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHJneE1hcHBlci5jYWxsKF9vcywgX3VhLCBfcmd4bWFwLm9zKTtcbiAgICAgICAgICAgIGlmIChfaXNTZWxmTmF2ICYmICFfb3NbTkFNRV0gJiYgX3VhY2ggJiYgX3VhY2gucGxhdGZvcm0gIT0gJ1Vua25vd24nKSB7XG4gICAgICAgICAgICAgICAgX29zW05BTUVdID0gX3VhY2gucGxhdGZvcm0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL2Nocm9tZSBvcy9pLCBDSFJPTUlVTV9PUylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9tYWNvcy9pLCBNQUNfT1MpOyAgICAgICAgICAgLy8gYmFja3dhcmQgY29tcGF0aWJpbGl0eVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIF9vcztcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5nZXRSZXN1bHQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHVhICAgICAgOiB0aGlzLmdldFVBKCksXG4gICAgICAgICAgICAgICAgYnJvd3NlciA6IHRoaXMuZ2V0QnJvd3NlcigpLFxuICAgICAgICAgICAgICAgIGVuZ2luZSAgOiB0aGlzLmdldEVuZ2luZSgpLFxuICAgICAgICAgICAgICAgIG9zICAgICAgOiB0aGlzLmdldE9TKCksXG4gICAgICAgICAgICAgICAgZGV2aWNlICA6IHRoaXMuZ2V0RGV2aWNlKCksXG4gICAgICAgICAgICAgICAgY3B1ICAgICA6IHRoaXMuZ2V0Q1BVKClcbiAgICAgICAgICAgIH07XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZ2V0VUEgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gX3VhO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNldFVBID0gZnVuY3Rpb24gKHVhKSB7XG4gICAgICAgICAgICBfdWEgPSAodHlwZW9mIHVhID09PSBTVFJfVFlQRSAmJiB1YS5sZW5ndGggPiBVQV9NQVhfTEVOR1RIKSA/IHRyaW0odWEsIFVBX01BWF9MRU5HVEgpIDogdWE7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5zZXRVQShfdWEpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuXG4gICAgVUFQYXJzZXIuVkVSU0lPTiA9IExJQlZFUlNJT047XG4gICAgVUFQYXJzZXIuQlJPV1NFUiA9ICBlbnVtZXJpemUoW05BTUUsIFZFUlNJT04sIE1BSk9SXSk7XG4gICAgVUFQYXJzZXIuQ1BVID0gZW51bWVyaXplKFtBUkNISVRFQ1RVUkVdKTtcbiAgICBVQVBhcnNlci5ERVZJQ0UgPSBlbnVtZXJpemUoW01PREVMLCBWRU5ET1IsIFRZUEUsIENPTlNPTEUsIE1PQklMRSwgU01BUlRUViwgVEFCTEVULCBXRUFSQUJMRSwgRU1CRURERURdKTtcbiAgICBVQVBhcnNlci5FTkdJTkUgPSBVQVBhcnNlci5PUyA9IGVudW1lcml6ZShbTkFNRSwgVkVSU0lPTl0pO1xuXG4gICAgLy8vLy8vLy8vLy9cbiAgICAvLyBFeHBvcnRcbiAgICAvLy8vLy8vLy8vXG5cbiAgICAvLyBjaGVjayBqcyBlbnZpcm9ubWVudFxuICAgIGlmICh0eXBlb2YoZXhwb3J0cykgIT09IFVOREVGX1RZUEUpIHtcbiAgICAgICAgLy8gbm9kZWpzIGVudlxuICAgICAgICBpZiAodHlwZW9mIG1vZHVsZSAhPT0gVU5ERUZfVFlQRSAmJiBtb2R1bGUuZXhwb3J0cykge1xuICAgICAgICAgICAgZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gVUFQYXJzZXI7XG4gICAgICAgIH1cbiAgICAgICAgZXhwb3J0cy5VQVBhcnNlciA9IFVBUGFyc2VyO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIHJlcXVpcmVqcyBlbnYgKG9wdGlvbmFsKVxuICAgICAgICBpZiAodHlwZW9mKGRlZmluZSkgPT09IEZVTkNfVFlQRSAmJiBkZWZpbmUuYW1kKSB7XG4gICAgICAgICAgICBkZWZpbmUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBVQVBhcnNlcjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFVOREVGX1RZUEUpIHtcbiAgICAgICAgICAgIC8vIGJyb3dzZXIgZW52XG4gICAgICAgICAgICB3aW5kb3cuVUFQYXJzZXIgPSBVQVBhcnNlcjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIGpRdWVyeS9aZXB0byBzcGVjaWZpYyAob3B0aW9uYWwpXG4gICAgLy8gTm90ZTpcbiAgICAvLyAgIEluIEFNRCBlbnYgdGhlIGdsb2JhbCBzY29wZSBzaG91bGQgYmUga2VwdCBjbGVhbiwgYnV0IGpRdWVyeSBpcyBhbiBleGNlcHRpb24uXG4gICAgLy8gICBqUXVlcnkgYWx3YXlzIGV4cG9ydHMgdG8gZ2xvYmFsIHNjb3BlLCB1bmxlc3MgalF1ZXJ5Lm5vQ29uZmxpY3QodHJ1ZSkgaXMgdXNlZCxcbiAgICAvLyAgIGFuZCB3ZSBzaG91bGQgY2F0Y2ggdGhhdC5cbiAgICB2YXIgJCA9IHR5cGVvZiB3aW5kb3cgIT09IFVOREVGX1RZUEUgJiYgKHdpbmRvdy5qUXVlcnkgfHwgd2luZG93LlplcHRvKTtcbiAgICBpZiAoJCAmJiAhJC51YSkge1xuICAgICAgICB2YXIgcGFyc2VyID0gbmV3IFVBUGFyc2VyKCk7XG4gICAgICAgICQudWEgPSBwYXJzZXIuZ2V0UmVzdWx0KCk7XG4gICAgICAgICQudWEuZ2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHBhcnNlci5nZXRVQSgpO1xuICAgICAgICB9O1xuICAgICAgICAkLnVhLnNldCA9IGZ1bmN0aW9uICh1YSkge1xuICAgICAgICAgICAgcGFyc2VyLnNldFVBKHVhKTtcbiAgICAgICAgICAgIHZhciByZXN1bHQgPSBwYXJzZXIuZ2V0UmVzdWx0KCk7XG4gICAgICAgICAgICBmb3IgKHZhciBwcm9wIGluIHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICQudWFbcHJvcF0gPSByZXN1bHRbcHJvcF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfVxuXG59KSh0eXBlb2Ygd2luZG93ID09PSAnb2JqZWN0JyA/IHdpbmRvdyA6IHRoaXMpO1xuIiwiKGZ1bmN0aW9uIChnbG9iYWwsIGZhY3RvcnkpIHtcbiAgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG4gICAgZGVmaW5lKFwid2ViZXh0ZW5zaW9uLXBvbHlmaWxsXCIsIFtcIm1vZHVsZVwiXSwgZmFjdG9yeSk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGV4cG9ydHMgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBmYWN0b3J5KG1vZHVsZSk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIG1vZCA9IHtcbiAgICAgIGV4cG9ydHM6IHt9XG4gICAgfTtcbiAgICBmYWN0b3J5KG1vZCk7XG4gICAgZ2xvYmFsLmJyb3dzZXIgPSBtb2QuZXhwb3J0cztcbiAgfVxufSkodHlwZW9mIGdsb2JhbFRoaXMgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWxUaGlzIDogdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdGhpcywgZnVuY3Rpb24gKG1vZHVsZSkge1xuICAvKiB3ZWJleHRlbnNpb24tcG9seWZpbGwgLSB2MC4xMi4wIC0gVHVlIE1heSAxNCAyMDI0IDE4OjAxOjI5ICovXG4gIC8qIC0qLSBNb2RlOiBpbmRlbnQtdGFicy1tb2RlOiBuaWw7IGpzLWluZGVudC1sZXZlbDogMiAtKi0gKi9cbiAgLyogdmltOiBzZXQgc3RzPTIgc3c9MiBldCB0dz04MDogKi9cbiAgLyogVGhpcyBTb3VyY2UgQ29kZSBGb3JtIGlzIHN1YmplY3QgdG8gdGhlIHRlcm1zIG9mIHRoZSBNb3ppbGxhIFB1YmxpY1xuICAgKiBMaWNlbnNlLCB2LiAyLjAuIElmIGEgY29weSBvZiB0aGUgTVBMIHdhcyBub3QgZGlzdHJpYnV0ZWQgd2l0aCB0aGlzXG4gICAqIGZpbGUsIFlvdSBjYW4gb2J0YWluIG9uZSBhdCBodHRwOi8vbW96aWxsYS5vcmcvTVBMLzIuMC8uICovXG4gIFwidXNlIHN0cmljdFwiO1xuXG4gIGlmICghKGdsb2JhbFRoaXMuY2hyb21lICYmIGdsb2JhbFRoaXMuY2hyb21lLnJ1bnRpbWUgJiYgZ2xvYmFsVGhpcy5jaHJvbWUucnVudGltZS5pZCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGlzIHNjcmlwdCBzaG91bGQgb25seSBiZSBsb2FkZWQgaW4gYSBicm93c2VyIGV4dGVuc2lvbi5cIik7XG4gIH1cbiAgaWYgKCEoZ2xvYmFsVGhpcy5icm93c2VyICYmIGdsb2JhbFRoaXMuYnJvd3Nlci5ydW50aW1lICYmIGdsb2JhbFRoaXMuYnJvd3Nlci5ydW50aW1lLmlkKSkge1xuICAgIGNvbnN0IENIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSA9IFwiVGhlIG1lc3NhZ2UgcG9ydCBjbG9zZWQgYmVmb3JlIGEgcmVzcG9uc2Ugd2FzIHJlY2VpdmVkLlwiO1xuXG4gICAgLy8gV3JhcHBpbmcgdGhlIGJ1bGsgb2YgdGhpcyBwb2x5ZmlsbCBpbiBhIG9uZS10aW1lLXVzZSBmdW5jdGlvbiBpcyBhIG1pbm9yXG4gICAgLy8gb3B0aW1pemF0aW9uIGZvciBGaXJlZm94LiBTaW5jZSBTcGlkZXJtb25rZXkgZG9lcyBub3QgZnVsbHkgcGFyc2UgdGhlXG4gICAgLy8gY29udGVudHMgb2YgYSBmdW5jdGlvbiB1bnRpbCB0aGUgZmlyc3QgdGltZSBpdCdzIGNhbGxlZCwgYW5kIHNpbmNlIGl0IHdpbGxcbiAgICAvLyBuZXZlciBhY3R1YWxseSBuZWVkIHRvIGJlIGNhbGxlZCwgdGhpcyBhbGxvd3MgdGhlIHBvbHlmaWxsIHRvIGJlIGluY2x1ZGVkXG4gICAgLy8gaW4gRmlyZWZveCBuZWFybHkgZm9yIGZyZWUuXG4gICAgY29uc3Qgd3JhcEFQSXMgPSBleHRlbnNpb25BUElzID0+IHtcbiAgICAgIC8vIE5PVEU6IGFwaU1ldGFkYXRhIGlzIGFzc29jaWF0ZWQgdG8gdGhlIGNvbnRlbnQgb2YgdGhlIGFwaS1tZXRhZGF0YS5qc29uIGZpbGVcbiAgICAgIC8vIGF0IGJ1aWxkIHRpbWUgYnkgcmVwbGFjaW5nIHRoZSBmb2xsb3dpbmcgXCJpbmNsdWRlXCIgd2l0aCB0aGUgY29udGVudCBvZiB0aGVcbiAgICAgIC8vIEpTT04gZmlsZS5cbiAgICAgIGNvbnN0IGFwaU1ldGFkYXRhID0ge1xuICAgICAgICBcImFsYXJtc1wiOiB7XG4gICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImNsZWFyQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiYm9va21hcmtzXCI6IHtcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldENoaWxkcmVuXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UmVjZW50XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0U3ViVHJlZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFRyZWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlVHJlZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImJyb3dzZXJBY3Rpb25cIjoge1xuICAgICAgICAgIFwiZGlzYWJsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImVuYWJsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEJhZGdlQmFja2dyb3VuZENvbG9yXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QmFkZ2VUZXh0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRUaXRsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm9wZW5Qb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEJhZGdlQmFja2dyb3VuZENvbG9yXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0QmFkZ2VUZXh0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0SWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJicm93c2luZ0RhdGFcIjoge1xuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQ2FjaGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVDb29raWVzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRG93bmxvYWRzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRm9ybURhdGFcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVIaXN0b3J5XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlTG9jYWxTdG9yYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlUGFzc3dvcmRzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlUGx1Z2luRGF0YVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldHRpbmdzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiY29tbWFuZHNcIjoge1xuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiY29udGV4dE1lbnVzXCI6IHtcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImNvb2tpZXNcIjoge1xuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsQ29va2llU3RvcmVzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiZGV2dG9vbHNcIjoge1xuICAgICAgICAgIFwiaW5zcGVjdGVkV2luZG93XCI6IHtcbiAgICAgICAgICAgIFwiZXZhbFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMixcbiAgICAgICAgICAgICAgXCJzaW5nbGVDYWxsYmFja0FyZ1wiOiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJwYW5lbHNcIjoge1xuICAgICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMyxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDMsXG4gICAgICAgICAgICAgIFwic2luZ2xlQ2FsbGJhY2tBcmdcIjogdHJ1ZVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZWxlbWVudHNcIjoge1xuICAgICAgICAgICAgICBcImNyZWF0ZVNpZGViYXJQYW5lXCI6IHtcbiAgICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImRvd25sb2Fkc1wiOiB7XG4gICAgICAgICAgXCJjYW5jZWxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkb3dubG9hZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImVyYXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0RmlsZUljb25cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJvcGVuXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicGF1c2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVGaWxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVzdW1lXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2hvd1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImV4dGVuc2lvblwiOiB7XG4gICAgICAgICAgXCJpc0FsbG93ZWRGaWxlU2NoZW1lQWNjZXNzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaXNBbGxvd2VkSW5jb2duaXRvQWNjZXNzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaGlzdG9yeVwiOiB7XG4gICAgICAgICAgXCJhZGRVcmxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZWxldGVBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZWxldGVSYW5nZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRlbGV0ZVVybFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFZpc2l0c1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImkxOG5cIjoge1xuICAgICAgICAgIFwiZGV0ZWN0TGFuZ3VhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBY2NlcHRMYW5ndWFnZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpZGVudGl0eVwiOiB7XG4gICAgICAgICAgXCJsYXVuY2hXZWJBdXRoRmxvd1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImlkbGVcIjoge1xuICAgICAgICAgIFwicXVlcnlTdGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIm1hbmFnZW1lbnRcIjoge1xuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0U2VsZlwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEVuYWJsZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1bmluc3RhbGxTZWxmXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwibm90aWZpY2F0aW9uc1wiOiB7XG4gICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFBlcm1pc3Npb25MZXZlbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInBhZ2VBY3Rpb25cIjoge1xuICAgICAgICAgIFwiZ2V0UG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRUaXRsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImhpZGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRJY29uXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0UG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRUaXRsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNob3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJwZXJtaXNzaW9uc1wiOiB7XG4gICAgICAgICAgXCJjb250YWluc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlcXVlc3RcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJydW50aW1lXCI6IHtcbiAgICAgICAgICBcImdldEJhY2tncm91bmRQYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UGxhdGZvcm1JbmZvXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3Blbk9wdGlvbnNQYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVxdWVzdFVwZGF0ZUNoZWNrXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VuZE1lc3NhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogM1xuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZW5kTmF0aXZlTWVzc2FnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFVuaW5zdGFsbFVSTFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInNlc3Npb25zXCI6IHtcbiAgICAgICAgICBcImdldERldmljZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRSZWNlbnRseUNsb3NlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlc3RvcmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJzdG9yYWdlXCI6IHtcbiAgICAgICAgICBcImxvY2FsXCI6IHtcbiAgICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwibWFuYWdlZFwiOiB7XG4gICAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzeW5jXCI6IHtcbiAgICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwidGFic1wiOiB7XG4gICAgICAgICAgXCJjYXB0dXJlVmlzaWJsZVRhYlwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRldGVjdExhbmd1YWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGlzY2FyZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImR1cGxpY2F0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImV4ZWN1dGVTY3JpcHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRDdXJyZW50XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Wm9vbVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFpvb21TZXR0aW5nc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdvQmFja1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdvRm9yd2FyZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImhpZ2hsaWdodFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImluc2VydENTU1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJxdWVyeVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbG9hZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUNTU1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlbmRNZXNzYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDNcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0Wm9vbVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFpvb21TZXR0aW5nc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInRvcFNpdGVzXCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIndlYk5hdmlnYXRpb25cIjoge1xuICAgICAgICAgIFwiZ2V0QWxsRnJhbWVzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0RnJhbWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ3ZWJSZXF1ZXN0XCI6IHtcbiAgICAgICAgICBcImhhbmRsZXJCZWhhdmlvckNoYW5nZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ3aW5kb3dzXCI6IHtcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEN1cnJlbnRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRMYXN0Rm9jdXNlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgaWYgKE9iamVjdC5rZXlzKGFwaU1ldGFkYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYXBpLW1ldGFkYXRhLmpzb24gaGFzIG5vdCBiZWVuIGluY2x1ZGVkIGluIGJyb3dzZXItcG9seWZpbGxcIik7XG4gICAgICB9XG5cbiAgICAgIC8qKlxuICAgICAgICogQSBXZWFrTWFwIHN1YmNsYXNzIHdoaWNoIGNyZWF0ZXMgYW5kIHN0b3JlcyBhIHZhbHVlIGZvciBhbnkga2V5IHdoaWNoIGRvZXNcbiAgICAgICAqIG5vdCBleGlzdCB3aGVuIGFjY2Vzc2VkLCBidXQgYmVoYXZlcyBleGFjdGx5IGFzIGFuIG9yZGluYXJ5IFdlYWtNYXBcbiAgICAgICAqIG90aGVyd2lzZS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBjcmVhdGVJdGVtXG4gICAgICAgKiAgICAgICAgQSBmdW5jdGlvbiB3aGljaCB3aWxsIGJlIGNhbGxlZCBpbiBvcmRlciB0byBjcmVhdGUgdGhlIHZhbHVlIGZvciBhbnlcbiAgICAgICAqICAgICAgICBrZXkgd2hpY2ggZG9lcyBub3QgZXhpc3QsIHRoZSBmaXJzdCB0aW1lIGl0IGlzIGFjY2Vzc2VkLiBUaGVcbiAgICAgICAqICAgICAgICBmdW5jdGlvbiByZWNlaXZlcywgYXMgaXRzIG9ubHkgYXJndW1lbnQsIHRoZSBrZXkgYmVpbmcgY3JlYXRlZC5cbiAgICAgICAqL1xuICAgICAgY2xhc3MgRGVmYXVsdFdlYWtNYXAgZXh0ZW5kcyBXZWFrTWFwIHtcbiAgICAgICAgY29uc3RydWN0b3IoY3JlYXRlSXRlbSwgaXRlbXMgPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBzdXBlcihpdGVtcyk7XG4gICAgICAgICAgdGhpcy5jcmVhdGVJdGVtID0gY3JlYXRlSXRlbTtcbiAgICAgICAgfVxuICAgICAgICBnZXQoa2V5KSB7XG4gICAgICAgICAgaWYgKCF0aGlzLmhhcyhrZXkpKSB7XG4gICAgICAgICAgICB0aGlzLnNldChrZXksIHRoaXMuY3JlYXRlSXRlbShrZXkpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHN1cGVyLmdldChrZXkpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBvYmplY3QgaXMgYW4gb2JqZWN0IHdpdGggYSBgdGhlbmAgbWV0aG9kLCBhbmQgY2FuXG4gICAgICAgKiB0aGVyZWZvcmUgYmUgYXNzdW1lZCB0byBiZWhhdmUgYXMgYSBQcm9taXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIHRlc3QuXG4gICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgdmFsdWUgaXMgdGhlbmFibGUuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0IGlzVGhlbmFibGUgPSB2YWx1ZSA9PiB7XG4gICAgICAgIHJldHVybiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIjtcbiAgICAgIH07XG5cbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlcyBhbmQgcmV0dXJucyBhIGZ1bmN0aW9uIHdoaWNoLCB3aGVuIGNhbGxlZCwgd2lsbCByZXNvbHZlIG9yIHJlamVjdFxuICAgICAgICogdGhlIGdpdmVuIHByb21pc2UgYmFzZWQgb24gaG93IGl0IGlzIGNhbGxlZDpcbiAgICAgICAqXG4gICAgICAgKiAtIElmLCB3aGVuIGNhbGxlZCwgYGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcmAgY29udGFpbnMgYSBub24tbnVsbCBvYmplY3QsXG4gICAgICAgKiAgIHRoZSBwcm9taXNlIGlzIHJlamVjdGVkIHdpdGggdGhhdCB2YWx1ZS5cbiAgICAgICAqIC0gSWYgdGhlIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aXRoIGV4YWN0bHkgb25lIGFyZ3VtZW50LCB0aGUgcHJvbWlzZSBpc1xuICAgICAgICogICByZXNvbHZlZCB0byB0aGF0IHZhbHVlLlxuICAgICAgICogLSBPdGhlcndpc2UsIHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHRvIGFuIGFycmF5IGNvbnRhaW5pbmcgYWxsIG9mIHRoZVxuICAgICAgICogICBmdW5jdGlvbidzIGFyZ3VtZW50cy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gcHJvbWlzZVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSByZXNvbHV0aW9uIGFuZCByZWplY3Rpb24gZnVuY3Rpb25zIG9mIGFcbiAgICAgICAqICAgICAgICBwcm9taXNlLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZXNvbHZlXG4gICAgICAgKiAgICAgICAgVGhlIHByb21pc2UncyByZXNvbHV0aW9uIGZ1bmN0aW9uLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZWplY3RcbiAgICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlamVjdGlvbiBmdW5jdGlvbi5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSB3cmFwcGVkIG1ldGhvZCB3aGljaCBoYXMgY3JlYXRlZCB0aGUgY2FsbGJhY2suXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnXG4gICAgICAgKiAgICAgICAgV2hldGhlciBvciBub3QgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgd2l0aCBvbmx5IHRoZSBmaXJzdFxuICAgICAgICogICAgICAgIGFyZ3VtZW50IG9mIHRoZSBjYWxsYmFjaywgYWx0ZXJuYXRpdmVseSBhbiBhcnJheSBvZiBhbGwgdGhlXG4gICAgICAgKiAgICAgICAgY2FsbGJhY2sgYXJndW1lbnRzIGlzIHJlc29sdmVkLiBCeSBkZWZhdWx0LCBpZiB0aGUgY2FsbGJhY2tcbiAgICAgICAqICAgICAgICBmdW5jdGlvbiBpcyBpbnZva2VkIHdpdGggb25seSBhIHNpbmdsZSBhcmd1bWVudCwgdGhhdCB3aWxsIGJlXG4gICAgICAgKiAgICAgICAgcmVzb2x2ZWQgdG8gdGhlIHByb21pc2UsIHdoaWxlIGFsbCBhcmd1bWVudHMgd2lsbCBiZSByZXNvbHZlZCBhc1xuICAgICAgICogICAgICAgIGFuIGFycmF5IGlmIG11bHRpcGxlIGFyZSBnaXZlbi5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7ZnVuY3Rpb259XG4gICAgICAgKiAgICAgICAgVGhlIGdlbmVyYXRlZCBjYWxsYmFjayBmdW5jdGlvbi5cbiAgICAgICAqL1xuICAgICAgY29uc3QgbWFrZUNhbGxiYWNrID0gKHByb21pc2UsIG1ldGFkYXRhKSA9PiB7XG4gICAgICAgIHJldHVybiAoLi4uY2FsbGJhY2tBcmdzKSA9PiB7XG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHByb21pc2UucmVqZWN0KG5ldyBFcnJvcihleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnIHx8IGNhbGxiYWNrQXJncy5sZW5ndGggPD0gMSAmJiBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZyAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHByb21pc2UucmVzb2x2ZShjYWxsYmFja0FyZ3NbMF0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9O1xuICAgICAgY29uc3QgcGx1cmFsaXplQXJndW1lbnRzID0gbnVtQXJncyA9PiBudW1BcmdzID09IDEgPyBcImFyZ3VtZW50XCIgOiBcImFyZ3VtZW50c1wiO1xuXG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSB3cmFwcGVyIGZ1bmN0aW9uIGZvciBhIG1ldGhvZCB3aXRoIHRoZSBnaXZlbiBuYW1lIGFuZCBtZXRhZGF0YS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICAgICAgICogICAgICAgIFRoZSBuYW1lIG9mIHRoZSBtZXRob2Qgd2hpY2ggaXMgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWluQXJnc1xuICAgICAgICogICAgICAgIFRoZSBtaW5pbXVtIG51bWJlciBvZiBhcmd1bWVudHMgd2hpY2ggbXVzdCBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24uIElmIGNhbGxlZCB3aXRoIGZld2VyIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtpbnRlZ2VyfSBtZXRhZGF0YS5tYXhBcmdzXG4gICAgICAgKiAgICAgICAgVGhlIG1heGltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtYXkgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uLiBJZiBjYWxsZWQgd2l0aCBtb3JlIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZ1xuICAgICAgICogICAgICAgIFdoZXRoZXIgb3Igbm90IHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHdpdGggb25seSB0aGUgZmlyc3RcbiAgICAgICAqICAgICAgICBhcmd1bWVudCBvZiB0aGUgY2FsbGJhY2ssIGFsdGVybmF0aXZlbHkgYW4gYXJyYXkgb2YgYWxsIHRoZVxuICAgICAgICogICAgICAgIGNhbGxiYWNrIGFyZ3VtZW50cyBpcyByZXNvbHZlZC4gQnkgZGVmYXVsdCwgaWYgdGhlIGNhbGxiYWNrXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24gaXMgaW52b2tlZCB3aXRoIG9ubHkgYSBzaW5nbGUgYXJndW1lbnQsIHRoYXQgd2lsbCBiZVxuICAgICAgICogICAgICAgIHJlc29sdmVkIHRvIHRoZSBwcm9taXNlLCB3aGlsZSBhbGwgYXJndW1lbnRzIHdpbGwgYmUgcmVzb2x2ZWQgYXNcbiAgICAgICAqICAgICAgICBhbiBhcnJheSBpZiBtdWx0aXBsZSBhcmUgZ2l2ZW4uXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge2Z1bmN0aW9uKG9iamVjdCwgLi4uKil9XG4gICAgICAgKiAgICAgICBUaGUgZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24uXG4gICAgICAgKi9cbiAgICAgIGNvbnN0IHdyYXBBc3luY0Z1bmN0aW9uID0gKG5hbWUsIG1ldGFkYXRhKSA9PiB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBhc3luY0Z1bmN0aW9uV3JhcHBlcih0YXJnZXQsIC4uLmFyZ3MpIHtcbiAgICAgICAgICBpZiAoYXJncy5sZW5ndGggPCBtZXRhZGF0YS5taW5BcmdzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IGxlYXN0ICR7bWV0YWRhdGEubWluQXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWluQXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoYXJncy5sZW5ndGggPiBtZXRhZGF0YS5tYXhBcmdzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBpZiAobWV0YWRhdGEuZmFsbGJhY2tUb05vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgLy8gVGhpcyBBUEkgbWV0aG9kIGhhcyBjdXJyZW50bHkgbm8gY2FsbGJhY2sgb24gQ2hyb21lLCBidXQgaXQgcmV0dXJuIGEgcHJvbWlzZSBvbiBGaXJlZm94LFxuICAgICAgICAgICAgICAvLyBhbmQgc28gdGhlIHBvbHlmaWxsIHdpbGwgdHJ5IHRvIGNhbGwgaXQgd2l0aCBhIGNhbGxiYWNrIGZpcnN0LCBhbmQgaXQgd2lsbCBmYWxsYmFja1xuICAgICAgICAgICAgICAvLyB0byBub3QgcGFzc2luZyB0aGUgY2FsbGJhY2sgaWYgdGhlIGZpcnN0IGNhbGwgZmFpbHMuXG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MsIG1ha2VDYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICAgICAgcmVqZWN0XG4gICAgICAgICAgICAgICAgfSwgbWV0YWRhdGEpKTtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoY2JFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHtuYW1lfSBBUEkgbWV0aG9kIGRvZXNuJ3Qgc2VlbSB0byBzdXBwb3J0IHRoZSBjYWxsYmFjayBwYXJhbWV0ZXIsIGAgKyBcImZhbGxpbmcgYmFjayB0byBjYWxsIGl0IHdpdGhvdXQgYSBjYWxsYmFjazogXCIsIGNiRXJyb3IpO1xuICAgICAgICAgICAgICAgIHRhcmdldFtuYW1lXSguLi5hcmdzKTtcblxuICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgQVBJIG1ldGhvZCBtZXRhZGF0YSwgc28gdGhhdCB0aGUgbmV4dCBBUEkgY2FsbHMgd2lsbCBub3QgdHJ5IHRvXG4gICAgICAgICAgICAgICAgLy8gdXNlIHRoZSB1bnN1cHBvcnRlZCBjYWxsYmFjayBhbnltb3JlLlxuICAgICAgICAgICAgICAgIG1ldGFkYXRhLmZhbGxiYWNrVG9Ob0NhbGxiYWNrID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgbWV0YWRhdGEubm9DYWxsYmFjayA9IHRydWU7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLm5vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgICAgICB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfTtcblxuICAgICAgLyoqXG4gICAgICAgKiBXcmFwcyBhbiBleGlzdGluZyBtZXRob2Qgb2YgdGhlIHRhcmdldCBvYmplY3QsIHNvIHRoYXQgY2FsbHMgdG8gaXQgYXJlXG4gICAgICAgKiBpbnRlcmNlcHRlZCBieSB0aGUgZ2l2ZW4gd3JhcHBlciBmdW5jdGlvbi4gVGhlIHdyYXBwZXIgZnVuY3Rpb24gcmVjZWl2ZXMsXG4gICAgICAgKiBhcyBpdHMgZmlyc3QgYXJndW1lbnQsIHRoZSBvcmlnaW5hbCBgdGFyZ2V0YCBvYmplY3QsIGZvbGxvd2VkIGJ5IGVhY2ggb2ZcbiAgICAgICAqIHRoZSBhcmd1bWVudHMgcGFzc2VkIHRvIHRoZSBvcmlnaW5hbCBtZXRob2QuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IHRhcmdldFxuICAgICAgICogICAgICAgIFRoZSBvcmlnaW5hbCB0YXJnZXQgb2JqZWN0IHRoYXQgdGhlIHdyYXBwZWQgbWV0aG9kIGJlbG9uZ3MgdG8uXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBtZXRob2RcbiAgICAgICAqICAgICAgICBUaGUgbWV0aG9kIGJlaW5nIHdyYXBwZWQuIFRoaXMgaXMgdXNlZCBhcyB0aGUgdGFyZ2V0IG9mIHRoZSBQcm94eVxuICAgICAgICogICAgICAgIG9iamVjdCB3aGljaCBpcyBjcmVhdGVkIHRvIHdyYXAgdGhlIG1ldGhvZC5cbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IHdyYXBwZXJcbiAgICAgICAqICAgICAgICBUaGUgd3JhcHBlciBmdW5jdGlvbiB3aGljaCBpcyBjYWxsZWQgaW4gcGxhY2Ugb2YgYSBkaXJlY3QgaW52b2NhdGlvblxuICAgICAgICogICAgICAgIG9mIHRoZSB3cmFwcGVkIG1ldGhvZC5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7UHJveHk8ZnVuY3Rpb24+fVxuICAgICAgICogICAgICAgIEEgUHJveHkgb2JqZWN0IGZvciB0aGUgZ2l2ZW4gbWV0aG9kLCB3aGljaCBpbnZva2VzIHRoZSBnaXZlbiB3cmFwcGVyXG4gICAgICAgKiAgICAgICAgbWV0aG9kIGluIGl0cyBwbGFjZS5cbiAgICAgICAqL1xuICAgICAgY29uc3Qgd3JhcE1ldGhvZCA9ICh0YXJnZXQsIG1ldGhvZCwgd3JhcHBlcikgPT4ge1xuICAgICAgICByZXR1cm4gbmV3IFByb3h5KG1ldGhvZCwge1xuICAgICAgICAgIGFwcGx5KHRhcmdldE1ldGhvZCwgdGhpc09iaiwgYXJncykge1xuICAgICAgICAgICAgcmV0dXJuIHdyYXBwZXIuY2FsbCh0aGlzT2JqLCB0YXJnZXQsIC4uLmFyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgbGV0IGhhc093blByb3BlcnR5ID0gRnVuY3Rpb24uY2FsbC5iaW5kKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkpO1xuXG4gICAgICAvKipcbiAgICAgICAqIFdyYXBzIGFuIG9iamVjdCBpbiBhIFByb3h5IHdoaWNoIGludGVyY2VwdHMgYW5kIHdyYXBzIGNlcnRhaW4gbWV0aG9kc1xuICAgICAgICogYmFzZWQgb24gdGhlIGdpdmVuIGB3cmFwcGVyc2AgYW5kIGBtZXRhZGF0YWAgb2JqZWN0cy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFyZ2V0XG4gICAgICAgKiAgICAgICAgVGhlIHRhcmdldCBvYmplY3QgdG8gd3JhcC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gW3dyYXBwZXJzID0ge31dXG4gICAgICAgKiAgICAgICAgQW4gb2JqZWN0IHRyZWUgY29udGFpbmluZyB3cmFwcGVyIGZ1bmN0aW9ucyBmb3Igc3BlY2lhbCBjYXNlcy4gQW55XG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24gcHJlc2VudCBpbiB0aGlzIG9iamVjdCB0cmVlIGlzIGNhbGxlZCBpbiBwbGFjZSBvZiB0aGVcbiAgICAgICAqICAgICAgICBtZXRob2QgaW4gdGhlIHNhbWUgbG9jYXRpb24gaW4gdGhlIGB0YXJnZXRgIG9iamVjdCB0cmVlLiBUaGVzZVxuICAgICAgICogICAgICAgIHdyYXBwZXIgbWV0aG9kcyBhcmUgaW52b2tlZCBhcyBkZXNjcmliZWQgaW4ge0BzZWUgd3JhcE1ldGhvZH0uXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IFttZXRhZGF0YSA9IHt9XVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCB0cmVlIGNvbnRhaW5pbmcgbWV0YWRhdGEgdXNlZCB0byBhdXRvbWF0aWNhbGx5IGdlbmVyYXRlXG4gICAgICAgKiAgICAgICAgUHJvbWlzZS1iYXNlZCB3cmFwcGVyIGZ1bmN0aW9ucyBmb3IgYXN5bmNocm9ub3VzLiBBbnkgZnVuY3Rpb24gaW5cbiAgICAgICAqICAgICAgICB0aGUgYHRhcmdldGAgb2JqZWN0IHRyZWUgd2hpY2ggaGFzIGEgY29ycmVzcG9uZGluZyBtZXRhZGF0YSBvYmplY3RcbiAgICAgICAqICAgICAgICBpbiB0aGUgc2FtZSBsb2NhdGlvbiBpbiB0aGUgYG1ldGFkYXRhYCB0cmVlIGlzIHJlcGxhY2VkIHdpdGggYW5cbiAgICAgICAqICAgICAgICBhdXRvbWF0aWNhbGx5LWdlbmVyYXRlZCB3cmFwcGVyIGZ1bmN0aW9uLCBhcyBkZXNjcmliZWQgaW5cbiAgICAgICAqICAgICAgICB7QHNlZSB3cmFwQXN5bmNGdW5jdGlvbn1cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7UHJveHk8b2JqZWN0Pn1cbiAgICAgICAqL1xuICAgICAgY29uc3Qgd3JhcE9iamVjdCA9ICh0YXJnZXQsIHdyYXBwZXJzID0ge30sIG1ldGFkYXRhID0ge30pID0+IHtcbiAgICAgICAgbGV0IGNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgbGV0IGhhbmRsZXJzID0ge1xuICAgICAgICAgIGhhcyhwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgICAgcmV0dXJuIHByb3AgaW4gdGFyZ2V0IHx8IHByb3AgaW4gY2FjaGU7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBnZXQocHJveHlUYXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICBpZiAocHJvcCBpbiBjYWNoZSkge1xuICAgICAgICAgICAgICByZXR1cm4gY2FjaGVbcHJvcF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIShwcm9wIGluIHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCB2YWx1ZSA9IHRhcmdldFtwcm9wXTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIG9uIHRoZSB1bmRlcmx5aW5nIG9iamVjdC4gQ2hlY2sgaWYgd2UgbmVlZCB0byBkb1xuICAgICAgICAgICAgICAvLyBhbnkgd3JhcHBpbmcuXG5cbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB3cmFwcGVyc1twcm9wXSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgaGF2ZSBhIHNwZWNpYWwtY2FzZSB3cmFwcGVyIGZvciB0aGlzIG1ldGhvZC5cbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXJzW3Byb3BdKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgcHJvcCkpIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIGFzeW5jIG1ldGhvZCB0aGF0IHdlIGhhdmUgbWV0YWRhdGEgZm9yLiBDcmVhdGUgYVxuICAgICAgICAgICAgICAgIC8vIFByb21pc2Ugd3JhcHBlciBmb3IgaXQuXG4gICAgICAgICAgICAgICAgbGV0IHdyYXBwZXIgPSB3cmFwQXN5bmNGdW5jdGlvbihwcm9wLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIHRoYXQgd2UgZG9uJ3Qga25vdyBvciBjYXJlIGFib3V0LiBSZXR1cm4gdGhlXG4gICAgICAgICAgICAgICAgLy8gb3JpZ2luYWwgbWV0aG9kLCBib3VuZCB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5iaW5kKHRhcmdldCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmIChoYXNPd25Qcm9wZXJ0eSh3cmFwcGVycywgcHJvcCkgfHwgaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSkge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIG9iamVjdCB0aGF0IHdlIG5lZWQgdG8gZG8gc29tZSB3cmFwcGluZyBmb3IgdGhlIGNoaWxkcmVuXG4gICAgICAgICAgICAgIC8vIG9mLiBDcmVhdGUgYSBzdWItb2JqZWN0IHdyYXBwZXIgZm9yIGl0IHdpdGggdGhlIGFwcHJvcHJpYXRlIGNoaWxkXG4gICAgICAgICAgICAgIC8vIG1ldGFkYXRhLlxuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBPYmplY3QodmFsdWUsIHdyYXBwZXJzW3Byb3BdLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGhhc093blByb3BlcnR5KG1ldGFkYXRhLCBcIipcIikpIHtcbiAgICAgICAgICAgICAgLy8gV3JhcCBhbGwgcHJvcGVydGllcyBpbiAqIG5hbWVzcGFjZS5cbiAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwT2JqZWN0KHZhbHVlLCB3cmFwcGVyc1twcm9wXSwgbWV0YWRhdGFbXCIqXCJdKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIFdlIGRvbid0IG5lZWQgdG8gZG8gYW55IHdyYXBwaW5nIGZvciB0aGlzIHByb3BlcnR5LFxuICAgICAgICAgICAgICAvLyBzbyBqdXN0IGZvcndhcmQgYWxsIGFjY2VzcyB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwge1xuICAgICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGdldCgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0YXJnZXRbcHJvcF07XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzZXQodmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBzZXQocHJveHlUYXJnZXQsIHByb3AsIHZhbHVlLCByZWNlaXZlcikge1xuICAgICAgICAgICAgaWYgKHByb3AgaW4gY2FjaGUpIHtcbiAgICAgICAgICAgICAgY2FjaGVbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBkZWZpbmVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCwgZGVzYykge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZGVmaW5lUHJvcGVydHkoY2FjaGUsIHByb3AsIGRlc2MpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgZGVsZXRlUHJvcGVydHkocHJveHlUYXJnZXQsIHByb3ApIHtcbiAgICAgICAgICAgIHJldHVybiBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KGNhY2hlLCBwcm9wKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gUGVyIGNvbnRyYWN0IG9mIHRoZSBQcm94eSBBUEksIHRoZSBcImdldFwiIHByb3h5IGhhbmRsZXIgbXVzdCByZXR1cm4gdGhlXG4gICAgICAgIC8vIG9yaWdpbmFsIHZhbHVlIG9mIHRoZSB0YXJnZXQgaWYgdGhhdCB2YWx1ZSBpcyBkZWNsYXJlZCByZWFkLW9ubHkgYW5kXG4gICAgICAgIC8vIG5vbi1jb25maWd1cmFibGUuIEZvciB0aGlzIHJlYXNvbiwgd2UgY3JlYXRlIGFuIG9iamVjdCB3aXRoIHRoZVxuICAgICAgICAvLyBwcm90b3R5cGUgc2V0IHRvIGB0YXJnZXRgIGluc3RlYWQgb2YgdXNpbmcgYHRhcmdldGAgZGlyZWN0bHkuXG4gICAgICAgIC8vIE90aGVyd2lzZSB3ZSBjYW5ub3QgcmV0dXJuIGEgY3VzdG9tIG9iamVjdCBmb3IgQVBJcyB0aGF0XG4gICAgICAgIC8vIGFyZSBkZWNsYXJlZCByZWFkLW9ubHkgYW5kIG5vbi1jb25maWd1cmFibGUsIHN1Y2ggYXMgYGNocm9tZS5kZXZ0b29sc2AuXG4gICAgICAgIC8vXG4gICAgICAgIC8vIFRoZSBwcm94eSBoYW5kbGVycyB0aGVtc2VsdmVzIHdpbGwgc3RpbGwgdXNlIHRoZSBvcmlnaW5hbCBgdGFyZ2V0YFxuICAgICAgICAvLyBpbnN0ZWFkIG9mIHRoZSBgcHJveHlUYXJnZXRgLCBzbyB0aGF0IHRoZSBtZXRob2RzIGFuZCBwcm9wZXJ0aWVzIGFyZVxuICAgICAgICAvLyBkZXJlZmVyZW5jZWQgdmlhIHRoZSBvcmlnaW5hbCB0YXJnZXRzLlxuICAgICAgICBsZXQgcHJveHlUYXJnZXQgPSBPYmplY3QuY3JlYXRlKHRhcmdldCk7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkocHJveHlUYXJnZXQsIGhhbmRsZXJzKTtcbiAgICAgIH07XG5cbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlcyBhIHNldCBvZiB3cmFwcGVyIGZ1bmN0aW9ucyBmb3IgYW4gZXZlbnQgb2JqZWN0LCB3aGljaCBoYW5kbGVzXG4gICAgICAgKiB3cmFwcGluZyBvZiBsaXN0ZW5lciBmdW5jdGlvbnMgdGhhdCB0aG9zZSBtZXNzYWdlcyBhcmUgcGFzc2VkLlxuICAgICAgICpcbiAgICAgICAqIEEgc2luZ2xlIHdyYXBwZXIgaXMgY3JlYXRlZCBmb3IgZWFjaCBsaXN0ZW5lciBmdW5jdGlvbiwgYW5kIHN0b3JlZCBpbiBhXG4gICAgICAgKiBtYXAuIFN1YnNlcXVlbnQgY2FsbHMgdG8gYGFkZExpc3RlbmVyYCwgYGhhc0xpc3RlbmVyYCwgb3IgYHJlbW92ZUxpc3RlbmVyYFxuICAgICAgICogcmV0cmlldmUgdGhlIG9yaWdpbmFsIHdyYXBwZXIsIHNvIHRoYXQgIGF0dGVtcHRzIHRvIHJlbW92ZSBhXG4gICAgICAgKiBwcmV2aW91c2x5LWFkZGVkIGxpc3RlbmVyIHdvcmsgYXMgZXhwZWN0ZWQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtEZWZhdWx0V2Vha01hcDxmdW5jdGlvbiwgZnVuY3Rpb24+fSB3cmFwcGVyTWFwXG4gICAgICAgKiAgICAgICAgQSBEZWZhdWx0V2Vha01hcCBvYmplY3Qgd2hpY2ggd2lsbCBjcmVhdGUgdGhlIGFwcHJvcHJpYXRlIHdyYXBwZXJcbiAgICAgICAqICAgICAgICBmb3IgYSBnaXZlbiBsaXN0ZW5lciBmdW5jdGlvbiB3aGVuIG9uZSBkb2VzIG5vdCBleGlzdCwgYW5kIHJldHJpZXZlXG4gICAgICAgKiAgICAgICAgYW4gZXhpc3Rpbmcgb25lIHdoZW4gaXQgZG9lcy5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7b2JqZWN0fVxuICAgICAgICovXG4gICAgICBjb25zdCB3cmFwRXZlbnQgPSB3cmFwcGVyTWFwID0+ICh7XG4gICAgICAgIGFkZExpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIsIC4uLmFyZ3MpIHtcbiAgICAgICAgICB0YXJnZXQuYWRkTGlzdGVuZXIod3JhcHBlck1hcC5nZXQobGlzdGVuZXIpLCAuLi5hcmdzKTtcbiAgICAgICAgfSxcbiAgICAgICAgaGFzTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICAgIHJldHVybiB0YXJnZXQuaGFzTGlzdGVuZXIod3JhcHBlck1hcC5nZXQobGlzdGVuZXIpKTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICAgIHRhcmdldC5yZW1vdmVMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG9uUmVxdWVzdEZpbmlzaGVkV3JhcHBlcnMgPSBuZXcgRGVmYXVsdFdlYWtNYXAobGlzdGVuZXIgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIGxpc3RlbmVyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICByZXR1cm4gbGlzdGVuZXI7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogV3JhcHMgYW4gb25SZXF1ZXN0RmluaXNoZWQgbGlzdGVuZXIgZnVuY3Rpb24gc28gdGhhdCBpdCB3aWxsIHJldHVybiBhXG4gICAgICAgICAqIGBnZXRDb250ZW50KClgIHByb3BlcnR5IHdoaWNoIHJldHVybnMgYSBgUHJvbWlzZWAgcmF0aGVyIHRoYW4gdXNpbmcgYVxuICAgICAgICAgKiBjYWxsYmFjayBBUEkuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSByZXFcbiAgICAgICAgICogICAgICAgIFRoZSBIQVIgZW50cnkgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgbmV0d29yayByZXF1ZXN0LlxuICAgICAgICAgKi9cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uUmVxdWVzdEZpbmlzaGVkKHJlcSkge1xuICAgICAgICAgIGNvbnN0IHdyYXBwZWRSZXEgPSB3cmFwT2JqZWN0KHJlcSwge30gLyogd3JhcHBlcnMgKi8sIHtcbiAgICAgICAgICAgIGdldENvbnRlbnQ6IHtcbiAgICAgICAgICAgICAgbWluQXJnczogMCxcbiAgICAgICAgICAgICAgbWF4QXJnczogMFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGxpc3RlbmVyKHdyYXBwZWRSZXEpO1xuICAgICAgICB9O1xuICAgICAgfSk7XG4gICAgICBjb25zdCBvbk1lc3NhZ2VXcmFwcGVycyA9IG5ldyBEZWZhdWx0V2Vha01hcChsaXN0ZW5lciA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgbGlzdGVuZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIHJldHVybiBsaXN0ZW5lcjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcmFwcyBhIG1lc3NhZ2UgbGlzdGVuZXIgZnVuY3Rpb24gc28gdGhhdCBpdCBtYXkgc2VuZCByZXNwb25zZXMgYmFzZWQgb25cbiAgICAgICAgICogaXRzIHJldHVybiB2YWx1ZSwgcmF0aGVyIHRoYW4gYnkgcmV0dXJuaW5nIGEgc2VudGluZWwgdmFsdWUgYW5kIGNhbGxpbmcgYVxuICAgICAgICAgKiBjYWxsYmFjay4gSWYgdGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHJldHVybnMgYSBQcm9taXNlLCB0aGUgcmVzcG9uc2UgaXNcbiAgICAgICAgICogc2VudCB3aGVuIHRoZSBwcm9taXNlIGVpdGhlciByZXNvbHZlcyBvciByZWplY3RzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0geyp9IG1lc3NhZ2VcbiAgICAgICAgICogICAgICAgIFRoZSBtZXNzYWdlIHNlbnQgYnkgdGhlIG90aGVyIGVuZCBvZiB0aGUgY2hhbm5lbC5cbiAgICAgICAgICogQHBhcmFtIHtvYmplY3R9IHNlbmRlclxuICAgICAgICAgKiAgICAgICAgRGV0YWlscyBhYm91dCB0aGUgc2VuZGVyIG9mIHRoZSBtZXNzYWdlLlxuICAgICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9uKCopfSBzZW5kUmVzcG9uc2VcbiAgICAgICAgICogICAgICAgIEEgY2FsbGJhY2sgd2hpY2gsIHdoZW4gY2FsbGVkIHdpdGggYW4gYXJiaXRyYXJ5IGFyZ3VtZW50LCBzZW5kc1xuICAgICAgICAgKiAgICAgICAgdGhhdCB2YWx1ZSBhcyBhIHJlc3BvbnNlLlxuICAgICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAgICAgICAgICogICAgICAgIFRydWUgaWYgdGhlIHdyYXBwZWQgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCB3aGljaCB3aWxsIGxhdGVyXG4gICAgICAgICAqICAgICAgICB5aWVsZCBhIHJlc3BvbnNlLiBGYWxzZSBvdGhlcndpc2UuXG4gICAgICAgICAqL1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gb25NZXNzYWdlKG1lc3NhZ2UsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSB7XG4gICAgICAgICAgbGV0IGRpZENhbGxTZW5kUmVzcG9uc2UgPSBmYWxzZTtcbiAgICAgICAgICBsZXQgd3JhcHBlZFNlbmRSZXNwb25zZTtcbiAgICAgICAgICBsZXQgc2VuZFJlc3BvbnNlUHJvbWlzZSA9IG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICAgICAgd3JhcHBlZFNlbmRSZXNwb25zZSA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICBkaWRDYWxsU2VuZFJlc3BvbnNlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlc3VsdCA9IGxpc3RlbmVyKG1lc3NhZ2UsIHNlbmRlciwgd3JhcHBlZFNlbmRSZXNwb25zZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICByZXN1bHQgPSBQcm9taXNlLnJlamVjdChlcnIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc1Jlc3VsdFRoZW5hYmxlID0gcmVzdWx0ICE9PSB0cnVlICYmIGlzVGhlbmFibGUocmVzdWx0KTtcblxuICAgICAgICAgIC8vIElmIHRoZSBsaXN0ZW5lciBkaWRuJ3QgcmV0dXJuZWQgdHJ1ZSBvciBhIFByb21pc2UsIG9yIGNhbGxlZFxuICAgICAgICAgIC8vIHdyYXBwZWRTZW5kUmVzcG9uc2Ugc3luY2hyb25vdXNseSwgd2UgY2FuIGV4aXQgZWFybGllclxuICAgICAgICAgIC8vIGJlY2F1c2UgdGhlcmUgd2lsbCBiZSBubyByZXNwb25zZSBzZW50IGZyb20gdGhpcyBsaXN0ZW5lci5cbiAgICAgICAgICBpZiAocmVzdWx0ICE9PSB0cnVlICYmICFpc1Jlc3VsdFRoZW5hYmxlICYmICFkaWRDYWxsU2VuZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gQSBzbWFsbCBoZWxwZXIgdG8gc2VuZCB0aGUgbWVzc2FnZSBpZiB0aGUgcHJvbWlzZSByZXNvbHZlc1xuICAgICAgICAgIC8vIGFuZCBhbiBlcnJvciBpZiB0aGUgcHJvbWlzZSByZWplY3RzIChhIHdyYXBwZWQgc2VuZE1lc3NhZ2UgaGFzXG4gICAgICAgICAgLy8gdG8gdHJhbnNsYXRlIHRoZSBtZXNzYWdlIGludG8gYSByZXNvbHZlZCBwcm9taXNlIG9yIGEgcmVqZWN0ZWRcbiAgICAgICAgICAvLyBwcm9taXNlKS5cbiAgICAgICAgICBjb25zdCBzZW5kUHJvbWlzZWRSZXN1bHQgPSBwcm9taXNlID0+IHtcbiAgICAgICAgICAgIHByb21pc2UudGhlbihtc2cgPT4ge1xuICAgICAgICAgICAgICAvLyBzZW5kIHRoZSBtZXNzYWdlIHZhbHVlLlxuICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UobXNnKTtcbiAgICAgICAgICAgIH0sIGVycm9yID0+IHtcbiAgICAgICAgICAgICAgLy8gU2VuZCBhIEpTT04gcmVwcmVzZW50YXRpb24gb2YgdGhlIGVycm9yIGlmIHRoZSByZWplY3RlZCB2YWx1ZVxuICAgICAgICAgICAgICAvLyBpcyBhbiBpbnN0YW5jZSBvZiBlcnJvciwgb3IgdGhlIG9iamVjdCBpdHNlbGYgb3RoZXJ3aXNlLlxuICAgICAgICAgICAgICBsZXQgbWVzc2FnZTtcbiAgICAgICAgICAgICAgaWYgKGVycm9yICYmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yIHx8IHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSBcInN0cmluZ1wiKSkge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWRcIjtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBzZW5kUmVzcG9uc2Uoe1xuICAgICAgICAgICAgICAgIF9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXzogdHJ1ZSxcbiAgICAgICAgICAgICAgICBtZXNzYWdlXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcbiAgICAgICAgICAgICAgLy8gUHJpbnQgYW4gZXJyb3Igb24gdGhlIGNvbnNvbGUgaWYgdW5hYmxlIHRvIHNlbmQgdGhlIHJlc3BvbnNlLlxuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHNlbmQgb25NZXNzYWdlIHJlamVjdGVkIHJlcGx5XCIsIGVycik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgLy8gSWYgdGhlIGxpc3RlbmVyIHJldHVybmVkIGEgUHJvbWlzZSwgc2VuZCB0aGUgcmVzb2x2ZWQgdmFsdWUgYXMgYVxuICAgICAgICAgIC8vIHJlc3VsdCwgb3RoZXJ3aXNlIHdhaXQgdGhlIHByb21pc2UgcmVsYXRlZCB0byB0aGUgd3JhcHBlZFNlbmRSZXNwb25zZVxuICAgICAgICAgIC8vIGNhbGxiYWNrIHRvIHJlc29sdmUgYW5kIHNlbmQgaXQgYXMgYSByZXNwb25zZS5cbiAgICAgICAgICBpZiAoaXNSZXN1bHRUaGVuYWJsZSkge1xuICAgICAgICAgICAgc2VuZFByb21pc2VkUmVzdWx0KHJlc3VsdCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNlbmRQcm9taXNlZFJlc3VsdChzZW5kUmVzcG9uc2VQcm9taXNlKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBMZXQgQ2hyb21lIGtub3cgdGhhdCB0aGUgbGlzdGVuZXIgaXMgcmVwbHlpbmcuXG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrID0gKHtcbiAgICAgICAgcmVqZWN0LFxuICAgICAgICByZXNvbHZlXG4gICAgICB9LCByZXBseSkgPT4ge1xuICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgIC8vIERldGVjdCB3aGVuIG5vbmUgb2YgdGhlIGxpc3RlbmVycyByZXBsaWVkIHRvIHRoZSBzZW5kTWVzc2FnZSBjYWxsIGFuZCByZXNvbHZlXG4gICAgICAgICAgLy8gdGhlIHByb21pc2UgdG8gdW5kZWZpbmVkIGFzIGluIEZpcmVmb3guXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9pc3N1ZXMvMTMwXG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSA9PT0gQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFKSB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHJlcGx5ICYmIHJlcGx5Ll9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXykge1xuICAgICAgICAgIC8vIENvbnZlcnQgYmFjayB0aGUgSlNPTiByZXByZXNlbnRhdGlvbiBvZiB0aGUgZXJyb3IgaW50b1xuICAgICAgICAgIC8vIGFuIEVycm9yIGluc3RhbmNlLlxuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IocmVwbHkubWVzc2FnZSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUocmVwbHkpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgY29uc3Qgd3JhcHBlZFNlbmRNZXNzYWdlID0gKG5hbWUsIG1ldGFkYXRhLCBhcGlOYW1lc3BhY2VPYmosIC4uLmFyZ3MpID0+IHtcbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoIDwgbWV0YWRhdGEubWluQXJncykge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID4gbWV0YWRhdGEubWF4QXJncykge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbW9zdCAke21ldGFkYXRhLm1heEFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1heEFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHdyYXBwZWRDYiA9IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrLmJpbmQobnVsbCwge1xuICAgICAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGFyZ3MucHVzaCh3cmFwcGVkQ2IpO1xuICAgICAgICAgIGFwaU5hbWVzcGFjZU9iai5zZW5kTWVzc2FnZSguLi5hcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgY29uc3Qgc3RhdGljV3JhcHBlcnMgPSB7XG4gICAgICAgIGRldnRvb2xzOiB7XG4gICAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgICAgb25SZXF1ZXN0RmluaXNoZWQ6IHdyYXBFdmVudChvblJlcXVlc3RGaW5pc2hlZFdyYXBwZXJzKVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgcnVudGltZToge1xuICAgICAgICAgIG9uTWVzc2FnZTogd3JhcEV2ZW50KG9uTWVzc2FnZVdyYXBwZXJzKSxcbiAgICAgICAgICBvbk1lc3NhZ2VFeHRlcm5hbDogd3JhcEV2ZW50KG9uTWVzc2FnZVdyYXBwZXJzKSxcbiAgICAgICAgICBzZW5kTWVzc2FnZTogd3JhcHBlZFNlbmRNZXNzYWdlLmJpbmQobnVsbCwgXCJzZW5kTWVzc2FnZVwiLCB7XG4gICAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgICAgbWF4QXJnczogM1xuICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIHRhYnM6IHtcbiAgICAgICAgICBzZW5kTWVzc2FnZTogd3JhcHBlZFNlbmRNZXNzYWdlLmJpbmQobnVsbCwgXCJzZW5kTWVzc2FnZVwiLCB7XG4gICAgICAgICAgICBtaW5BcmdzOiAyLFxuICAgICAgICAgICAgbWF4QXJnczogM1xuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCBzZXR0aW5nTWV0YWRhdGEgPSB7XG4gICAgICAgIGNsZWFyOiB7XG4gICAgICAgICAgbWluQXJnczogMSxcbiAgICAgICAgICBtYXhBcmdzOiAxXG4gICAgICAgIH0sXG4gICAgICAgIGdldDoge1xuICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgbWF4QXJnczogMVxuICAgICAgICB9LFxuICAgICAgICBzZXQ6IHtcbiAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgIG1heEFyZ3M6IDFcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGFwaU1ldGFkYXRhLnByaXZhY3kgPSB7XG4gICAgICAgIG5ldHdvcms6IHtcbiAgICAgICAgICBcIipcIjogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH0sXG4gICAgICAgIHNlcnZpY2VzOiB7XG4gICAgICAgICAgXCIqXCI6IHNldHRpbmdNZXRhZGF0YVxuICAgICAgICB9LFxuICAgICAgICB3ZWJzaXRlczoge1xuICAgICAgICAgIFwiKlwiOiBzZXR0aW5nTWV0YWRhdGFcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHJldHVybiB3cmFwT2JqZWN0KGV4dGVuc2lvbkFQSXMsIHN0YXRpY1dyYXBwZXJzLCBhcGlNZXRhZGF0YSk7XG4gICAgfTtcblxuICAgIC8vIFRoZSBidWlsZCBwcm9jZXNzIGFkZHMgYSBVTUQgd3JhcHBlciBhcm91bmQgdGhpcyBmaWxlLCB3aGljaCBtYWtlcyB0aGVcbiAgICAvLyBgbW9kdWxlYCB2YXJpYWJsZSBhdmFpbGFibGUuXG4gICAgbW9kdWxlLmV4cG9ydHMgPSB3cmFwQVBJcyhjaHJvbWUpO1xuICB9IGVsc2Uge1xuICAgIG1vZHVsZS5leHBvcnRzID0gZ2xvYmFsVGhpcy5icm93c2VyO1xuICB9XG59KTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJyb3dzZXItcG9seWZpbGwuanMubWFwXG4iLCIvKipcbiAqIEBmaWxlXG4gKlxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5pbXBvcnQgeyBMb2dnZXIsIExvZ0xldmVsIH0gZnJvbSAnQGFkZ3VhcmQvbG9nZ2VyJztcblxuY2xhc3MgRXh0ZW5kZWRMb2dnZXIgZXh0ZW5kcyBMb2dnZXIge1xuICAgIGlzVmVyYm9zZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY3VycmVudExldmVsID09PSBMb2dMZXZlbC5EZWJ1Z1xuICAgICAgICAgICAgIHx8IHRoaXMuY3VycmVudExldmVsID09PSBMb2dMZXZlbC5UcmFjZTtcbiAgICB9XG59XG5cbmNvbnN0IGxvZ2dlciA9IG5ldyBFeHRlbmRlZExvZ2dlcigpO1xuXG5sb2dnZXIuY3VycmVudExldmVsID0gSVNfUkVMRUFTRSB8fCBJU19CRVRBXG4gICAgPyBMb2dMZXZlbC5JbmZvXG4gICAgOiBMb2dMZXZlbC5UcmFjZTtcblxuLy8gRXhwb3NlIGxvZ2dlciB0byB0aGUgd2luZG93IG9iamVjdCxcbi8vIHRvIGhhdmUgcG9zc2liaWxpdHkgdG8gc3dpdGNoIGxvZyBsZXZlbCBmcm9tIHRoZSBjb25zb2xlLlxuLy8gRXhhbXBsZTogYWRndWFyZC5sb2dnZXIuY3VycmVudExldmVsID0gJ2RlYnVnJ1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1nbG9iYWxzXG5PYmplY3QuYXNzaWduKHNlbGYsIHsgYWRndWFyZDogeyAuLi5zZWxmLmFkZ3VhcmQsIGxvZ2dlciB9IH0pO1xuXG5leHBvcnQgeyBMb2dMZXZlbCwgbG9nZ2VyIH07XG4iLCIvKipcbiAqIEBmaWxlXG4gKiBUaGlzIGZpbGUgaXMgcGFydCBvZiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIChodHRwczovL2dpdGh1Yi5jb20vQWRndWFyZFRlYW0vQWRndWFyZEJyb3dzZXJFeHRlbnNpb24pLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXG4gKiBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuXG4gKiBTZWUgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogWW91IHNob3VsZCBoYXZlIHJlY2VpdmVkIGEgY29weSBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2VcbiAqIGFsb25nIHdpdGggQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbi4gSWYgbm90LCBzZWUgPGh0dHA6Ly93d3cuZ251Lm9yZy9saWNlbnNlcy8+LlxuICovXG5cbi8qKlxuICogSW1wb3J0YW50OiBkbyBub3QgdXNlIHouaW5mZXJPZiwgYmVjYXVzZSBpdCBicmluZ3MgYSBsb3Qgb2Ygc2lkZSBlZmZlY3RzIHdpdGhcbiAqIG1hbnkgZGVwZW5kZW5jaWVzIHRvIHRoZSBidW5kbGUuXG4gKlxuICogQWxzbyBwbGVhc2UgdHJ5LCBpZiBwb3NzaWJsZSwgdG8gbm90IGltcG9ydCBoZXJlIGV4dGVybmFsIG1vZHVsZXNcbiAqIG90aGVyIHRoYXQgdHlwZXMuXG4gKi9cbmltcG9ydCB7IHR5cGUgV2luZG93cyB9IGZyb20gJ3dlYmV4dGVuc2lvbi1wb2x5ZmlsbCc7XG5cbmltcG9ydCB7IHR5cGUgRm9yd2FyZEZyb20gfSBmcm9tICcuLi9mb3J3YXJkJztcbmltcG9ydCB0eXBlIHtcbiAgICBDdXN0b21GaWx0ZXJNZXRhZGF0YSxcbiAgICBTZXR0aW5nT3B0aW9uLFxuICAgIFNldHRpbmdzLFxufSBmcm9tICcuLi8uLi9iYWNrZ3JvdW5kL3NjaGVtYSc7XG5pbXBvcnQgdHlwZSB7IE5vdGlmaWVyVHlwZSB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5pbXBvcnQgdHlwZSB7IEFwcGVhcmFuY2VUaGVtZSB9IGZyb20gJy4uL3NldHRpbmdzJztcbmltcG9ydCB0eXBlIHsgRmlsdGVyaW5nTG9nVGFiSW5mbyB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvYXBpL2ZpbHRlcmluZy1sb2cnO1xuaW1wb3J0IHR5cGUgeyBHZXRUYWJJbmZvRm9yUG9wdXBSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvdWkvcG9wdXAnO1xuaW1wb3J0IHR5cGUgeyBHZXRGaWx0ZXJpbmdMb2dEYXRhUmVzcG9uc2UgfSBmcm9tICcuLi8uLi9iYWNrZ3JvdW5kL3NlcnZpY2VzL2ZpbHRlcmluZy1sb2cnO1xuaW1wb3J0IHR5cGUge1xuICAgIElSdWxlc0xpbWl0cyxcbiAgICBNdjNMaW1pdHNDaGVja1Jlc3VsdCxcbiAgICBTdGF0aWNMaW1pdHNDaGVja1Jlc3VsdCxcbn0gZnJvbSAnLi4vLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy9ydWxlcy1saW1pdHMvaW50ZXJmYWNlJztcbmltcG9ydCB0eXBlIHsgUGFnZUluaXRBcHBEYXRhIH0gZnJvbSAnLi4vLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy91aS9tYWluJztcbmltcG9ydCB0eXBlIHsgRXhwb3J0TWVzc2FnZVJlc3BvbnNlLCBHZXRPcHRpb25zRGF0YVJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy9zZXR0aW5ncy90eXBlcyc7XG5pbXBvcnQgdHlwZSB7IENyZWF0ZUV2ZW50TGlzdGVuZXJSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvZXZlbnQnO1xuaW1wb3J0IHR5cGUgeyBGaWx0ZXJNZXRhZGF0YSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvYXBpL2ZpbHRlcnMvbWFpbic7XG5pbXBvcnQgdHlwZSB7IEdldEFsbG93bGlzdERvbWFpbnNSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvYWxsb3dsaXN0JztcbmltcG9ydCB0eXBlIHsgR2V0VXNlclJ1bGVzRWRpdG9yRGF0YVJlc3BvbnNlLCBHZXRVc2VyUnVsZXNSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvdXNlcnJ1bGVzJztcbmltcG9ydCB0eXBlIHsgR2V0Q3VzdG9tRmlsdGVySW5mb1Jlc3VsdCB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvYXBpJztcblxuZXhwb3J0IGNvbnN0IEFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSA9ICdhcHAnO1xuXG5leHBvcnQgdHlwZSBNZXNzYWdlQ29tbW9uUHJvcHMgPSB7XG4gICAgaGFuZGxlck5hbWU6IHR5cGVvZiBBUFBfTUVTU0FHRV9IQU5ETEVSX05BTUU7XG59O1xuXG4vKipcbiAqIE1lc3NhZ2UgdHlwZXMgdXNlZCBmb3IgbWVzc2FnZSBwYXNzaW5nIGJldHdlZW4gZXh0ZW5zaW9uIGNvbnRleHRzXG4gKiAocG9wdXAsIGZpbHRlcmluZyBsb2csIGNvbnRlbnQgc2NyaXB0cywgYmFja2dyb3VuZClcbiAqL1xuZXhwb3J0IGVudW0gTWVzc2FnZVR5cGUge1xuICAgIENyZWF0ZUV2ZW50TGlzdGVuZXIgPSAnY3JlYXRlRXZlbnRMaXN0ZW5lcicsXG4gICAgUmVtb3ZlTGlzdGVuZXIgPSAncmVtb3ZlTGlzdGVuZXInLFxuICAgIE9wZW5FeHRlbnNpb25TdG9yZSA9ICdvcGVuRXh0ZW5zaW9uU3RvcmUnLFxuICAgIEFkZEFuZEVuYWJsZUZpbHRlciA9ICdhZGRBbmRFbmFibGVGaWx0ZXInLFxuICAgIEFwcGx5U2V0dGluZ3NKc29uID0gJ2FwcGx5U2V0dGluZ3NKc29uJyxcbiAgICBPcGVuRmlsdGVyaW5nTG9nID0gJ29wZW5GaWx0ZXJpbmdMb2cnLFxuICAgIE9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzID0gJ29wZW5GdWxsc2NyZWVuVXNlclJ1bGVzJyxcbiAgICBVcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWUgPSAndXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lJyxcbiAgICBSZXNldEJsb2NrZWRBZHNDb3VudCA9ICdyZXNldEJsb2NrZWRBZHNDb3VudCcsXG4gICAgUmVzZXRTZXR0aW5ncyA9ICdyZXNldFNldHRpbmdzJyxcbiAgICBHZXRVc2VyUnVsZXMgPSAnZ2V0VXNlclJ1bGVzJyxcbiAgICBTYXZlVXNlclJ1bGVzID0gJ3NhdmVVc2VyUnVsZXMnLFxuICAgIEdldEFsbG93bGlzdERvbWFpbnMgPSAnZ2V0QWxsb3dsaXN0RG9tYWlucycsXG4gICAgU2F2ZUFsbG93bGlzdERvbWFpbnMgPSAnc2F2ZUFsbG93bGlzdERvbWFpbnMnLFxuICAgIENoZWNrRmlsdGVyc1VwZGF0ZSA9ICdjaGVja0ZpbHRlcnNVcGRhdGUnLFxuICAgIERpc2FibGVGaWx0ZXJzR3JvdXAgPSAnZGlzYWJsZUZpbHRlcnNHcm91cCcsXG4gICAgRGlzYWJsZUZpbHRlciA9ICdkaXNhYmxlRmlsdGVyJyxcbiAgICBMb2FkQ3VzdG9tRmlsdGVySW5mbyA9ICdsb2FkQ3VzdG9tRmlsdGVySW5mbycsXG4gICAgU3Vic2NyaWJlVG9DdXN0b21GaWx0ZXIgPSAnc3Vic2NyaWJlVG9DdXN0b21GaWx0ZXInLFxuICAgIFJlbW92ZUFudGlCYW5uZXJGaWx0ZXIgPSAncmVtb3ZlQW50aUJhbm5lckZpbHRlcicsXG4gICAgR2V0SXNFbmdpbmVTdGFydGVkID0gJ2dldElzRW5naW5lU3RhcnRlZCcsXG4gICAgR2V0VGFiSW5mb0ZvclBvcHVwID0gJ2dldFRhYkluZm9Gb3JQb3B1cCcsXG4gICAgQ2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWQgPSAnY2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWQnLFxuICAgIE9wZW5SdWxlc0xpbWl0c1RhYiA9ICdvcGVuUnVsZXNMaW1pdHNUYWInLFxuICAgIE9wZW5TZXR0aW5nc1RhYiA9ICdvcGVuU2V0dGluZ3NUYWInLFxuICAgIE9wZW5Bc3Npc3RhbnQgPSAnb3BlbkFzc2lzdGFudCcsXG4gICAgT3BlbkFidXNlVGFiID0gJ29wZW5BYnVzZVRhYicsXG4gICAgT3BlblNpdGVSZXBvcnRUYWIgPSAnb3BlblNpdGVSZXBvcnRUYWInLFxuICAgIE9wZW5Db21wYXJlUGFnZSA9ICdvcGVuQ29tcGFyZVBhZ2UnLFxuICAgIFJlc2V0VXNlclJ1bGVzRm9yUGFnZSA9ICdyZXNldFVzZXJSdWxlc0ZvclBhZ2UnLFxuICAgIFJlbW92ZUFsbG93bGlzdERvbWFpbiA9ICdyZW1vdmVBbGxvd2xpc3REb21haW4nLFxuICAgIEFkZEFsbG93bGlzdERvbWFpbiA9ICdhZGRBbGxvd2xpc3REb21haW4nLFxuICAgIE9uT3BlbkZpbHRlcmluZ0xvZ1BhZ2UgPSAnb25PcGVuRmlsdGVyaW5nTG9nUGFnZScsXG4gICAgR2V0RmlsdGVyaW5nTG9nRGF0YSA9ICdnZXRGaWx0ZXJpbmdMb2dEYXRhJyxcbiAgICBJbml0aWFsaXplRnJhbWVTY3JpcHQgPSAnaW5pdGlhbGl6ZUZyYW1lU2NyaXB0JyxcbiAgICBPbkNsb3NlRmlsdGVyaW5nTG9nUGFnZSA9ICdvbkNsb3NlRmlsdGVyaW5nTG9nUGFnZScsXG4gICAgR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQgPSAnZ2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQnLFxuICAgIFN5bmNocm9uaXplT3BlblRhYnMgPSAnc3luY2hyb25pemVPcGVuVGFicycsXG4gICAgQ2xlYXJFdmVudHNCeVRhYklkID0gJ2NsZWFyRXZlbnRzQnlUYWJJZCcsXG4gICAgUmVmcmVzaFBhZ2UgPSAncmVmcmVzaFBhZ2UnLFxuICAgIEFkZFVzZXJSdWxlID0gJ2FkZFVzZXJSdWxlJyxcbiAgICBSZW1vdmVVc2VyUnVsZSA9ICdyZW1vdmVVc2VyUnVsZScsXG4gICAgRW5hYmxlRmlsdGVyc0dyb3VwID0gJ2VuYWJsZUZpbHRlcnNHcm91cCcsXG4gICAgTm90aWZ5TGlzdGVuZXJzID0gJ25vdGlmeUxpc3RlbmVycycsXG4gICAgQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbiA9ICdhZGRMb25nTGl2ZWRDb25uZWN0aW9uJyxcbiAgICBHZXRPcHRpb25zRGF0YSA9ICdnZXRPcHRpb25zRGF0YScsXG4gICAgQ2hhbmdlVXNlclNldHRpbmdzID0gJ2NoYW5nZVVzZXJTZXR0aW5nJyxcbiAgICBDaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSA9ICdjaGVja1JlcXVlc3RGaWx0ZXJSZWFkeScsXG4gICAgT3BlblRoYW5reW91UGFnZSA9ICdvcGVuVGhhbmtZb3VQYWdlJyxcbiAgICBPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCA9ICdvcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCcsXG4gICAgR2V0U2VsZWN0b3JzQW5kU2NyaXB0cyA9ICdnZXRTZWxlY3RvcnNBbmRTY3JpcHRzJyxcbiAgICBDaGVja1BhZ2VTY3JpcHRXcmFwcGVyUmVxdWVzdCA9ICdjaGVja1BhZ2VTY3JpcHRXcmFwcGVyUmVxdWVzdCcsXG4gICAgUHJvY2Vzc1Nob3VsZENvbGxhcHNlID0gJ3Byb2Nlc3NTaG91bGRDb2xsYXBzZScsXG4gICAgUHJvY2Vzc1Nob3VsZENvbGxhcHNlTWFueSA9ICdwcm9jZXNzU2hvdWxkQ29sbGFwc2VNYW55JyxcbiAgICBBZGRGaWx0ZXJpbmdTdWJzY3JpcHRpb24gPSAnYWRkRmlsdGVyU3Vic2NyaXB0aW9uJyxcbiAgICBTZXROb3RpZmljYXRpb25WaWV3ZWQgPSAnc2V0Tm90aWZpY2F0aW9uVmlld2VkJyxcbiAgICBTYXZlQ3NzSGl0c1N0YXRzID0gJ3NhdmVDc3NIaXRTdGF0cycsXG4gICAgR2V0Q29va2llUnVsZXMgPSAnZ2V0Q29va2llUnVsZXMnLFxuICAgIFNhdmVDb29raWVMb2dFdmVudCA9ICdzYXZlQ29va2llUnVsZUV2ZW50JyxcbiAgICBMb2FkU2V0dGluZ3NKc29uID0gJ2xvYWRTZXR0aW5nc0pzb24nLFxuICAgIEFkZFVybFRvVHJ1c3RlZCA9ICdhZGRVcmxUb1RydXN0ZWQnLFxuICAgIFNldFByZXNlcnZlTG9nU3RhdGUgPSAnc2V0UHJlc2VydmVMb2dTdGF0ZScsXG4gICAgR2V0VXNlclJ1bGVzRWRpdG9yRGF0YSA9ICdnZXRVc2VyUnVsZXNFZGl0b3JEYXRhJyxcbiAgICBHZXRFZGl0b3JTdG9yYWdlQ29udGVudCA9ICdnZXRFZGl0b3JTdG9yYWdlQ29udGVudCcsXG4gICAgU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQgPSAnc2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQnLFxuICAgIFNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlID0gJ3NldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlJyxcbiAgICBBcHBJbml0aWFsaXplZCA9ICdhcHBJbml0aWFsaXplZCcsXG4gICAgVXBkYXRlVG90YWxCbG9ja2VkID0gJ3VwZGF0ZVRvdGFsQmxvY2tlZCcsXG4gICAgU2NyaXB0bGV0Q2xvc2VXaW5kb3cgPSAnc2NyaXB0bGV0Q2xvc2VXaW5kb3cnLFxuICAgIFNob3dSdWxlTGltaXRzQWxlcnQgPSAnc2hvd1J1bGVMaW1pdHNBbGVydCcsXG4gICAgU2hvd0FsZXJ0UG9wdXAgPSAnc2hvd0FsZXJ0UG9wdXAnLFxuICAgIFNob3dWZXJzaW9uVXBkYXRlZFBvcHVwID0gJ3Nob3dWZXJzaW9uVXBkYXRlZFBvcHVwJyxcbiAgICBVcGRhdGVMaXN0ZW5lcnMgPSAndXBkYXRlTGlzdGVuZXJzJyxcbiAgICBTZXRDb25zZW50ZWRGaWx0ZXJzID0gJ3NldENvbnNlbnRlZEZpbHRlcnMnLFxuICAgIEdldElzQ29uc2VudGVkRmlsdGVyID0gJ2dldElzQ29uc2VudGVkRmlsdGVyJyxcbiAgICBHZXRSdWxlc0xpbWl0c0NvdW50ZXJzTXYzID0gJ2dldFJ1bGVzTGltaXRzQ291bnRlcnNNdjMnLFxuICAgIENhbkVuYWJsZVN0YXRpY0ZpbHRlck12MyA9ICdjYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjMnLFxuICAgIENhbkVuYWJsZVN0YXRpY0dyb3VwTXYzID0gJ2NhbkVuYWJsZVN0YXRpY0dyb3VwTXYzJyxcbiAgICBDbGVhclJ1bGVzTGltaXRzV2FybmluZ012MyA9ICdjbGVhclJ1bGVzTGltaXRzV2FybmluZ012MycsXG4gICAgUmVzdG9yZUZpbHRlcnNNdjMgPSAncmVzdG9yZUZpbHRlcnNNdjMnLFxuICAgIEN1cnJlbnRMaW1pdHNNdjMgPSAnY3VycmVudExpbWl0c012MycsXG59XG5cbmV4cG9ydCB0eXBlIEFwcGx5U2V0dGluZ3NKc29uTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5BcHBseVNldHRpbmdzSnNvbixcbiAgICBkYXRhOiB7XG4gICAgICAgIGpzb246IHN0cmluZyxcbiAgICB9LFxufTtcblxuZXhwb3J0IHR5cGUgTG9hZFNldHRpbmdzSnNvbk1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuTG9hZFNldHRpbmdzSnNvbixcbiAgICBkYXRhOiB7XG4gICAgICAgIGpzb246IHN0cmluZyxcbiAgICB9LFxufTtcblxuZXhwb3J0IHR5cGUgQWRkRmlsdGVyaW5nU3Vic2NyaXB0aW9uTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5BZGRGaWx0ZXJpbmdTdWJzY3JpcHRpb24sXG4gICAgZGF0YToge1xuICAgICAgICB1cmw6IHN0cmluZyxcbiAgICAgICAgdGl0bGU/OiBzdHJpbmcsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgQ3JlYXRlRXZlbnRMaXN0ZW5lck1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ3JlYXRlRXZlbnRMaXN0ZW5lcixcbiAgICBkYXRhOiB7XG4gICAgICAgIGV2ZW50czogTm90aWZpZXJUeXBlW11cbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBSZW1vdmVMaXN0ZW5lck1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuUmVtb3ZlTGlzdGVuZXIsXG4gICAgZGF0YToge1xuICAgICAgICBsaXN0ZW5lcklkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgR2V0SXNFbmdpbmVTdGFydGVkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5HZXRJc0VuZ2luZVN0YXJ0ZWQsXG59O1xuXG5leHBvcnQgdHlwZSBHZXRUYWJJbmZvRm9yUG9wdXBNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldFRhYkluZm9Gb3JQb3B1cDtcbiAgICBkYXRhOiB7XG4gICAgICAgIHRhYklkOiBudW1iZXI7XG4gICAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIENoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5DaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZDtcbiAgICBkYXRhOiB7XG4gICAgICAgIHN0YXRlOiBib29sZWFuO1xuICAgIH07XG59O1xuXG5leHBvcnQgdHlwZSBPcGVuUnVsZXNMaW1pdHNUYWJNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk9wZW5SdWxlc0xpbWl0c1RhYjtcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5TZXR0aW5nc1RhYk1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlblNldHRpbmdzVGFiO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkFzc2lzdGFudE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlbkFzc2lzdGFudDtcbn07XG5cbmV4cG9ydCB0eXBlIFVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lO1xuICAgIGRhdGE6IHtcbiAgICAgICAgdGhlbWU6IEFwcGVhcmFuY2VUaGVtZTtcbiAgICB9O1xufTtcblxuZXhwb3J0IHR5cGUgQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbk1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbixcbiAgICBkYXRhOiB7XG4gICAgICAgIGV2ZW50czogTm90aWZpZXJUeXBlW11cbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBOb3RpZnlMaXN0ZW5lcnNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk5vdGlmeUxpc3RlbmVycyxcbiAgICBkYXRhOiBhbnk7XG59O1xuXG5leHBvcnQgdHlwZSBVcGRhdGVMaXN0ZW5lcnNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlVwZGF0ZUxpc3RlbmVycyxcbn07XG5cbmV4cG9ydCB0eXBlIENoZWNrRmlsdGVyc1VwZGF0ZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ2hlY2tGaWx0ZXJzVXBkYXRlO1xufTtcblxuZXhwb3J0IHR5cGUgR2V0QWxsb3dsaXN0RG9tYWluc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0QWxsb3dsaXN0RG9tYWlucztcbn07XG5cbmV4cG9ydCB0eXBlIFJlc2V0QmxvY2tlZEFkc0NvdW50TWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5SZXNldEJsb2NrZWRBZHNDb3VudDtcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5Db21wYXJlUGFnZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlbkNvbXBhcmVQYWdlO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkV4dGVuc2lvblN0b3JlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuRXh0ZW5zaW9uU3RvcmU7XG59O1xuXG5leHBvcnQgdHlwZSBPcGVuRmlsdGVyaW5nTG9nTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuRmlsdGVyaW5nTG9nO1xufTtcblxuZXhwb3J0IHR5cGUgT3BlbkFidXNlVGFiTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuQWJ1c2VUYWI7XG4gICAgZGF0YToge1xuICAgICAgICB1cmw6IHN0cmluZztcbiAgICAgICAgZnJvbTogRm9yd2FyZEZyb207XG4gICAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5TaXRlUmVwb3J0VGFiTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuU2l0ZVJlcG9ydFRhYjtcbiAgICBkYXRhOiB7XG4gICAgICAgIHVybDogc3RyaW5nO1xuICAgICAgICBmcm9tOiBGb3J3YXJkRnJvbTtcbiAgICB9O1xufTtcblxuZXhwb3J0IHR5cGUgT3BlblRoYW5reW91UGFnZU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZTtcbn07XG5cbmV4cG9ydCB0eXBlIEdldE9wdGlvbnNEYXRhTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5HZXRPcHRpb25zRGF0YTtcbn07XG5cbmV4cG9ydCB0eXBlIENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZTxUIGV4dGVuZHMgU2V0dGluZ09wdGlvbiA9IFNldHRpbmdPcHRpb24+ID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkNoYW5nZVVzZXJTZXR0aW5ncztcbiAgICBkYXRhOiB7XG4gICAgICAgIGtleTogVCxcbiAgICAgICAgdmFsdWU6IFNldHRpbmdzW1RdXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgUmVzZXRTZXR0aW5nc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuUmVzZXRTZXR0aW5nc1xufTtcblxuZXhwb3J0IHR5cGUgQWRkQW5kRW5hYmxlRmlsdGVyTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5BZGRBbmRFbmFibGVGaWx0ZXJcbiAgICBkYXRhOiB7XG4gICAgICAgIGZpbHRlcklkOiBudW1iZXJcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBEaXNhYmxlRmlsdGVyTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5EaXNhYmxlRmlsdGVyXG4gICAgZGF0YToge1xuICAgICAgICBmaWx0ZXJJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFJlbW92ZUFudGlCYW5uZXJGaWx0ZXJNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlbW92ZUFudGlCYW5uZXJGaWx0ZXJcbiAgICBkYXRhOiB7XG4gICAgICAgIGZpbHRlcklkOiBudW1iZXJcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBTYXZlQWxsb3dsaXN0RG9tYWluc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU2F2ZUFsbG93bGlzdERvbWFpbnNcbiAgICBkYXRhOiB7XG4gICAgICAgIHZhbHVlOiBzdHJpbmcsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgU2F2ZVVzZXJSdWxlc01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU2F2ZVVzZXJSdWxlc1xuICAgIGRhdGE6IHtcbiAgICAgICAgdmFsdWU6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBHZXRVc2VyUnVsZXNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc1xufTtcblxuZXhwb3J0IHR5cGUgR2V0VXNlclJ1bGVzRWRpdG9yRGF0YU1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0VXNlclJ1bGVzRWRpdG9yRGF0YVxufTtcblxuZXhwb3J0IHR5cGUgQWRkVXNlclJ1bGVNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkFkZFVzZXJSdWxlXG4gICAgZGF0YToge1xuICAgICAgICBydWxlVGV4dDogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFJlbW92ZVVzZXJSdWxlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5SZW1vdmVVc2VyUnVsZVxuICAgIGRhdGE6IHtcbiAgICAgICAgcnVsZVRleHQ6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBSZXNldFVzZXJSdWxlc0ZvclBhZ2VNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlc2V0VXNlclJ1bGVzRm9yUGFnZVxuICAgIGRhdGE6IHtcbiAgICAgICAgdXJsOiBzdHJpbmcsXG4gICAgICAgIHRhYklkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgR2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldEVkaXRvclN0b3JhZ2VDb250ZW50XG59O1xuXG5leHBvcnQgdHlwZSBTZXRFZGl0b3JTdG9yYWdlQ29udGVudE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRcbiAgICBkYXRhOiB7XG4gICAgICAgIGNvbnRlbnQ6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBBZGRBbGxvd2xpc3REb21haW5NZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkFkZEFsbG93bGlzdERvbWFpblxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBSZW1vdmVBbGxvd2xpc3REb21haW5NZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlbW92ZUFsbG93bGlzdERvbWFpblxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICAgICAgdGFiUmVmcmVzaDogYm9vbGVhbixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBMb2FkQ3VzdG9tRmlsdGVySW5mb01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuTG9hZEN1c3RvbUZpbHRlckluZm9cbiAgICBkYXRhOiB7XG4gICAgICAgIHVybDogc3RyaW5nLFxuICAgICAgICB0aXRsZT86IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBDdXN0b21GaWx0ZXJTdWJzY3JpcHRpb25EYXRhID0ge1xuICAgIGN1c3RvbVVybDogc3RyaW5nLFxuICAgIG5hbWU6IHN0cmluZyxcbiAgICB0cnVzdGVkOiBib29sZWFuLFxufTtcblxuZXhwb3J0IHR5cGUgU3Vic2NyaWJlVG9DdXN0b21GaWx0ZXJNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlN1YnNjcmliZVRvQ3VzdG9tRmlsdGVyXG4gICAgZGF0YToge1xuICAgICAgICBmaWx0ZXI6IEN1c3RvbUZpbHRlclN1YnNjcmlwdGlvbkRhdGFcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBBcHBJbml0aWFsaXplZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQXBwSW5pdGlhbGl6ZWRcbn07XG5cbmV4cG9ydCB0eXBlIFVwZGF0ZVRvdGFsQmxvY2tlZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuVXBkYXRlVG90YWxCbG9ja2VkXG4gICAgZGF0YToge1xuICAgICAgICB0YWJJZDogbnVtYmVyLFxuICAgICAgICB0b3RhbEJsb2NrZWQ6IG51bWJlcixcbiAgICAgICAgdG90YWxCbG9ja2VkVGFiOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgQ2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHlNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkNoZWNrUmVxdWVzdEZpbHRlclJlYWR5XG59O1xuXG5leHBvcnQgdHlwZSBHZXRGaWx0ZXJpbmdMb2dEYXRhTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5HZXRGaWx0ZXJpbmdMb2dEYXRhLFxufTtcblxuZXhwb3J0IHR5cGUgU3luY2hyb25pemVPcGVuVGFic01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuU3luY2hyb25pemVPcGVuVGFicyxcbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5GaWx0ZXJpbmdMb2dQYWdlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5Pbk9wZW5GaWx0ZXJpbmdMb2dQYWdlXG59O1xuXG5leHBvcnQgdHlwZSBDbG9zZUZpbHRlcmluZ0xvZ1BhZ2VNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLk9uQ2xvc2VGaWx0ZXJpbmdMb2dQYWdlXG59O1xuXG5leHBvcnQgdHlwZSBDbGVhckV2ZW50c0J5VGFiSWRNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkNsZWFyRXZlbnRzQnlUYWJJZFxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICAgICAgaWdub3JlUHJlc2VydmVMb2c/OiBib29sZWFuLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFNldFByZXNlcnZlTG9nU3RhdGVNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlNldFByZXNlcnZlTG9nU3RhdGVcbiAgICBkYXRhOiB7XG4gICAgICAgIHN0YXRlOiBib29sZWFuLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZSxcbiAgICBkYXRhOiB7XG4gICAgICAgIHdpbmRvd1N0YXRlOiBXaW5kb3dzLkNyZWF0ZUNyZWF0ZURhdGFUeXBlXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgUmVmcmVzaFBhZ2VNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlLFxuICAgIGRhdGE6IHtcbiAgICAgICAgdGFiSWQ6IG51bWJlcixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBHZXRGaWx0ZXJpbmdJbmZvQnlUYWJJZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQsXG4gICAgZGF0YToge1xuICAgICAgICB0YWJJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIEVuYWJsZUZpbHRlcnNHcm91cE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuRW5hYmxlRmlsdGVyc0dyb3VwLFxuICAgIGRhdGE6IHtcbiAgICAgICAgZ3JvdXBJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIERpc2FibGVGaWx0ZXJzR3JvdXBNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXJzR3JvdXAsXG4gICAgZGF0YToge1xuICAgICAgICBncm91cElkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgSW5pdGlhbGl6ZUZyYW1lU2NyaXB0TWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5Jbml0aWFsaXplRnJhbWVTY3JpcHQsXG59O1xuXG5leHBvcnQgdHlwZSBTZXRDb25zZW50ZWRGaWx0ZXJzTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TZXRDb25zZW50ZWRGaWx0ZXJzLFxuICAgIGRhdGE6IHtcbiAgICAgICAgZmlsdGVySWRzOiBudW1iZXJbXSxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBHZXRJc0NvbnNlbnRlZEZpbHRlck1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuR2V0SXNDb25zZW50ZWRGaWx0ZXIsXG4gICAgZGF0YToge1xuICAgICAgICBmaWx0ZXJJZDogbnVtYmVyLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIE9wZW5TYWZlYnJvd3NpbmdUcnVzdGVkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5PcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCxcbiAgICBkYXRhOiB7XG4gICAgICAgIHVybDogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIEFkZFVybFRvVHJ1c3RlZE1lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQWRkVXJsVG9UcnVzdGVkLFxuICAgIGRhdGE6IHtcbiAgICAgICAgdXJsOiBzdHJpbmcsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgU2V0Tm90aWZpY2F0aW9uVmlld2VkTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TZXROb3RpZmljYXRpb25WaWV3ZWQsXG4gICAgZGF0YToge1xuICAgICAgICB3aXRoRGVsYXk6IGJvb2xlYW4sXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgU2NyaXB0bGV0Q2xvc2VXaW5kb3dNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlNjcmlwdGxldENsb3NlV2luZG93LFxufTtcblxuZXhwb3J0IHR5cGUgU2hvd0FsZXJ0UG9wdXBNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLlNob3dBbGVydFBvcHVwLFxuICAgIGRhdGE6IHtcbiAgICAgICAgaXNBZGd1YXJkVGFiOiBib29sZWFuLFxuICAgICAgICB0aXRsZTogc3RyaW5nLFxuICAgICAgICB0ZXh0OiBzdHJpbmcgfCBzdHJpbmdbXSxcbiAgICAgICAgYWxlcnRTdHlsZXM6IHN0cmluZyxcbiAgICAgICAgYWxlcnRDb250YWluZXJTdHlsZXM6IHN0cmluZyxcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBTaG93UnVsZUxpbWl0c0FsZXJ0TWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TaG93UnVsZUxpbWl0c0FsZXJ0LFxuICAgIGRhdGE6IHtcbiAgICAgICAgaXNBZGd1YXJkVGFiOiBib29sZWFuLFxuICAgICAgICBtYWluVGV4dDogc3RyaW5nLFxuICAgICAgICBsaW5rVGV4dDogc3RyaW5nLFxuICAgICAgICBhbGVydFN0eWxlczogc3RyaW5nLFxuICAgICAgICBhbGVydENvbnRhaW5lclN0eWxlczogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIFNob3dWZXJzaW9uVXBkYXRlZFBvcHVwTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5TaG93VmVyc2lvblVwZGF0ZWRQb3B1cCxcbiAgICBkYXRhOiB7XG4gICAgICAgIGlzQWRndWFyZFRhYjogYm9vbGVhbixcbiAgICAgICAgdGl0bGU6IHN0cmluZyxcbiAgICAgICAgZGVzY3JpcHRpb246IHN0cmluZyxcbiAgICAgICAgY2hhbmdlbG9nSHJlZjogc3RyaW5nLFxuICAgICAgICBjaGFuZ2Vsb2dUZXh0OiBzdHJpbmcsXG4gICAgICAgIHNob3dQcm9tb05vdGlmaWNhdGlvbjogYm9vbGVhbixcbiAgICAgICAgb2ZmZXI6IHN0cmluZyxcbiAgICAgICAgb2ZmZXJEZXNjOiBzdHJpbmcsXG4gICAgICAgIG9mZmVyQnV0dG9uVGV4dDogc3RyaW5nLFxuICAgICAgICBvZmZlckJ1dHRvbkhyZWY6IHN0cmluZyxcbiAgICAgICAgb2ZmZXJCZ0ltYWdlOiBzdHJpbmcsXG4gICAgICAgIGRpc2FibGVOb3RpZmljYXRpb25UZXh0OiBzdHJpbmcsXG4gICAgICAgIGFsZXJ0U3R5bGVzOiBzdHJpbmcsXG4gICAgICAgIGlmcmFtZVN0eWxlczogc3RyaW5nLFxuICAgIH1cbn07XG5cbmV4cG9ydCB0eXBlIENhbkVuYWJsZVN0YXRpY0ZpbHRlck12M01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ2FuRW5hYmxlU3RhdGljRmlsdGVyTXYzLFxuICAgIGRhdGE6IHtcbiAgICAgICAgZmlsdGVySWQ6IG51bWJlcixcbiAgICB9XG59O1xuXG5leHBvcnQgdHlwZSBDYW5FbmFibGVTdGF0aWNHcm91cE12M01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ2FuRW5hYmxlU3RhdGljR3JvdXBNdjMsXG4gICAgZGF0YToge1xuICAgICAgICBncm91cElkOiBudW1iZXIsXG4gICAgfVxufTtcblxuZXhwb3J0IHR5cGUgQ3VycmVudExpbWl0c012M01lc3NhZ2UgPSB7XG4gICAgdHlwZTogTWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012Mztcbn07XG5cbmV4cG9ydCB0eXBlIFJlc3RvcmVGaWx0ZXJzTXYzTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5SZXN0b3JlRmlsdGVyc012Mztcbn07XG5cbmV4cG9ydCB0eXBlIENsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzTWVzc2FnZSA9IHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZS5DbGVhclJ1bGVzTGltaXRzV2FybmluZ012Mztcbn07XG5cbmV4cG9ydCB0eXBlIEdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjNNZXNzYWdlID0ge1xuICAgIHR5cGU6IE1lc3NhZ2VUeXBlLkdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjM7XG59O1xuXG4vLyBVbmlmaWVkIG1lc3NhZ2UgbWFwIHRoYXQgaW5jbHVkZXMgYm90aCBtZXNzYWdlIHN0cnVjdHVyZSBhbmQgcmVzcG9uc2UgdHlwZXNcbmV4cG9ydCB0eXBlIE1lc3NhZ2VNYXAgPSB7XG4gICAgW01lc3NhZ2VUeXBlLkNyZWF0ZUV2ZW50TGlzdGVuZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IENyZWF0ZUV2ZW50TGlzdGVuZXJNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogQ3JlYXRlRXZlbnRMaXN0ZW5lclJlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbl06IHtcbiAgICAgICAgbWVzc2FnZTogQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQXBwbHlTZXR0aW5nc0pzb25dOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFwcGx5U2V0dGluZ3NKc29uTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5Mb2FkU2V0dGluZ3NKc29uXToge1xuICAgICAgICBtZXNzYWdlOiBMb2FkU2V0dGluZ3NKc29uTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEV4cG9ydE1lc3NhZ2VSZXNwb25zZTtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkFkZEZpbHRlcmluZ1N1YnNjcmlwdGlvbl06IHtcbiAgICAgICAgbWVzc2FnZTogQWRkRmlsdGVyaW5nU3Vic2NyaXB0aW9uTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5HZXRJc0VuZ2luZVN0YXJ0ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldElzRW5naW5lU3RhcnRlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBib29sZWFuO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0VGFiSW5mb0ZvclBvcHVwXToge1xuICAgICAgICBtZXNzYWdlOiBHZXRUYWJJbmZvRm9yUG9wdXBNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogR2V0VGFiSW5mb0ZvclBvcHVwUmVzcG9uc2UgfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5DaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZF06IHtcbiAgICAgICAgbWVzc2FnZTogQ2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLk9wZW5SdWxlc0xpbWl0c1RhYl06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlblJ1bGVzTGltaXRzVGFiTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5PcGVuU2V0dGluZ3NUYWJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IE9wZW5TZXR0aW5nc1RhYk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkFzc2lzdGFudF06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkFzc2lzdGFudE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lXToge1xuICAgICAgICBtZXNzYWdlOiBVcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlN5bmNocm9uaXplT3BlblRhYnNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFN5bmNocm9uaXplT3BlblRhYnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogRmlsdGVyaW5nTG9nVGFiSW5mb1tdO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2hlY2tGaWx0ZXJzVXBkYXRlXToge1xuICAgICAgICBtZXNzYWdlOiBDaGVja0ZpbHRlcnNVcGRhdGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogRmlsdGVyTWV0YWRhdGFbXSB8IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldEFsbG93bGlzdERvbWFpbnNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldEFsbG93bGlzdERvbWFpbnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogR2V0QWxsb3dsaXN0RG9tYWluc1Jlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkV4dGVuc2lvblN0b3JlXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuRXh0ZW5zaW9uU3RvcmVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLk9wZW5Db21wYXJlUGFnZV06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkNvbXBhcmVQYWdlTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5PcGVuRnVsbHNjcmVlblVzZXJSdWxlc106IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlc2V0QmxvY2tlZEFkc0NvdW50XToge1xuICAgICAgICBtZXNzYWdlOiBSZXNldEJsb2NrZWRBZHNDb3VudE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkZpbHRlcmluZ0xvZ106IHtcbiAgICAgICAgbWVzc2FnZTogT3BlbkZpbHRlcmluZ0xvZ01lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlbkFidXNlVGFiXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuQWJ1c2VUYWJNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLk9wZW5TaXRlUmVwb3J0VGFiXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuU2l0ZVJlcG9ydFRhYk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZV06IHtcbiAgICAgICAgbWVzc2FnZTogT3BlblRoYW5reW91UGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0T3B0aW9uc0RhdGFdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldE9wdGlvbnNEYXRhTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEdldE9wdGlvbnNEYXRhUmVzcG9uc2U7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5DaGFuZ2VVc2VyU2V0dGluZ3NdOiB7XG4gICAgICAgIG1lc3NhZ2U6IENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5SZXNldFNldHRpbmdzXToge1xuICAgICAgICBtZXNzYWdlOiBSZXNldFNldHRpbmdzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRBbmRFbmFibGVGaWx0ZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFkZEFuZEVuYWJsZUZpbHRlck1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5EaXNhYmxlRmlsdGVyXToge1xuICAgICAgICBtZXNzYWdlOiBEaXNhYmxlRmlsdGVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5SZW1vdmVBbnRpQmFubmVyRmlsdGVyXToge1xuICAgICAgICBtZXNzYWdlOiBSZW1vdmVBbnRpQmFubmVyRmlsdGVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TYXZlQWxsb3dsaXN0RG9tYWluc106IHtcbiAgICAgICAgbWVzc2FnZTogU2F2ZUFsbG93bGlzdERvbWFpbnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNhdmVVc2VyUnVsZXNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNhdmVVc2VyUnVsZXNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc106IHtcbiAgICAgICAgbWVzc2FnZTogR2V0VXNlclJ1bGVzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEdldFVzZXJSdWxlc1Jlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0VXNlclJ1bGVzRWRpdG9yRGF0YV06IHtcbiAgICAgICAgbWVzc2FnZTogR2V0VXNlclJ1bGVzRWRpdG9yRGF0YU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBHZXRVc2VyUnVsZXNFZGl0b3JEYXRhUmVzcG9uc2U7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRVc2VyUnVsZV06IHtcbiAgICAgICAgbWVzc2FnZTogQWRkVXNlclJ1bGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlbW92ZVVzZXJSdWxlXToge1xuICAgICAgICBtZXNzYWdlOiBSZW1vdmVVc2VyUnVsZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuUmVzZXRVc2VyUnVsZXNGb3JQYWdlXToge1xuICAgICAgICBtZXNzYWdlOiBSZXNldFVzZXJSdWxlc0ZvclBhZ2VNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldEVkaXRvclN0b3JhZ2VDb250ZW50XToge1xuICAgICAgICBtZXNzYWdlOiBHZXRFZGl0b3JTdG9yYWdlQ29udGVudE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXRFZGl0b3JTdG9yYWdlQ29udGVudF06IHtcbiAgICAgICAgbWVzc2FnZTogU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlbW92ZUFsbG93bGlzdERvbWFpbl06IHtcbiAgICAgICAgbWVzc2FnZTogUmVtb3ZlQWxsb3dsaXN0RG9tYWluTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRBbGxvd2xpc3REb21haW5dOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFkZEFsbG93bGlzdERvbWFpbk1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuTG9hZEN1c3RvbUZpbHRlckluZm9dOiB7XG4gICAgICAgIG1lc3NhZ2U6IExvYWRDdXN0b21GaWx0ZXJJbmZvTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEdldEN1c3RvbUZpbHRlckluZm9SZXN1bHQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TdWJzY3JpYmVUb0N1c3RvbUZpbHRlcl06IHtcbiAgICAgICAgbWVzc2FnZTogU3Vic2NyaWJlVG9DdXN0b21GaWx0ZXJNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogQ3VzdG9tRmlsdGVyTWV0YWRhdGE7XG4gICAgfVxuICAgIC8vIFRoaXMgbWVzc2FnZSBpcyBzZW50IGZyb20gYmFja2dyb3VuZCBhbmQgaGFuZGxlZCBvbiBVSSBzaWRlLlxuICAgIFtNZXNzYWdlVHlwZS5BcHBJbml0aWFsaXplZF06IHtcbiAgICAgICAgbWVzc2FnZTogQXBwSW5pdGlhbGl6ZWRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogbmV2ZXI7XG4gICAgfVxuICAgIC8vIFRoaXMgbWVzc2FnZSBpcyBzZW50IGZyb20gYmFja2dyb3VuZCBhbmQgaGFuZGxlZCBvbiBVSSBzaWRlLlxuICAgIFtNZXNzYWdlVHlwZS5VcGRhdGVUb3RhbEJsb2NrZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFVwZGF0ZVRvdGFsQmxvY2tlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBuZXZlcjtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0xvZ0RhdGFdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldEZpbHRlcmluZ0xvZ0RhdGFNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogR2V0RmlsdGVyaW5nTG9nRGF0YVJlc3BvbnNlO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHldOiB7XG4gICAgICAgIG1lc3NhZ2U6IENoZWNrUmVxdWVzdEZpbHRlclJlYWR5TWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5Pbk9wZW5GaWx0ZXJpbmdMb2dQYWdlXToge1xuICAgICAgICBtZXNzYWdlOiBPcGVuRmlsdGVyaW5nTG9nUGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT25DbG9zZUZpbHRlcmluZ0xvZ1BhZ2VdOiB7XG4gICAgICAgIG1lc3NhZ2U6IENsb3NlRmlsdGVyaW5nTG9nUGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2xlYXJFdmVudHNCeVRhYklkXToge1xuICAgICAgICBtZXNzYWdlOiBDbGVhckV2ZW50c0J5VGFiSWRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNldFByZXNlcnZlTG9nU3RhdGVdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNldFByZXNlcnZlTG9nU3RhdGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlXToge1xuICAgICAgICBtZXNzYWdlOiBSZWZyZXNoUGFnZU1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldEZpbHRlcmluZ0luZm9CeVRhYklkTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IEZpbHRlcmluZ0xvZ1RhYkluZm8gfCB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZV06IHtcbiAgICAgICAgbWVzc2FnZTogU2V0RmlsdGVyaW5nTG9nV2luZG93U3RhdGVNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkVuYWJsZUZpbHRlcnNHcm91cF06IHtcbiAgICAgICAgbWVzc2FnZTogRW5hYmxlRmlsdGVyc0dyb3VwTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IG51bWJlcltdIHwgdW5kZWZpbmVkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuRGlzYWJsZUZpbHRlcnNHcm91cF06IHtcbiAgICAgICAgbWVzc2FnZTogRGlzYWJsZUZpbHRlcnNHcm91cE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuT3BlblNhZmVicm93c2luZ1RydXN0ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IE9wZW5TYWZlYnJvd3NpbmdUcnVzdGVkTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXROb3RpZmljYXRpb25WaWV3ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNldE5vdGlmaWNhdGlvblZpZXdlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBQcm9taXNlPHZvaWQ+O1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuUmVtb3ZlTGlzdGVuZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFJlbW92ZUxpc3RlbmVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TY3JpcHRsZXRDbG9zZVdpbmRvd106IHtcbiAgICAgICAgbWVzc2FnZTogU2NyaXB0bGV0Q2xvc2VXaW5kb3dNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNob3dSdWxlTGltaXRzQWxlcnRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IFNob3dSdWxlTGltaXRzQWxlcnRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogYm9vbGVhbjtcbiAgICB9XG4gICAgLy8gVGhpcyBtZXNzYWdlIGlzIHNlbnQgZnJvbSBiYWNrZ3JvdW5kIGFuZCBoYW5kbGVkIG9uIFVJIHNpZGUuXG4gICAgW01lc3NhZ2VUeXBlLk5vdGlmeUxpc3RlbmVyc106IHtcbiAgICAgICAgbWVzc2FnZTogTm90aWZ5TGlzdGVuZXJzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IG5ldmVyO1xuICAgIH1cbiAgICAvLyBUaGlzIG1lc3NhZ2UgaXMgc2VudCBmcm9tIGJhY2tncm91bmQgYW5kIGhhbmRsZWQgb24gVUkgc2lkZS5cbiAgICBbTWVzc2FnZVR5cGUuVXBkYXRlTGlzdGVuZXJzXToge1xuICAgICAgICBtZXNzYWdlOiBVcGRhdGVMaXN0ZW5lcnNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogbmV2ZXI7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TaG93QWxlcnRQb3B1cF06IHtcbiAgICAgICAgbWVzc2FnZTogU2hvd0FsZXJ0UG9wdXBNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLlNob3dWZXJzaW9uVXBkYXRlZFBvcHVwXToge1xuICAgICAgICBtZXNzYWdlOiBTaG93VmVyc2lvblVwZGF0ZWRQb3B1cE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBib29sZWFuO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuR2V0SXNDb25zZW50ZWRGaWx0ZXJdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldElzQ29uc2VudGVkRmlsdGVyTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IGJvb2xlYW47XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5TZXRDb25zZW50ZWRGaWx0ZXJzXToge1xuICAgICAgICBtZXNzYWdlOiBTZXRDb25zZW50ZWRGaWx0ZXJzTWVzc2FnZTtcbiAgICAgICAgcmVzcG9uc2U6IHZvaWQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5BZGRVcmxUb1RydXN0ZWRdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEFkZFVybFRvVHJ1c3RlZE1lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012M106IHtcbiAgICAgICAgbWVzc2FnZTogQ3VycmVudExpbWl0c012M01lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiBNdjNMaW1pdHNDaGVja1Jlc3VsdDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjNdOiB7XG4gICAgICAgIG1lc3NhZ2U6IEdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogSVJ1bGVzTGltaXRzIHwgdW5kZWZpbmVkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuQ2FuRW5hYmxlU3RhdGljRmlsdGVyTXYzXToge1xuICAgICAgICBtZXNzYWdlOiBDYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogU3RhdGljTGltaXRzQ2hlY2tSZXN1bHQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5DYW5FbmFibGVTdGF0aWNHcm91cE12M106IHtcbiAgICAgICAgbWVzc2FnZTogQ2FuRW5hYmxlU3RhdGljR3JvdXBNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogU3RhdGljTGltaXRzQ2hlY2tSZXN1bHQ7XG4gICAgfVxuICAgIFtNZXNzYWdlVHlwZS5SZXN0b3JlRmlsdGVyc012M106IHtcbiAgICAgICAgbWVzc2FnZTogUmVzdG9yZUZpbHRlcnNNdjNNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogdm9pZDtcbiAgICB9XG4gICAgW01lc3NhZ2VUeXBlLkNsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzXToge1xuICAgICAgICBtZXNzYWdlOiBDbGVhclJ1bGVzTGltaXRzV2FybmluZ012M01lc3NhZ2U7XG4gICAgICAgIHJlc3BvbnNlOiB2b2lkO1xuICAgIH1cbiAgICBbTWVzc2FnZVR5cGUuSW5pdGlhbGl6ZUZyYW1lU2NyaXB0XToge1xuICAgICAgICBtZXNzYWdlOiBJbml0aWFsaXplRnJhbWVTY3JpcHRNZXNzYWdlO1xuICAgICAgICByZXNwb25zZTogUGFnZUluaXRBcHBEYXRhO1xuICAgIH1cbn07XG5cbi8qKlxuICogSGVscGVyIHR5cGUgdG8gY2hlY2sgaWYgYSBnaXZlbiB0eXBlIGlzIGEgdmFsaWQgbWVzc2FnZSB0eXBlLlxuICovXG5leHBvcnQgdHlwZSBWYWxpZE1lc3NhZ2VUeXBlcyA9IGtleW9mIE1lc3NhZ2VNYXA7XG5cbi8qKlxuICogQWxsIG1lc3NhZ2VzIHRoYXQgY2FuIGJlIHNlbnQuXG4gKi9cbmV4cG9ydCB0eXBlIE1lc3NhZ2UgPSBNZXNzYWdlTWFwW1ZhbGlkTWVzc2FnZVR5cGVzXVsnbWVzc2FnZSddICYgTWVzc2FnZUNvbW1vblByb3BzO1xuXG4vKipcbiAqIEhlbHBlciB0eXBlIHRvIGV4dHJhY3QgdGhlIG1lc3NhZ2UgdHlwZSBmb3IgYSBnaXZlbiBtZXNzYWdlLlxuICovXG5leHBvcnQgdHlwZSBFeHRyYWN0ZWRNZXNzYWdlPFQ+ID0gRXh0cmFjdDxNZXNzYWdlLCB7IHR5cGU6IFQgfT47XG5cbi8qKlxuICogSGVscGVyIHR5cGUgdG8gZXh0cmFjdCB0aGUgcmVzcG9uc2UgdHlwZSBmb3IgYSBnaXZlbiBtZXNzYWdlIHR5cGVcbiAqL1xuZXhwb3J0IHR5cGUgRXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+ID0gTWVzc2FnZU1hcFtUXVsncmVzcG9uc2UnXTtcblxuLyoqXG4gKiBIZWxwZXIgdHlwZSB0byBleHRyYWN0IHRoZSBtZXNzYWdlIHR5cGUgZm9yIGEgZ2l2ZW4gbWVzc2FnZSB3aXRob3V0IGhhbmRsZXJOYW1lLlxuICovXG5leHBvcnQgdHlwZSBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+ID0geyB0eXBlOiBUIH0gJiBPbWl0PEV4dHJhY3RlZE1lc3NhZ2U8VD4sICdoYW5kbGVyTmFtZSc+O1xuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2NvbnN0YW50cyc7XG5leHBvcnQgKiBmcm9tICcuL3NlbmQtbWVzc2FnZSc7XG5leHBvcnQgKiBmcm9tICcuL21lc3NhZ2UtaGFuZGxlcic7XG4iLCIvKipcbiAqIEBmaWxlXG4gKiBUaGlzIGZpbGUgaXMgcGFydCBvZiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIChodHRwczovL2dpdGh1Yi5jb20vQWRndWFyZFRlYW0vQWRndWFyZEJyb3dzZXJFeHRlbnNpb24pLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXG4gKiBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuXG4gKiBTZWUgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogWW91IHNob3VsZCBoYXZlIHJlY2VpdmVkIGEgY29weSBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2VcbiAqIGFsb25nIHdpdGggQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbi4gSWYgbm90LCBzZWUgPGh0dHA6Ly93d3cuZ251Lm9yZy9saWNlbnNlcy8+LlxuICovXG5pbXBvcnQgYnJvd3NlciwgeyBSdW50aW1lIH0gZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJztcblxuaW1wb3J0IHsgdHlwZSBFbmdpbmVNZXNzYWdlIH0gZnJvbSAnZW5naW5lJztcblxuaW1wb3J0IHtcbiAgICB0eXBlIE1lc3NhZ2VUeXBlLFxuICAgIHR5cGUgTWVzc2FnZSxcbiAgICB0eXBlIEV4dHJhY3RlZE1lc3NhZ2UsXG4gICAgdHlwZSBWYWxpZE1lc3NhZ2VUeXBlcyxcbiAgICB0eXBlIEV4dHJhY3RNZXNzYWdlUmVzcG9uc2UsXG4gICAgQVBQX01FU1NBR0VfSEFORExFUl9OQU1FLFxufSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbmV4cG9ydCB0eXBlIE1lc3NhZ2VMaXN0ZW5lcjxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+ID0gKFxuICAgIG1lc3NhZ2U6IEV4dHJhY3RlZE1lc3NhZ2U8VD4sXG4gICAgc2VuZGVyOiBSdW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4pID0+IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxUPj4gfCBFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPFQ+O1xuXG4vKipcbiAqIFR5cGUgZ3VhcmQgZm9yIG1lc3NhZ2VzIHRoYXQgaGF2ZSBhICd0eXBlJyBmaWVsZCB3aXRoIHBvc3NpYmxlIHtAbGluayBNZXNzYWdlVHlwZX0uXG4gKlxuICogQG5vdGUgQWRkZWQgdG8gbm8gYnJpbmcgaGVyZSBodWdlIHpvZCBsaWJyYXJ5LlxuICpcbiAqIEBwYXJhbSBtZXNzYWdlIFVua25vd24gbWVzc2FnZS5cbiAqXG4gKiBAcmV0dXJucyBUcnVlIGlmIG1lc3NhZ2UgaGFzICd0eXBlJyBmaWVsZCB3aXRoIHBvc3NpYmxlIHtAbGluayBNZXNzYWdlVHlwZX0uXG4gKi9cbmV4cG9ydCBjb25zdCBtZXNzYWdlSGFzVHlwZUZpZWxkID0gKG1lc3NhZ2U6IHVua25vd24pOiBtZXNzYWdlIGlzIHsgdHlwZTogTWVzc2FnZVR5cGUgfSA9PiB7XG4gICAgcmV0dXJuIHR5cGVvZiBtZXNzYWdlID09PSAnb2JqZWN0JyAmJiBtZXNzYWdlICE9PSBudWxsICYmICd0eXBlJyBpbiBtZXNzYWdlO1xufTtcblxuLyoqXG4gKiBUeXBlIGd1YXJkIGZvciBtZXNzYWdlcyB0aGF0IGhhdmUgYSAndHlwZScgZmllbGQgYW5kICdkYXRhJyBmaWVsZCBhbmQgbG9va3MgbGlrZSB7QGxpbmsgTWVzc2FnZX0uXG4gKlxuICogQG5vdGUgQWRkZWQgdG8gbm8gYnJpbmcgaGVyZSBodWdlIHpvZCBsaWJyYXJ5LlxuICpcbiAqIEBwYXJhbSBtZXNzYWdlIFVua25vd24gbWVzc2FnZS5cbiAqXG4gKiBAcmV0dXJucyBUcnVlIGlmIG1lc3NhZ2UgaGFzICd0eXBlJyBhbmQgJ2RhdGEnIGZpZWxkcyBhbmQgbG9va3MgbGlrZSB7QGxpbmsgTWVzc2FnZX0uXG4gKi9cbmV4cG9ydCBjb25zdCBtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMgPSAobWVzc2FnZTogdW5rbm93bik6IG1lc3NhZ2UgaXMgTWVzc2FnZSA9PiB7XG4gICAgcmV0dXJuIG1lc3NhZ2VIYXNUeXBlRmllbGQobWVzc2FnZSkgJiYgJ2RhdGEnIGluIG1lc3NhZ2U7XG59O1xuXG4vKipcbiAqIEFQSSBmb3IgaGFuZGxpbmcgTWVzc2FnZXMgdmlhIHtAbGluayBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlfVxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTWVzc2FnZUhhbmRsZXIge1xuICAgIHByb3RlY3RlZCBsaXN0ZW5lcnMgPSBuZXcgTWFwPFZhbGlkTWVzc2FnZVR5cGVzLCBNZXNzYWdlTGlzdGVuZXI8VmFsaWRNZXNzYWdlVHlwZXM+PigpO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuaGFuZGxlTWVzc2FnZSA9IHRoaXMuaGFuZGxlTWVzc2FnZS5iaW5kKHRoaXMpO1xuICAgIH1cblxuICAgIHB1YmxpYyBpbml0KCk6IHZvaWQge1xuICAgICAgICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKHRoaXMuaGFuZGxlTWVzc2FnZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkIG1lc3NhZ2UgbGlzdGVuZXIuXG4gICAgICogTGlzdGVuZXJzIGxpbWl0ZWQgdG8gMSBwZXIgbWVzc2FnZSB0eXBlIHRvIHByZXZlbnQgcmFjZVxuICAgICAqIGNvbmRpdGlvbiB3aGlsZSByZXNwb25zZSBwcm9jZXNzaW5nLlxuICAgICAqXG4gICAgICogVE9ETzogaW1wbGVtZW50IGxpc3RlbmVycyBwcmlvcml0eSBleGVjdXRpb24gc3RyYXRlZ3lcbiAgICAgKlxuICAgICAqIEBwYXJhbSB0eXBlIC0ge0BsaW5rIFZhbGlkTWVzc2FnZVR5cGVzfVxuICAgICAqIEBwYXJhbSBsaXN0ZW5lciAtIHtAbGluayBNZXNzYWdlTGlzdGVuZXJ9XG4gICAgICpcbiAgICAgKiBAdGhyb3dzIGVycm9yLCBpZiBtZXNzYWdlIGxpc3RlbmVyIGFscmVhZHkgYWRkZWRcbiAgICAgKi9cbiAgICBwdWJsaWMgYWRkTGlzdGVuZXI8VCBleHRlbmRzIFZhbGlkTWVzc2FnZVR5cGVzPihcbiAgICAgICAgdHlwZTogVCxcbiAgICAgICAgbGlzdGVuZXI6IE1lc3NhZ2VMaXN0ZW5lcjxUPixcbiAgICApOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMubGlzdGVuZXJzLmhhcyh0eXBlKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNZXNzYWdlIGhhbmRsZXI6ICR7dHlwZX0gbGlzdGVuZXIgaGFzIGFscmVhZHkgYmVlbiByZWdpc3RlcmVkYCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDYXN0IHRocm91Z2ggdW5rbm93biB0byBoZWxwIFRTIHVuZGVyc3RhbmQgdGhhdCB0aGUgbGlzdGVuZXIgaXMgb2ZcbiAgICAgICAgLy8gdGhlIGNvcnJlY3QgdHlwZS4gSXQgd2lsbCBjaGVjayB0eXBlcyBhdCBjb21waWxlIHRpbWUuXG4gICAgICAgIHRoaXMubGlzdGVuZXJzLnNldCh0eXBlLCBsaXN0ZW5lciBhcyB1bmtub3duIGFzIE1lc3NhZ2VMaXN0ZW5lcjxWYWxpZE1lc3NhZ2VUeXBlcz4pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlbW92ZXMgbWVzc2FnZSBsaXN0ZW5lci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0eXBlIC0ge0BsaW5rIFZhbGlkTWVzc2FnZVR5cGVzfVxuICAgICAqL1xuICAgIHB1YmxpYyByZW1vdmVMaXN0ZW5lcjxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+KHR5cGU6IFQpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5saXN0ZW5lcnMuZGVsZXRlKHR5cGUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlbW92ZXMgYWxsIGxpc3RlbmVyc1xuICAgICAqL1xuICAgIHB1YmxpYyByZW1vdmVMaXN0ZW5lcnMoKTogdm9pZCB7XG4gICAgICAgIHRoaXMubGlzdGVuZXJzLmNsZWFyKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIG1lc3NhZ2UgaXMgb2YgdHlwZSB7QGxpbmsgTWVzc2FnZX0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbWVzc2FnZSBNZXNzYWdlIG9mIGJhc2ljIHR5cGUge0BsaW5rIE1lc3NhZ2V9IG9yIHtAbGluayBFbmdpbmVNZXNzYWdlfS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFRydWUgaWYgdGhlIG1lc3NhZ2UgaXMgb2YgdHlwZSB7QGxpbmsgTWVzc2FnZX0uXG4gICAgICovXG4gICAgcHJvdGVjdGVkIHN0YXRpYyBpc1ZhbGlkTWVzc2FnZVR5cGUobWVzc2FnZTogTWVzc2FnZSB8IEVuZ2luZU1lc3NhZ2UpOiBtZXNzYWdlIGlzIE1lc3NhZ2Uge1xuICAgICAgICByZXR1cm4gbWVzc2FnZS5oYW5kbGVyTmFtZSA9PT0gQVBQX01FU1NBR0VfSEFORExFUl9OQU1FICYmICd0eXBlJyBpbiBtZXNzYWdlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZXMgZGF0YSBmcm9tIHtAbGluayBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlfSBhbmQgbWF0Y2ggc3BlY2lmaWVkIGxpc3RlbmVyLlxuICAgICAqXG4gICAgICogQHBhcmFtIG1lc3NhZ2UgLSB7QGxpbmsgTWVzc2FnZX1cbiAgICAgKiBAcGFyYW0gc2VuZGVyIC0gQW4gb2JqZWN0IGNvbnRhaW5pbmcgaW5mb3JtYXRpb24gYWJvdXQgdGhlIHNjcmlwdCBjb250ZXh0IHRoYXQgc2VudCBhIG1lc3NhZ2Ugb3IgcmVxdWVzdC5cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgaGFuZGxlTWVzc2FnZShcbiAgICAgICAgbWVzc2FnZTogTWVzc2FnZSB8IHVua25vd24sXG4gICAgICAgIHNlbmRlcjogUnVudGltZS5NZXNzYWdlU2VuZGVyXG4gICAgKTogUHJvbWlzZTx1bmtub3duPiB8IHVuZGVmaW5lZDtcbn1cbiIsIi8qKlxuICogQGZpbGVcbiAqIFRoaXMgZmlsZSBpcyBwYXJ0IG9mIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gKGh0dHBzOi8vZ2l0aHViLmNvbS9BZGd1YXJkVGVhbS9BZGd1YXJkQnJvd3NlckV4dGVuc2lvbikuXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBmcmVlIHNvZnR3YXJlOiB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbiwgZWl0aGVyIHZlcnNpb24gMyBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBkaXN0cmlidXRlZCBpbiB0aGUgaG9wZSB0aGF0IGl0IHdpbGwgYmUgdXNlZnVsLFxuICogYnV0IFdJVEhPVVQgQU5ZIFdBUlJBTlRZOyB3aXRob3V0IGV2ZW4gdGhlIGltcGxpZWQgd2FycmFudHkgb2ZcbiAqIE1FUkNIQU5UQUJJTElUWSBvciBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRS5cbiAqIFNlZSB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgZm9yIG1vcmUgZGV0YWlscy5cbiAqXG4gKiBZb3Ugc2hvdWxkIGhhdmUgcmVjZWl2ZWQgYSBjb3B5IG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZVxuICogYWxvbmcgd2l0aCBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uLiBJZiBub3QsIHNlZSA8aHR0cDovL3d3dy5nbnUub3JnL2xpY2Vuc2VzLz4uXG4gKi9cblxuaW1wb3J0IGJyb3dzZXIgZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJztcblxuaW1wb3J0IHtcbiAgICBNZXNzYWdlVHlwZSxcbiAgICBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lLFxuICAgIEFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSxcbn0gZnJvbSAnLi9jb25zdGFudHMnO1xuXG4vKipcbiAqIFRPRE86IENvbnNpZGVyIG1vdmluZyB0aGlzIGZpbGUgdG8gdGhlIGJhY2tncm91bmQgZm9sZGVyLCBiZWNhdXNlIGFsbCBtZXNzYWdlc1xuICogZnJvbSB0aGUgVUkgc2hvdWxkIGJlIHNlbmQgdmlhIG1ldGhvZHMgb2YgTWVzc2VuZ2VyIGNsYXNzIGluc3RlYWQgb2YgdXNpbmdcbiAqIGRpcmVjdGx5IHNlbmRNZXNzYWdlIHRvIHByb3BlciB0eXBlcyBjaGVja2luZy5cbiAqXG4gKiB7QGxpbmsgc2VuZE1lc3NhZ2V9IHNlbmRzIGFwcCBtZXNzYWdlIHZpYSB7QGxpbmsgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlfSBhbmRcbiAqIGdldHMgcmVzcG9uc2UgZnJvbSBhbm90aGVyIGV4dGVuc2lvbiBwYWdlIG1lc3NhZ2UgaGFuZGxlclxuICpcbiAqIEBwYXJhbSBtZXNzYWdlIC0gcGFydGlhbCB7QGxpbmsgTWVzc2FnZX0gcmVjb3JkIHdpdGhvdXQge0BsaW5rIE1lc3NhZ2UuaGFuZGxlck5hbWV9IGZpZWxkXG4gKlxuICogQHJldHVybnMgbWVzc2FnZSBoYW5kbGVyIHJlc3BvbnNlXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kTWVzc2FnZTxUIGV4dGVuZHMgTWVzc2FnZVR5cGU+KFxuICAgIG1lc3NhZ2U6IE1lc3NhZ2VXaXRob3V0SGFuZGxlck5hbWU8VD4sXG4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICAgIGhhbmRsZXJOYW1lOiBBUFBfTUVTU0FHRV9IQU5ETEVSX05BTUUsXG4gICAgICAgICAgICAuLi5tZXNzYWdlLFxuICAgICAgICB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIGRvIG5vdGhpbmdcbiAgICB9XG59XG5cbi8qKlxuICoge0BsaW5rIHNlbmRUYWJNZXNzYWdlfSBzZW5kcyBtZXNzYWdlIHRvIHNwZWNpZmllZCB0YWIgdmlhIHtAbGluayBicm93c2VyLnRhYnMuc2VuZE1lc3NhZ2V9IGFuZFxuICogZ2V0cyByZXNwb25zZSBmcm9tIGl0XG4gKlxuICogQHBhcmFtIHRhYklkIC0gdGFiIGlkXG4gKiBAcGFyYW0gbWVzc2FnZSAtIHBhcnRpYWwge0BsaW5rIE1lc3NhZ2V9IHJlY29yZCB3aXRob3V0IHtAbGluayBNZXNzYWdlLmhhbmRsZXJOYW1lfSBmaWVsZFxuICpcbiAqIEByZXR1cm5zIHRhYiBtZXNzYWdlIGhhbmRsZXIgcmVzcG9uc2VcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRUYWJNZXNzYWdlPFQgZXh0ZW5kcyBNZXNzYWdlVHlwZT4oXG4gICAgdGFiSWQ6IG51bWJlcixcbiAgICBtZXNzYWdlOiBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+LFxuKTogUHJvbWlzZTx1bmtub3duPiB7XG4gICAgcmV0dXJuIGJyb3dzZXIudGFicy5zZW5kTWVzc2FnZSh0YWJJZCwge1xuICAgICAgICBoYW5kbGVyTmFtZTogQVBQX01FU1NBR0VfSEFORExFUl9OQU1FLFxuICAgICAgICAuLi5tZXNzYWdlLFxuICAgIH0pO1xufVxuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5pbXBvcnQgVUFQYXJzZXIgZnJvbSAndWEtcGFyc2VyLWpzJztcblxuaW1wb3J0IHsgTUlOX1NVUFBPUlRFRF9WRVJTSU9OIH0gZnJvbSAnLi4vLi4vLi4vY29uc3RhbnRzJztcblxuLyoqXG4gKiBIZWxwZXIgY2xhc3MgZm9yIHVzZXIgYWdlbnQgZGF0YS5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9Vc2VyLUFnZW50X0NsaWVudF9IaW50c19BUEkjYnJvd3Nlcl9jb21wYXRpYmlsaXR5XG4gKi9cbmV4cG9ydCBjbGFzcyBVc2VyQWdlbnQge1xuICAgIHN0YXRpYyBXSU5ET1dTXzEwX09TX1ZFUlNJT04gPSAnMTAnO1xuXG4gICAgc3RhdGljIFdJTkRPV1NfMTFfT1NfVkVSU0lPTiA9ICcxMSc7XG5cbiAgICBzdGF0aWMgUExBVEZPUk1fVkVSU0lPTiA9ICdwbGF0Zm9ybVZlcnNpb24nO1xuXG4gICAgc3RhdGljIE1JTl9XSU5ET1dTXzExX1BMQVRGT1JNX1ZFUlNJT04gPSAxMztcblxuICAgIHN0YXRpYyBwYXJzZXIgPSBuZXcgVUFQYXJzZXIobmF2aWdhdG9yLnVzZXJBZ2VudCk7XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGN1cnJlbnQgYnJvd3NlciBuYW1lLlxuICAgICAqXG4gICAgICogQHJldHVybnMgdXNlciBhZ2VudCBicm93c2VyIG5hbWUuXG4gICAgICovXG4gICAgc3RhdGljIGdldEJyb3dzZXJOYW1lKCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiBVc2VyQWdlbnQuaXNGaXJlZm94TW9iaWxlXG4gICAgICAgICAgICAvLyBGaXJlZm94IG1vYmlsZSBkb2VzIG5vdCBoYXZlIG93biBkZWRpY2F0ZWQgYnJvd3NlciBuYW1lXG4gICAgICAgICAgICA/ICdGaXJlZm94IE1vYmlsZSdcbiAgICAgICAgICAgIDogVXNlckFnZW50LnBhcnNlci5nZXRCcm93c2VyKCkubmFtZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGN1cnJlbnQgT1MgbmFtZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIE9TIG5hbWUgYXMgc3RyaW5nIGlmIHBvc3NpYmxlIHRvIGRldGVjdCwgdW5kZWZpbmVkIG90aGVyd2lzZS5cbiAgICAgKi9cbiAgICBzdGF0aWMgZ2V0U3lzdGVtTmFtZSgpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gVXNlckFnZW50LnBhcnNlci5nZXRPUygpLm5hbWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBjdXJyZW50IE9TIHZlcnNpb24uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBPUyB2ZXJzaW9uIGFzIHN0cmluZyBpZiBwb3NzaWJsZSB0byBkZXRlY3QsIHVuZGVmaW5lZCBvdGhlcndpc2UuXG4gICAgICovXG4gICAgc3RhdGljIGdldFN5c3RlbVZlcnNpb24oKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIFVzZXJBZ2VudC5wYXJzZXIuZ2V0T1MoKS52ZXJzaW9uO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgY3VycmVudCBwbGF0Zm9ybSB2ZXJzaW9uLlxuICAgICAqIFVzZXMgTmF2aWdhdG9yVUFEYXRhLmdldEhpZ2hFbnRyb3B5VmFsdWVzKCkgdG8gZ2V0IHBsYXRmb3JtIHZlcnNpb24uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBBY3R1YWwgcGxhdGZvcm0gdmVyc2lvbiBhcyBzdHJpbmcgaWYgcG9zc2libGUgdG8gZGV0ZWN0LCB1bmRlZmluZWQgb3RoZXJ3aXNlLlxuICAgICAqL1xuICAgIHN0YXRpYyBhc3luYyBnZXRQbGF0Zm9ybVZlcnNpb24oKTogUHJvbWlzZTxzdHJpbmcgfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgbGV0IHBsYXRmb3JtVmVyc2lvbjogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICAgICAgY29uc3QgdWEgPSBhd2FpdCBuYXZpZ2F0b3IudXNlckFnZW50RGF0YS5nZXRIaWdoRW50cm9weVZhbHVlcyhbVXNlckFnZW50LlBMQVRGT1JNX1ZFUlNJT05dKTtcbiAgICAgICAgICAgIHBsYXRmb3JtVmVyc2lvbiA9IHVhW1VzZXJBZ2VudC5QTEFURk9STV9WRVJTSU9OXTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLy8gZG8gbm90aGluZ1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwbGF0Zm9ybVZlcnNpb247XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhY3R1YWwgV2luZG93cyB2ZXJzaW9uIGlmIGl0IGlzIHBhcnNlZCBmcm9tIHVzZXIgYWdlbnQgYXMgV2luZG93cyAxMC5cbiAgICAgKlxuICAgICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vbGVhcm4ubWljcm9zb2Z0LmNvbS9lbi11cy9taWNyb3NvZnQtZWRnZS93ZWItcGxhdGZvcm0vaG93LXRvLWRldGVjdC13aW4xMSNzYW1wbGUtY29kZS1mb3ItZGV0ZWN0aW5nLXdpbmRvd3MtMTF9LlxuICAgICAqXG4gICAgICogQHJldHVybnMgQWN0dWFsIFdpbmRvd3MgdmVyc2lvbi5cbiAgICAgKi9cbiAgICBzdGF0aWMgYXN5bmMgZ2V0QWN0dWFsV2luZG93c1ZlcnNpb24odmVyc2lvbjogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgbGV0IGFjdHVhbFZlcnNpb24gPSB2ZXJzaW9uO1xuICAgICAgICBjb25zdCBwbGF0Zm9ybVZlcnNpb24gPSBhd2FpdCBVc2VyQWdlbnQuZ2V0UGxhdGZvcm1WZXJzaW9uKCk7XG5cbiAgICAgICAgaWYgKHR5cGVvZiBwbGF0Zm9ybVZlcnNpb24gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBjb25zdCByYXdNYWpvclBsYXRmb3JtVmVyc2lvbiA9IHBsYXRmb3JtVmVyc2lvbi5zcGxpdCgnLicpWzBdO1xuICAgICAgICAgICAgY29uc3QgbWFqb3JQbGF0Zm9ybVZlcnNpb24gPSByYXdNYWpvclBsYXRmb3JtVmVyc2lvbiAmJiBwYXJzZUludChyYXdNYWpvclBsYXRmb3JtVmVyc2lvbiwgMTApO1xuXG4gICAgICAgICAgICBpZiAoIW1ham9yUGxhdGZvcm1WZXJzaW9uXG4gICAgICAgICAgICAgICAgfHwgTnVtYmVyLmlzTmFOKG1ham9yUGxhdGZvcm1WZXJzaW9uKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBhY3R1YWxWZXJzaW9uO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobWFqb3JQbGF0Zm9ybVZlcnNpb24gPj0gVXNlckFnZW50Lk1JTl9XSU5ET1dTXzExX1BMQVRGT1JNX1ZFUlNJT04pIHtcbiAgICAgICAgICAgICAgICBhY3R1YWxWZXJzaW9uID0gVXNlckFnZW50LldJTkRPV1NfMTFfT1NfVkVSU0lPTjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBhY3R1YWxWZXJzaW9uO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYWN0dWFsIE1hY09TIHZlcnNpb24gaWYgaXQgaXMgcG9zc2libGUgdG8gZGV0ZWN0LCBvdGhlcndpc2UgcmV0dXJucyBwYXNzZWQgYHZlcnNpb25gLlxuICAgICAqXG4gICAgICogQHBhcmFtIHZlcnNpb24gTWFjT1MgdmVyc2lvbiBwYXJzZWQgZnJvbSB1c2VyIGFnZW50LlxuICAgICAqXG4gICAgICogQHJldHVybnMgQWN0dWFsIE1hY09TIHZlcnNpb24uXG4gICAgICovXG4gICAgc3RhdGljIGFzeW5jIGdldEFjdHVhbE1hY29zVmVyc2lvbih2ZXJzaW9uOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICBsZXQgYWN0dWFsVmVyc2lvbiA9IHZlcnNpb247XG4gICAgICAgIGNvbnN0IHBsYXRmb3JtVmVyc2lvbiA9IGF3YWl0IFVzZXJBZ2VudC5nZXRQbGF0Zm9ybVZlcnNpb24oKTtcblxuICAgICAgICBpZiAodHlwZW9mIHBsYXRmb3JtVmVyc2lvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIGFjdHVhbFZlcnNpb24gPSBwbGF0Zm9ybVZlcnNpb247XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYWN0dWFsVmVyc2lvbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGN1cnJlbnQgc3lzdGVtIGluZm8g4oCUIE9TIG5hbWUgYW5kIHZlcnNpb24uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBTeXN0ZW0gaW5mbyBhcyBzdHJpbmcgaWYgcG9zc2libGUgdG8gZGV0ZWN0LCB1bmRlZmluZWQgb3RoZXJ3aXNlLlxuICAgICAqL1xuICAgIHN0YXRpYyBhc3luYyBnZXRTeXN0ZW1JbmZvKCk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIGxldCBzeXN0ZW1JbmZvOiBzdHJpbmcgPSAnJztcbiAgICAgICAgY29uc3Qgb3NOYW1lID0gVXNlckFnZW50LmdldFN5c3RlbU5hbWUoKTtcbiAgICAgICAgbGV0IG9zVmVyc2lvbiA9IFVzZXJBZ2VudC5nZXRTeXN0ZW1WZXJzaW9uKCk7XG5cbiAgICAgICAgaWYgKHR5cGVvZiBvc05hbWUgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBzeXN0ZW1JbmZvICs9IG9zTmFtZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0eXBlb2Ygb3NWZXJzaW9uICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgLy8gd2luZG93cyAxMSBpcyBwYXJzZWQgYXMgd2luZG93cyAxMCBmcm9tIHVzZXIgYWdlbnRcbiAgICAgICAgICAgIGlmIChVc2VyQWdlbnQuaXNXaW5kb3dzICYmIG9zVmVyc2lvbiA9PT0gVXNlckFnZW50LldJTkRPV1NfMTBfT1NfVkVSU0lPTikge1xuICAgICAgICAgICAgICAgIG9zVmVyc2lvbiA9IGF3YWl0IFVzZXJBZ2VudC5nZXRBY3R1YWxXaW5kb3dzVmVyc2lvbihvc1ZlcnNpb24pO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChVc2VyQWdlbnQuaXNNYWNPcykge1xuICAgICAgICAgICAgICAgIC8vIG1hYyBvcyB2ZXJzaW9uIGNhbiBiZSBwYXJzZWQgZnJvbSB1c2VyIGFnZW50IGFzIDEwLjE1LjdcbiAgICAgICAgICAgICAgICAvLyBzbyBpdCBhbHNvIG1pZ2h0IGJlIG1vcmUgc3BlY2lmaWMgdmVyc2lvbiBsaWtlIDEzLjUuMlxuICAgICAgICAgICAgICAgIG9zVmVyc2lvbiA9IGF3YWl0IFVzZXJBZ2VudC5nZXRBY3R1YWxNYWNvc1ZlcnNpb24ob3NWZXJzaW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN5c3RlbUluZm8gKz0gYCAke29zVmVyc2lvbn1gO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHN5c3RlbUluZm8ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHN5c3RlbUluZm87XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIGN1cnJlbnQgYnJvd3NlciBpcyBhcyBnaXZlbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBicm93c2VyTmFtZSBCcm93c2VyIE5hbWUuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB0cnVlLCBpZiBjdXJyZW50IGJyb3dzZXIgaGFzIHNwZWNpZmllZCBuYW1lLlxuICAgICAqL1xuICAgIHN0YXRpYyBpc1RhcmdldEJyb3dzZXIoYnJvd3Nlck5hbWU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gVXNlckFnZW50LnBhcnNlci5nZXRCcm93c2VyKCkubmFtZSA9PT0gYnJvd3Nlck5hbWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgY3VycmVudCBwbGF0Zm9ybSBpcyBhcyBnaXZlbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBwbGF0Zm9ybU5hbWUgUGxhdGZvcm0gbmFtZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIHRydWUsIGlmIGN1cnJlbnQgYnJvd3NlciBoYXMgc3BlY2lmaWVkIG5hbWUuXG4gICAgICovXG4gICAgc3RhdGljIGlzVGFyZ2V0UGxhdGZvcm0ocGxhdGZvcm1OYW1lOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIFVzZXJBZ2VudC5nZXRTeXN0ZW1OYW1lKCkgPT09IHBsYXRmb3JtTmFtZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBjdXJyZW50IGVuZ2luZSBpcyBhcyBnaXZlbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBlbmdpbmVOYW1lIEVuZ2luZSBuYW1lLlxuICAgICAqXG4gICAgICogQHJldHVybnMgdHJ1ZSwgaWYgY3VycmVudCBlbmdpbmUgaGFzIHNwZWNpZmllZCBuYW1lLlxuICAgICAqL1xuICAgIHN0YXRpYyBpc1RhcmdldEVuZ2luZShlbmdpbmVOYW1lOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIFVzZXJBZ2VudC5wYXJzZXIuZ2V0RW5naW5lKCkubmFtZSA9PT0gZW5naW5lTmFtZTtcbiAgICB9XG5cbiAgICBzdGF0aWMgaXNUYXJnZXREZXZpY2VUeXBlKGRldmljZVR5cGU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gVXNlckFnZW50LnBhcnNlci5nZXREZXZpY2UoKS50eXBlID09PSBkZXZpY2VUeXBlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYSBtYWpvciBicm93c2VyIHZlcnNpb24uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBicm93c2VyIHZlcnNpb24gbnVtYmVyIG9yIHVuZGVmaW5lZC5cbiAgICAgKi9cbiAgICBzdGF0aWMgZ2V0VmVyc2lvbigpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICAgICAgICBjb25zdCBicm93c2VyID0gdGhpcy5wYXJzZXIuZ2V0QnJvd3NlcigpO1xuICAgICAgICBjb25zdCB2ZXJzaW9uTnVtYmVyID0gTnVtYmVyKGJyb3dzZXIudmVyc2lvbj8uc3BsaXQoJy4nKVswXSk7XG4gICAgICAgIHJldHVybiBOdW1iZXIuaXNOYU4odmVyc2lvbk51bWJlcikgPyB1bmRlZmluZWQgOiB2ZXJzaW9uTnVtYmVyO1xuICAgIH1cblxuICAgIHN0YXRpYyB2ZXJzaW9uID0gVXNlckFnZW50LmdldFZlcnNpb24oKTtcblxuICAgIHN0YXRpYyBpc0Nocm9tZSA9IFVzZXJBZ2VudC5pc1RhcmdldEJyb3dzZXIoJ0Nocm9tZScpO1xuXG4gICAgc3RhdGljIGlzRmlyZWZveCA9IFVzZXJBZ2VudC5pc1RhcmdldEJyb3dzZXIoJ0ZpcmVmb3gnKTtcblxuICAgIHN0YXRpYyBpc09wZXJhID0gVXNlckFnZW50LmlzVGFyZ2V0QnJvd3NlcignT3BlcmEnKTtcblxuICAgIHN0YXRpYyBpc1lhbmRleCA9IFVzZXJBZ2VudC5pc1RhcmdldEJyb3dzZXIoJ1lhbmRleCcpO1xuXG4gICAgc3RhdGljIGlzRWRnZSA9IFVzZXJBZ2VudC5pc1RhcmdldEJyb3dzZXIoJ0VkZ2UnKTtcblxuICAgIHN0YXRpYyBpc0VkZ2VDaHJvbWl1bSA9IFVzZXJBZ2VudC5pc0VkZ2UgJiYgISEoVXNlckFnZW50LnZlcnNpb24gJiYgVXNlckFnZW50LnZlcnNpb24gPj0gNzkpO1xuXG4gICAgc3RhdGljIGlzTWFjT3MgPSBVc2VyQWdlbnQuaXNUYXJnZXRQbGF0Zm9ybSgnTWFjIE9TJyk7XG5cbiAgICBzdGF0aWMgaXNXaW5kb3dzID0gVXNlckFnZW50LmlzVGFyZ2V0UGxhdGZvcm0oJ1dpbmRvd3MnKTtcblxuICAgIHN0YXRpYyBpc0FuZHJvaWQgPSBVc2VyQWdlbnQuaXNUYXJnZXRQbGF0Zm9ybSgnQW5kcm9pZCcpO1xuXG4gICAgc3RhdGljIGlzQ2hyb21pdW0gPSBVc2VyQWdlbnQuaXNUYXJnZXRFbmdpbmUoJ0JsaW5rJyk7XG5cbiAgICBzdGF0aWMgaXNNb2JpbGVEZXZpY2UgPSBVc2VyQWdlbnQuaXNUYXJnZXREZXZpY2VUeXBlKCdtb2JpbGUnKTtcblxuICAgIHN0YXRpYyBpc0ZpcmVmb3hNb2JpbGUgPSBVc2VyQWdlbnQuaXNGaXJlZm94ICYmIFVzZXJBZ2VudC5pc01vYmlsZURldmljZTtcblxuICAgIHN0YXRpYyBpc1N1cHBvcnRlZEJyb3dzZXIgPSAoVXNlckFnZW50LmlzQ2hyb21lICYmIE51bWJlcihVc2VyQWdlbnQudmVyc2lvbikgPj0gTUlOX1NVUFBPUlRFRF9WRVJTSU9OLkNIUk9NSVVNX01WMilcbiAgICAgICAgfHwgKFVzZXJBZ2VudC5pc0VkZ2VDaHJvbWl1bSAmJiBOdW1iZXIoVXNlckFnZW50LnZlcnNpb24pID49IE1JTl9TVVBQT1JURURfVkVSU0lPTi5FREdFX0NIUk9NSVVNKVxuICAgICAgICB8fCAoVXNlckFnZW50LmlzRmlyZWZveCAmJiBOdW1iZXIoVXNlckFnZW50LnZlcnNpb24pID49IE1JTl9TVVBQT1JURURfVkVSU0lPTi5GSVJFRk9YKVxuICAgICAgICB8fCAoVXNlckFnZW50LmlzRmlyZWZveE1vYmlsZSAmJiBOdW1iZXIoVXNlckFnZW50LnZlcnNpb24pID49IE1JTl9TVVBQT1JURURfVkVSU0lPTi5GSVJFRk9YX01PQklMRSlcbiAgICAgICAgfHwgKFVzZXJBZ2VudC5pc09wZXJhICYmIE51bWJlcihVc2VyQWdlbnQudmVyc2lvbikgPj0gTUlOX1NVUFBPUlRFRF9WRVJTSU9OLk9QRVJBKTtcblxuICAgIHN0YXRpYyBicm93c2VyTmFtZSA9IFVzZXJBZ2VudC5nZXRCcm93c2VyTmFtZSgpO1xufVxuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5pbXBvcnQgYnJvd3NlciBmcm9tICd3ZWJleHRlbnNpb24tcG9seWZpbGwnO1xuaW1wb3J0IHsgbmFub2lkIH0gZnJvbSAnbmFub2lkJztcblxuaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSAnLi4vLi4vY29tbW9uL2xvZ2dlcic7XG5pbXBvcnQge1xuICAgIEFQUF9NRVNTQUdFX0hBTkRMRVJfTkFNRSxcbiAgICBNZXNzYWdlVHlwZSxcbiAgICBtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMsXG4gICAgbWVzc2FnZUhhc1R5cGVGaWVsZCxcbn0gZnJvbSAnLi4vLi4vY29tbW9uL21lc3NhZ2VzJztcbmltcG9ydCB0eXBlIHtcbiAgICBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lLFxuICAgIENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZSxcbiAgICBBZGRBbmRFbmFibGVGaWx0ZXJNZXNzYWdlLFxuICAgIERpc2FibGVGaWx0ZXJNZXNzYWdlLFxuICAgIEFwcGx5U2V0dGluZ3NKc29uTWVzc2FnZSxcbiAgICBTZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZU1lc3NhZ2UsXG4gICAgU2F2ZVVzZXJSdWxlc01lc3NhZ2UsXG4gICAgU2V0Q29uc2VudGVkRmlsdGVyc01lc3NhZ2UsXG4gICAgR2V0SXNDb25zZW50ZWRGaWx0ZXJNZXNzYWdlLFxuICAgIExvYWRDdXN0b21GaWx0ZXJJbmZvTWVzc2FnZSxcbiAgICBTdWJzY3JpYmVUb0N1c3RvbUZpbHRlck1lc3NhZ2UsXG4gICAgUmVtb3ZlQW50aUJhbm5lckZpbHRlck1lc3NhZ2UsXG4gICAgR2V0VGFiSW5mb0ZvclBvcHVwTWVzc2FnZSxcbiAgICBDaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZE1lc3NhZ2UsXG4gICAgT3BlbkFidXNlVGFiTWVzc2FnZSxcbiAgICBPcGVuU2l0ZVJlcG9ydFRhYk1lc3NhZ2UsXG4gICAgUmVzZXRVc2VyUnVsZXNGb3JQYWdlTWVzc2FnZSxcbiAgICBSZW1vdmVBbGxvd2xpc3REb21haW5NZXNzYWdlLFxuICAgIEFkZEFsbG93bGlzdERvbWFpbk1lc3NhZ2UsXG4gICAgR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWRNZXNzYWdlLFxuICAgIENsZWFyRXZlbnRzQnlUYWJJZE1lc3NhZ2UsXG4gICAgUmVmcmVzaFBhZ2VNZXNzYWdlLFxuICAgIEFkZFVzZXJSdWxlTWVzc2FnZSxcbiAgICBSZW1vdmVVc2VyUnVsZU1lc3NhZ2UsXG4gICAgU2V0UHJlc2VydmVMb2dTdGF0ZU1lc3NhZ2UsXG4gICAgU2V0RWRpdG9yU3RvcmFnZUNvbnRlbnRNZXNzYWdlLFxuICAgIENhbkVuYWJsZVN0YXRpY0ZpbHRlck12M01lc3NhZ2UsXG4gICAgQ2FuRW5hYmxlU3RhdGljR3JvdXBNdjNNZXNzYWdlLFxuICAgIEV4dHJhY3RNZXNzYWdlUmVzcG9uc2UsXG4gICAgVmFsaWRNZXNzYWdlVHlwZXMsXG4gICAgU2V0Tm90aWZpY2F0aW9uVmlld2VkTWVzc2FnZSxcbiAgICBVcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWVNZXNzYWdlLFxuICAgIEFkZFVybFRvVHJ1c3RlZE1lc3NhZ2UsXG4gICAgRXh0cmFjdGVkTWVzc2FnZSxcbiAgICBPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZE1lc3NhZ2UsXG59IGZyb20gJy4uLy4uL2NvbW1vbi9tZXNzYWdlcyc7XG5pbXBvcnQgeyBOb3RpZmllclR5cGUgfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IENyZWF0ZUV2ZW50TGlzdGVuZXJSZXNwb25zZSB9IGZyb20gJy4uLy4uL2JhY2tncm91bmQvc2VydmljZXMvZXZlbnQnO1xuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJy4uLy4uL2NvbW1vbi9tZXNzYWdlcycpLk1lc3NhZ2VNYXB9IE1lc3NhZ2VNYXBcbiAqL1xuXG4vKipcbiAqIFR5cGUgb2YgbWVzc2FnZSBmb3IgbG9uZy1saXZlZCBjb25uZWN0aW9uIGxpc3RlbmVyIGNhbGxiYWNrIG1lc3NhZ2UgYXJndW1lbnQuXG4gKi9cbmV4cG9ydCB0eXBlIExvbmdMaXZlZENvbm5lY3Rpb25DYWxsYmFja01lc3NhZ2UgPSB7XG4gICAgLyoqXG4gICAgICogVHlwZSBvZiBub3RpZmllci5cbiAgICAgKi9cbiAgICB0eXBlOiBOb3RpZmllclR5cGUsXG5cbiAgICAvKipcbiAgICAgKiBEYXRhIG9mIG5vdGlmaWVyLlxuICAgICAqL1xuICAgIGRhdGE6IGFueSxcbn07XG5cbmV4cG9ydCBjb25zdCBlbnVtIFBhZ2Uge1xuICAgIEZ1bGxzY3JlZW5Vc2VyUnVsZXMgPSAnZnVsbHNjcmVlbi11c2VyLXJ1bGVzJyxcbiAgICBGaWx0ZXJpbmdMb2cgPSAnZmlsdGVyaW5nLWxvZycsXG59XG5cbnR5cGUgVW5sb2FkQ2FsbGJhY2sgPSAoKSA9PiB2b2lkO1xuXG4vKipcbiAqIE1lc3NlbmdlciBjbGFzcywgdXNlZCB0byBjb21tdW5pY2F0ZSB3aXRoIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgZnJvbSB0aGUgVUkuXG4gKiBBY3R1YWxseSwgaXQncyBhIHdyYXBwZXIgYXJvdW5kIHRoZSBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UgbWV0aG9kLlxuICovXG5jbGFzcyBNZXNzZW5nZXIge1xuICAgIG9uTWVzc2FnZSA9IGJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2U7XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGFuIGluc3RhbmNlIG9mIHRoZSBNZXNzZW5nZXIgY2xhc3MuXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMucmVzZXRVc2VyUnVsZXNGb3JQYWdlID0gdGhpcy5yZXNldFVzZXJSdWxlc0ZvclBhZ2UuYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy51cGRhdGVGaWx0ZXJzID0gdGhpcy51cGRhdGVGaWx0ZXJzLmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMucmVtb3ZlQWxsb3dsaXN0RG9tYWluID0gdGhpcy5yZW1vdmVBbGxvd2xpc3REb21haW4uYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy5hZGRBbGxvd2xpc3REb21haW4gPSB0aGlzLmFkZEFsbG93bGlzdERvbWFpbi5iaW5kKHRoaXMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlLlxuICAgICAqXG4gICAgICogQWxsIG1lc3NhZ2VzIGRlc2NyaWJlZCBpbiB0aGUge0BsaW5rIE1lc3NhZ2VUeXBlfSBlbnVtLlxuICAgICAqIEFsbCBhbnN3ZXJzIGRlc2NyaWJlZCBpbiB0aGUge0BsaW5rIE1lc3NhZ2VNYXB9IHR5cGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdHlwZSBNZXNzYWdlIHR5cGUuXG4gICAgICogQHBhcmFtIGRhdGEgTWVzc2FnZSBkYXRhLiBPcHRpb25hbCBiZWNhdXNlIG5vdCBhbGwgbWVzc2FnZXMgaGF2ZSBkYXRhLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3BvbnNlIGZyb20gdGhlIGJhY2tncm91bmQgcGFnZS5cbiAgICAgKiBUeXBlIG9mIHRoZSByZXNwb25zZSBkZXBlbmRzIG9uIHRoZSBtZXNzYWdlIHR5cGUuIEdvIHRvIHtAbGluayBNZXNzYWdlTWFwfVxuICAgICAqIHRvIHNlZSBhbGwgcG9zc2libGUgbWVzc2FnZSB0eXBlcyBhbmQgdGhlaXIgcmVzcG9uc2VzLlxuICAgICAqL1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gICAgcHJpdmF0ZSBhc3luYyBzZW5kTWVzc2FnZTxUIGV4dGVuZHMgVmFsaWRNZXNzYWdlVHlwZXM+KFxuICAgICAgICB0eXBlOiBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+Wyd0eXBlJ10sXG4gICAgICAgIGRhdGE/OiAnZGF0YScgZXh0ZW5kcyBrZXlvZiBNZXNzYWdlV2l0aG91dEhhbmRsZXJOYW1lPFQ+ID8gTWVzc2FnZVdpdGhvdXRIYW5kbGVyTmFtZTxUPlsnZGF0YSddIDogdW5kZWZpbmVkLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxUPj4ge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgICAgICBoYW5kbGVyTmFtZTogQVBQX01FU1NBR0VfSEFORExFUl9OQU1FLFxuICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgIGRhdGEsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZSBhcyBFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPFQ+O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgbG9uZy1saXZlZCBjb25uZWN0aW9ucyBiZXR3ZWVuIHBvcHVwIGFuZCBiYWNrZ3JvdW5kIHBhZ2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcGFnZSBQYWdlIG5hbWUuXG4gICAgICogQHBhcmFtIGV2ZW50cyBMaXN0IG9mIGV2ZW50cyB0byB3aGljaCBzdWJzY3JpYmUuXG4gICAgICogQHBhcmFtIGNhbGxiYWNrIENhbGxiYWNrIGNhbGxlZCB3aGVuIGV2ZW50IGZpcmVzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgRnVuY3Rpb24gdG8gcmVtb3ZlIGxpc3RlbmVyIG9uIHVubG9hZC5cbiAgICAgKi9cbiAgICBzdGF0aWMgY3JlYXRlTG9uZ0xpdmVkQ29ubmVjdGlvbiA9IChcbiAgICAgICAgcGFnZTogUGFnZSxcbiAgICAgICAgZXZlbnRzOiBOb3RpZmllclR5cGVbXSxcbiAgICAgICAgY2FsbGJhY2s6IChtZXNzYWdlOiBMb25nTGl2ZWRDb25uZWN0aW9uQ2FsbGJhY2tNZXNzYWdlKSA9PiB2b2lkLFxuICAgICk6IFVubG9hZENhbGxiYWNrID0+IHtcbiAgICAgICAgbGV0IHBvcnQ6IGJyb3dzZXIuUnVudGltZS5Qb3J0O1xuICAgICAgICBsZXQgZm9yY2VEaXNjb25uZWN0ZWQgPSBmYWxzZTtcblxuICAgICAgICBjb25zdCBjb25uZWN0ID0gKCk6IHZvaWQgPT4ge1xuICAgICAgICAgICAgcG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHsgbmFtZTogYCR7cGFnZX1fJHtuYW5vaWQoKX1gIH0pO1xuICAgICAgICAgICAgcG9ydC5wb3N0TWVzc2FnZSh7IHR5cGU6IE1lc3NhZ2VUeXBlLkFkZExvbmdMaXZlZENvbm5lY3Rpb24sIGRhdGE6IHsgZXZlbnRzIH0gfSk7XG5cbiAgICAgICAgICAgIHBvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKChtZXNzYWdlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFtZXNzYWdlSGFzVHlwZUZpZWxkKG1lc3NhZ2UpKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcignUmVjZWl2ZWQgbWVzc2FnZSBpbiBNZXNzZW5nZXIuY3JlYXRlTG9uZ0xpdmVkQ29ubmVjdGlvbiBoYXMgbm8gdHlwZSBmaWVsZDogJywgbWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS50eXBlID09PSBNZXNzYWdlVHlwZS5Ob3RpZnlMaXN0ZW5lcnMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMobWVzc2FnZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcignUmVjZWl2ZWQgbWVzc2FnZSB3aXRoIHR5cGUgTWVzc2FnZVR5cGUuTm90aWZ5TGlzdGVuZXJzIGhhcyBubyBkYXRhOiAnLCBtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhc3RlZE1lc3NhZ2UgPSBtZXNzYWdlIGFzIEV4dHJhY3RlZE1lc3NhZ2U8TWVzc2FnZVR5cGUuTm90aWZ5TGlzdGVuZXJzPjtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBbdHlwZSwgLi4uZGF0YV0gPSBjYXN0ZWRNZXNzYWdlLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKHsgdHlwZSwgZGF0YSB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChicm93c2VyLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihicm93c2VyLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyB3ZSB0cnkgdG8gY29ubmVjdCBhZ2FpbiBpZiB0aGUgYmFja2dyb3VuZCBwYWdlIHdhcyB0ZXJtaW5hdGVkXG4gICAgICAgICAgICAgICAgaWYgKCFmb3JjZURpc2Nvbm5lY3RlZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25uZWN0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29ubmVjdCgpO1xuXG4gICAgICAgIGNvbnN0IG9uVW5sb2FkID0gKCk6IHZvaWQgPT4ge1xuICAgICAgICAgICAgaWYgKHBvcnQpIHtcbiAgICAgICAgICAgICAgICBmb3JjZURpc2Nvbm5lY3RlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JlZm9yZXVubG9hZCcsIG9uVW5sb2FkKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3VubG9hZCcsIG9uVW5sb2FkKTtcblxuICAgICAgICByZXR1cm4gb25VbmxvYWQ7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIE1ldGhvZCBzdWJzY3JpYmVzIHRvIG5vdGlmaWVyIG1vZHVsZSBldmVudHMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXZlbnRzIExpc3Qgb2YgZXZlbnRzIHRvIHdoaWNoIHN1YnNjcmliZS5cbiAgICAgKiBAcGFyYW0gY2FsbGJhY2sgQ2FsbGJhY2sgY2FsbGVkIHdoZW4gZXZlbnQgZmlyZXMuXG4gICAgICogQHBhcmFtIG9uVW5sb2FkQ2FsbGJhY2sgQ2FsbGJhY2sgdXNlZCB0byByZW1vdmUgbGlzdGVuZXIgb24gdW5sb2FkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgRnVuY3Rpb24gdG8gcmVtb3ZlIGxpc3RlbmVyIG9uIHVubG9hZC5cbiAgICAgKi9cbiAgICBjcmVhdGVFdmVudExpc3RlbmVyID0gYXN5bmMgKFxuICAgICAgICBldmVudHM6IE5vdGlmaWVyVHlwZVtdLFxuICAgICAgICBjYWxsYmFjazogKG1lc3NhZ2U6IExvbmdMaXZlZENvbm5lY3Rpb25DYWxsYmFja01lc3NhZ2UpID0+IHZvaWQsXG4gICAgICAgIG9uVW5sb2FkQ2FsbGJhY2s/OiAoKSA9PiB2b2lkLFxuICAgICk6IFByb21pc2U8VW5sb2FkQ2FsbGJhY2s+ID0+IHtcbiAgICAgICAgbGV0IGxpc3RlbmVySWQ6IG51bWJlciB8IG51bGw7XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2U6IENyZWF0ZUV2ZW50TGlzdGVuZXJSZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICBNZXNzYWdlVHlwZS5DcmVhdGVFdmVudExpc3RlbmVyLFxuICAgICAgICAgICAgeyBldmVudHMgfSxcbiAgICAgICAgKTtcblxuICAgICAgICBsaXN0ZW5lcklkID0gcmVzcG9uc2UubGlzdGVuZXJJZDtcblxuICAgICAgICBjb25zdCBvblVwZGF0ZUxpc3RlbmVycyA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRSZXNwb25zZTogQ3JlYXRlRXZlbnRMaXN0ZW5lclJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShcbiAgICAgICAgICAgICAgICBNZXNzYWdlVHlwZS5DcmVhdGVFdmVudExpc3RlbmVyLFxuICAgICAgICAgICAgICAgIHsgZXZlbnRzIH0sXG4gICAgICAgICAgICApO1xuXG4gICAgICAgICAgICBsaXN0ZW5lcklkID0gdXBkYXRlZFJlc3BvbnNlLmxpc3RlbmVySWQ7XG4gICAgICAgIH07XG5cbiAgICAgICAgYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSkgPT4ge1xuICAgICAgICAgICAgaWYgKCFtZXNzYWdlSGFzVHlwZUZpZWxkKG1lc3NhZ2UpKSB7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmVycm9yKCdSZWNlaXZlZCBtZXNzYWdlIGluIE1lc3Nlbmdlci5jcmVhdGVFdmVudExpc3RlbmVyIGhhcyBubyB0eXBlIGZpZWxkOiAnLCBtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobWVzc2FnZS50eXBlID09PSBNZXNzYWdlVHlwZS5Ob3RpZnlMaXN0ZW5lcnMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIW1lc3NhZ2VIYXNUeXBlQW5kRGF0YUZpZWxkcyhtZXNzYWdlKSkge1xuICAgICAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoJ1JlY2VpdmVkIG1lc3NhZ2Ugd2l0aCB0eXBlIE1lc3NhZ2VUeXBlLk5vdGlmeUxpc3RlbmVycyBoYXMgbm8gZGF0YTogJywgbWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3QgY2FzdGVkTWVzc2FnZSA9IG1lc3NhZ2UgYXMgRXh0cmFjdGVkTWVzc2FnZTxNZXNzYWdlVHlwZS5Ob3RpZnlMaXN0ZW5lcnM+O1xuXG4gICAgICAgICAgICAgICAgY29uc3QgW3R5cGUsIC4uLmRhdGFdID0gY2FzdGVkTWVzc2FnZS5kYXRhO1xuXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50cy5pbmNsdWRlcyh0eXBlKSkge1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayh7IHR5cGUsIGRhdGEgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTWVzc2FnZVR5cGUuVXBkYXRlTGlzdGVuZXJzKSB7XG4gICAgICAgICAgICAgICAgb25VcGRhdGVMaXN0ZW5lcnMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3Qgb25VbmxvYWQgPSAoKTogdm9pZCA9PiB7XG4gICAgICAgICAgICBpZiAoIWxpc3RlbmVySWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICAgICAgTWVzc2FnZVR5cGUuUmVtb3ZlTGlzdGVuZXIsXG4gICAgICAgICAgICAgICAgeyBsaXN0ZW5lcklkIH0sXG4gICAgICAgICAgICApO1xuXG4gICAgICAgICAgICBsaXN0ZW5lcklkID0gbnVsbDtcblxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvblVubG9hZENhbGxiYWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgb25VbmxvYWRDYWxsYmFjaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCBvblVubG9hZCk7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd1bmxvYWQnLCBvblVubG9hZCk7XG5cbiAgICAgICAgcmV0dXJuIG9uVW5sb2FkO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgZnJvbSBiYWNrZ3JvdW5kIHBhZ2UgdG8gdXBkYXRlIGxpc3RlbmVycyBvbiB0aGUgVUkuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2hlbiB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUxpc3RlbmVycygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuVXBkYXRlTGlzdGVuZXJzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5VcGRhdGVMaXN0ZW5lcnMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGdldCB0aGUgc2V0dGluZ3MgZGF0YSBmb3JcbiAgICAgKiB0aGUgb3B0aW9ucyBwYWdlIHdpdGggc29tZSBhZGRpdGlvbmFsIGluZm8uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgc2V0dGluZ3MgZGF0YSBmb3JcbiAgICAgKiB0aGUgb3B0aW9ucyBwYWdlIHdpdGggc29tZSBhZGRpdGlvbmFsIGluZm8uXG4gICAgICovXG4gICAgYXN5bmMgZ2V0T3B0aW9uc0RhdGEoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldE9wdGlvbnNEYXRhPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRPcHRpb25zRGF0YSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hhbmdlIHRoZSB1c2VyIHNldHRpbmcuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc2V0dGluZ0lkIFNldHRpbmcgaWRlbnRpZmllci5cbiAgICAgKiBAcGFyYW0gdmFsdWUgU2V0dGluZyB2YWx1ZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIGNoYW5nZVVzZXJTZXR0aW5nKFxuICAgICAgICBzZXR0aW5nSWQ6IENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZVsnZGF0YSddWydrZXknXSxcbiAgICAgICAgdmFsdWU6IENoYW5nZVVzZXJTZXR0aW5nTWVzc2FnZVsnZGF0YSddWyd2YWx1ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5DaGFuZ2VVc2VyU2V0dGluZ3M+PiB7XG4gICAgICAgIGF3YWl0IHRoaXMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICBNZXNzYWdlVHlwZS5DaGFuZ2VVc2VyU2V0dGluZ3MsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAga2V5OiBzZXR0aW5nSWQsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIGV4dGVuc2lvbiBzdG9yZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIG9wZW5FeHRlbnNpb25TdG9yZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkV4dGVuc2lvblN0b3JlPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuRXh0ZW5zaW9uU3RvcmUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIGNvbXBhcmUgcGFnZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIG9wZW5Db21wYXJlUGFnZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkNvbXBhcmVQYWdlPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuQ29tcGFyZVBhZ2UpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGVuYWJsZSBhIGZpbHRlciBieSBmaWx0ZXIgaWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZmlsdGVySWQgRmlsdGVyIGlkZW50aWZpZXIuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBlbmFibGVGaWx0ZXIoXG4gICAgICAgIGZpbHRlcklkOiBBZGRBbmRFbmFibGVGaWx0ZXJNZXNzYWdlWydkYXRhJ11bJ2ZpbHRlcklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkFkZEFuZEVuYWJsZUZpbHRlcj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQWRkQW5kRW5hYmxlRmlsdGVyLCB7IGZpbHRlcklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGRpc2FibGUgYSBmaWx0ZXIgYnkgZmlsdGVyIGlkLlxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbHRlcklkIEZpbHRlciBpZGVudGlmaWVyLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgZGlzYWJsZUZpbHRlcihcbiAgICAgICAgZmlsdGVySWQ6IERpc2FibGVGaWx0ZXJNZXNzYWdlWydkYXRhJ11bJ2ZpbHRlcklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXI+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXIsIHsgZmlsdGVySWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gYXBwbHkgc2V0dGluZ3MgZnJvbSBhIEpTT04gb2JqZWN0LlxuICAgICAqXG4gICAgICogQHBhcmFtIGpzb24gSlNPTiBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBzZXR0aW5ncyB0byBhcHBseS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIGFwcGx5U2V0dGluZ3NKc29uKFxuICAgICAgICBqc29uOiBBcHBseVNldHRpbmdzSnNvbk1lc3NhZ2VbJ2RhdGEnXVsnanNvbiddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5BcHBseVNldHRpbmdzSnNvbj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQXBwbHlTZXR0aW5nc0pzb24sIHsganNvbiB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBvcGVuIHRoZSBmaWx0ZXJpbmcgbG9nLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlbkZpbHRlcmluZ0xvZygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkZpbHRlcmluZ0xvZz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlbkZpbHRlcmluZ0xvZyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gcmVzZXQgdGhlIGJsb2NrZWQgYWRzIHN0YXRpc3RpY3MuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyByZXNldFN0YXRpc3RpY3MoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlJlc2V0QmxvY2tlZEFkc0NvdW50Pj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5SZXNldEJsb2NrZWRBZHNDb3VudCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2V0IHRoZSBmaWx0ZXJpbmcgbG9nIHdpbmRvdyBzdGF0ZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB3aW5kb3dTdGF0ZSBTdGF0ZSBvZiB0aGUgZmlsdGVyaW5nIGxvZyB3aW5kb3cuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBzZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZShcbiAgICAgICAgd2luZG93U3RhdGU6IFNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlTWVzc2FnZVsnZGF0YSddWyd3aW5kb3dTdGF0ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuU2V0RmlsdGVyaW5nTG9nV2luZG93U3RhdGUsIHsgd2luZG93U3RhdGUgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gcmVzZXQgdGhlIHNldHRpbmdzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgcmVzZXRTZXR0aW5ncygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuUmVzZXRTZXR0aW5ncz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuUmVzZXRTZXR0aW5ncyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IHRoZSB1c2VyIHJ1bGVzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHVzZXIgcnVsZXMuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0VXNlclJ1bGVzKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5HZXRVc2VyUnVsZXM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2F2ZSB1c2VyIHJ1bGVzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHZhbHVlIFVzZXIgcnVsZXMgdmFsdWUgdG8gc2F2ZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHNhdmVVc2VyUnVsZXMoXG4gICAgICAgIHZhbHVlOiBTYXZlVXNlclJ1bGVzTWVzc2FnZVsnZGF0YSddWyd2YWx1ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TYXZlVXNlclJ1bGVzPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlNhdmVVc2VyUnVsZXMsIHsgdmFsdWUgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gb3BlbiB1c2VyIHJ1bGVzIGVkaXRvciBpbiBmdWxsc2NyZWVuLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlbkZ1bGxzY3JlZW5Vc2VyUnVsZXMoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuRnVsbHNjcmVlblVzZXJSdWxlcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IHRoZSBhbGxvd2xpc3QgZG9tYWlucy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBsaXN0IG9mIGFsbG93bGlzdCBkb21haW5zLlxuICAgICAqL1xuICAgIGFzeW5jIGdldEFsbG93bGlzdCgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0QWxsb3dsaXN0RG9tYWlucz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuR2V0QWxsb3dsaXN0RG9tYWlucyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2F2ZSB0aGUgYWxsb3dsaXN0IGRvbWFpbnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdmFsdWUgQWxsb3dsaXN0IGRvbWFpbnMgdmFsdWUgdG8gc2F2ZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHNhdmVBbGxvd2xpc3QoXG4gICAgICAgIHZhbHVlOiBTYXZlVXNlclJ1bGVzTWVzc2FnZVsnZGF0YSddWyd2YWx1ZSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TYXZlQWxsb3dsaXN0RG9tYWlucz4+IHtcbiAgICAgICAgYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TYXZlQWxsb3dsaXN0RG9tYWlucywgeyB2YWx1ZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBtYXJrIGEgbm90aWZpY2F0aW9uIGFzIHZpZXdlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB3aXRoRGVsYXkgV2hldGhlciB0aGUgbm90aWZpY2F0aW9uIHNob3VsZCBiZSBtYXJrZWQgYXMgdmlld2VkIGFmdGVyIGEgZGVsYXkuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBzZXROb3RpZmljYXRpb25WaWV3ZWQoXG4gICAgICAgIHdpdGhEZWxheTogU2V0Tm90aWZpY2F0aW9uVmlld2VkTWVzc2FnZVsnZGF0YSddWyd3aXRoRGVsYXknXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuU2V0Tm90aWZpY2F0aW9uVmlld2VkPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlNldE5vdGlmaWNhdGlvblZpZXdlZCwgeyB3aXRoRGVsYXkgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gdXBkYXRlIGZpbHRlcnMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbGlzdCBvZiBmaWx0ZXJzLlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUZpbHRlcnMoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNoZWNrRmlsdGVyc1VwZGF0ZT4+IHtcbiAgICAgICAgaWYgKF9fSVNfTVYzX18pIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZygnRmlsdGVycyB1cGRhdGUgaXMgbm90IHN1cHBvcnRlZCBpbiBNVjMnKTtcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkNoZWNrRmlsdGVyc1VwZGF0ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gdXBkYXRlIHRoZSBzdGF0dXMgb2YgYSBmaWx0ZXIgZ3JvdXAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gaWQgR3JvdXAgaWRlbnRpZmllci5cbiAgICAgKiBAcGFyYW0gZW5hYmxlZCBXaGV0aGVyIHRoZSBncm91cCBzaG91bGQgYmUgZW5hYmxlZCBvciBkaXNhYmxlZC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUdyb3VwU3RhdHVzKFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgICAgICBlbmFibGVkOiBib29sZWFuLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5FbmFibGVGaWx0ZXJzR3JvdXAgfCBNZXNzYWdlVHlwZS5EaXNhYmxlRmlsdGVyc0dyb3VwPj4ge1xuICAgICAgICBjb25zdCB0eXBlID0gZW5hYmxlZCA/IE1lc3NhZ2VUeXBlLkVuYWJsZUZpbHRlcnNHcm91cCA6IE1lc3NhZ2VUeXBlLkRpc2FibGVGaWx0ZXJzR3JvdXA7XG4gICAgICAgIGNvbnN0IGdyb3VwSWQgPSBOdW1iZXIucGFyc2VJbnQoaWQsIDEwKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZSh0eXBlLCB7IGdyb3VwSWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2V0IGNvbnNlbnRlZCBmaWx0ZXJzLlxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbHRlcklkcyBMaXN0IG9mIGZpbHRlciBpZGVudGlmaWVycy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIHNldENvbnNlbnRlZEZpbHRlcnMoXG4gICAgICAgIGZpbHRlcklkczogU2V0Q29uc2VudGVkRmlsdGVyc01lc3NhZ2VbJ2RhdGEnXVsnZmlsdGVySWRzJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlNldENvbnNlbnRlZEZpbHRlcnM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlNldENvbnNlbnRlZEZpbHRlcnMsIHsgZmlsdGVySWRzIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNoZWNrIGlmIGEgZmlsdGVyIGlzIGNvbnNlbnRlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWx0ZXJJZCBGaWx0ZXIgaWRlbnRpZmllci5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgb2YgdGhlIGNoZWNrLlxuICAgICAqL1xuICAgIGFzeW5jIGdldElzQ29uc2VudGVkRmlsdGVyKFxuICAgICAgICBmaWx0ZXJJZDogR2V0SXNDb25zZW50ZWRGaWx0ZXJNZXNzYWdlWydkYXRhJ11bJ2ZpbHRlcklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldElzQ29uc2VudGVkRmlsdGVyPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRJc0NvbnNlbnRlZEZpbHRlciwgeyBmaWx0ZXJJZCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjaGVjayBhIGN1c3RvbSBmaWx0ZXIgVVJMLlxuICAgICAqXG4gICAgICogQHBhcmFtIHVybCBDdXN0b20gZmlsdGVyIFVSTC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgb2YgdGhlIGNoZWNrLlxuICAgICAqL1xuICAgIGFzeW5jIGNoZWNrQ3VzdG9tVXJsKFxuICAgICAgICB1cmw6IExvYWRDdXN0b21GaWx0ZXJJbmZvTWVzc2FnZVsnZGF0YSddWyd1cmwnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuTG9hZEN1c3RvbUZpbHRlckluZm8+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkxvYWRDdXN0b21GaWx0ZXJJbmZvLCB7IHVybCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBhZGQgYSBjdXN0b20gZmlsdGVyLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtDdXN0b21GaWx0ZXJTdWJzY3JpcHRpb25EYXRhfSBmaWx0ZXIgQ3VzdG9tIGZpbHRlciBkYXRhLlxuICAgICAqXG4gICAgICogQHJldHVybnMge1Byb21pc2U8Q3VzdG9tRmlsdGVyTWV0YWRhdGE+fSBDdXN0b20gZmlsdGVyIG1ldGFkYXRhLlxuICAgICAqL1xuICAgIGFzeW5jIGFkZEN1c3RvbUZpbHRlcihcbiAgICAgICAgZmlsdGVyOiBTdWJzY3JpYmVUb0N1c3RvbUZpbHRlck1lc3NhZ2VbJ2RhdGEnXVsnZmlsdGVyJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlN1YnNjcmliZVRvQ3VzdG9tRmlsdGVyPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TdWJzY3JpYmVUb0N1c3RvbUZpbHRlciwgeyBmaWx0ZXIgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gcmVtb3ZlIGEgY3VzdG9tIGZpbHRlci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWx0ZXJJZCBDdXN0b20gZmlsdGVyIElELlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBmaWx0ZXIgaXMgcmVtb3ZlZC5cbiAgICAgKi9cbiAgICBhc3luYyByZW1vdmVDdXN0b21GaWx0ZXIoXG4gICAgICAgIGZpbHRlcklkOiBSZW1vdmVBbnRpQmFubmVyRmlsdGVyTWVzc2FnZVsnZGF0YSddWydmaWx0ZXJJZCddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5SZW1vdmVBbnRpQmFubmVyRmlsdGVyPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlbW92ZUFudGlCYW5uZXJGaWx0ZXIsIHsgZmlsdGVySWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hlY2sgaWYgdGhlIGVuZ2luZSBpcyBzdGFydGVkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIGEgYm9vbGVhbiB2YWx1ZTpcbiAgICAgKiB0cnVlIGlmIHRoZSBlbmdpbmUgaXMgc3RhcnRlZCwgZmFsc2Ugb3RoZXJ3aXNlLlxuICAgICAqL1xuICAgIGFzeW5jIGdldElzRW5naW5lU3RhcnRlZCgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0SXNFbmdpbmVTdGFydGVkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRJc0VuZ2luZVN0YXJ0ZWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCB0byBnZXQgdGhlIHRhYiBpbmZvIGZvciB0aGUgcG9wdXAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGFiSWQgVGFiIElELlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHRhYiBpbmZvIG9yIHVuZGVmaW5lZC5cbiAgICAgKi9cbiAgICBhc3luYyBnZXRUYWJJbmZvRm9yUG9wdXAoXG4gICAgICAgIHRhYklkOiBHZXRUYWJJbmZvRm9yUG9wdXBNZXNzYWdlWydkYXRhJ11bJ3RhYklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldFRhYkluZm9Gb3JQb3B1cD4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuR2V0VGFiSW5mb0ZvclBvcHVwLCB7IHRhYklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNoYW5nZSBhcHBsaWNhdGlvbiBmaWx0ZXJpbmcgc3RhdGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc3RhdGUgQXBwbGljYXRpb24gZmlsdGVyaW5nIHN0YXRlLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBzdGF0ZSBpcyBjaGFuZ2VkLlxuICAgICAqL1xuICAgIGFzeW5jIGNoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkKFxuICAgICAgICBzdGF0ZTogQ2hhbmdlQXBwbGljYXRpb25GaWx0ZXJpbmdQYXVzZWRNZXNzYWdlWydkYXRhJ11bJ3N0YXRlJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZCwgeyBzdGF0ZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byB1cGRhdGUgdGhlIHRoZW1lIG9mIHRoZSBmdWxsc2NyZWVuIHVzZXIgcnVsZXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGhlbWUgVGhlbWUgdG8gc2V0LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSB0aGVtZSBpcyB1cGRhdGVkLlxuICAgICAqL1xuICAgIGFzeW5jIHVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZShcbiAgICAgICAgdGhlbWU6IFVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZU1lc3NhZ2VbJ2RhdGEnXVsndGhlbWUnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5VcGRhdGVGdWxsc2NyZWVuVXNlclJ1bGVzVGhlbWUsIHsgdGhlbWUgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gb3BlbiB0aGUgcnVsZXMgbGltaXRzIHRhYi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgdGFiIGlzIG9wZW5lZC5cbiAgICAgKi9cbiAgICBhc3luYyBvcGVuUnVsZXNMaW1pdHNUYWIoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5SdWxlc0xpbWl0c1RhYj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlblJ1bGVzTGltaXRzVGFiKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBvcGVuIHRoZSBzZXR0aW5ncyB0YWIuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHRhYiBpcyBvcGVuZWQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlblNldHRpbmdzVGFiKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5PcGVuU2V0dGluZ3NUYWI+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLk9wZW5TZXR0aW5nc1RhYik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gb3BlbiB0aGUgYXNzaXN0YW50LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBhc3Npc3RhbnQgaXMgb3BlbmVkLlxuICAgICAqL1xuICAgIGFzeW5jIG9wZW5Bc3Npc3RhbnQoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5Bc3Npc3RhbnQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLk9wZW5Bc3Npc3RhbnQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIGFidXNlIHJlcG9ydGluZyB0YWIgZm9yIGEgc2l0ZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmwgVGhlIFVSTCBvZiB0aGUgc2l0ZSB0byByZXBvcnQgYWJ1c2UgZm9yLlxuICAgICAqIEBwYXJhbSBmcm9tIFRoZSBzb3VyY2Ugb2YgdGhlIHJlcXVlc3QuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHRhYiBpcyBvcGVuZWQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlbkFidXNlU2l0ZShcbiAgICAgICAgdXJsOiBPcGVuQWJ1c2VUYWJNZXNzYWdlWydkYXRhJ11bJ3VybCddLFxuICAgICAgICBmcm9tOiBPcGVuQWJ1c2VUYWJNZXNzYWdlWydkYXRhJ11bJ2Zyb20nXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlbkFidXNlVGFiPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuQWJ1c2VUYWIsIHsgdXJsLCBmcm9tIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNoZWNrIHNpdGUgc2VjdXJpdHkuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdXJsIFRoZSBVUkwgb2YgdGhlIHNpdGUgdG8gY2hlY2suXG4gICAgICogQHBhcmFtIGZyb20gVGhlIHNvdXJjZSBvZiB0aGUgcmVxdWVzdC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBzaXRlIHNlY3VyaXR5IGluZm8uXG4gICAgICovXG4gICAgYXN5bmMgY2hlY2tTaXRlU2VjdXJpdHkoXG4gICAgICAgIHVybDogT3BlblNpdGVSZXBvcnRUYWJNZXNzYWdlWydkYXRhJ11bJ3VybCddLFxuICAgICAgICBmcm9tOiBPcGVuU2l0ZVJlcG9ydFRhYk1lc3NhZ2VbJ2RhdGEnXVsnZnJvbSddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5PcGVuU2l0ZVJlcG9ydFRhYj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlblNpdGVSZXBvcnRUYWIsIHsgdXJsLCBmcm9tIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlc2V0IHVzZXIgcnVsZXMgZm9yIGEgc3BlY2lmaWMgcGFnZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmwgVGhlIFVSTCBvZiB0aGUgcGFnZS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgdXNlciBydWxlcyBhcmUgcmVzZXQuXG4gICAgICovXG4gICAgYXN5bmMgcmVzZXRVc2VyUnVsZXNGb3JQYWdlKFxuICAgICAgICB1cmw6IFJlc2V0VXNlclJ1bGVzRm9yUGFnZU1lc3NhZ2VbJ2RhdGEnXVsndXJsJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlJlc2V0VXNlclJ1bGVzRm9yUGFnZT4+IHtcbiAgICAgICAgY29uc3QgW2N1cnJlbnRUYWJdID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuXG4gICAgICAgIGlmICghY3VycmVudFRhYj8uaWQpIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZygnW3Jlc2V0VXNlclJ1bGVzRm9yUGFnZV06IGNhbm5vdCBnZXQgY3VycmVudCB0YWIgaWQnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKFxuICAgICAgICAgICAgTWVzc2FnZVR5cGUuUmVzZXRVc2VyUnVsZXNGb3JQYWdlLFxuICAgICAgICAgICAgeyB1cmwsIHRhYklkOiBjdXJyZW50VGFiPy5pZCB9LFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlbW92ZSBhbiBhbGxvd2xpc3QgZG9tYWluLlxuICAgICAqXG4gICAgICogQHBhcmFtIHRhYklkIFRoZSBJRCBvZiB0aGUgdGFiLlxuICAgICAqIEBwYXJhbSB0YWJSZWZyZXNoIFdoZXRoZXIgdGhlIHRhYiBzaG91bGQgYmUgcmVmcmVzaGVkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBkb21haW4gaXMgcmVtb3ZlZC5cbiAgICAgKi9cbiAgICBhc3luYyByZW1vdmVBbGxvd2xpc3REb21haW4oXG4gICAgICAgIHRhYklkOiBSZW1vdmVBbGxvd2xpc3REb21haW5NZXNzYWdlWydkYXRhJ11bJ3RhYklkJ10sXG4gICAgICAgIHRhYlJlZnJlc2g6IFJlbW92ZUFsbG93bGlzdERvbWFpbk1lc3NhZ2VbJ2RhdGEnXVsndGFiUmVmcmVzaCddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5SZW1vdmVBbGxvd2xpc3REb21haW4+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlbW92ZUFsbG93bGlzdERvbWFpbiwgeyB0YWJJZCwgdGFiUmVmcmVzaCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBhZGQgYW4gYWxsb3dsaXN0IGRvbWFpbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0YWJJZCBUaGUgSUQgb2YgdGhlIHRhYi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgZG9tYWluIGlzIGFkZGVkLlxuICAgICAqL1xuICAgIGFzeW5jIGFkZEFsbG93bGlzdERvbWFpbihcbiAgICAgICAgdGFiSWQ6IEFkZEFsbG93bGlzdERvbWFpbk1lc3NhZ2VbJ2RhdGEnXVsndGFiSWQnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQWRkQWxsb3dsaXN0RG9tYWluPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5BZGRBbGxvd2xpc3REb21haW4sIHsgdGFiSWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogV29ya3Mgb25seSBpbiBNVjIsIHNpbmNlIE1WMyBkb2Vzbid0IHN1cHBvcnQgZmlsdGVyaW5nIGxvZyB5ZXQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIGZpbHRlcmluZyBsb2cgcGFnZSBpcyBvcGVuZWQuXG4gICAgICovXG4gICAgYXN5bmMgb25PcGVuRmlsdGVyaW5nTG9nUGFnZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT25PcGVuRmlsdGVyaW5nTG9nUGFnZT4+IHtcbiAgICAgICAgYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5Pbk9wZW5GaWx0ZXJpbmdMb2dQYWdlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBnZXQgZmlsdGVyaW5nIGxvZyBkYXRhLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggZmlsdGVyaW5nIGxvZyBkYXRhLlxuICAgICAqL1xuICAgIGFzeW5jIGdldEZpbHRlcmluZ0xvZ0RhdGEoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0xvZ0RhdGE+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0xvZ0RhdGEpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGNsb3NlIHRoZSBmaWx0ZXJpbmcgbG9nIHBhZ2UuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHBhZ2UgaXMgY2xvc2VkLlxuICAgICAqL1xuICAgIGFzeW5jIG9uQ2xvc2VGaWx0ZXJpbmdMb2dQYWdlKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5PbkNsb3NlRmlsdGVyaW5nTG9nUGFnZT4+IHtcbiAgICAgICAgYXdhaXQgdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PbkNsb3NlRmlsdGVyaW5nTG9nUGFnZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IGZpbHRlcmluZyBpbmZvIGJ5IHRhYiBJRC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0YWJJZCBUaGUgSUQgb2YgdGhlIHRhYi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGZpbHRlcmluZyBpbmZvIGFib3V0IHRoZSB0YWIuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQoXG4gICAgICAgIHRhYklkOiBHZXRGaWx0ZXJpbmdJbmZvQnlUYWJJZE1lc3NhZ2VbJ2RhdGEnXVsndGFiSWQnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldEZpbHRlcmluZ0luZm9CeVRhYklkLCB7IHRhYklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHN5bmNocm9uaXplIHRoZSBsaXN0IG9mIG9wZW4gdGFicy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGFuIGFycmF5IG9mIGZpbHRlcmluZyBpbmZvIGFib3V0IG9wZW4gdGFicy5cbiAgICAgKi9cbiAgICBhc3luYyBzeW5jaHJvbml6ZU9wZW5UYWJzKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5TeW5jaHJvbml6ZU9wZW5UYWJzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TeW5jaHJvbml6ZU9wZW5UYWJzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjbGVhciBldmVudHMgYnkgdGFiIElELlxuICAgICAqXG4gICAgICogQHBhcmFtIHRhYklkIFRoZSBJRCBvZiB0aGUgdGFiLlxuICAgICAqIEBwYXJhbSBpZ25vcmVQcmVzZXJ2ZUxvZyBPcHRpb25hbCBmbGFnIHRvIGlnbm9yZSB0aGUgcHJlc2VydmUgbG9nIHN0YXRlLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBldmVudHMgYXJlIGNsZWFyZWQuXG4gICAgICovXG4gICAgYXN5bmMgY2xlYXJFdmVudHNCeVRhYklkKFxuICAgICAgICB0YWJJZDogQ2xlYXJFdmVudHNCeVRhYklkTWVzc2FnZVsnZGF0YSddWyd0YWJJZCddLFxuICAgICAgICBpZ25vcmVQcmVzZXJ2ZUxvZz86IENsZWFyRXZlbnRzQnlUYWJJZE1lc3NhZ2VbJ2RhdGEnXVsnaWdub3JlUHJlc2VydmVMb2cnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQ2xlYXJFdmVudHNCeVRhYklkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DbGVhckV2ZW50c0J5VGFiSWQsIHsgdGFiSWQsIGlnbm9yZVByZXNlcnZlTG9nIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlZnJlc2ggdGhlIGN1cnJlbnQgcGFnZSBieSB0YWIgSUQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGFiSWQgVGhlIElEIG9mIHRoZSB0YWIuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIHBhZ2UgaXMgcmVmcmVzaGVkLlxuICAgICAqL1xuICAgIGFzeW5jIHJlZnJlc2hQYWdlKFxuICAgICAgICB0YWJJZDogUmVmcmVzaFBhZ2VNZXNzYWdlWydkYXRhJ11bJ3RhYklkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlZnJlc2hQYWdlLCB7IHRhYklkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGFkZCBhIHVzZXIgcnVsZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBydWxlVGV4dCBVc2VyIHJ1bGUgdGV4dCB0byBiZSBhZGRlZC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyBhZnRlciB0aGUgbWVzc2FnZSBpcyBzZW50LlxuICAgICAqL1xuICAgIGFzeW5jIGFkZFVzZXJSdWxlKFxuICAgICAgICBydWxlVGV4dDogQWRkVXNlclJ1bGVNZXNzYWdlWydkYXRhJ11bJ3J1bGVUZXh0J10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkFkZFVzZXJSdWxlPj4ge1xuICAgICAgICBhd2FpdCB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkFkZFVzZXJSdWxlLCB7IHJ1bGVUZXh0IH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlbW92ZSBhIHVzZXIgcnVsZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBydWxlVGV4dCBVc2VyIHJ1bGUgdGV4dCB0byBiZSByZW1vdmVkLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgcmVtb3ZlVXNlclJ1bGUoXG4gICAgICAgIHJ1bGVUZXh0OiBSZW1vdmVVc2VyUnVsZU1lc3NhZ2VbJ2RhdGEnXVsncnVsZVRleHQnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuUmVtb3ZlVXNlclJ1bGU+PiB7XG4gICAgICAgIGF3YWl0IHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuUmVtb3ZlVXNlclJ1bGUsIHsgcnVsZVRleHQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gc2V0IHRoZSBwcmVzZXJ2ZSBsb2cgc3RhdGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc3RhdGUgU3RhdGUgaW5kaWNhdGluZyB3aGV0aGVyIHRvIHByZXNlcnZlIHRoZSBsb2cuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBzZXRQcmVzZXJ2ZUxvZ1N0YXRlKFxuICAgICAgICBzdGF0ZTogU2V0UHJlc2VydmVMb2dTdGF0ZU1lc3NhZ2VbJ2RhdGEnXVsnc3RhdGUnXSxcbiAgICApOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuU2V0UHJlc2VydmVMb2dTdGF0ZT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuU2V0UHJlc2VydmVMb2dTdGF0ZSwgeyBzdGF0ZSB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBnZXQgdGhlIGVkaXRvciBzdG9yYWdlIGNvbnRlbnQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZWRpdG9yIHN0b3JhZ2UgY29udGVudC5cbiAgICAgKi9cbiAgICBhc3luYyBnZXRFZGl0b3JTdG9yYWdlQ29udGVudCgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldEVkaXRvclN0b3JhZ2VDb250ZW50KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBzZXQgdGhlIGVkaXRvciBzdG9yYWdlIGNvbnRlbnQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY29udGVudCBDb250ZW50IHRvIGJlIHN0b3JlZCBpbiB0aGUgZWRpdG9yLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgc2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQoXG4gICAgICAgIGNvbnRlbnQ6IFNldEVkaXRvclN0b3JhZ2VDb250ZW50TWVzc2FnZVsnZGF0YSddWydjb250ZW50J10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLlNldEVkaXRvclN0b3JhZ2VDb250ZW50Pj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5TZXRFZGl0b3JTdG9yYWdlQ29udGVudCwgeyBjb250ZW50IH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGdldCB0aGUgcnVsZXMgbGltaXRzIGNvdW50ZXJzIGZvciBNVjMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcnVsZXMgbGltaXRzIGNvdW50ZXJzIGZvciBNVjMuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0UnVsZXNMaW1pdHNDb3VudGVycygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuR2V0UnVsZXNMaW1pdHNDb3VudGVyc012Mz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuR2V0UnVsZXNMaW1pdHNDb3VudGVyc012Myk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hlY2sgaWYgaXQgaXMgcG9zc2libGUgdG8gZW5hYmxlIGEgc3RhdGljIGZpbHRlci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWx0ZXJJZCBGaWx0ZXIgSUQgdG8gY2hlY2suXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0IG9mIHRoZSBzdGF0aWMgZmlsdGVyIGNoZWNrLlxuICAgICAqXG4gICAgICogQHRocm93cyBFcnJvciBJZiB0aGUgZmlsdGVyIGlzIG5vdCBzdGF0aWMuXG4gICAgICovXG4gICAgYXN5bmMgY2FuRW5hYmxlU3RhdGljRmlsdGVyKFxuICAgICAgICBmaWx0ZXJJZDogQ2FuRW5hYmxlU3RhdGljRmlsdGVyTXYzTWVzc2FnZVsnZGF0YSddWydmaWx0ZXJJZCddLFxuICAgICk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5DYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkNhbkVuYWJsZVN0YXRpY0ZpbHRlck12MywgeyBmaWx0ZXJJZCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjaGVjayBpZiBhbGwgZHluYW1pYyBydWxlcyBmb3IgYSB1c2VyIHJ1bGVzJyBncm91cCBjYW4gYmUgZW5hYmxlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBncm91cElkIEdyb3VwIGlkZW50aWZpZXIgdG8gY2hlY2suXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0IG9mIHRoZSBzdGF0aWMgZ3JvdXAgY2hlY2suXG4gICAgICovXG4gICAgYXN5bmMgY2FuRW5hYmxlU3RhdGljR3JvdXAoXG4gICAgICAgIGdyb3VwSWQ6IENhbkVuYWJsZVN0YXRpY0dyb3VwTXYzTWVzc2FnZVsnZGF0YSddWydncm91cElkJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNhbkVuYWJsZVN0YXRpY0dyb3VwTXYzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DYW5FbmFibGVTdGF0aWNHcm91cE12MywgeyBncm91cElkIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIGdldCB0aGUgY3VycmVudCBzdGF0aWMgZmlsdGVycyBsaW1pdHMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgY3VycmVudCBzdGF0aWMgZmlsdGVycyBsaW1pdHMuXG4gICAgICovXG4gICAgYXN5bmMgZ2V0Q3VycmVudExpbWl0cygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012Mz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQ3VycmVudExpbWl0c012Myk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gY2hlY2sgaWYgdGhlIHJlcXVlc3QgZmlsdGVyIGlzIHJlYWR5LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIGEgYm9vbGVhbiBpbmRpY2F0aW5nIGlmIHRoZSByZXF1ZXN0IGZpbHRlciBpcyByZWFkeS5cbiAgICAgKi9cbiAgICBhc3luYyBjaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuQ2hlY2tSZXF1ZXN0RmlsdGVyUmVhZHk+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkNoZWNrUmVxdWVzdEZpbHRlclJlYWR5KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBhZGQgYSBVUkwgdG8gdGhlIHRydXN0ZWQgbGlzdC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmwgVVJMIHRvIGJlIGFkZGVkIHRvIHRoZSB0cnVzdGVkIGxpc3QuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyBhZGRVcmxUb1RydXN0ZWQodXJsOiBBZGRVcmxUb1RydXN0ZWRNZXNzYWdlWydkYXRhJ11bJ3VybCddKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkFkZFVybFRvVHJ1c3RlZD4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuQWRkVXJsVG9UcnVzdGVkLCB7IHVybCB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBnZXQgdXNlciBydWxlcyBlZGl0b3IgZGF0YS5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB1c2VyIHJ1bGVzIGVkaXRvciBkYXRhLlxuICAgICAqL1xuICAgIGFzeW5jIGdldFVzZXJSdWxlc0VkaXRvckRhdGEoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc0VkaXRvckRhdGE+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkdldFVzZXJSdWxlc0VkaXRvckRhdGEpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIHJlc3RvcmUgZmlsdGVycyBpbiBNVjMuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgYWZ0ZXIgdGhlIG1lc3NhZ2UgaXMgc2VudC5cbiAgICAgKi9cbiAgICBhc3luYyByZXN0b3JlRmlsdGVyc012MygpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuUmVzdG9yZUZpbHRlcnNNdjM+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLlJlc3RvcmVGaWx0ZXJzTXYzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBjbGVhciB0aGUgcnVsZXMgbGltaXRzIHdhcm5pbmcgaW4gTVYzLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgY2xlYXJSdWxlc0xpbWl0c1dhcm5pbmdNdjMoKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkNsZWFyUnVsZXNMaW1pdHNXYXJuaW5nTXYzPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5DbGVhclJ1bGVzTGltaXRzV2FybmluZ012Myk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gZ2V0IHRoZSBhbGxvd2xpc3QgZG9tYWlucy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBhbGxvd2xpc3QgZG9tYWlucy5cbiAgICAgKi9cbiAgICBhc3luYyBnZXRBbGxvd2xpc3REb21haW5zKCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5HZXRBbGxvd2xpc3REb21haW5zPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5HZXRBbGxvd2xpc3REb21haW5zKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhIG1lc3NhZ2UgdG8gdGhlIGJhY2tncm91bmQgcGFnZSB0byBsb2FkIHRoZSBzZXR0aW5ncyBKU09OLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGxvYWRlZCBzZXR0aW5ncyBKU09OLlxuICAgICAqL1xuICAgIGFzeW5jIGxvYWRTZXR0aW5nc0pzb24oKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLkxvYWRTZXR0aW5nc0pzb24+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkxvYWRTZXR0aW5nc0pzb24pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgbWVzc2FnZSB0byB0aGUgYmFja2dyb3VuZCBwYWdlIHRvIG9wZW4gdGhlIHRoYW5rIHlvdSBwYWdlLlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBtZXNzYWdlIGlzIHNlbnQuXG4gICAgICovXG4gICAgYXN5bmMgb3BlblRoYW5reW91UGFnZSgpOiBQcm9taXNlPEV4dHJhY3RNZXNzYWdlUmVzcG9uc2U8TWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UoTWVzc2FnZVR5cGUuT3BlblRoYW5reW91UGFnZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gaW5pdGlhbGl6ZSB0aGUgZnJhbWUgc2NyaXB0LlxuICAgICAqXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGluaXRpYWxpemF0aW9uIGRhdGEgZm9yIHRoZSBmcmFtZSBzY3JpcHQuXG4gICAgICovXG4gICAgYXN5bmMgaW5pdGlhbGl6ZUZyYW1lU2NyaXB0KCk6IFByb21pc2U8RXh0cmFjdE1lc3NhZ2VSZXNwb25zZTxNZXNzYWdlVHlwZS5Jbml0aWFsaXplRnJhbWVTY3JpcHQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlbmRNZXNzYWdlKE1lc3NhZ2VUeXBlLkluaXRpYWxpemVGcmFtZVNjcmlwdCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBiYWNrZ3JvdW5kIHBhZ2UgdG8gbWFyayB1cmwgYXMgdHJ1c3RlZCBhbmQgaWdub3JlXG4gICAgICogc2FmZWJyb3dzaW5nIGNoZWNrcyBmb3IgaXQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgaW5pdGlhbGl6YXRpb24gZGF0YSBmb3IgdGhlIGZyYW1lIHNjcmlwdC5cbiAgICAgKi9cbiAgICBhc3luYyBvcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZChcbiAgICAgICAgdXJsOiBPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZE1lc3NhZ2VbJ2RhdGEnXVsndXJsJ10sXG4gICAgKTogUHJvbWlzZTxFeHRyYWN0TWVzc2FnZVJlc3BvbnNlPE1lc3NhZ2VUeXBlLk9wZW5TYWZlYnJvd3NpbmdUcnVzdGVkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShNZXNzYWdlVHlwZS5PcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCwgeyB1cmwgfSk7XG4gICAgfVxufVxuXG5jb25zdCBtZXNzZW5nZXIgPSBuZXcgTWVzc2VuZ2VyKCk7XG5cbmV4cG9ydCB7IG1lc3NlbmdlciwgTWVzc2VuZ2VyIH07XG4iLCIvKipcbiAqIEBmaWxlXG4gKiBUaGlzIGZpbGUgaXMgcGFydCBvZiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIChodHRwczovL2dpdGh1Yi5jb20vQWRndWFyZFRlYW0vQWRndWFyZEJyb3dzZXJFeHRlbnNpb24pLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXG4gKiBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuXG4gKiBTZWUgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogWW91IHNob3VsZCBoYXZlIHJlY2VpdmVkIGEgY29weSBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2VcbiAqIGFsb25nIHdpdGggQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbi4gSWYgbm90LCBzZWUgPGh0dHA6Ly93d3cuZ251Lm9yZy9saWNlbnNlcy8+LlxuICovXG5cbmltcG9ydCB7IFVzZXJBZ2VudCB9IGZyb20gJy4uL2NvbW1vbi91c2VyLWFnZW50JztcbmltcG9ydCB7IHR5cGUgUGFnZUluaXRBcHBEYXRhIH0gZnJvbSAnLi4vYmFja2dyb3VuZC9zZXJ2aWNlcyc7XG5cbmltcG9ydCB7IG1lc3NlbmdlciB9IGZyb20gJy4vc2VydmljZXMvbWVzc2VuZ2VyJztcblxuY29uc3QgUGFnZUNvbnRyb2xsZXIgPSAocmVzcG9uc2U6IFBhZ2VJbml0QXBwRGF0YSkgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgICAgdXNlclNldHRpbmdzLFxuICAgICAgICBlbmFibGVkRmlsdGVycyxcbiAgICAgICAgY29uc3RhbnRzOiB7IEFudGlCYW5uZXJGaWx0ZXJzSWQgfSxcbiAgICB9ID0gcmVzcG9uc2U7XG5cbiAgICBsZXQgc2FmZWJyb3dzaW5nRW5hYmxlZENoZWNrYm94OiBIVE1MRWxlbWVudCB8IG51bGwgPSBudWxsO1xuICAgIGxldCB0cmFja2luZ0ZpbHRlckVuYWJsZWRDaGVja2JveDogSFRNTEVsZW1lbnQgfCBudWxsID0gbnVsbDtcbiAgICBsZXQgc29jaWFsRmlsdGVyRW5hYmxlZENoZWNrYm94OiBIVE1MRWxlbWVudCB8IG51bGwgPSBudWxsO1xuICAgIGxldCBzZW5kU3RhdHNDaGVja2JveDogSFRNTEVsZW1lbnQgfCBudWxsID0gbnVsbDtcbiAgICBsZXQgYWxsb3dBY2NlcHRhYmxlQWRzQ2hlY2tib3g6IEhUTUxFbGVtZW50IHwgbnVsbCA9IG51bGw7XG5cbiAgICBjb25zdCBzYWZlYnJvd3NpbmdFbmFibGVkQ2hhbmdlID0gKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGNoZWNrYm94ID0gZS5jdXJyZW50VGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgICAgIG1lc3Nlbmdlci5jaGFuZ2VVc2VyU2V0dGluZyhcbiAgICAgICAgICAgIHVzZXJTZXR0aW5ncy5uYW1lcy5EaXNhYmxlU2FmZWJyb3dzaW5nLFxuICAgICAgICAgICAgIWNoZWNrYm94LmNoZWNrZWQsXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIGNvbnN0IHRyYWNraW5nRmlsdGVyRW5hYmxlZENoYW5nZSA9IChlOiBFdmVudCkgPT4ge1xuICAgICAgICBjb25zdCBjaGVja2JveCA9IGUuY3VycmVudFRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgICBpZiAoY2hlY2tib3guY2hlY2tlZCkge1xuICAgICAgICAgICAgbWVzc2VuZ2VyLmVuYWJsZUZpbHRlcihBbnRpQmFubmVyRmlsdGVyc0lkLlRyYWNraW5nRmlsdGVySWQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbWVzc2VuZ2VyLmRpc2FibGVGaWx0ZXIoQW50aUJhbm5lckZpbHRlcnNJZC5UcmFja2luZ0ZpbHRlcklkKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBzb2NpYWxGaWx0ZXJFbmFibGVkQ2hhbmdlID0gKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGNoZWNrYm94ID0gZS5jdXJyZW50VGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgICAgIGlmIChjaGVja2JveC5jaGVja2VkKSB7XG4gICAgICAgICAgICBtZXNzZW5nZXIuZW5hYmxlRmlsdGVyKEFudGlCYW5uZXJGaWx0ZXJzSWQuU29jaWFsRmlsdGVySWQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbWVzc2VuZ2VyLmRpc2FibGVGaWx0ZXIoQW50aUJhbm5lckZpbHRlcnNJZC5Tb2NpYWxGaWx0ZXJJZCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgc2VuZFN0YXRzQ2hlY2tib3hDaGFuZ2UgPSAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgY2hlY2tib3ggPSBlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICAgICAgbWVzc2VuZ2VyLmNoYW5nZVVzZXJTZXR0aW5nKFxuICAgICAgICAgICAgdXNlclNldHRpbmdzLm5hbWVzLkRpc2FibGVDb2xsZWN0SGl0cyxcbiAgICAgICAgICAgICFjaGVja2JveC5jaGVja2VkLFxuICAgICAgICApO1xuICAgIH07XG5cbiAgICBjb25zdCBhbGxvd0FjY2VwdGFibGVBZHNDaGFuZ2UgPSAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgY2hlY2tib3ggPSBlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICAgICAgaWYgKGNoZWNrYm94LmNoZWNrZWQpIHtcbiAgICAgICAgICAgIG1lc3Nlbmdlci5lbmFibGVGaWx0ZXIoQW50aUJhbm5lckZpbHRlcnNJZC5TZWFyY2hBbmRTZWxmUHJvbW9GaWx0ZXJJZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBtZXNzZW5nZXIuZGlzYWJsZUZpbHRlcihBbnRpQmFubmVyRmlsdGVyc0lkLlNlYXJjaEFuZFNlbGZQcm9tb0ZpbHRlcklkKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBiaW5kRXZlbnRzID0gKCkgPT4ge1xuICAgICAgICBzYWZlYnJvd3NpbmdFbmFibGVkQ2hlY2tib3ggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2FmZWJyb3dzaW5nRW5hYmxlZENoZWNrYm94Jyk7XG4gICAgICAgIHRyYWNraW5nRmlsdGVyRW5hYmxlZENoZWNrYm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RyYWNraW5nRmlsdGVyRW5hYmxlZENoZWNrYm94Jyk7XG4gICAgICAgIHNvY2lhbEZpbHRlckVuYWJsZWRDaGVja2JveCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzb2NpYWxGaWx0ZXJFbmFibGVkQ2hlY2tib3gnKTtcbiAgICAgICAgLy8gc2VuZFNhZmVicm93c2luZ1N0YXRzQ2hlY2tib3ggLSBpZCBzYXZlZCwgYmVjYXVzZSBpdCBzaG91bGQgYmUgY2hhbmdlZCBvbiB0aGFua3lvdSBwYWdlXG4gICAgICAgIHNlbmRTdGF0c0NoZWNrYm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NlbmRTYWZlYnJvd3NpbmdTdGF0c0NoZWNrYm94Jyk7XG4gICAgICAgIGFsbG93QWNjZXB0YWJsZUFkc0NoZWNrYm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FsbG93QWNjZXB0YWJsZUFkcycpO1xuXG4gICAgICAgIHNhZmVicm93c2luZ0VuYWJsZWRDaGVja2JveD8uYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgc2FmZWJyb3dzaW5nRW5hYmxlZENoYW5nZSk7XG4gICAgICAgIHRyYWNraW5nRmlsdGVyRW5hYmxlZENoZWNrYm94Py5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB0cmFja2luZ0ZpbHRlckVuYWJsZWRDaGFuZ2UpO1xuICAgICAgICBzb2NpYWxGaWx0ZXJFbmFibGVkQ2hlY2tib3g/LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIHNvY2lhbEZpbHRlckVuYWJsZWRDaGFuZ2UpO1xuICAgICAgICAvLyBpZ25vcmUgRmlyZWZveCwgc2VlIHRhc2sgQUctMjMyMlxuICAgICAgICBpZiAoIVVzZXJBZ2VudC5pc0ZpcmVmb3gpIHtcbiAgICAgICAgICAgIHNlbmRTdGF0c0NoZWNrYm94Py5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBzZW5kU3RhdHNDaGVja2JveENoYW5nZSk7XG4gICAgICAgIH1cbiAgICAgICAgYWxsb3dBY2NlcHRhYmxlQWRzQ2hlY2tib3g/LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGFsbG93QWNjZXB0YWJsZUFkc0NoYW5nZSk7XG5cbiAgICAgICAgY29uc3Qgb3BlbkV4dGVuc2lvblN0b3JlQnRuczogSFRNTEVsZW1lbnRbXSA9IFtdLnNsaWNlLmNhbGwoZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLm9wZW5FeHRlbnNpb25TdG9yZScpKTtcbiAgICAgICAgb3BlbkV4dGVuc2lvblN0b3JlQnRucy5mb3JFYWNoKChvcGVuRXh0ZW5zaW9uU3RvcmVCdG4pID0+IHtcbiAgICAgICAgICAgIG9wZW5FeHRlbnNpb25TdG9yZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICBtZXNzZW5nZXIub3BlbkV4dGVuc2lvblN0b3JlKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3Qgb3BlblNldHRpbmdzQnRuczogSFRNTEVsZW1lbnRbXSA9IFtdLnNsaWNlLmNhbGwoZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLm9wZW5TZXR0aW5ncycpKTtcbiAgICAgICAgb3BlblNldHRpbmdzQnRucy5mb3JFYWNoKChvcGVuU2V0dGluZ3NCdG4pID0+IHtcbiAgICAgICAgICAgIG9wZW5TZXR0aW5nc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIG1lc3Nlbmdlci5vcGVuU2V0dGluZ3NUYWIoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgdXBkYXRlQ2hlY2tib3ggPSAoY2hlY2tib3g6IEhUTUxFbGVtZW50IHwgbnVsbCwgZW5hYmxlZDogYm9vbGVhbikgPT4ge1xuICAgICAgICBpZiAoIWNoZWNrYm94KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGVuYWJsZWQpIHtcbiAgICAgICAgICAgIGNoZWNrYm94LnNldEF0dHJpYnV0ZSgnY2hlY2tlZCcsICdjaGVja2VkJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjaGVja2JveC5yZW1vdmVBdHRyaWJ1dGUoJ2NoZWNrZWQnKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCByZW5kZXIgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHRyYWNraW5nRmlsdGVyRW5hYmxlZCA9IEFudGlCYW5uZXJGaWx0ZXJzSWQuVHJhY2tpbmdGaWx0ZXJJZCBpbiBlbmFibGVkRmlsdGVycztcbiAgICAgICAgY29uc3Qgc29jaWFsRmlsdGVyRW5hYmxlZCA9IEFudGlCYW5uZXJGaWx0ZXJzSWQuU29jaWFsRmlsdGVySWQgaW4gZW5hYmxlZEZpbHRlcnM7XG4gICAgICAgIGNvbnN0IGFsbG93QWNjZXB0YWJsZUFkc0VuYWJsZWQgPSBBbnRpQmFubmVyRmlsdGVyc0lkLlNlYXJjaEFuZFNlbGZQcm9tb0ZpbHRlcklkIGluIGVuYWJsZWRGaWx0ZXJzO1xuICAgICAgICBjb25zdCBjb2xsZWN0SGl0c0NvdW50ID0gIXVzZXJTZXR0aW5ncy52YWx1ZXNbdXNlclNldHRpbmdzLm5hbWVzLkRpc2FibGVDb2xsZWN0SGl0c107XG5cbiAgICAgICAgaWYgKCFfX0lTX01WM19fKSB7XG4gICAgICAgICAgICBjb25zdCBzYWZlYnJvd3NpbmdFbmFibGVkID0gIXVzZXJTZXR0aW5ncy52YWx1ZXNbdXNlclNldHRpbmdzLm5hbWVzLkRpc2FibGVTYWZlYnJvd3NpbmddO1xuICAgICAgICAgICAgdXBkYXRlQ2hlY2tib3goc2FmZWJyb3dzaW5nRW5hYmxlZENoZWNrYm94LCBzYWZlYnJvd3NpbmdFbmFibGVkKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHVwZGF0ZUNoZWNrYm94KHRyYWNraW5nRmlsdGVyRW5hYmxlZENoZWNrYm94LCB0cmFja2luZ0ZpbHRlckVuYWJsZWQpO1xuICAgICAgICB1cGRhdGVDaGVja2JveChzb2NpYWxGaWx0ZXJFbmFibGVkQ2hlY2tib3gsIHNvY2lhbEZpbHRlckVuYWJsZWQpO1xuICAgICAgICB1cGRhdGVDaGVja2JveChhbGxvd0FjY2VwdGFibGVBZHNDaGVja2JveCwgYWxsb3dBY2NlcHRhYmxlQWRzRW5hYmxlZCk7XG4gICAgICAgIHVwZGF0ZUNoZWNrYm94KHNlbmRTdGF0c0NoZWNrYm94LCBjb2xsZWN0SGl0c0NvdW50KTtcbiAgICB9O1xuXG4gICAgY29uc3QgaW5pdCA9ICgpID0+IHtcbiAgICAgICAgYmluZEV2ZW50cygpO1xuICAgICAgICByZW5kZXIoKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW5pdCxcbiAgICB9O1xufTtcblxubGV0IHRpbWVvdXRJZDogbnVtYmVyO1xubGV0IGNvdW50ZXIgPSAwO1xuY29uc3QgTUFYX1dBSVRfUkVUUlkgPSAxMDtcbmNvbnN0IFJFVFJZX1RJTUVPVVRfTVMgPSAxMDA7XG5jb25zdCBpbml0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgbWVzc2VuZ2VyID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICBpZiAoY291bnRlciA+IE1BWF9XQUlUX1JFVFJZKSB7XG4gICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGltZW91dElkID0gd2luZG93LnNldFRpbWVvdXQoaW5pdCwgUkVUUllfVElNRU9VVF9NUyk7XG4gICAgICAgIGNvdW50ZXIgKz0gMTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGltZW91dElkKTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgbWVzc2VuZ2VyLmluaXRpYWxpemVGcmFtZVNjcmlwdCgpO1xuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBQYWdlQ29udHJvbGxlcihyZXNwb25zZSk7XG5cbiAgICBpZiAoZG9jdW1lbnQucmVhZHlTdGF0ZSA9PT0gJ2xvYWRpbmcnKSB7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCAoKSA9PiB7XG4gICAgICAgICAgICBjb250cm9sbGVyLmluaXQoKTtcbiAgICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgY29udHJvbGxlci5pbml0KCk7XG4gICAgfVxufTtcblxuZXhwb3J0IGNvbnN0IHRoYW5reW91ID0ge1xuICAgIGluaXQsXG59O1xuIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG4vLyBUT0RPOiBnZW5lcmF0ZSB0b29scy9idW5kbGUvbWFuaWZlc3QuY29tbW9uLmpzb24gd2l0aCB0aGlzIGNvbnN0YW50c1xuXG5leHBvcnQgY29uc3QgV0VCX0FDQ0VTU0lCTEVfUkVTT1VSQ0VTX09VVFBVVCA9ICd3ZWItYWNjZXNzaWJsZS1yZXNvdXJjZXMnO1xuZXhwb3J0IGNvbnN0IFdFQl9BQ0NFU1NJQkxFX1JFU09VUkNFU19PVVRQVVRfUkVESVJFQ1RTID0gYCR7V0VCX0FDQ0VTU0lCTEVfUkVTT1VSQ0VTX09VVFBVVH0vcmVkaXJlY3RzYDtcblxuZXhwb3J0IGNvbnN0IEJBQ0tHUk9VTkRfT1VUUFVUID0gJ3BhZ2VzL2JhY2tncm91bmQnO1xuZXhwb3J0IGNvbnN0IE9QVElPTlNfT1VUUFVUID0gJ3BhZ2VzL29wdGlvbnMnO1xuZXhwb3J0IGNvbnN0IFBPUFVQX09VVFBVVCA9ICdwYWdlcy9wb3B1cCc7XG5leHBvcnQgY29uc3QgRklMVEVSSU5HX0xPR19PVVRQVVQgPSAncGFnZXMvZmlsdGVyaW5nLWxvZyc7XG5leHBvcnQgY29uc3QgUE9TVF9JTlNUQUxMX09VVFBVVCA9ICdwYWdlcy9wb3N0LWluc3RhbGwnO1xuZXhwb3J0IGNvbnN0IEZVTExTQ1JFRU5fVVNFUl9SVUxFU19PVVRQVVQgPSAncGFnZXMvZnVsbHNjcmVlbi11c2VyLXJ1bGVzJztcbmV4cG9ydCBjb25zdCBTQUZFQlJPV1NJTkdfT1VUUFVUID0gJ3BhZ2VzL3NhZmVicm93c2luZyc7XG5leHBvcnQgY29uc3QgRE9DVU1FTlRfQkxPQ0tfT1VUUFVUID0gJ3BhZ2VzL2FkLWJsb2NrZWQnO1xuZXhwb3J0IGNvbnN0IFNVQlNDUklCRV9PVVRQVVQgPSAncGFnZXMvc3Vic2NyaWJlJztcbmV4cG9ydCBjb25zdCBDT05URU5UX1NDUklQVF9TVEFSVF9PVVRQVVQgPSAncGFnZXMvY29udGVudC1zY3JpcHQtc3RhcnQnO1xuZXhwb3J0IGNvbnN0IENPTlRFTlRfU0NSSVBUX0VORF9PVVRQVVQgPSAncGFnZXMvY29udGVudC1zY3JpcHQtZW5kJztcbmV4cG9ydCBjb25zdCBUSEFOS1lPVV9PVVRQVVQgPSAncGFnZXMvdGhhbmt5b3UnO1xuZXhwb3J0IGNvbnN0IEFTU0lTVEFOVF9JTkpFQ1RfT1VUUFVUID0gJ3BhZ2VzL2Fzc2lzdGFudC1pbmplY3QnO1xuZXhwb3J0IGNvbnN0IEdQQ19TQ1JJUFRfT1VUUFVUID0gJ3BhZ2VzL2dwYyc7XG5leHBvcnQgY29uc3QgSElERV9ET0NVTUVOVF9SRUZFUlJFUl9PVVRQVVQgPSAncGFnZXMvaGlkZS1kb2N1bWVudC1yZWZlcnJlcic7XG5leHBvcnQgY29uc3QgREVWVE9PTFNfT1VUUFVUID0gJ3BhZ2VzL2RldnRvb2xzJztcbmV4cG9ydCBjb25zdCBERVZUT09MU19FTEVNRU5UX1NJREVCQVJfT1VUUFVUID0gJ3BhZ2VzL2RldnRvb2xzLWVsZW1lbnRzLXNpZGViYXInO1xuXG5leHBvcnQgY29uc3QgU0hBUkVEX0VESVRPUl9PVVRQVVQgPSAnc2hhcmVkL2VkaXRvcic7XG5cbmV4cG9ydCBjb25zdCBSRUFDVF9WRU5ET1JfT1VUUFVUID0gJ3ZlbmRvcnMvcmVhY3QnO1xuZXhwb3J0IGNvbnN0IE1PQlhfVkVORE9SX09VVFBVVCA9ICd2ZW5kb3JzL21vYngnO1xuZXhwb3J0IGNvbnN0IFhTVEFURV9WRU5ET1JfT1VUUFVUID0gJ3ZlbmRvcnMveHN0YXRlJztcbmV4cG9ydCBjb25zdCBUU1VSTEZJTFRFUl9WRU5ET1JfT1VUUFVUID0gJ3ZlbmRvcnMvdHN1cmxmaWx0ZXInO1xuZXhwb3J0IGNvbnN0IEFHVFJFRV9WRU5ET1JfT1VUUFVUID0gJ3ZlbmRvcnMvYWd0cmVlJztcbmV4cG9ydCBjb25zdCBDU1NfVE9LRU5JWkVSX1ZFTkRPUl9PVVRQVVQgPSAndmVuZG9ycy9jc3MtdG9rZW5pemVyJztcbmV4cG9ydCBjb25zdCBUU1dFQkVYVEVOU0lPTl9WRU5ET1JfT1VUUFVUID0gJ3ZlbmRvcnMvdHN3ZWJleHRlbnNpb24nO1xuZXhwb3J0IGNvbnN0IFRFWFRfRU5DT0RJTkdfUE9MWUZJTExfVkVORE9SX09VVFBVVCA9ICd2ZW5kb3JzL3RleHQtZW5jb2RpbmctcG9seWZpbGwnO1xuZXhwb3J0IGNvbnN0IFNDUklQVExFVFNfVkVORE9SX09VVFBVVCA9ICd2ZW5kb3JzL3NjcmlwdGxldHMnO1xuXG4vLyBQbGFjZWQgaGVyZSB0byB1c2UgaW4gdGhlIG5vZGUgZW52aXJvbm1lbnQgYW5kIGluIHRoZSBicm93c2VyXG4vLyBJbXBvcnRhbnQ6IGV4dGVuc2lvbnMgJy5qcycgdXNlZCBmb3IgY29ycmVjdCB3b3JrIG9mIENsb3VkZmxhcmUgY2FjaGUsIGJ1dFxuLy8gcmVhbCBmb3JtYXQgb2YgdGhlc2UgZmlsZXMgaXMgSlNPTi5cbi8vIFNlZSBBRy0xOTAxIGZvciBkZXRhaWxzLlxuZXhwb3J0IGNvbnN0IFJFTU9URV9NRVRBREFUQV9GSUxFX05BTUUgPSAnZmlsdGVycy5qcyc7XG5leHBvcnQgY29uc3QgUkVNT1RFX0kxOE5fTUVUQURBVEFfRklMRV9OQU1FID0gJ2ZpbHRlcnNfaTE4bi5qcyc7XG4vLyBCdXQgbG9jYWxseSB3ZSBwcmVmZXIgdG8gdXNlICcuanNvbicgZXh0ZW5zaW9uLlxuZXhwb3J0IGNvbnN0IExPQ0FMX01FVEFEQVRBX0ZJTEVfTkFNRSA9ICdmaWx0ZXJzLmpzb24nO1xuZXhwb3J0IGNvbnN0IExPQ0FMX0kxOE5fTUVUQURBVEFfRklMRV9OQU1FID0gJ2ZpbHRlcnNfaTE4bi5qc29uJztcblxuLyoqXG4gKiBMaXN0IG9mIEFkR3VhcmQgZmlsdGVycyBJRHMuXG4gKlxuICogYDEyYCBpcyBhYnNlbnQgYmVjYXVzZSBTYWZhcmkgZmlsdGVyIGlmIG9ic29sZXRlIGFuZCBub3QgdXNlZCBhbnltb3JlLlxuICovXG5leHBvcnQgY29uc3QgQURHVUFSRF9GSUxURVJTX0lEUyA9IFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEzLCAxNCwgMTUsIDE2LCAxNywgMTgsIDE5LCAyMCwgMjEsIDIyLCAyMywgMjI0XTtcblxuLyoqXG4gKiBNaW5pbXVtIHN1cHBvcnRlZCBicm93c2VyIHZlcnNpb25zLlxuICpcbiAqIElNUE9SVEFOVCEgVXBkYXRlIGJyb3dzZXIgY29tcGF0aWJpbGl0eSBpbiB0aGUgUkVBRE1FLm1kIGZpbGUgd2hlbiBjaGFuZ2luZyB0aGUgdmVyc2lvbnMuXG4gKi9cbmV4cG9ydCBjb25zdCBNSU5fU1VQUE9SVEVEX1ZFUlNJT04gPSB7XG4gICAgQ0hST01JVU1fTVYyOiA3OSxcbiAgICBDSFJPTUlVTV9NVjM6IDEyMSxcbiAgICBGSVJFRk9YOiA3OCxcbiAgICBGSVJFRk9YX01PQklMRTogMTEzLFxuICAgIE9QRVJBOiA2NyxcbiAgICBFREdFX0NIUk9NSVVNOiA4MCxcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIHRyeVRvU3RyaW5nID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RyeS10by1zdHJpbmcnKTtcblxudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG5cbi8vIGBBc3NlcnQ6IElzQ2FsbGFibGUoYXJndW1lbnQpIGlzIHRydWVgXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICBpZiAoaXNDYWxsYWJsZShhcmd1bWVudCkpIHJldHVybiBhcmd1bWVudDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IodHJ5VG9TdHJpbmcoYXJndW1lbnQpICsgJyBpcyBub3QgYSBmdW5jdGlvbicpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc1Bvc3NpYmxlUHJvdG90eXBlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLXBvc3NpYmxlLXByb3RvdHlwZScpO1xuXG52YXIgJFN0cmluZyA9IFN0cmluZztcbnZhciAkVHlwZUVycm9yID0gVHlwZUVycm9yO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICBpZiAoaXNQb3NzaWJsZVByb3RvdHlwZShhcmd1bWVudCkpIHJldHVybiBhcmd1bWVudDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IoXCJDYW4ndCBzZXQgXCIgKyAkU3RyaW5nKGFyZ3VtZW50KSArICcgYXMgYSBwcm90b3R5cGUnKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgd2VsbEtub3duU3ltYm9sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sJyk7XG52YXIgY3JlYXRlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1jcmVhdGUnKTtcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5JykuZjtcblxudmFyIFVOU0NPUEFCTEVTID0gd2VsbEtub3duU3ltYm9sKCd1bnNjb3BhYmxlcycpO1xudmFyIEFycmF5UHJvdG90eXBlID0gQXJyYXkucHJvdG90eXBlO1xuXG4vLyBBcnJheS5wcm90b3R5cGVbQEB1bnNjb3BhYmxlc11cbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtYXJyYXkucHJvdG90eXBlLUBAdW5zY29wYWJsZXNcbmlmIChBcnJheVByb3RvdHlwZVtVTlNDT1BBQkxFU10gPT09IHVuZGVmaW5lZCkge1xuICBkZWZpbmVQcm9wZXJ0eShBcnJheVByb3RvdHlwZSwgVU5TQ09QQUJMRVMsIHtcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgdmFsdWU6IGNyZWF0ZShudWxsKVxuICB9KTtcbn1cblxuLy8gYWRkIGEga2V5IHRvIEFycmF5LnByb3RvdHlwZVtAQHVuc2NvcGFibGVzXVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIEFycmF5UHJvdG90eXBlW1VOU0NPUEFCTEVTXVtrZXldID0gdHJ1ZTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG5cbnZhciAkU3RyaW5nID0gU3RyaW5nO1xudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG5cbi8vIGBBc3NlcnQ6IFR5cGUoYXJndW1lbnQpIGlzIE9iamVjdGBcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyZ3VtZW50KSB7XG4gIGlmIChpc09iamVjdChhcmd1bWVudCkpIHJldHVybiBhcmd1bWVudDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IoJFN0cmluZyhhcmd1bWVudCkgKyAnIGlzIG5vdCBhbiBvYmplY3QnKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9JbmRleGVkT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLWluZGV4ZWQtb2JqZWN0Jyk7XG52YXIgdG9BYnNvbHV0ZUluZGV4ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLWFic29sdXRlLWluZGV4Jyk7XG52YXIgbGVuZ3RoT2ZBcnJheUxpa2UgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvbGVuZ3RoLW9mLWFycmF5LWxpa2UnKTtcblxuLy8gYEFycmF5LnByb3RvdHlwZS57IGluZGV4T2YsIGluY2x1ZGVzIH1gIG1ldGhvZHMgaW1wbGVtZW50YXRpb25cbnZhciBjcmVhdGVNZXRob2QgPSBmdW5jdGlvbiAoSVNfSU5DTFVERVMpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICgkdGhpcywgZWwsIGZyb21JbmRleCkge1xuICAgIHZhciBPID0gdG9JbmRleGVkT2JqZWN0KCR0aGlzKTtcbiAgICB2YXIgbGVuZ3RoID0gbGVuZ3RoT2ZBcnJheUxpa2UoTyk7XG4gICAgaWYgKGxlbmd0aCA9PT0gMCkgcmV0dXJuICFJU19JTkNMVURFUyAmJiAtMTtcbiAgICB2YXIgaW5kZXggPSB0b0Fic29sdXRlSW5kZXgoZnJvbUluZGV4LCBsZW5ndGgpO1xuICAgIHZhciB2YWx1ZTtcbiAgICAvLyBBcnJheSNpbmNsdWRlcyB1c2VzIFNhbWVWYWx1ZVplcm8gZXF1YWxpdHkgYWxnb3JpdGhtXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXNlbGYtY29tcGFyZSAtLSBOYU4gY2hlY2tcbiAgICBpZiAoSVNfSU5DTFVERVMgJiYgZWwgIT09IGVsKSB3aGlsZSAobGVuZ3RoID4gaW5kZXgpIHtcbiAgICAgIHZhbHVlID0gT1tpbmRleCsrXTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zZWxmLWNvbXBhcmUgLS0gTmFOIGNoZWNrXG4gICAgICBpZiAodmFsdWUgIT09IHZhbHVlKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBBcnJheSNpbmRleE9mIGlnbm9yZXMgaG9sZXMsIEFycmF5I2luY2x1ZGVzIC0gbm90XG4gICAgfSBlbHNlIGZvciAoO2xlbmd0aCA+IGluZGV4OyBpbmRleCsrKSB7XG4gICAgICBpZiAoKElTX0lOQ0xVREVTIHx8IGluZGV4IGluIE8pICYmIE9baW5kZXhdID09PSBlbCkgcmV0dXJuIElTX0lOQ0xVREVTIHx8IGluZGV4IHx8IDA7XG4gICAgfSByZXR1cm4gIUlTX0lOQ0xVREVTICYmIC0xO1xuICB9O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIC8vIGBBcnJheS5wcm90b3R5cGUuaW5jbHVkZXNgIG1ldGhvZFxuICAvLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWFycmF5LnByb3RvdHlwZS5pbmNsdWRlc1xuICBpbmNsdWRlczogY3JlYXRlTWV0aG9kKHRydWUpLFxuICAvLyBgQXJyYXkucHJvdG90eXBlLmluZGV4T2ZgIG1ldGhvZFxuICAvLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWFycmF5LnByb3RvdHlwZS5pbmRleG9mXG4gIGluZGV4T2Y6IGNyZWF0ZU1ldGhvZChmYWxzZSlcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdW5jdXJyeVRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzJyk7XG5cbnZhciB0b1N0cmluZyA9IHVuY3VycnlUaGlzKHt9LnRvU3RyaW5nKTtcbnZhciBzdHJpbmdTbGljZSA9IHVuY3VycnlUaGlzKCcnLnNsaWNlKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIHN0cmluZ1NsaWNlKHRvU3RyaW5nKGl0KSwgOCwgLTEpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBUT19TVFJJTkdfVEFHX1NVUFBPUlQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8tc3RyaW5nLXRhZy1zdXBwb3J0Jyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIGNsYXNzb2ZSYXcgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY2xhc3NvZi1yYXcnKTtcbnZhciB3ZWxsS25vd25TeW1ib2wgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvd2VsbC1rbm93bi1zeW1ib2wnKTtcblxudmFyIFRPX1NUUklOR19UQUcgPSB3ZWxsS25vd25TeW1ib2woJ3RvU3RyaW5nVGFnJyk7XG52YXIgJE9iamVjdCA9IE9iamVjdDtcblxuLy8gRVMzIHdyb25nIGhlcmVcbnZhciBDT1JSRUNUX0FSR1VNRU5UUyA9IGNsYXNzb2ZSYXcoZnVuY3Rpb24gKCkgeyByZXR1cm4gYXJndW1lbnRzOyB9KCkpID09PSAnQXJndW1lbnRzJztcblxuLy8gZmFsbGJhY2sgZm9yIElFMTEgU2NyaXB0IEFjY2VzcyBEZW5pZWQgZXJyb3JcbnZhciB0cnlHZXQgPSBmdW5jdGlvbiAoaXQsIGtleSkge1xuICB0cnkge1xuICAgIHJldHVybiBpdFtrZXldO1xuICB9IGNhdGNoIChlcnJvcikgeyAvKiBlbXB0eSAqLyB9XG59O1xuXG4vLyBnZXR0aW5nIHRhZyBmcm9tIEVTNisgYE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmdgXG5tb2R1bGUuZXhwb3J0cyA9IFRPX1NUUklOR19UQUdfU1VQUE9SVCA/IGNsYXNzb2ZSYXcgOiBmdW5jdGlvbiAoaXQpIHtcbiAgdmFyIE8sIHRhZywgcmVzdWx0O1xuICByZXR1cm4gaXQgPT09IHVuZGVmaW5lZCA/ICdVbmRlZmluZWQnIDogaXQgPT09IG51bGwgPyAnTnVsbCdcbiAgICAvLyBAQHRvU3RyaW5nVGFnIGNhc2VcbiAgICA6IHR5cGVvZiAodGFnID0gdHJ5R2V0KE8gPSAkT2JqZWN0KGl0KSwgVE9fU1RSSU5HX1RBRykpID09ICdzdHJpbmcnID8gdGFnXG4gICAgLy8gYnVpbHRpblRhZyBjYXNlXG4gICAgOiBDT1JSRUNUX0FSR1VNRU5UUyA/IGNsYXNzb2ZSYXcoTylcbiAgICAvLyBFUzMgYXJndW1lbnRzIGZhbGxiYWNrXG4gICAgOiAocmVzdWx0ID0gY2xhc3NvZlJhdyhPKSkgPT09ICdPYmplY3QnICYmIGlzQ2FsbGFibGUoTy5jYWxsZWUpID8gJ0FyZ3VtZW50cycgOiByZXN1bHQ7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgb3duS2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vd24ta2V5cycpO1xudmFyIGdldE93blByb3BlcnR5RGVzY3JpcHRvck1vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1kZXNjcmlwdG9yJyk7XG52YXIgZGVmaW5lUHJvcGVydHlNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uICh0YXJnZXQsIHNvdXJjZSwgZXhjZXB0aW9ucykge1xuICB2YXIga2V5cyA9IG93bktleXMoc291cmNlKTtcbiAgdmFyIGRlZmluZVByb3BlcnR5ID0gZGVmaW5lUHJvcGVydHlNb2R1bGUuZjtcbiAgdmFyIGdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvck1vZHVsZS5mO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIga2V5ID0ga2V5c1tpXTtcbiAgICBpZiAoIWhhc093bih0YXJnZXQsIGtleSkgJiYgIShleGNlcHRpb25zICYmIGhhc093bihleGNlcHRpb25zLCBrZXkpKSkge1xuICAgICAgZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIGdldE93blByb3BlcnR5RGVzY3JpcHRvcihzb3VyY2UsIGtleSkpO1xuICAgIH1cbiAgfVxufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xudmFyIGRlZmluZVByb3BlcnR5TW9kdWxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1kZWZpbmUtcHJvcGVydHknKTtcbnZhciBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3InKTtcblxubW9kdWxlLmV4cG9ydHMgPSBERVNDUklQVE9SUyA/IGZ1bmN0aW9uIChvYmplY3QsIGtleSwgdmFsdWUpIHtcbiAgcmV0dXJuIGRlZmluZVByb3BlcnR5TW9kdWxlLmYob2JqZWN0LCBrZXksIGNyZWF0ZVByb3BlcnR5RGVzY3JpcHRvcigxLCB2YWx1ZSkpO1xufSA6IGZ1bmN0aW9uIChvYmplY3QsIGtleSwgdmFsdWUpIHtcbiAgb2JqZWN0W2tleV0gPSB2YWx1ZTtcbiAgcmV0dXJuIG9iamVjdDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChiaXRtYXAsIHZhbHVlKSB7XG4gIHJldHVybiB7XG4gICAgZW51bWVyYWJsZTogIShiaXRtYXAgJiAxKSxcbiAgICBjb25maWd1cmFibGU6ICEoYml0bWFwICYgMiksXG4gICAgd3JpdGFibGU6ICEoYml0bWFwICYgNCksXG4gICAgdmFsdWU6IHZhbHVlXG4gIH07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIG1ha2VCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL21ha2UtYnVpbHQtaW4nKTtcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5Jyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHRhcmdldCwgbmFtZSwgZGVzY3JpcHRvcikge1xuICBpZiAoZGVzY3JpcHRvci5nZXQpIG1ha2VCdWlsdEluKGRlc2NyaXB0b3IuZ2V0LCBuYW1lLCB7IGdldHRlcjogdHJ1ZSB9KTtcbiAgaWYgKGRlc2NyaXB0b3Iuc2V0KSBtYWtlQnVpbHRJbihkZXNjcmlwdG9yLnNldCwgbmFtZSwgeyBzZXR0ZXI6IHRydWUgfSk7XG4gIHJldHVybiBkZWZpbmVQcm9wZXJ0eS5mKHRhcmdldCwgbmFtZSwgZGVzY3JpcHRvcik7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcbnZhciBkZWZpbmVQcm9wZXJ0eU1vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZGVmaW5lLXByb3BlcnR5Jyk7XG52YXIgbWFrZUJ1aWx0SW4gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvbWFrZS1idWlsdC1pbicpO1xudmFyIGRlZmluZUdsb2JhbFByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHknKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoTywga2V5LCB2YWx1ZSwgb3B0aW9ucykge1xuICBpZiAoIW9wdGlvbnMpIG9wdGlvbnMgPSB7fTtcbiAgdmFyIHNpbXBsZSA9IG9wdGlvbnMuZW51bWVyYWJsZTtcbiAgdmFyIG5hbWUgPSBvcHRpb25zLm5hbWUgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMubmFtZSA6IGtleTtcbiAgaWYgKGlzQ2FsbGFibGUodmFsdWUpKSBtYWtlQnVpbHRJbih2YWx1ZSwgbmFtZSwgb3B0aW9ucyk7XG4gIGlmIChvcHRpb25zLmdsb2JhbCkge1xuICAgIGlmIChzaW1wbGUpIE9ba2V5XSA9IHZhbHVlO1xuICAgIGVsc2UgZGVmaW5lR2xvYmFsUHJvcGVydHkoa2V5LCB2YWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICghb3B0aW9ucy51bnNhZmUpIGRlbGV0ZSBPW2tleV07XG4gICAgICBlbHNlIGlmIChPW2tleV0pIHNpbXBsZSA9IHRydWU7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHsgLyogZW1wdHkgKi8gfVxuICAgIGlmIChzaW1wbGUpIE9ba2V5XSA9IHZhbHVlO1xuICAgIGVsc2UgZGVmaW5lUHJvcGVydHlNb2R1bGUuZihPLCBrZXksIHtcbiAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgY29uZmlndXJhYmxlOiAhb3B0aW9ucy5ub25Db25maWd1cmFibGUsXG4gICAgICB3cml0YWJsZTogIW9wdGlvbnMubm9uV3JpdGFibGVcbiAgICB9KTtcbiAgfSByZXR1cm4gTztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuICB0cnkge1xuICAgIGRlZmluZVByb3BlcnR5KGdsb2JhbFRoaXMsIGtleSwgeyB2YWx1ZTogdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgZ2xvYmFsVGhpc1trZXldID0gdmFsdWU7XG4gIH0gcmV0dXJuIHZhbHVlO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBmYWlscyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mYWlscycpO1xuXG4vLyBEZXRlY3QgSUU4J3MgaW5jb21wbGV0ZSBkZWZpbmVQcm9wZXJ0eSBpbXBsZW1lbnRhdGlvblxubW9kdWxlLmV4cG9ydHMgPSAhZmFpbHMoZnVuY3Rpb24gKCkge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHJlcXVpcmVkIGZvciB0ZXN0aW5nXG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoe30sIDEsIHsgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiA3OyB9IH0pWzFdICE9PSA3O1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xudmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLW9iamVjdCcpO1xuXG52YXIgZG9jdW1lbnQgPSBnbG9iYWxUaGlzLmRvY3VtZW50O1xuLy8gdHlwZW9mIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQgaXMgJ29iamVjdCcgaW4gb2xkIElFXG52YXIgRVhJU1RTID0gaXNPYmplY3QoZG9jdW1lbnQpICYmIGlzT2JqZWN0KGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gRVhJU1RTID8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChpdCkgOiB7fTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyBJRTgtIGRvbid0IGVudW0gYnVnIGtleXNcbm1vZHVsZS5leHBvcnRzID0gW1xuICAnY29uc3RydWN0b3InLFxuICAnaGFzT3duUHJvcGVydHknLFxuICAnaXNQcm90b3R5cGVPZicsXG4gICdwcm9wZXJ0eUlzRW51bWVyYWJsZScsXG4gICd0b0xvY2FsZVN0cmluZycsXG4gICd0b1N0cmluZycsXG4gICd2YWx1ZU9mJ1xuXTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG5cbnZhciBuYXZpZ2F0b3IgPSBnbG9iYWxUaGlzLm5hdmlnYXRvcjtcbnZhciB1c2VyQWdlbnQgPSBuYXZpZ2F0b3IgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudDtcblxubW9kdWxlLmV4cG9ydHMgPSB1c2VyQWdlbnQgPyBTdHJpbmcodXNlckFnZW50KSA6ICcnO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdsb2JhbFRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2xvYmFsLXRoaXMnKTtcbnZhciB1c2VyQWdlbnQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW52aXJvbm1lbnQtdXNlci1hZ2VudCcpO1xuXG52YXIgcHJvY2VzcyA9IGdsb2JhbFRoaXMucHJvY2VzcztcbnZhciBEZW5vID0gZ2xvYmFsVGhpcy5EZW5vO1xudmFyIHZlcnNpb25zID0gcHJvY2VzcyAmJiBwcm9jZXNzLnZlcnNpb25zIHx8IERlbm8gJiYgRGVuby52ZXJzaW9uO1xudmFyIHY4ID0gdmVyc2lvbnMgJiYgdmVyc2lvbnMudjg7XG52YXIgbWF0Y2gsIHZlcnNpb247XG5cbmlmICh2OCkge1xuICBtYXRjaCA9IHY4LnNwbGl0KCcuJyk7XG4gIC8vIGluIG9sZCBDaHJvbWUsIHZlcnNpb25zIG9mIFY4IGlzbid0IFY4ID0gQ2hyb21lIC8gMTBcbiAgLy8gYnV0IHRoZWlyIGNvcnJlY3QgdmVyc2lvbnMgYXJlIG5vdCBpbnRlcmVzdGluZyBmb3IgdXNcbiAgdmVyc2lvbiA9IG1hdGNoWzBdID4gMCAmJiBtYXRjaFswXSA8IDQgPyAxIDogKyhtYXRjaFswXSArIG1hdGNoWzFdKTtcbn1cblxuLy8gQnJvd3NlckZTIE5vZGVKUyBgcHJvY2Vzc2AgcG9seWZpbGwgaW5jb3JyZWN0bHkgc2V0IGAudjhgIHRvIGAwLjBgXG4vLyBzbyBjaGVjayBgdXNlckFnZW50YCBldmVuIGlmIGAudjhgIGV4aXN0cywgYnV0IDBcbmlmICghdmVyc2lvbiAmJiB1c2VyQWdlbnQpIHtcbiAgbWF0Y2ggPSB1c2VyQWdlbnQubWF0Y2goL0VkZ2VcXC8oXFxkKykvKTtcbiAgaWYgKCFtYXRjaCB8fCBtYXRjaFsxXSA+PSA3NCkge1xuICAgIG1hdGNoID0gdXNlckFnZW50Lm1hdGNoKC9DaHJvbWVcXC8oXFxkKykvKTtcbiAgICBpZiAobWF0Y2gpIHZlcnNpb24gPSArbWF0Y2hbMV07XG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB2ZXJzaW9uO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xuXG52YXIgJEVycm9yID0gRXJyb3I7XG52YXIgcmVwbGFjZSA9IHVuY3VycnlUaGlzKCcnLnJlcGxhY2UpO1xuXG52YXIgVEVTVCA9IChmdW5jdGlvbiAoYXJnKSB7IHJldHVybiBTdHJpbmcobmV3ICRFcnJvcihhcmcpLnN0YWNrKTsgfSkoJ3p4Y2FzZCcpO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlZG9zL25vLXZ1bG5lcmFibGUsIHNvbmFyanMvc2xvdy1yZWdleCAtLSBzYWZlXG52YXIgVjhfT1JfQ0hBS1JBX1NUQUNLX0VOVFJZID0gL1xcblxccyphdCBbXjpdKjpbXlxcbl0qLztcbnZhciBJU19WOF9PUl9DSEFLUkFfU1RBQ0sgPSBWOF9PUl9DSEFLUkFfU1RBQ0tfRU5UUlkudGVzdChURVNUKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoc3RhY2ssIGRyb3BFbnRyaWVzKSB7XG4gIGlmIChJU19WOF9PUl9DSEFLUkFfU1RBQ0sgJiYgdHlwZW9mIHN0YWNrID09ICdzdHJpbmcnICYmICEkRXJyb3IucHJlcGFyZVN0YWNrVHJhY2UpIHtcbiAgICB3aGlsZSAoZHJvcEVudHJpZXMtLSkgc3RhY2sgPSByZXBsYWNlKHN0YWNrLCBWOF9PUl9DSEFLUkFfU1RBQ0tfRU5UUlksICcnKTtcbiAgfSByZXR1cm4gc3RhY2s7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGNyZWF0ZU5vbkVudW1lcmFibGVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jcmVhdGUtbm9uLWVudW1lcmFibGUtcHJvcGVydHknKTtcbnZhciBjbGVhckVycm9yU3RhY2sgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZXJyb3Itc3RhY2stY2xlYXInKTtcbnZhciBFUlJPUl9TVEFDS19JTlNUQUxMQUJMRSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9lcnJvci1zdGFjay1pbnN0YWxsYWJsZScpO1xuXG4vLyBub24tc3RhbmRhcmQgVjhcbnZhciBjYXB0dXJlU3RhY2tUcmFjZSA9IEVycm9yLmNhcHR1cmVTdGFja1RyYWNlO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChlcnJvciwgQywgc3RhY2ssIGRyb3BFbnRyaWVzKSB7XG4gIGlmIChFUlJPUl9TVEFDS19JTlNUQUxMQUJMRSkge1xuICAgIGlmIChjYXB0dXJlU3RhY2tUcmFjZSkgY2FwdHVyZVN0YWNrVHJhY2UoZXJyb3IsIEMpO1xuICAgIGVsc2UgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KGVycm9yLCAnc3RhY2snLCBjbGVhckVycm9yU3RhY2soc3RhY2ssIGRyb3BFbnRyaWVzKSk7XG4gIH1cbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcbnZhciBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3InKTtcblxubW9kdWxlLmV4cG9ydHMgPSAhZmFpbHMoZnVuY3Rpb24gKCkge1xuICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IoJ2EnKTtcbiAgaWYgKCEoJ3N0YWNrJyBpbiBlcnJvcikpIHJldHVybiB0cnVlO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGVycm9yLCAnc3RhY2snLCBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IoMSwgNykpO1xuICByZXR1cm4gZXJyb3Iuc3RhY2sgIT09IDc7XG59KTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1nZXQtb3duLXByb3BlcnR5LWRlc2NyaXB0b3InKS5mO1xudmFyIGNyZWF0ZU5vbkVudW1lcmFibGVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jcmVhdGUtbm9uLWVudW1lcmFibGUtcHJvcGVydHknKTtcbnZhciBkZWZpbmVCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1idWlsdC1pbicpO1xudmFyIGRlZmluZUdsb2JhbFByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHknKTtcbnZhciBjb3B5Q29uc3RydWN0b3JQcm9wZXJ0aWVzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NvcHktY29uc3RydWN0b3ItcHJvcGVydGllcycpO1xudmFyIGlzRm9yY2VkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLWZvcmNlZCcpO1xuXG4vKlxuICBvcHRpb25zLnRhcmdldCAgICAgICAgIC0gbmFtZSBvZiB0aGUgdGFyZ2V0IG9iamVjdFxuICBvcHRpb25zLmdsb2JhbCAgICAgICAgIC0gdGFyZ2V0IGlzIHRoZSBnbG9iYWwgb2JqZWN0XG4gIG9wdGlvbnMuc3RhdCAgICAgICAgICAgLSBleHBvcnQgYXMgc3RhdGljIG1ldGhvZHMgb2YgdGFyZ2V0XG4gIG9wdGlvbnMucHJvdG8gICAgICAgICAgLSBleHBvcnQgYXMgcHJvdG90eXBlIG1ldGhvZHMgb2YgdGFyZ2V0XG4gIG9wdGlvbnMucmVhbCAgICAgICAgICAgLSByZWFsIHByb3RvdHlwZSBtZXRob2QgZm9yIHRoZSBgcHVyZWAgdmVyc2lvblxuICBvcHRpb25zLmZvcmNlZCAgICAgICAgIC0gZXhwb3J0IGV2ZW4gaWYgdGhlIG5hdGl2ZSBmZWF0dXJlIGlzIGF2YWlsYWJsZVxuICBvcHRpb25zLmJpbmQgICAgICAgICAgIC0gYmluZCBtZXRob2RzIHRvIHRoZSB0YXJnZXQsIHJlcXVpcmVkIGZvciB0aGUgYHB1cmVgIHZlcnNpb25cbiAgb3B0aW9ucy53cmFwICAgICAgICAgICAtIHdyYXAgY29uc3RydWN0b3JzIHRvIHByZXZlbnRpbmcgZ2xvYmFsIHBvbGx1dGlvbiwgcmVxdWlyZWQgZm9yIHRoZSBgcHVyZWAgdmVyc2lvblxuICBvcHRpb25zLnVuc2FmZSAgICAgICAgIC0gdXNlIHRoZSBzaW1wbGUgYXNzaWdubWVudCBvZiBwcm9wZXJ0eSBpbnN0ZWFkIG9mIGRlbGV0ZSArIGRlZmluZVByb3BlcnR5XG4gIG9wdGlvbnMuc2hhbSAgICAgICAgICAgLSBhZGQgYSBmbGFnIHRvIG5vdCBjb21wbGV0ZWx5IGZ1bGwgcG9seWZpbGxzXG4gIG9wdGlvbnMuZW51bWVyYWJsZSAgICAgLSBleHBvcnQgYXMgZW51bWVyYWJsZSBwcm9wZXJ0eVxuICBvcHRpb25zLmRvbnRDYWxsR2V0U2V0IC0gcHJldmVudCBjYWxsaW5nIGEgZ2V0dGVyIG9uIHRhcmdldFxuICBvcHRpb25zLm5hbWUgICAgICAgICAgIC0gdGhlIC5uYW1lIG9mIHRoZSBmdW5jdGlvbiBpZiBpdCBkb2VzIG5vdCBtYXRjaCB0aGUga2V5XG4qL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAob3B0aW9ucywgc291cmNlKSB7XG4gIHZhciBUQVJHRVQgPSBvcHRpb25zLnRhcmdldDtcbiAgdmFyIEdMT0JBTCA9IG9wdGlvbnMuZ2xvYmFsO1xuICB2YXIgU1RBVElDID0gb3B0aW9ucy5zdGF0O1xuICB2YXIgRk9SQ0VELCB0YXJnZXQsIGtleSwgdGFyZ2V0UHJvcGVydHksIHNvdXJjZVByb3BlcnR5LCBkZXNjcmlwdG9yO1xuICBpZiAoR0xPQkFMKSB7XG4gICAgdGFyZ2V0ID0gZ2xvYmFsVGhpcztcbiAgfSBlbHNlIGlmIChTVEFUSUMpIHtcbiAgICB0YXJnZXQgPSBnbG9iYWxUaGlzW1RBUkdFVF0gfHwgZGVmaW5lR2xvYmFsUHJvcGVydHkoVEFSR0VULCB7fSk7XG4gIH0gZWxzZSB7XG4gICAgdGFyZ2V0ID0gZ2xvYmFsVGhpc1tUQVJHRVRdICYmIGdsb2JhbFRoaXNbVEFSR0VUXS5wcm90b3R5cGU7XG4gIH1cbiAgaWYgKHRhcmdldCkgZm9yIChrZXkgaW4gc291cmNlKSB7XG4gICAgc291cmNlUHJvcGVydHkgPSBzb3VyY2Vba2V5XTtcbiAgICBpZiAob3B0aW9ucy5kb250Q2FsbEdldFNldCkge1xuICAgICAgZGVzY3JpcHRvciA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSk7XG4gICAgICB0YXJnZXRQcm9wZXJ0eSA9IGRlc2NyaXB0b3IgJiYgZGVzY3JpcHRvci52YWx1ZTtcbiAgICB9IGVsc2UgdGFyZ2V0UHJvcGVydHkgPSB0YXJnZXRba2V5XTtcbiAgICBGT1JDRUQgPSBpc0ZvcmNlZChHTE9CQUwgPyBrZXkgOiBUQVJHRVQgKyAoU1RBVElDID8gJy4nIDogJyMnKSArIGtleSwgb3B0aW9ucy5mb3JjZWQpO1xuICAgIC8vIGNvbnRhaW5lZCBpbiB0YXJnZXRcbiAgICBpZiAoIUZPUkNFRCAmJiB0YXJnZXRQcm9wZXJ0eSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHNvdXJjZVByb3BlcnR5ID09IHR5cGVvZiB0YXJnZXRQcm9wZXJ0eSkgY29udGludWU7XG4gICAgICBjb3B5Q29uc3RydWN0b3JQcm9wZXJ0aWVzKHNvdXJjZVByb3BlcnR5LCB0YXJnZXRQcm9wZXJ0eSk7XG4gICAgfVxuICAgIC8vIGFkZCBhIGZsYWcgdG8gbm90IGNvbXBsZXRlbHkgZnVsbCBwb2x5ZmlsbHNcbiAgICBpZiAob3B0aW9ucy5zaGFtIHx8ICh0YXJnZXRQcm9wZXJ0eSAmJiB0YXJnZXRQcm9wZXJ0eS5zaGFtKSkge1xuICAgICAgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KHNvdXJjZVByb3BlcnR5LCAnc2hhbScsIHRydWUpO1xuICAgIH1cbiAgICBkZWZpbmVCdWlsdEluKHRhcmdldCwga2V5LCBzb3VyY2VQcm9wZXJ0eSwgb3B0aW9ucyk7XG4gIH1cbn07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChleGVjKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuICEhZXhlYygpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIE5BVElWRV9CSU5EID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLWJpbmQtbmF0aXZlJyk7XG5cbnZhciBGdW5jdGlvblByb3RvdHlwZSA9IEZ1bmN0aW9uLnByb3RvdHlwZTtcbnZhciBhcHBseSA9IEZ1bmN0aW9uUHJvdG90eXBlLmFwcGx5O1xudmFyIGNhbGwgPSBGdW5jdGlvblByb3RvdHlwZS5jYWxsO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tZnVuY3Rpb24tcHJvdG90eXBlLWJpbmQsIGVzL25vLXJlZmxlY3QgLS0gc2FmZVxubW9kdWxlLmV4cG9ydHMgPSB0eXBlb2YgUmVmbGVjdCA9PSAnb2JqZWN0JyAmJiBSZWZsZWN0LmFwcGx5IHx8IChOQVRJVkVfQklORCA/IGNhbGwuYmluZChhcHBseSkgOiBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBjYWxsLmFwcGx5KGFwcGx5LCBhcmd1bWVudHMpO1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSAhZmFpbHMoZnVuY3Rpb24gKCkge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tZnVuY3Rpb24tcHJvdG90eXBlLWJpbmQgLS0gc2FmZVxuICB2YXIgdGVzdCA9IChmdW5jdGlvbiAoKSB7IC8qIGVtcHR5ICovIH0pLmJpbmQoKTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXByb3RvdHlwZS1idWlsdGlucyAtLSBzYWZlXG4gIHJldHVybiB0eXBlb2YgdGVzdCAhPSAnZnVuY3Rpb24nIHx8IHRlc3QuaGFzT3duUHJvcGVydHkoJ3Byb3RvdHlwZScpO1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgTkFUSVZFX0JJTkQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tYmluZC1uYXRpdmUnKTtcblxudmFyIGNhbGwgPSBGdW5jdGlvbi5wcm90b3R5cGUuY2FsbDtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1mdW5jdGlvbi1wcm90b3R5cGUtYmluZCAtLSBzYWZlXG5tb2R1bGUuZXhwb3J0cyA9IE5BVElWRV9CSU5EID8gY2FsbC5iaW5kKGNhbGwpIDogZnVuY3Rpb24gKCkge1xuICByZXR1cm4gY2FsbC5hcHBseShjYWxsLCBhcmd1bWVudHMpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG5cbnZhciBGdW5jdGlvblByb3RvdHlwZSA9IEZ1bmN0aW9uLnByb3RvdHlwZTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZ2V0b3ducHJvcGVydHlkZXNjcmlwdG9yIC0tIHNhZmVcbnZhciBnZXREZXNjcmlwdG9yID0gREVTQ1JJUFRPUlMgJiYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcblxudmFyIEVYSVNUUyA9IGhhc093bihGdW5jdGlvblByb3RvdHlwZSwgJ25hbWUnKTtcbi8vIGFkZGl0aW9uYWwgcHJvdGVjdGlvbiBmcm9tIG1pbmlmaWVkIC8gbWFuZ2xlZCAvIGRyb3BwZWQgZnVuY3Rpb24gbmFtZXNcbnZhciBQUk9QRVIgPSBFWElTVFMgJiYgKGZ1bmN0aW9uIHNvbWV0aGluZygpIHsgLyogZW1wdHkgKi8gfSkubmFtZSA9PT0gJ3NvbWV0aGluZyc7XG52YXIgQ09ORklHVVJBQkxFID0gRVhJU1RTICYmICghREVTQ1JJUFRPUlMgfHwgKERFU0NSSVBUT1JTICYmIGdldERlc2NyaXB0b3IoRnVuY3Rpb25Qcm90b3R5cGUsICduYW1lJykuY29uZmlndXJhYmxlKSk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBFWElTVFM6IEVYSVNUUyxcbiAgUFJPUEVSOiBQUk9QRVIsXG4gIENPTkZJR1VSQUJMRTogQ09ORklHVVJBQkxFXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xudmFyIGFDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hLWNhbGxhYmxlJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKG9iamVjdCwga2V5LCBtZXRob2QpIHtcbiAgdHJ5IHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5ZGVzY3JpcHRvciAtLSBzYWZlXG4gICAgcmV0dXJuIHVuY3VycnlUaGlzKGFDYWxsYWJsZShPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iamVjdCwga2V5KVttZXRob2RdKSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgTkFUSVZFX0JJTkQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tYmluZC1uYXRpdmUnKTtcblxudmFyIEZ1bmN0aW9uUHJvdG90eXBlID0gRnVuY3Rpb24ucHJvdG90eXBlO1xudmFyIGNhbGwgPSBGdW5jdGlvblByb3RvdHlwZS5jYWxsO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLWZ1bmN0aW9uLXByb3RvdHlwZS1iaW5kIC0tIHNhZmVcbnZhciB1bmN1cnJ5VGhpc1dpdGhCaW5kID0gTkFUSVZFX0JJTkQgJiYgRnVuY3Rpb25Qcm90b3R5cGUuYmluZC5iaW5kKGNhbGwsIGNhbGwpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IE5BVElWRV9CSU5EID8gdW5jdXJyeVRoaXNXaXRoQmluZCA6IGZ1bmN0aW9uIChmbikge1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBjYWxsLmFwcGx5KGZuLCBhcmd1bWVudHMpO1xuICB9O1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xuXG52YXIgYUZ1bmN0aW9uID0gZnVuY3Rpb24gKGFyZ3VtZW50KSB7XG4gIHJldHVybiBpc0NhbGxhYmxlKGFyZ3VtZW50KSA/IGFyZ3VtZW50IDogdW5kZWZpbmVkO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAobmFtZXNwYWNlLCBtZXRob2QpIHtcbiAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPCAyID8gYUZ1bmN0aW9uKGdsb2JhbFRoaXNbbmFtZXNwYWNlXSkgOiBnbG9iYWxUaGlzW25hbWVzcGFjZV0gJiYgZ2xvYmFsVGhpc1tuYW1lc3BhY2VdW21ldGhvZF07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGFDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hLWNhbGxhYmxlJyk7XG52YXIgaXNOdWxsT3JVbmRlZmluZWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtbnVsbC1vci11bmRlZmluZWQnKTtcblxuLy8gYEdldE1ldGhvZGAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWdldG1ldGhvZFxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoViwgUCkge1xuICB2YXIgZnVuYyA9IFZbUF07XG4gIHJldHVybiBpc051bGxPclVuZGVmaW5lZChmdW5jKSA/IHVuZGVmaW5lZCA6IGFDYWxsYWJsZShmdW5jKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgY2hlY2sgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGl0ICYmIGl0Lk1hdGggPT09IE1hdGggJiYgaXQ7XG59O1xuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vemxvaXJvY2svY29yZS1qcy9pc3N1ZXMvODYjaXNzdWVjb21tZW50LTExNTc1OTAyOFxubW9kdWxlLmV4cG9ydHMgPVxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tZ2xvYmFsLXRoaXMgLS0gc2FmZVxuICBjaGVjayh0eXBlb2YgZ2xvYmFsVGhpcyA9PSAnb2JqZWN0JyAmJiBnbG9iYWxUaGlzKSB8fFxuICBjaGVjayh0eXBlb2Ygd2luZG93ID09ICdvYmplY3QnICYmIHdpbmRvdykgfHxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtZ2xvYmFscyAtLSBzYWZlXG4gIGNoZWNrKHR5cGVvZiBzZWxmID09ICdvYmplY3QnICYmIHNlbGYpIHx8XG4gIGNoZWNrKHR5cGVvZiBnbG9iYWwgPT0gJ29iamVjdCcgJiYgZ2xvYmFsKSB8fFxuICBjaGVjayh0eXBlb2YgdGhpcyA9PSAnb2JqZWN0JyAmJiB0aGlzKSB8fFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmV3LWZ1bmMgLS0gZmFsbGJhY2tcbiAgKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0pKCkgfHwgRnVuY3Rpb24oJ3JldHVybiB0aGlzJykoKTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciB1bmN1cnJ5VGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mdW5jdGlvbi11bmN1cnJ5LXRoaXMnKTtcbnZhciB0b09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1vYmplY3QnKTtcblxudmFyIGhhc093blByb3BlcnR5ID0gdW5jdXJyeVRoaXMoe30uaGFzT3duUHJvcGVydHkpO1xuXG4vLyBgSGFzT3duUHJvcGVydHlgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1oYXNvd25wcm9wZXJ0eVxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1oYXNvd24gLS0gc2FmZVxubW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuaGFzT3duIHx8IGZ1bmN0aW9uIGhhc093bihpdCwga2V5KSB7XG4gIHJldHVybiBoYXNPd25Qcm9wZXJ0eSh0b09iamVjdChpdCksIGtleSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xubW9kdWxlLmV4cG9ydHMgPSB7fTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnZXRCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dldC1idWlsdC1pbicpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGdldEJ1aWx0SW4oJ2RvY3VtZW50JywgJ2RvY3VtZW50RWxlbWVudCcpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcbnZhciBjcmVhdGVFbGVtZW50ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RvY3VtZW50LWNyZWF0ZS1lbGVtZW50Jyk7XG5cbi8vIFRoYW5rcyB0byBJRTggZm9yIGl0cyBmdW5ueSBkZWZpbmVQcm9wZXJ0eVxubW9kdWxlLmV4cG9ydHMgPSAhREVTQ1JJUFRPUlMgJiYgIWZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1kZWZpbmVwcm9wZXJ0eSAtLSByZXF1aXJlZCBmb3IgdGVzdGluZ1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGNyZWF0ZUVsZW1lbnQoJ2RpdicpLCAnYScsIHtcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIDc7IH1cbiAgfSkuYSAhPT0gNztcbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2ZhaWxzJyk7XG52YXIgY2xhc3NvZiA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jbGFzc29mLXJhdycpO1xuXG52YXIgJE9iamVjdCA9IE9iamVjdDtcbnZhciBzcGxpdCA9IHVuY3VycnlUaGlzKCcnLnNwbGl0KTtcblxuLy8gZmFsbGJhY2sgZm9yIG5vbi1hcnJheS1saWtlIEVTMyBhbmQgbm9uLWVudW1lcmFibGUgb2xkIFY4IHN0cmluZ3Ncbm1vZHVsZS5leHBvcnRzID0gZmFpbHMoZnVuY3Rpb24gKCkge1xuICAvLyB0aHJvd3MgYW4gZXJyb3IgaW4gcmhpbm8sIHNlZSBodHRwczovL2dpdGh1Yi5jb20vbW96aWxsYS9yaGluby9pc3N1ZXMvMzQ2XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wcm90b3R5cGUtYnVpbHRpbnMgLS0gc2FmZVxuICByZXR1cm4gISRPYmplY3QoJ3onKS5wcm9wZXJ0eUlzRW51bWVyYWJsZSgwKTtcbn0pID8gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBjbGFzc29mKGl0KSA9PT0gJ1N0cmluZycgPyBzcGxpdChpdCwgJycpIDogJE9iamVjdChpdCk7XG59IDogJE9iamVjdDtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc0NhbGxhYmxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLWNhbGxhYmxlJyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG52YXIgc2V0UHJvdG90eXBlT2YgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LXNldC1wcm90b3R5cGUtb2YnKTtcblxuLy8gbWFrZXMgc3ViY2xhc3Npbmcgd29yayBjb3JyZWN0IGZvciB3cmFwcGVkIGJ1aWx0LWluc1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoJHRoaXMsIGR1bW15LCBXcmFwcGVyKSB7XG4gIHZhciBOZXdUYXJnZXQsIE5ld1RhcmdldFByb3RvdHlwZTtcbiAgaWYgKFxuICAgIC8vIGl0IGNhbiB3b3JrIG9ubHkgd2l0aCBuYXRpdmUgYHNldFByb3RvdHlwZU9mYFxuICAgIHNldFByb3RvdHlwZU9mICYmXG4gICAgLy8gd2UgaGF2ZW4ndCBjb21wbGV0ZWx5IGNvcnJlY3QgcHJlLUVTNiB3YXkgZm9yIGdldHRpbmcgYG5ldy50YXJnZXRgLCBzbyB1c2UgdGhpc1xuICAgIGlzQ2FsbGFibGUoTmV3VGFyZ2V0ID0gZHVtbXkuY29uc3RydWN0b3IpICYmXG4gICAgTmV3VGFyZ2V0ICE9PSBXcmFwcGVyICYmXG4gICAgaXNPYmplY3QoTmV3VGFyZ2V0UHJvdG90eXBlID0gTmV3VGFyZ2V0LnByb3RvdHlwZSkgJiZcbiAgICBOZXdUYXJnZXRQcm90b3R5cGUgIT09IFdyYXBwZXIucHJvdG90eXBlXG4gICkgc2V0UHJvdG90eXBlT2YoJHRoaXMsIE5ld1RhcmdldFByb3RvdHlwZSk7XG4gIHJldHVybiAkdGhpcztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdW5jdXJyeVRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIHN0b3JlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZC1zdG9yZScpO1xuXG52YXIgZnVuY3Rpb25Ub1N0cmluZyA9IHVuY3VycnlUaGlzKEZ1bmN0aW9uLnRvU3RyaW5nKTtcblxuLy8gdGhpcyBoZWxwZXIgYnJva2VuIGluIGBjb3JlLWpzQDMuNC4xLTMuNC40YCwgc28gd2UgY2FuJ3QgdXNlIGBzaGFyZWRgIGhlbHBlclxuaWYgKCFpc0NhbGxhYmxlKHN0b3JlLmluc3BlY3RTb3VyY2UpKSB7XG4gIHN0b3JlLmluc3BlY3RTb3VyY2UgPSBmdW5jdGlvbiAoaXQpIHtcbiAgICByZXR1cm4gZnVuY3Rpb25Ub1N0cmluZyhpdCk7XG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3RvcmUuaW5zcGVjdFNvdXJjZTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcbnZhciBjcmVhdGVOb25FbnVtZXJhYmxlUHJvcGVydHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLW5vbi1lbnVtZXJhYmxlLXByb3BlcnR5Jyk7XG5cbi8vIGBJbnN0YWxsRXJyb3JDYXVzZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvcHJvcG9zYWwtZXJyb3ItY2F1c2UvI3NlYy1lcnJvcm9iamVjdHMtaW5zdGFsbC1lcnJvci1jYXVzZVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoTywgb3B0aW9ucykge1xuICBpZiAoaXNPYmplY3Qob3B0aW9ucykgJiYgJ2NhdXNlJyBpbiBvcHRpb25zKSB7XG4gICAgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KE8sICdjYXVzZScsIG9wdGlvbnMuY2F1c2UpO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIE5BVElWRV9XRUFLX01BUCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy93ZWFrLW1hcC1iYXNpYy1kZXRlY3Rpb24nKTtcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG52YXIgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NyZWF0ZS1ub24tZW51bWVyYWJsZS1wcm9wZXJ0eScpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgc2hhcmVkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZC1zdG9yZScpO1xudmFyIHNoYXJlZEtleSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9zaGFyZWQta2V5Jyk7XG52YXIgaGlkZGVuS2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oaWRkZW4ta2V5cycpO1xuXG52YXIgT0JKRUNUX0FMUkVBRFlfSU5JVElBTElaRUQgPSAnT2JqZWN0IGFscmVhZHkgaW5pdGlhbGl6ZWQnO1xudmFyIFR5cGVFcnJvciA9IGdsb2JhbFRoaXMuVHlwZUVycm9yO1xudmFyIFdlYWtNYXAgPSBnbG9iYWxUaGlzLldlYWtNYXA7XG52YXIgc2V0LCBnZXQsIGhhcztcblxudmFyIGVuZm9yY2UgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGhhcyhpdCkgPyBnZXQoaXQpIDogc2V0KGl0LCB7fSk7XG59O1xuXG52YXIgZ2V0dGVyRm9yID0gZnVuY3Rpb24gKFRZUEUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChpdCkge1xuICAgIHZhciBzdGF0ZTtcbiAgICBpZiAoIWlzT2JqZWN0KGl0KSB8fCAoc3RhdGUgPSBnZXQoaXQpKS50eXBlICE9PSBUWVBFKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbmNvbXBhdGlibGUgcmVjZWl2ZXIsICcgKyBUWVBFICsgJyByZXF1aXJlZCcpO1xuICAgIH0gcmV0dXJuIHN0YXRlO1xuICB9O1xufTtcblxuaWYgKE5BVElWRV9XRUFLX01BUCB8fCBzaGFyZWQuc3RhdGUpIHtcbiAgdmFyIHN0b3JlID0gc2hhcmVkLnN0YXRlIHx8IChzaGFyZWQuc3RhdGUgPSBuZXcgV2Vha01hcCgpKTtcbiAgLyogZXNsaW50LWRpc2FibGUgbm8tc2VsZi1hc3NpZ24gLS0gcHJvdG90eXBlIG1ldGhvZHMgcHJvdGVjdGlvbiAqL1xuICBzdG9yZS5nZXQgPSBzdG9yZS5nZXQ7XG4gIHN0b3JlLmhhcyA9IHN0b3JlLmhhcztcbiAgc3RvcmUuc2V0ID0gc3RvcmUuc2V0O1xuICAvKiBlc2xpbnQtZW5hYmxlIG5vLXNlbGYtYXNzaWduIC0tIHByb3RvdHlwZSBtZXRob2RzIHByb3RlY3Rpb24gKi9cbiAgc2V0ID0gZnVuY3Rpb24gKGl0LCBtZXRhZGF0YSkge1xuICAgIGlmIChzdG9yZS5oYXMoaXQpKSB0aHJvdyBuZXcgVHlwZUVycm9yKE9CSkVDVF9BTFJFQURZX0lOSVRJQUxJWkVEKTtcbiAgICBtZXRhZGF0YS5mYWNhZGUgPSBpdDtcbiAgICBzdG9yZS5zZXQoaXQsIG1ldGFkYXRhKTtcbiAgICByZXR1cm4gbWV0YWRhdGE7XG4gIH07XG4gIGdldCA9IGZ1bmN0aW9uIChpdCkge1xuICAgIHJldHVybiBzdG9yZS5nZXQoaXQpIHx8IHt9O1xuICB9O1xuICBoYXMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgICByZXR1cm4gc3RvcmUuaGFzKGl0KTtcbiAgfTtcbn0gZWxzZSB7XG4gIHZhciBTVEFURSA9IHNoYXJlZEtleSgnc3RhdGUnKTtcbiAgaGlkZGVuS2V5c1tTVEFURV0gPSB0cnVlO1xuICBzZXQgPSBmdW5jdGlvbiAoaXQsIG1ldGFkYXRhKSB7XG4gICAgaWYgKGhhc093bihpdCwgU1RBVEUpKSB0aHJvdyBuZXcgVHlwZUVycm9yKE9CSkVDVF9BTFJFQURZX0lOSVRJQUxJWkVEKTtcbiAgICBtZXRhZGF0YS5mYWNhZGUgPSBpdDtcbiAgICBjcmVhdGVOb25FbnVtZXJhYmxlUHJvcGVydHkoaXQsIFNUQVRFLCBtZXRhZGF0YSk7XG4gICAgcmV0dXJuIG1ldGFkYXRhO1xuICB9O1xuICBnZXQgPSBmdW5jdGlvbiAoaXQpIHtcbiAgICByZXR1cm4gaGFzT3duKGl0LCBTVEFURSkgPyBpdFtTVEFURV0gOiB7fTtcbiAgfTtcbiAgaGFzID0gZnVuY3Rpb24gKGl0KSB7XG4gICAgcmV0dXJuIGhhc093bihpdCwgU1RBVEUpO1xuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgc2V0OiBzZXQsXG4gIGdldDogZ2V0LFxuICBoYXM6IGhhcyxcbiAgZW5mb3JjZTogZW5mb3JjZSxcbiAgZ2V0dGVyRm9yOiBnZXR0ZXJGb3Jcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLUlzSFRNTEREQS1pbnRlcm5hbC1zbG90XG52YXIgZG9jdW1lbnRBbGwgPSB0eXBlb2YgZG9jdW1lbnQgPT0gJ29iamVjdCcgJiYgZG9jdW1lbnQuYWxsO1xuXG4vLyBgSXNDYWxsYWJsZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWlzY2FsbGFibGVcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSB1bmljb3JuL25vLXR5cGVvZi11bmRlZmluZWQgLS0gcmVxdWlyZWQgZm9yIHRlc3Rpbmdcbm1vZHVsZS5leHBvcnRzID0gdHlwZW9mIGRvY3VtZW50QWxsID09ICd1bmRlZmluZWQnICYmIGRvY3VtZW50QWxsICE9PSB1bmRlZmluZWQgPyBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmd1bWVudCA9PSAnZnVuY3Rpb24nIHx8IGFyZ3VtZW50ID09PSBkb2N1bWVudEFsbDtcbn0gOiBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmd1bWVudCA9PSAnZnVuY3Rpb24nO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBmYWlscyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mYWlscycpO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcblxudmFyIHJlcGxhY2VtZW50ID0gLyN8XFwucHJvdG90eXBlXFwuLztcblxudmFyIGlzRm9yY2VkID0gZnVuY3Rpb24gKGZlYXR1cmUsIGRldGVjdGlvbikge1xuICB2YXIgdmFsdWUgPSBkYXRhW25vcm1hbGl6ZShmZWF0dXJlKV07XG4gIHJldHVybiB2YWx1ZSA9PT0gUE9MWUZJTEwgPyB0cnVlXG4gICAgOiB2YWx1ZSA9PT0gTkFUSVZFID8gZmFsc2VcbiAgICA6IGlzQ2FsbGFibGUoZGV0ZWN0aW9uKSA/IGZhaWxzKGRldGVjdGlvbilcbiAgICA6ICEhZGV0ZWN0aW9uO1xufTtcblxudmFyIG5vcm1hbGl6ZSA9IGlzRm9yY2VkLm5vcm1hbGl6ZSA9IGZ1bmN0aW9uIChzdHJpbmcpIHtcbiAgcmV0dXJuIFN0cmluZyhzdHJpbmcpLnJlcGxhY2UocmVwbGFjZW1lbnQsICcuJykudG9Mb3dlckNhc2UoKTtcbn07XG5cbnZhciBkYXRhID0gaXNGb3JjZWQuZGF0YSA9IHt9O1xudmFyIE5BVElWRSA9IGlzRm9yY2VkLk5BVElWRSA9ICdOJztcbnZhciBQT0xZRklMTCA9IGlzRm9yY2VkLlBPTFlGSUxMID0gJ1AnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGlzRm9yY2VkO1xuIiwiJ3VzZSBzdHJpY3QnO1xuLy8gd2UgY2FuJ3QgdXNlIGp1c3QgYGl0ID09IG51bGxgIHNpbmNlIG9mIGBkb2N1bWVudC5hbGxgIHNwZWNpYWwgY2FzZVxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1Jc0hUTUxEREEtaW50ZXJuYWwtc2xvdC1hZWNcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBpdCA9PT0gbnVsbCB8fCBpdCA9PT0gdW5kZWZpbmVkO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc0NhbGxhYmxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLWNhbGxhYmxlJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiB0eXBlb2YgaXQgPT0gJ29iamVjdCcgPyBpdCAhPT0gbnVsbCA6IGlzQ2FsbGFibGUoaXQpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuIGlzT2JqZWN0KGFyZ3VtZW50KSB8fCBhcmd1bWVudCA9PT0gbnVsbDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGZhbHNlO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdldEJ1aWx0SW4gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2V0LWJ1aWx0LWluJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xudmFyIGlzUHJvdG90eXBlT2YgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWlzLXByb3RvdHlwZS1vZicpO1xudmFyIFVTRV9TWU1CT0xfQVNfVUlEID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3VzZS1zeW1ib2wtYXMtdWlkJyk7XG5cbnZhciAkT2JqZWN0ID0gT2JqZWN0O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFVTRV9TWU1CT0xfQVNfVUlEID8gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiB0eXBlb2YgaXQgPT0gJ3N5bWJvbCc7XG59IDogZnVuY3Rpb24gKGl0KSB7XG4gIHZhciAkU3ltYm9sID0gZ2V0QnVpbHRJbignU3ltYm9sJyk7XG4gIHJldHVybiBpc0NhbGxhYmxlKCRTeW1ib2wpICYmIGlzUHJvdG90eXBlT2YoJFN5bWJvbC5wcm90b3R5cGUsICRPYmplY3QoaXQpKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9MZW5ndGggPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8tbGVuZ3RoJyk7XG5cbi8vIGBMZW5ndGhPZkFycmF5TGlrZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLWxlbmd0aG9mYXJyYXlsaWtlXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChvYmopIHtcbiAgcmV0dXJuIHRvTGVuZ3RoKG9iai5sZW5ndGgpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciB1bmN1cnJ5VGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mdW5jdGlvbi11bmN1cnJ5LXRoaXMnKTtcbnZhciBmYWlscyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mYWlscycpO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcbnZhciBoYXNPd24gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaGFzLW93bi1wcm9wZXJ0eScpO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgQ09ORklHVVJBQkxFX0ZVTkNUSU9OX05BTUUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tbmFtZScpLkNPTkZJR1VSQUJMRTtcbnZhciBpbnNwZWN0U291cmNlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2luc3BlY3Qtc291cmNlJyk7XG52YXIgSW50ZXJuYWxTdGF0ZU1vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pbnRlcm5hbC1zdGF0ZScpO1xuXG52YXIgZW5mb3JjZUludGVybmFsU3RhdGUgPSBJbnRlcm5hbFN0YXRlTW9kdWxlLmVuZm9yY2U7XG52YXIgZ2V0SW50ZXJuYWxTdGF0ZSA9IEludGVybmFsU3RhdGVNb2R1bGUuZ2V0O1xudmFyICRTdHJpbmcgPSBTdHJpbmc7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBzdHJpbmdTbGljZSA9IHVuY3VycnlUaGlzKCcnLnNsaWNlKTtcbnZhciByZXBsYWNlID0gdW5jdXJyeVRoaXMoJycucmVwbGFjZSk7XG52YXIgam9pbiA9IHVuY3VycnlUaGlzKFtdLmpvaW4pO1xuXG52YXIgQ09ORklHVVJBQkxFX0xFTkdUSCA9IERFU0NSSVBUT1JTICYmICFmYWlscyhmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBkZWZpbmVQcm9wZXJ0eShmdW5jdGlvbiAoKSB7IC8qIGVtcHR5ICovIH0sICdsZW5ndGgnLCB7IHZhbHVlOiA4IH0pLmxlbmd0aCAhPT0gODtcbn0pO1xuXG52YXIgVEVNUExBVEUgPSBTdHJpbmcoU3RyaW5nKS5zcGxpdCgnU3RyaW5nJyk7XG5cbnZhciBtYWtlQnVpbHRJbiA9IG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHZhbHVlLCBuYW1lLCBvcHRpb25zKSB7XG4gIGlmIChzdHJpbmdTbGljZSgkU3RyaW5nKG5hbWUpLCAwLCA3KSA9PT0gJ1N5bWJvbCgnKSB7XG4gICAgbmFtZSA9ICdbJyArIHJlcGxhY2UoJFN0cmluZyhuYW1lKSwgL15TeW1ib2xcXCgoW14pXSopXFwpLiokLywgJyQxJykgKyAnXSc7XG4gIH1cbiAgaWYgKG9wdGlvbnMgJiYgb3B0aW9ucy5nZXR0ZXIpIG5hbWUgPSAnZ2V0ICcgKyBuYW1lO1xuICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLnNldHRlcikgbmFtZSA9ICdzZXQgJyArIG5hbWU7XG4gIGlmICghaGFzT3duKHZhbHVlLCAnbmFtZScpIHx8IChDT05GSUdVUkFCTEVfRlVOQ1RJT05fTkFNRSAmJiB2YWx1ZS5uYW1lICE9PSBuYW1lKSkge1xuICAgIGlmIChERVNDUklQVE9SUykgZGVmaW5lUHJvcGVydHkodmFsdWUsICduYW1lJywgeyB2YWx1ZTogbmFtZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuICAgIGVsc2UgdmFsdWUubmFtZSA9IG5hbWU7XG4gIH1cbiAgaWYgKENPTkZJR1VSQUJMRV9MRU5HVEggJiYgb3B0aW9ucyAmJiBoYXNPd24ob3B0aW9ucywgJ2FyaXR5JykgJiYgdmFsdWUubGVuZ3RoICE9PSBvcHRpb25zLmFyaXR5KSB7XG4gICAgZGVmaW5lUHJvcGVydHkodmFsdWUsICdsZW5ndGgnLCB7IHZhbHVlOiBvcHRpb25zLmFyaXR5IH0pO1xuICB9XG4gIHRyeSB7XG4gICAgaWYgKG9wdGlvbnMgJiYgaGFzT3duKG9wdGlvbnMsICdjb25zdHJ1Y3RvcicpICYmIG9wdGlvbnMuY29uc3RydWN0b3IpIHtcbiAgICAgIGlmIChERVNDUklQVE9SUykgZGVmaW5lUHJvcGVydHkodmFsdWUsICdwcm90b3R5cGUnLCB7IHdyaXRhYmxlOiBmYWxzZSB9KTtcbiAgICAvLyBpbiBWOCB+IENocm9tZSA1MywgcHJvdG90eXBlcyBvZiBzb21lIG1ldGhvZHMsIGxpa2UgYEFycmF5LnByb3RvdHlwZS52YWx1ZXNgLCBhcmUgbm9uLXdyaXRhYmxlXG4gICAgfSBlbHNlIGlmICh2YWx1ZS5wcm90b3R5cGUpIHZhbHVlLnByb3RvdHlwZSA9IHVuZGVmaW5lZDtcbiAgfSBjYXRjaCAoZXJyb3IpIHsgLyogZW1wdHkgKi8gfVxuICB2YXIgc3RhdGUgPSBlbmZvcmNlSW50ZXJuYWxTdGF0ZSh2YWx1ZSk7XG4gIGlmICghaGFzT3duKHN0YXRlLCAnc291cmNlJykpIHtcbiAgICBzdGF0ZS5zb3VyY2UgPSBqb2luKFRFTVBMQVRFLCB0eXBlb2YgbmFtZSA9PSAnc3RyaW5nJyA/IG5hbWUgOiAnJyk7XG4gIH0gcmV0dXJuIHZhbHVlO1xufTtcblxuLy8gYWRkIGZha2UgRnVuY3Rpb24jdG9TdHJpbmcgZm9yIGNvcnJlY3Qgd29yayB3cmFwcGVkIG1ldGhvZHMgLyBjb25zdHJ1Y3RvcnMgd2l0aCBtZXRob2RzIGxpa2UgTG9EYXNoIGlzTmF0aXZlXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZXh0ZW5kLW5hdGl2ZSAtLSByZXF1aXJlZFxuRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nID0gbWFrZUJ1aWx0SW4oZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gIHJldHVybiBpc0NhbGxhYmxlKHRoaXMpICYmIGdldEludGVybmFsU3RhdGUodGhpcykuc291cmNlIHx8IGluc3BlY3RTb3VyY2UodGhpcyk7XG59LCAndG9TdHJpbmcnKTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBjZWlsID0gTWF0aC5jZWlsO1xudmFyIGZsb29yID0gTWF0aC5mbG9vcjtcblxuLy8gYE1hdGgudHJ1bmNgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1tYXRoLnRydW5jXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tbWF0aC10cnVuYyAtLSBzYWZlXG5tb2R1bGUuZXhwb3J0cyA9IE1hdGgudHJ1bmMgfHwgZnVuY3Rpb24gdHJ1bmMoeCkge1xuICB2YXIgbiA9ICt4O1xuICByZXR1cm4gKG4gPiAwID8gZmxvb3IgOiBjZWlsKShuKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9TdHJpbmcgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8tc3RyaW5nJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyZ3VtZW50LCAkZGVmYXVsdCkge1xuICByZXR1cm4gYXJndW1lbnQgPT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50cy5sZW5ndGggPCAyID8gJycgOiAkZGVmYXVsdCA6IHRvU3RyaW5nKGFyZ3VtZW50KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vKiBnbG9iYWwgQWN0aXZlWE9iamVjdCAtLSBvbGQgSUUsIFdTSCAqL1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2FuLW9iamVjdCcpO1xudmFyIGRlZmluZVByb3BlcnRpZXNNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0aWVzJyk7XG52YXIgZW51bUJ1Z0tleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW51bS1idWcta2V5cycpO1xudmFyIGhpZGRlbktleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaGlkZGVuLWtleXMnKTtcbnZhciBodG1sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2h0bWwnKTtcbnZhciBkb2N1bWVudENyZWF0ZUVsZW1lbnQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZG9jdW1lbnQtY3JlYXRlLWVsZW1lbnQnKTtcbnZhciBzaGFyZWRLZXkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvc2hhcmVkLWtleScpO1xuXG52YXIgR1QgPSAnPic7XG52YXIgTFQgPSAnPCc7XG52YXIgUFJPVE9UWVBFID0gJ3Byb3RvdHlwZSc7XG52YXIgU0NSSVBUID0gJ3NjcmlwdCc7XG52YXIgSUVfUFJPVE8gPSBzaGFyZWRLZXkoJ0lFX1BST1RPJyk7XG5cbnZhciBFbXB0eUNvbnN0cnVjdG9yID0gZnVuY3Rpb24gKCkgeyAvKiBlbXB0eSAqLyB9O1xuXG52YXIgc2NyaXB0VGFnID0gZnVuY3Rpb24gKGNvbnRlbnQpIHtcbiAgcmV0dXJuIExUICsgU0NSSVBUICsgR1QgKyBjb250ZW50ICsgTFQgKyAnLycgKyBTQ1JJUFQgKyBHVDtcbn07XG5cbi8vIENyZWF0ZSBvYmplY3Qgd2l0aCBmYWtlIGBudWxsYCBwcm90b3R5cGU6IHVzZSBBY3RpdmVYIE9iamVjdCB3aXRoIGNsZWFyZWQgcHJvdG90eXBlXG52YXIgTnVsbFByb3RvT2JqZWN0VmlhQWN0aXZlWCA9IGZ1bmN0aW9uIChhY3RpdmVYRG9jdW1lbnQpIHtcbiAgYWN0aXZlWERvY3VtZW50LndyaXRlKHNjcmlwdFRhZygnJykpO1xuICBhY3RpdmVYRG9jdW1lbnQuY2xvc2UoKTtcbiAgdmFyIHRlbXAgPSBhY3RpdmVYRG9jdW1lbnQucGFyZW50V2luZG93Lk9iamVjdDtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZWxlc3MtYXNzaWdubWVudCAtLSBhdm9pZCBtZW1vcnkgbGVha1xuICBhY3RpdmVYRG9jdW1lbnQgPSBudWxsO1xuICByZXR1cm4gdGVtcDtcbn07XG5cbi8vIENyZWF0ZSBvYmplY3Qgd2l0aCBmYWtlIGBudWxsYCBwcm90b3R5cGU6IHVzZSBpZnJhbWUgT2JqZWN0IHdpdGggY2xlYXJlZCBwcm90b3R5cGVcbnZhciBOdWxsUHJvdG9PYmplY3RWaWFJRnJhbWUgPSBmdW5jdGlvbiAoKSB7XG4gIC8vIFRocmFzaCwgd2FzdGUgYW5kIHNvZG9teTogSUUgR0MgYnVnXG4gIHZhciBpZnJhbWUgPSBkb2N1bWVudENyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xuICB2YXIgSlMgPSAnamF2YScgKyBTQ1JJUFQgKyAnOic7XG4gIHZhciBpZnJhbWVEb2N1bWVudDtcbiAgaWZyYW1lLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gIGh0bWwuYXBwZW5kQ2hpbGQoaWZyYW1lKTtcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvaXNzdWVzLzQ3NVxuICBpZnJhbWUuc3JjID0gU3RyaW5nKEpTKTtcbiAgaWZyYW1lRG9jdW1lbnQgPSBpZnJhbWUuY29udGVudFdpbmRvdy5kb2N1bWVudDtcbiAgaWZyYW1lRG9jdW1lbnQub3BlbigpO1xuICBpZnJhbWVEb2N1bWVudC53cml0ZShzY3JpcHRUYWcoJ2RvY3VtZW50LkY9T2JqZWN0JykpO1xuICBpZnJhbWVEb2N1bWVudC5jbG9zZSgpO1xuICByZXR1cm4gaWZyYW1lRG9jdW1lbnQuRjtcbn07XG5cbi8vIENoZWNrIGZvciBkb2N1bWVudC5kb21haW4gYW5kIGFjdGl2ZSB4IHN1cHBvcnRcbi8vIE5vIG5lZWQgdG8gdXNlIGFjdGl2ZSB4IGFwcHJvYWNoIHdoZW4gZG9jdW1lbnQuZG9tYWluIGlzIG5vdCBzZXRcbi8vIHNlZSBodHRwczovL2dpdGh1Yi5jb20vZXMtc2hpbXMvZXM1LXNoaW0vaXNzdWVzLzE1MFxuLy8gdmFyaWF0aW9uIG9mIGh0dHBzOi8vZ2l0aHViLmNvbS9raXRjYW1icmlkZ2UvZXM1LXNoaW0vY29tbWl0LzRmNzM4YWMwNjYzNDZcbi8vIGF2b2lkIElFIEdDIGJ1Z1xudmFyIGFjdGl2ZVhEb2N1bWVudDtcbnZhciBOdWxsUHJvdG9PYmplY3QgPSBmdW5jdGlvbiAoKSB7XG4gIHRyeSB7XG4gICAgYWN0aXZlWERvY3VtZW50ID0gbmV3IEFjdGl2ZVhPYmplY3QoJ2h0bWxmaWxlJyk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGlnbm9yZSAqLyB9XG4gIE51bGxQcm90b09iamVjdCA9IHR5cGVvZiBkb2N1bWVudCAhPSAndW5kZWZpbmVkJ1xuICAgID8gZG9jdW1lbnQuZG9tYWluICYmIGFjdGl2ZVhEb2N1bWVudFxuICAgICAgPyBOdWxsUHJvdG9PYmplY3RWaWFBY3RpdmVYKGFjdGl2ZVhEb2N1bWVudCkgLy8gb2xkIElFXG4gICAgICA6IE51bGxQcm90b09iamVjdFZpYUlGcmFtZSgpXG4gICAgOiBOdWxsUHJvdG9PYmplY3RWaWFBY3RpdmVYKGFjdGl2ZVhEb2N1bWVudCk7IC8vIFdTSFxuICB2YXIgbGVuZ3RoID0gZW51bUJ1Z0tleXMubGVuZ3RoO1xuICB3aGlsZSAobGVuZ3RoLS0pIGRlbGV0ZSBOdWxsUHJvdG9PYmplY3RbUFJPVE9UWVBFXVtlbnVtQnVnS2V5c1tsZW5ndGhdXTtcbiAgcmV0dXJuIE51bGxQcm90b09iamVjdCgpO1xufTtcblxuaGlkZGVuS2V5c1tJRV9QUk9UT10gPSB0cnVlO1xuXG4vLyBgT2JqZWN0LmNyZWF0ZWAgbWV0aG9kXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5jcmVhdGVcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtY3JlYXRlIC0tIHNhZmVcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmNyZWF0ZSB8fCBmdW5jdGlvbiBjcmVhdGUoTywgUHJvcGVydGllcykge1xuICB2YXIgcmVzdWx0O1xuICBpZiAoTyAhPT0gbnVsbCkge1xuICAgIEVtcHR5Q29uc3RydWN0b3JbUFJPVE9UWVBFXSA9IGFuT2JqZWN0KE8pO1xuICAgIHJlc3VsdCA9IG5ldyBFbXB0eUNvbnN0cnVjdG9yKCk7XG4gICAgRW1wdHlDb25zdHJ1Y3RvcltQUk9UT1RZUEVdID0gbnVsbDtcbiAgICAvLyBhZGQgXCJfX3Byb3RvX19cIiBmb3IgT2JqZWN0LmdldFByb3RvdHlwZU9mIHBvbHlmaWxsXG4gICAgcmVzdWx0W0lFX1BST1RPXSA9IE87XG4gIH0gZWxzZSByZXN1bHQgPSBOdWxsUHJvdG9PYmplY3QoKTtcbiAgcmV0dXJuIFByb3BlcnRpZXMgPT09IHVuZGVmaW5lZCA/IHJlc3VsdCA6IGRlZmluZVByb3BlcnRpZXNNb2R1bGUuZihyZXN1bHQsIFByb3BlcnRpZXMpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xudmFyIFY4X1BST1RPVFlQRV9ERUZJTkVfQlVHID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3Y4LXByb3RvdHlwZS1kZWZpbmUtYnVnJyk7XG52YXIgZGVmaW5lUHJvcGVydHlNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eScpO1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2FuLW9iamVjdCcpO1xudmFyIHRvSW5kZXhlZE9iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1pbmRleGVkLW9iamVjdCcpO1xudmFyIG9iamVjdEtleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWtleXMnKTtcblxuLy8gYE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzYCBtZXRob2Rcbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtb2JqZWN0LmRlZmluZXByb3BlcnRpZXNcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZGVmaW5lcHJvcGVydGllcyAtLSBzYWZlXG5leHBvcnRzLmYgPSBERVNDUklQVE9SUyAmJiAhVjhfUFJPVE9UWVBFX0RFRklORV9CVUcgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyA6IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXMoTywgUHJvcGVydGllcykge1xuICBhbk9iamVjdChPKTtcbiAgdmFyIHByb3BzID0gdG9JbmRleGVkT2JqZWN0KFByb3BlcnRpZXMpO1xuICB2YXIga2V5cyA9IG9iamVjdEtleXMoUHJvcGVydGllcyk7XG4gIHZhciBsZW5ndGggPSBrZXlzLmxlbmd0aDtcbiAgdmFyIGluZGV4ID0gMDtcbiAgdmFyIGtleTtcbiAgd2hpbGUgKGxlbmd0aCA+IGluZGV4KSBkZWZpbmVQcm9wZXJ0eU1vZHVsZS5mKE8sIGtleSA9IGtleXNbaW5kZXgrK10sIHByb3BzW2tleV0pO1xuICByZXR1cm4gTztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgREVTQ1JJUFRPUlMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZGVzY3JpcHRvcnMnKTtcbnZhciBJRThfRE9NX0RFRklORSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pZTgtZG9tLWRlZmluZScpO1xudmFyIFY4X1BST1RPVFlQRV9ERUZJTkVfQlVHID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3Y4LXByb3RvdHlwZS1kZWZpbmUtYnVnJyk7XG52YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvYW4tb2JqZWN0Jyk7XG52YXIgdG9Qcm9wZXJ0eUtleSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1wcm9wZXJ0eS1rZXknKTtcblxudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWRlZmluZXByb3BlcnR5IC0tIHNhZmVcbnZhciAkZGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5ZGVzY3JpcHRvciAtLSBzYWZlXG52YXIgJGdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgRU5VTUVSQUJMRSA9ICdlbnVtZXJhYmxlJztcbnZhciBDT05GSUdVUkFCTEUgPSAnY29uZmlndXJhYmxlJztcbnZhciBXUklUQUJMRSA9ICd3cml0YWJsZSc7XG5cbi8vIGBPYmplY3QuZGVmaW5lUHJvcGVydHlgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1vYmplY3QuZGVmaW5lcHJvcGVydHlcbmV4cG9ydHMuZiA9IERFU0NSSVBUT1JTID8gVjhfUFJPVE9UWVBFX0RFRklORV9CVUcgPyBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKSB7XG4gIGFuT2JqZWN0KE8pO1xuICBQID0gdG9Qcm9wZXJ0eUtleShQKTtcbiAgYW5PYmplY3QoQXR0cmlidXRlcyk7XG4gIGlmICh0eXBlb2YgTyA9PT0gJ2Z1bmN0aW9uJyAmJiBQID09PSAncHJvdG90eXBlJyAmJiAndmFsdWUnIGluIEF0dHJpYnV0ZXMgJiYgV1JJVEFCTEUgaW4gQXR0cmlidXRlcyAmJiAhQXR0cmlidXRlc1tXUklUQUJMRV0pIHtcbiAgICB2YXIgY3VycmVudCA9ICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoTywgUCk7XG4gICAgaWYgKGN1cnJlbnQgJiYgY3VycmVudFtXUklUQUJMRV0pIHtcbiAgICAgIE9bUF0gPSBBdHRyaWJ1dGVzLnZhbHVlO1xuICAgICAgQXR0cmlidXRlcyA9IHtcbiAgICAgICAgY29uZmlndXJhYmxlOiBDT05GSUdVUkFCTEUgaW4gQXR0cmlidXRlcyA/IEF0dHJpYnV0ZXNbQ09ORklHVVJBQkxFXSA6IGN1cnJlbnRbQ09ORklHVVJBQkxFXSxcbiAgICAgICAgZW51bWVyYWJsZTogRU5VTUVSQUJMRSBpbiBBdHRyaWJ1dGVzID8gQXR0cmlidXRlc1tFTlVNRVJBQkxFXSA6IGN1cnJlbnRbRU5VTUVSQUJMRV0sXG4gICAgICAgIHdyaXRhYmxlOiBmYWxzZVxuICAgICAgfTtcbiAgICB9XG4gIH0gcmV0dXJuICRkZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKTtcbn0gOiAkZGVmaW5lUHJvcGVydHkgOiBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKSB7XG4gIGFuT2JqZWN0KE8pO1xuICBQID0gdG9Qcm9wZXJ0eUtleShQKTtcbiAgYW5PYmplY3QoQXR0cmlidXRlcyk7XG4gIGlmIChJRThfRE9NX0RFRklORSkgdHJ5IHtcbiAgICByZXR1cm4gJGRlZmluZVByb3BlcnR5KE8sIFAsIEF0dHJpYnV0ZXMpO1xuICB9IGNhdGNoIChlcnJvcikgeyAvKiBlbXB0eSAqLyB9XG4gIGlmICgnZ2V0JyBpbiBBdHRyaWJ1dGVzIHx8ICdzZXQnIGluIEF0dHJpYnV0ZXMpIHRocm93IG5ldyAkVHlwZUVycm9yKCdBY2Nlc3NvcnMgbm90IHN1cHBvcnRlZCcpO1xuICBpZiAoJ3ZhbHVlJyBpbiBBdHRyaWJ1dGVzKSBPW1BdID0gQXR0cmlidXRlcy52YWx1ZTtcbiAgcmV0dXJuIE87XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgY2FsbCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9mdW5jdGlvbi1jYWxsJyk7XG52YXIgcHJvcGVydHlJc0VudW1lcmFibGVNb2R1bGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LXByb3BlcnR5LWlzLWVudW1lcmFibGUnKTtcbnZhciBjcmVhdGVQcm9wZXJ0eURlc2NyaXB0b3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvY3JlYXRlLXByb3BlcnR5LWRlc2NyaXB0b3InKTtcbnZhciB0b0luZGV4ZWRPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8taW5kZXhlZC1vYmplY3QnKTtcbnZhciB0b1Byb3BlcnR5S2V5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLXByb3BlcnR5LWtleScpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgSUU4X0RPTV9ERUZJTkUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaWU4LWRvbS1kZWZpbmUnKTtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1nZXRvd25wcm9wZXJ0eWRlc2NyaXB0b3IgLS0gc2FmZVxudmFyICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuXG4vLyBgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcmAgbWV0aG9kXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5nZXRvd25wcm9wZXJ0eWRlc2NyaXB0b3JcbmV4cG9ydHMuZiA9IERFU0NSSVBUT1JTID8gJGdldE93blByb3BlcnR5RGVzY3JpcHRvciA6IGZ1bmN0aW9uIGdldE93blByb3BlcnR5RGVzY3JpcHRvcihPLCBQKSB7XG4gIE8gPSB0b0luZGV4ZWRPYmplY3QoTyk7XG4gIFAgPSB0b1Byb3BlcnR5S2V5KFApO1xuICBpZiAoSUU4X0RPTV9ERUZJTkUpIHRyeSB7XG4gICAgcmV0dXJuICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoTywgUCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbiAgaWYgKGhhc093bihPLCBQKSkgcmV0dXJuIGNyZWF0ZVByb3BlcnR5RGVzY3JpcHRvcighY2FsbChwcm9wZXJ0eUlzRW51bWVyYWJsZU1vZHVsZS5mLCBPLCBQKSwgT1tQXSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGludGVybmFsT2JqZWN0S2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3Qta2V5cy1pbnRlcm5hbCcpO1xudmFyIGVudW1CdWdLZXlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2VudW0tYnVnLWtleXMnKTtcblxudmFyIGhpZGRlbktleXMgPSBlbnVtQnVnS2V5cy5jb25jYXQoJ2xlbmd0aCcsICdwcm90b3R5cGUnKTtcblxuLy8gYE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzYCBtZXRob2Rcbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtb2JqZWN0LmdldG93bnByb3BlcnR5bmFtZXNcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZ2V0b3ducHJvcGVydHluYW1lcyAtLSBzYWZlXG5leHBvcnRzLmYgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyB8fCBmdW5jdGlvbiBnZXRPd25Qcm9wZXJ0eU5hbWVzKE8pIHtcbiAgcmV0dXJuIGludGVybmFsT2JqZWN0S2V5cyhPLCBoaWRkZW5LZXlzKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5c3ltYm9scyAtLSBzYWZlXG5leHBvcnRzLmYgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHVuY3VycnlUaGlzKHt9LmlzUHJvdG90eXBlT2YpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgdG9JbmRleGVkT2JqZWN0ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3RvLWluZGV4ZWQtb2JqZWN0Jyk7XG52YXIgaW5kZXhPZiA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hcnJheS1pbmNsdWRlcycpLmluZGV4T2Y7XG52YXIgaGlkZGVuS2V5cyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oaWRkZW4ta2V5cycpO1xuXG52YXIgcHVzaCA9IHVuY3VycnlUaGlzKFtdLnB1c2gpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChvYmplY3QsIG5hbWVzKSB7XG4gIHZhciBPID0gdG9JbmRleGVkT2JqZWN0KG9iamVjdCk7XG4gIHZhciBpID0gMDtcbiAgdmFyIHJlc3VsdCA9IFtdO1xuICB2YXIga2V5O1xuICBmb3IgKGtleSBpbiBPKSAhaGFzT3duKGhpZGRlbktleXMsIGtleSkgJiYgaGFzT3duKE8sIGtleSkgJiYgcHVzaChyZXN1bHQsIGtleSk7XG4gIC8vIERvbid0IGVudW0gYnVnICYgaGlkZGVuIGtleXNcbiAgd2hpbGUgKG5hbWVzLmxlbmd0aCA+IGkpIGlmIChoYXNPd24oTywga2V5ID0gbmFtZXNbaSsrXSkpIHtcbiAgICB+aW5kZXhPZihyZXN1bHQsIGtleSkgfHwgcHVzaChyZXN1bHQsIGtleSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgaW50ZXJuYWxPYmplY3RLZXlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1rZXlzLWludGVybmFsJyk7XG52YXIgZW51bUJ1Z0tleXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW51bS1idWcta2V5cycpO1xuXG4vLyBgT2JqZWN0LmtleXNgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1vYmplY3Qua2V5c1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1rZXlzIC0tIHNhZmVcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmtleXMgfHwgZnVuY3Rpb24ga2V5cyhPKSB7XG4gIHJldHVybiBpbnRlcm5hbE9iamVjdEtleXMoTywgZW51bUJ1Z0tleXMpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciAkcHJvcGVydHlJc0VudW1lcmFibGUgPSB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZ2V0b3ducHJvcGVydHlkZXNjcmlwdG9yIC0tIHNhZmVcbnZhciBnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuXG4vLyBOYXNob3JuIH4gSkRLOCBidWdcbnZhciBOQVNIT1JOX0JVRyA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvciAmJiAhJHByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoeyAxOiAyIH0sIDEpO1xuXG4vLyBgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZWAgbWV0aG9kIGltcGxlbWVudGF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5wcm90b3R5cGUucHJvcGVydHlpc2VudW1lcmFibGVcbmV4cG9ydHMuZiA9IE5BU0hPUk5fQlVHID8gZnVuY3Rpb24gcHJvcGVydHlJc0VudW1lcmFibGUoVikge1xuICB2YXIgZGVzY3JpcHRvciA9IGdldE93blByb3BlcnR5RGVzY3JpcHRvcih0aGlzLCBWKTtcbiAgcmV0dXJuICEhZGVzY3JpcHRvciAmJiBkZXNjcmlwdG9yLmVudW1lcmFibGU7XG59IDogJHByb3BlcnR5SXNFbnVtZXJhYmxlO1xuIiwiJ3VzZSBzdHJpY3QnO1xuLyogZXNsaW50LWRpc2FibGUgbm8tcHJvdG8gLS0gc2FmZSAqL1xudmFyIHVuY3VycnlUaGlzQWNjZXNzb3IgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzLWFjY2Vzc29yJyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtb2JqZWN0Jyk7XG52YXIgcmVxdWlyZU9iamVjdENvZXJjaWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9yZXF1aXJlLW9iamVjdC1jb2VyY2libGUnKTtcbnZhciBhUG9zc2libGVQcm90b3R5cGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvYS1wb3NzaWJsZS1wcm90b3R5cGUnKTtcblxuLy8gYE9iamVjdC5zZXRQcm90b3R5cGVPZmAgbWV0aG9kXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLW9iamVjdC5zZXRwcm90b3R5cGVvZlxuLy8gV29ya3Mgd2l0aCBfX3Byb3RvX18gb25seS4gT2xkIHY4IGNhbid0IHdvcmsgd2l0aCBudWxsIHByb3RvIG9iamVjdHMuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LXNldHByb3RvdHlwZW9mIC0tIHNhZmVcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8ICgnX19wcm90b19fJyBpbiB7fSA/IGZ1bmN0aW9uICgpIHtcbiAgdmFyIENPUlJFQ1RfU0VUVEVSID0gZmFsc2U7XG4gIHZhciB0ZXN0ID0ge307XG4gIHZhciBzZXR0ZXI7XG4gIHRyeSB7XG4gICAgc2V0dGVyID0gdW5jdXJyeVRoaXNBY2Nlc3NvcihPYmplY3QucHJvdG90eXBlLCAnX19wcm90b19fJywgJ3NldCcpO1xuICAgIHNldHRlcih0ZXN0LCBbXSk7XG4gICAgQ09SUkVDVF9TRVRURVIgPSB0ZXN0IGluc3RhbmNlb2YgQXJyYXk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbiAgcmV0dXJuIGZ1bmN0aW9uIHNldFByb3RvdHlwZU9mKE8sIHByb3RvKSB7XG4gICAgcmVxdWlyZU9iamVjdENvZXJjaWJsZShPKTtcbiAgICBhUG9zc2libGVQcm90b3R5cGUocHJvdG8pO1xuICAgIGlmICghaXNPYmplY3QoTykpIHJldHVybiBPO1xuICAgIGlmIChDT1JSRUNUX1NFVFRFUikgc2V0dGVyKE8sIHByb3RvKTtcbiAgICBlbHNlIE8uX19wcm90b19fID0gcHJvdG87XG4gICAgcmV0dXJuIE87XG4gIH07XG59KCkgOiB1bmRlZmluZWQpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGNhbGwgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tY2FsbCcpO1xudmFyIGlzQ2FsbGFibGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaXMtY2FsbGFibGUnKTtcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcblxudmFyICRUeXBlRXJyb3IgPSBUeXBlRXJyb3I7XG5cbi8vIGBPcmRpbmFyeVRvUHJpbWl0aXZlYCBhYnN0cmFjdCBvcGVyYXRpb25cbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtb3JkaW5hcnl0b3ByaW1pdGl2ZVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaW5wdXQsIHByZWYpIHtcbiAgdmFyIGZuLCB2YWw7XG4gIGlmIChwcmVmID09PSAnc3RyaW5nJyAmJiBpc0NhbGxhYmxlKGZuID0gaW5wdXQudG9TdHJpbmcpICYmICFpc09iamVjdCh2YWwgPSBjYWxsKGZuLCBpbnB1dCkpKSByZXR1cm4gdmFsO1xuICBpZiAoaXNDYWxsYWJsZShmbiA9IGlucHV0LnZhbHVlT2YpICYmICFpc09iamVjdCh2YWwgPSBjYWxsKGZuLCBpbnB1dCkpKSByZXR1cm4gdmFsO1xuICBpZiAocHJlZiAhPT0gJ3N0cmluZycgJiYgaXNDYWxsYWJsZShmbiA9IGlucHV0LnRvU3RyaW5nKSAmJiAhaXNPYmplY3QodmFsID0gY2FsbChmbiwgaW5wdXQpKSkgcmV0dXJuIHZhbDtcbiAgdGhyb3cgbmV3ICRUeXBlRXJyb3IoXCJDYW4ndCBjb252ZXJ0IG9iamVjdCB0byBwcmltaXRpdmUgdmFsdWVcIik7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdldEJ1aWx0SW4gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2V0LWJ1aWx0LWluJyk7XG52YXIgdW5jdXJyeVRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tdW5jdXJyeS10aGlzJyk7XG52YXIgZ2V0T3duUHJvcGVydHlOYW1lc01vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1uYW1lcycpO1xudmFyIGdldE93blByb3BlcnR5U3ltYm9sc01vZHVsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9vYmplY3QtZ2V0LW93bi1wcm9wZXJ0eS1zeW1ib2xzJyk7XG52YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvYW4tb2JqZWN0Jyk7XG5cbnZhciBjb25jYXQgPSB1bmN1cnJ5VGhpcyhbXS5jb25jYXQpO1xuXG4vLyBhbGwgb2JqZWN0IGtleXMsIGluY2x1ZGVzIG5vbi1lbnVtZXJhYmxlIGFuZCBzeW1ib2xzXG5tb2R1bGUuZXhwb3J0cyA9IGdldEJ1aWx0SW4oJ1JlZmxlY3QnLCAnb3duS2V5cycpIHx8IGZ1bmN0aW9uIG93bktleXMoaXQpIHtcbiAgdmFyIGtleXMgPSBnZXRPd25Qcm9wZXJ0eU5hbWVzTW9kdWxlLmYoYW5PYmplY3QoaXQpKTtcbiAgdmFyIGdldE93blByb3BlcnR5U3ltYm9scyA9IGdldE93blByb3BlcnR5U3ltYm9sc01vZHVsZS5mO1xuICByZXR1cm4gZ2V0T3duUHJvcGVydHlTeW1ib2xzID8gY29uY2F0KGtleXMsIGdldE93blByb3BlcnR5U3ltYm9scyhpdCkpIDoga2V5cztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgZGVmaW5lUHJvcGVydHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWRlZmluZS1wcm9wZXJ0eScpLmY7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKFRhcmdldCwgU291cmNlLCBrZXkpIHtcbiAga2V5IGluIFRhcmdldCB8fCBkZWZpbmVQcm9wZXJ0eShUYXJnZXQsIGtleSwge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFNvdXJjZVtrZXldOyB9LFxuICAgIHNldDogZnVuY3Rpb24gKGl0KSB7IFNvdXJjZVtrZXldID0gaXQ7IH1cbiAgfSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGlzTnVsbE9yVW5kZWZpbmVkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2lzLW51bGwtb3ItdW5kZWZpbmVkJyk7XG5cbnZhciAkVHlwZUVycm9yID0gVHlwZUVycm9yO1xuXG4vLyBgUmVxdWlyZU9iamVjdENvZXJjaWJsZWAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLXJlcXVpcmVvYmplY3Rjb2VyY2libGVcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIGlmIChpc051bGxPclVuZGVmaW5lZChpdCkpIHRocm93IG5ldyAkVHlwZUVycm9yKFwiQ2FuJ3QgY2FsbCBtZXRob2Qgb24gXCIgKyBpdCk7XG4gIHJldHVybiBpdDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgc2hhcmVkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZCcpO1xudmFyIHVpZCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy91aWQnKTtcblxudmFyIGtleXMgPSBzaGFyZWQoJ2tleXMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIHJldHVybiBrZXlzW2tleV0gfHwgKGtleXNba2V5XSA9IHVpZChrZXkpKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgSVNfUFVSRSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1wdXJlJyk7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xudmFyIGRlZmluZUdsb2JhbFByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2RlZmluZS1nbG9iYWwtcHJvcGVydHknKTtcblxudmFyIFNIQVJFRCA9ICdfX2NvcmUtanNfc2hhcmVkX18nO1xudmFyIHN0b3JlID0gbW9kdWxlLmV4cG9ydHMgPSBnbG9iYWxUaGlzW1NIQVJFRF0gfHwgZGVmaW5lR2xvYmFsUHJvcGVydHkoU0hBUkVELCB7fSk7XG5cbihzdG9yZS52ZXJzaW9ucyB8fCAoc3RvcmUudmVyc2lvbnMgPSBbXSkpLnB1c2goe1xuICB2ZXJzaW9uOiAnMy40MC4wJyxcbiAgbW9kZTogSVNfUFVSRSA/ICdwdXJlJyA6ICdnbG9iYWwnLFxuICBjb3B5cmlnaHQ6ICfCqSAyMDE0LTIwMjUgRGVuaXMgUHVzaGthcmV2ICh6bG9pcm9jay5ydSknLFxuICBsaWNlbnNlOiAnaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvYmxvYi92My40MC4wL0xJQ0VOU0UnLFxuICBzb3VyY2U6ICdodHRwczovL2dpdGh1Yi5jb20vemxvaXJvY2svY29yZS1qcydcbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHN0b3JlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3NoYXJlZC1zdG9yZScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChrZXksIHZhbHVlKSB7XG4gIHJldHVybiBzdG9yZVtrZXldIHx8IChzdG9yZVtrZXldID0gdmFsdWUgfHwge30pO1xufTtcbiIsIid1c2Ugc3RyaWN0Jztcbi8qIGVzbGludC1kaXNhYmxlIGVzL25vLXN5bWJvbCAtLSByZXF1aXJlZCBmb3IgdGVzdGluZyAqL1xudmFyIFY4X1ZFUlNJT04gPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZW52aXJvbm1lbnQtdjgtdmVyc2lvbicpO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2ZhaWxzJyk7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xuXG52YXIgJFN0cmluZyA9IGdsb2JhbFRoaXMuU3RyaW5nO1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5c3ltYm9scyAtLSByZXF1aXJlZCBmb3IgdGVzdGluZ1xubW9kdWxlLmV4cG9ydHMgPSAhIU9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgJiYgIWZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgdmFyIHN5bWJvbCA9IFN5bWJvbCgnc3ltYm9sIGRldGVjdGlvbicpO1xuICAvLyBDaHJvbWUgMzggU3ltYm9sIGhhcyBpbmNvcnJlY3QgdG9TdHJpbmcgY29udmVyc2lvblxuICAvLyBgZ2V0LW93bi1wcm9wZXJ0eS1zeW1ib2xzYCBwb2x5ZmlsbCBzeW1ib2xzIGNvbnZlcnRlZCB0byBvYmplY3QgYXJlIG5vdCBTeW1ib2wgaW5zdGFuY2VzXG4gIC8vIG5iOiBEbyBub3QgY2FsbCBgU3RyaW5nYCBkaXJlY3RseSB0byBhdm9pZCB0aGlzIGJlaW5nIG9wdGltaXplZCBvdXQgdG8gYHN5bWJvbCsnJ2Agd2hpY2ggd2lsbCxcbiAgLy8gb2YgY291cnNlLCBmYWlsLlxuICByZXR1cm4gISRTdHJpbmcoc3ltYm9sKSB8fCAhKE9iamVjdChzeW1ib2wpIGluc3RhbmNlb2YgU3ltYm9sKSB8fFxuICAgIC8vIENocm9tZSAzOC00MCBzeW1ib2xzIGFyZSBub3QgaW5oZXJpdGVkIGZyb20gRE9NIGNvbGxlY3Rpb25zIHByb3RvdHlwZXMgdG8gaW5zdGFuY2VzXG4gICAgIVN5bWJvbC5zaGFtICYmIFY4X1ZFUlNJT04gJiYgVjhfVkVSU0lPTiA8IDQxO1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG52YXIgdG9JbnRlZ2VyT3JJbmZpbml0eSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1pbnRlZ2VyLW9yLWluZmluaXR5Jyk7XG5cbnZhciBtYXggPSBNYXRoLm1heDtcbnZhciBtaW4gPSBNYXRoLm1pbjtcblxuLy8gSGVscGVyIGZvciBhIHBvcHVsYXIgcmVwZWF0aW5nIGNhc2Ugb2YgdGhlIHNwZWM6XG4vLyBMZXQgaW50ZWdlciBiZSA/IFRvSW50ZWdlcihpbmRleCkuXG4vLyBJZiBpbnRlZ2VyIDwgMCwgbGV0IHJlc3VsdCBiZSBtYXgoKGxlbmd0aCArIGludGVnZXIpLCAwKTsgZWxzZSBsZXQgcmVzdWx0IGJlIG1pbihpbnRlZ2VyLCBsZW5ndGgpLlxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaW5kZXgsIGxlbmd0aCkge1xuICB2YXIgaW50ZWdlciA9IHRvSW50ZWdlck9ySW5maW5pdHkoaW5kZXgpO1xuICByZXR1cm4gaW50ZWdlciA8IDAgPyBtYXgoaW50ZWdlciArIGxlbmd0aCwgMCkgOiBtaW4oaW50ZWdlciwgbGVuZ3RoKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vLyB0b09iamVjdCB3aXRoIGZhbGxiYWNrIGZvciBub24tYXJyYXktbGlrZSBFUzMgc3RyaW5nc1xudmFyIEluZGV4ZWRPYmplY3QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaW5kZXhlZC1vYmplY3QnKTtcbnZhciByZXF1aXJlT2JqZWN0Q29lcmNpYmxlID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3JlcXVpcmUtb2JqZWN0LWNvZXJjaWJsZScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gSW5kZXhlZE9iamVjdChyZXF1aXJlT2JqZWN0Q29lcmNpYmxlKGl0KSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHRydW5jID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL21hdGgtdHJ1bmMnKTtcblxuLy8gYFRvSW50ZWdlck9ySW5maW5pdHlgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy10b2ludGVnZXJvcmluZmluaXR5XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICB2YXIgbnVtYmVyID0gK2FyZ3VtZW50O1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2VsZi1jb21wYXJlIC0tIE5hTiBjaGVja1xuICByZXR1cm4gbnVtYmVyICE9PSBudW1iZXIgfHwgbnVtYmVyID09PSAwID8gMCA6IHRydW5jKG51bWJlcik7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHRvSW50ZWdlck9ySW5maW5pdHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdG8taW50ZWdlci1vci1pbmZpbml0eScpO1xuXG52YXIgbWluID0gTWF0aC5taW47XG5cbi8vIGBUb0xlbmd0aGAgYWJzdHJhY3Qgb3BlcmF0aW9uXG4vLyBodHRwczovL3RjMzkuZXMvZWNtYTI2Mi8jc2VjLXRvbGVuZ3RoXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICB2YXIgbGVuID0gdG9JbnRlZ2VyT3JJbmZpbml0eShhcmd1bWVudCk7XG4gIHJldHVybiBsZW4gPiAwID8gbWluKGxlbiwgMHgxRkZGRkZGRkZGRkZGRikgOiAwOyAvLyAyICoqIDUzIC0gMSA9PSA5MDA3MTk5MjU0NzQwOTkxXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHJlcXVpcmVPYmplY3RDb2VyY2libGUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvcmVxdWlyZS1vYmplY3QtY29lcmNpYmxlJyk7XG5cbnZhciAkT2JqZWN0ID0gT2JqZWN0O1xuXG4vLyBgVG9PYmplY3RgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy10b29iamVjdFxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgcmV0dXJuICRPYmplY3QocmVxdWlyZU9iamVjdENvZXJjaWJsZShhcmd1bWVudCkpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBjYWxsID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLWNhbGwnKTtcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1vYmplY3QnKTtcbnZhciBpc1N5bWJvbCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1zeW1ib2wnKTtcbnZhciBnZXRNZXRob2QgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2V0LW1ldGhvZCcpO1xudmFyIG9yZGluYXJ5VG9QcmltaXRpdmUgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb3JkaW5hcnktdG8tcHJpbWl0aXZlJyk7XG52YXIgd2VsbEtub3duU3ltYm9sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sJyk7XG5cbnZhciAkVHlwZUVycm9yID0gVHlwZUVycm9yO1xudmFyIFRPX1BSSU1JVElWRSA9IHdlbGxLbm93blN5bWJvbCgndG9QcmltaXRpdmUnKTtcblxuLy8gYFRvUHJpbWl0aXZlYCBhYnN0cmFjdCBvcGVyYXRpb25cbi8vIGh0dHBzOi8vdGMzOS5lcy9lY21hMjYyLyNzZWMtdG9wcmltaXRpdmVcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGlucHV0LCBwcmVmKSB7XG4gIGlmICghaXNPYmplY3QoaW5wdXQpIHx8IGlzU3ltYm9sKGlucHV0KSkgcmV0dXJuIGlucHV0O1xuICB2YXIgZXhvdGljVG9QcmltID0gZ2V0TWV0aG9kKGlucHV0LCBUT19QUklNSVRJVkUpO1xuICB2YXIgcmVzdWx0O1xuICBpZiAoZXhvdGljVG9QcmltKSB7XG4gICAgaWYgKHByZWYgPT09IHVuZGVmaW5lZCkgcHJlZiA9ICdkZWZhdWx0JztcbiAgICByZXN1bHQgPSBjYWxsKGV4b3RpY1RvUHJpbSwgaW5wdXQsIHByZWYpO1xuICAgIGlmICghaXNPYmplY3QocmVzdWx0KSB8fCBpc1N5bWJvbChyZXN1bHQpKSByZXR1cm4gcmVzdWx0O1xuICAgIHRocm93IG5ldyAkVHlwZUVycm9yKFwiQ2FuJ3QgY29udmVydCBvYmplY3QgdG8gcHJpbWl0aXZlIHZhbHVlXCIpO1xuICB9XG4gIGlmIChwcmVmID09PSB1bmRlZmluZWQpIHByZWYgPSAnbnVtYmVyJztcbiAgcmV0dXJuIG9yZGluYXJ5VG9QcmltaXRpdmUoaW5wdXQsIHByZWYpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciB0b1ByaW1pdGl2ZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy90by1wcmltaXRpdmUnKTtcbnZhciBpc1N5bWJvbCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1zeW1ib2wnKTtcblxuLy8gYFRvUHJvcGVydHlLZXlgIGFic3RyYWN0IG9wZXJhdGlvblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy10b3Byb3BlcnR5a2V5XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChhcmd1bWVudCkge1xuICB2YXIga2V5ID0gdG9QcmltaXRpdmUoYXJndW1lbnQsICdzdHJpbmcnKTtcbiAgcmV0dXJuIGlzU3ltYm9sKGtleSkgPyBrZXkgOiBrZXkgKyAnJztcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgd2VsbEtub3duU3ltYm9sID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3dlbGwta25vd24tc3ltYm9sJyk7XG5cbnZhciBUT19TVFJJTkdfVEFHID0gd2VsbEtub3duU3ltYm9sKCd0b1N0cmluZ1RhZycpO1xudmFyIHRlc3QgPSB7fTtcblxudGVzdFtUT19TVFJJTkdfVEFHXSA9ICd6JztcblxubW9kdWxlLmV4cG9ydHMgPSBTdHJpbmcodGVzdCkgPT09ICdbb2JqZWN0IHpdJztcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBjbGFzc29mID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NsYXNzb2YnKTtcblxudmFyICRTdHJpbmcgPSBTdHJpbmc7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGFyZ3VtZW50KSB7XG4gIGlmIChjbGFzc29mKGFyZ3VtZW50KSA9PT0gJ1N5bWJvbCcpIHRocm93IG5ldyBUeXBlRXJyb3IoJ0Nhbm5vdCBjb252ZXJ0IGEgU3ltYm9sIHZhbHVlIHRvIGEgc3RyaW5nJyk7XG4gIHJldHVybiAkU3RyaW5nKGFyZ3VtZW50KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgJFN0cmluZyA9IFN0cmluZztcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoYXJndW1lbnQpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gJFN0cmluZyhhcmd1bWVudCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuICdPYmplY3QnO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHVuY3VycnlUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Z1bmN0aW9uLXVuY3VycnktdGhpcycpO1xuXG52YXIgaWQgPSAwO1xudmFyIHBvc3RmaXggPSBNYXRoLnJhbmRvbSgpO1xudmFyIHRvU3RyaW5nID0gdW5jdXJyeVRoaXMoMS4wLnRvU3RyaW5nKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIHJldHVybiAnU3ltYm9sKCcgKyAoa2V5ID09PSB1bmRlZmluZWQgPyAnJyA6IGtleSkgKyAnKV8nICsgdG9TdHJpbmcoKytpZCArIHBvc3RmaXgsIDM2KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG4vKiBlc2xpbnQtZGlzYWJsZSBlcy9uby1zeW1ib2wgLS0gcmVxdWlyZWQgZm9yIHRlc3RpbmcgKi9cbnZhciBOQVRJVkVfU1lNQk9MID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3N5bWJvbC1jb25zdHJ1Y3Rvci1kZXRlY3Rpb24nKTtcblxubW9kdWxlLmV4cG9ydHMgPSBOQVRJVkVfU1lNQk9MICYmXG4gICFTeW1ib2wuc2hhbSAmJlxuICB0eXBlb2YgU3ltYm9sLml0ZXJhdG9yID09ICdzeW1ib2wnO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgZmFpbHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZmFpbHMnKTtcblxuLy8gVjggfiBDaHJvbWUgMzYtXG4vLyBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvdjgvaXNzdWVzL2RldGFpbD9pZD0zMzM0XG5tb2R1bGUuZXhwb3J0cyA9IERFU0NSSVBUT1JTICYmIGZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLW9iamVjdC1kZWZpbmVwcm9wZXJ0eSAtLSByZXF1aXJlZCBmb3IgdGVzdGluZ1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGZ1bmN0aW9uICgpIHsgLyogZW1wdHkgKi8gfSwgJ3Byb3RvdHlwZScsIHtcbiAgICB2YWx1ZTogNDIsXG4gICAgd3JpdGFibGU6IGZhbHNlXG4gIH0pLnByb3RvdHlwZSAhPT0gNDI7XG59KTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1jYWxsYWJsZScpO1xuXG52YXIgV2Vha01hcCA9IGdsb2JhbFRoaXMuV2Vha01hcDtcblxubW9kdWxlLmV4cG9ydHMgPSBpc0NhbGxhYmxlKFdlYWtNYXApICYmIC9uYXRpdmUgY29kZS8udGVzdChTdHJpbmcoV2Vha01hcCkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGdsb2JhbFRoaXMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZ2xvYmFsLXRoaXMnKTtcbnZhciBzaGFyZWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvc2hhcmVkJyk7XG52YXIgaGFzT3duID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2hhcy1vd24tcHJvcGVydHknKTtcbnZhciB1aWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdWlkJyk7XG52YXIgTkFUSVZFX1NZTUJPTCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9zeW1ib2wtY29uc3RydWN0b3ItZGV0ZWN0aW9uJyk7XG52YXIgVVNFX1NZTUJPTF9BU19VSUQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvdXNlLXN5bWJvbC1hcy11aWQnKTtcblxudmFyIFN5bWJvbCA9IGdsb2JhbFRoaXMuU3ltYm9sO1xudmFyIFdlbGxLbm93blN5bWJvbHNTdG9yZSA9IHNoYXJlZCgnd2tzJyk7XG52YXIgY3JlYXRlV2VsbEtub3duU3ltYm9sID0gVVNFX1NZTUJPTF9BU19VSUQgPyBTeW1ib2xbJ2ZvciddIHx8IFN5bWJvbCA6IFN5bWJvbCAmJiBTeW1ib2wud2l0aG91dFNldHRlciB8fCB1aWQ7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgaWYgKCFoYXNPd24oV2VsbEtub3duU3ltYm9sc1N0b3JlLCBuYW1lKSkge1xuICAgIFdlbGxLbm93blN5bWJvbHNTdG9yZVtuYW1lXSA9IE5BVElWRV9TWU1CT0wgJiYgaGFzT3duKFN5bWJvbCwgbmFtZSlcbiAgICAgID8gU3ltYm9sW25hbWVdXG4gICAgICA6IGNyZWF0ZVdlbGxLbm93blN5bWJvbCgnU3ltYm9sLicgKyBuYW1lKTtcbiAgfSByZXR1cm4gV2VsbEtub3duU3ltYm9sc1N0b3JlW25hbWVdO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnZXRCdWlsdEluID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dldC1idWlsdC1pbicpO1xudmFyIGhhc093biA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9oYXMtb3duLXByb3BlcnR5Jyk7XG52YXIgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2NyZWF0ZS1ub24tZW51bWVyYWJsZS1wcm9wZXJ0eScpO1xudmFyIGlzUHJvdG90eXBlT2YgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvb2JqZWN0LWlzLXByb3RvdHlwZS1vZicpO1xudmFyIHNldFByb3RvdHlwZU9mID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL29iamVjdC1zZXQtcHJvdG90eXBlLW9mJyk7XG52YXIgY29weUNvbnN0cnVjdG9yUHJvcGVydGllcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9jb3B5LWNvbnN0cnVjdG9yLXByb3BlcnRpZXMnKTtcbnZhciBwcm94eUFjY2Vzc29yID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL3Byb3h5LWFjY2Vzc29yJyk7XG52YXIgaW5oZXJpdElmUmVxdWlyZWQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvaW5oZXJpdC1pZi1yZXF1aXJlZCcpO1xudmFyIG5vcm1hbGl6ZVN0cmluZ0FyZ3VtZW50ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL25vcm1hbGl6ZS1zdHJpbmctYXJndW1lbnQnKTtcbnZhciBpbnN0YWxsRXJyb3JDYXVzZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pbnN0YWxsLWVycm9yLWNhdXNlJyk7XG52YXIgaW5zdGFsbEVycm9yU3RhY2sgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZXJyb3Itc3RhY2staW5zdGFsbCcpO1xudmFyIERFU0NSSVBUT1JTID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2Rlc2NyaXB0b3JzJyk7XG52YXIgSVNfUFVSRSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9pcy1wdXJlJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKEZVTExfTkFNRSwgd3JhcHBlciwgRk9SQ0VELCBJU19BR0dSRUdBVEVfRVJST1IpIHtcbiAgdmFyIFNUQUNLX1RSQUNFX0xJTUlUID0gJ3N0YWNrVHJhY2VMaW1pdCc7XG4gIHZhciBPUFRJT05TX1BPU0lUSU9OID0gSVNfQUdHUkVHQVRFX0VSUk9SID8gMiA6IDE7XG4gIHZhciBwYXRoID0gRlVMTF9OQU1FLnNwbGl0KCcuJyk7XG4gIHZhciBFUlJPUl9OQU1FID0gcGF0aFtwYXRoLmxlbmd0aCAtIDFdO1xuICB2YXIgT3JpZ2luYWxFcnJvciA9IGdldEJ1aWx0SW4uYXBwbHkobnVsbCwgcGF0aCk7XG5cbiAgaWYgKCFPcmlnaW5hbEVycm9yKSByZXR1cm47XG5cbiAgdmFyIE9yaWdpbmFsRXJyb3JQcm90b3R5cGUgPSBPcmlnaW5hbEVycm9yLnByb3RvdHlwZTtcblxuICAvLyBWOCA5LjMtIGJ1ZyBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvdjgvaXNzdWVzL2RldGFpbD9pZD0xMjAwNlxuICBpZiAoIUlTX1BVUkUgJiYgaGFzT3duKE9yaWdpbmFsRXJyb3JQcm90b3R5cGUsICdjYXVzZScpKSBkZWxldGUgT3JpZ2luYWxFcnJvclByb3RvdHlwZS5jYXVzZTtcblxuICBpZiAoIUZPUkNFRCkgcmV0dXJuIE9yaWdpbmFsRXJyb3I7XG5cbiAgdmFyIEJhc2VFcnJvciA9IGdldEJ1aWx0SW4oJ0Vycm9yJyk7XG5cbiAgdmFyIFdyYXBwZWRFcnJvciA9IHdyYXBwZXIoZnVuY3Rpb24gKGEsIGIpIHtcbiAgICB2YXIgbWVzc2FnZSA9IG5vcm1hbGl6ZVN0cmluZ0FyZ3VtZW50KElTX0FHR1JFR0FURV9FUlJPUiA/IGIgOiBhLCB1bmRlZmluZWQpO1xuICAgIHZhciByZXN1bHQgPSBJU19BR0dSRUdBVEVfRVJST1IgPyBuZXcgT3JpZ2luYWxFcnJvcihhKSA6IG5ldyBPcmlnaW5hbEVycm9yKCk7XG4gICAgaWYgKG1lc3NhZ2UgIT09IHVuZGVmaW5lZCkgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KHJlc3VsdCwgJ21lc3NhZ2UnLCBtZXNzYWdlKTtcbiAgICBpbnN0YWxsRXJyb3JTdGFjayhyZXN1bHQsIFdyYXBwZWRFcnJvciwgcmVzdWx0LnN0YWNrLCAyKTtcbiAgICBpZiAodGhpcyAmJiBpc1Byb3RvdHlwZU9mKE9yaWdpbmFsRXJyb3JQcm90b3R5cGUsIHRoaXMpKSBpbmhlcml0SWZSZXF1aXJlZChyZXN1bHQsIHRoaXMsIFdyYXBwZWRFcnJvcik7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiBPUFRJT05TX1BPU0lUSU9OKSBpbnN0YWxsRXJyb3JDYXVzZShyZXN1bHQsIGFyZ3VtZW50c1tPUFRJT05TX1BPU0lUSU9OXSk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSk7XG5cbiAgV3JhcHBlZEVycm9yLnByb3RvdHlwZSA9IE9yaWdpbmFsRXJyb3JQcm90b3R5cGU7XG5cbiAgaWYgKEVSUk9SX05BTUUgIT09ICdFcnJvcicpIHtcbiAgICBpZiAoc2V0UHJvdG90eXBlT2YpIHNldFByb3RvdHlwZU9mKFdyYXBwZWRFcnJvciwgQmFzZUVycm9yKTtcbiAgICBlbHNlIGNvcHlDb25zdHJ1Y3RvclByb3BlcnRpZXMoV3JhcHBlZEVycm9yLCBCYXNlRXJyb3IsIHsgbmFtZTogdHJ1ZSB9KTtcbiAgfSBlbHNlIGlmIChERVNDUklQVE9SUyAmJiBTVEFDS19UUkFDRV9MSU1JVCBpbiBPcmlnaW5hbEVycm9yKSB7XG4gICAgcHJveHlBY2Nlc3NvcihXcmFwcGVkRXJyb3IsIE9yaWdpbmFsRXJyb3IsIFNUQUNLX1RSQUNFX0xJTUlUKTtcbiAgICBwcm94eUFjY2Vzc29yKFdyYXBwZWRFcnJvciwgT3JpZ2luYWxFcnJvciwgJ3ByZXBhcmVTdGFja1RyYWNlJyk7XG4gIH1cblxuICBjb3B5Q29uc3RydWN0b3JQcm9wZXJ0aWVzKFdyYXBwZWRFcnJvciwgT3JpZ2luYWxFcnJvcik7XG5cbiAgaWYgKCFJU19QVVJFKSB0cnkge1xuICAgIC8vIFNhZmFyaSAxMy0gYnVnOiBXZWJBc3NlbWJseSBlcnJvcnMgZG9lcyBub3QgaGF2ZSBhIHByb3BlciBgLm5hbWVgXG4gICAgaWYgKE9yaWdpbmFsRXJyb3JQcm90b3R5cGUubmFtZSAhPT0gRVJST1JfTkFNRSkge1xuICAgICAgY3JlYXRlTm9uRW51bWVyYWJsZVByb3BlcnR5KE9yaWdpbmFsRXJyb3JQcm90b3R5cGUsICduYW1lJywgRVJST1JfTkFNRSk7XG4gICAgfVxuICAgIE9yaWdpbmFsRXJyb3JQcm90b3R5cGUuY29uc3RydWN0b3IgPSBXcmFwcGVkRXJyb3I7XG4gIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cblxuICByZXR1cm4gV3JhcHBlZEVycm9yO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciAkID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2V4cG9ydCcpO1xudmFyICRpbmNsdWRlcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hcnJheS1pbmNsdWRlcycpLmluY2x1ZGVzO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2ZhaWxzJyk7XG52YXIgYWRkVG9VbnNjb3BhYmxlcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9hZGQtdG8tdW5zY29wYWJsZXMnKTtcblxuLy8gRkY5OSsgYnVnXG52YXIgQlJPS0VOX09OX1NQQVJTRSA9IGZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGVzL25vLWFycmF5LXByb3RvdHlwZS1pbmNsdWRlcyAtLSBkZXRlY3Rpb25cbiAgcmV0dXJuICFBcnJheSgxKS5pbmNsdWRlcygpO1xufSk7XG5cbi8vIGBBcnJheS5wcm90b3R5cGUuaW5jbHVkZXNgIG1ldGhvZFxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1hcnJheS5wcm90b3R5cGUuaW5jbHVkZXNcbiQoeyB0YXJnZXQ6ICdBcnJheScsIHByb3RvOiB0cnVlLCBmb3JjZWQ6IEJST0tFTl9PTl9TUEFSU0UgfSwge1xuICBpbmNsdWRlczogZnVuY3Rpb24gaW5jbHVkZXMoZWwgLyogLCBmcm9tSW5kZXggPSAwICovKSB7XG4gICAgcmV0dXJuICRpbmNsdWRlcyh0aGlzLCBlbCwgYXJndW1lbnRzLmxlbmd0aCA+IDEgPyBhcmd1bWVudHNbMV0gOiB1bmRlZmluZWQpO1xuICB9XG59KTtcblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1hcnJheS5wcm90b3R5cGUtQEB1bnNjb3BhYmxlc1xuYWRkVG9VbnNjb3BhYmxlcygnaW5jbHVkZXMnKTtcbiIsIid1c2Ugc3RyaWN0Jztcbi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzIC0tIHJlcXVpcmVkIGZvciBmdW5jdGlvbnMgYC5sZW5ndGhgICovXG52YXIgJCA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9leHBvcnQnKTtcbnZhciBnbG9iYWxUaGlzID0gcmVxdWlyZSgnLi4vaW50ZXJuYWxzL2dsb2JhbC10aGlzJyk7XG52YXIgYXBwbHkgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZnVuY3Rpb24tYXBwbHknKTtcbnZhciB3cmFwRXJyb3JDb25zdHJ1Y3RvcldpdGhDYXVzZSA9IHJlcXVpcmUoJy4uL2ludGVybmFscy93cmFwLWVycm9yLWNvbnN0cnVjdG9yLXdpdGgtY2F1c2UnKTtcblxudmFyIFdFQl9BU1NFTUJMWSA9ICdXZWJBc3NlbWJseSc7XG52YXIgV2ViQXNzZW1ibHkgPSBnbG9iYWxUaGlzW1dFQl9BU1NFTUJMWV07XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1lcnJvci1jYXVzZSAtLSBmZWF0dXJlIGRldGVjdGlvblxudmFyIEZPUkNFRCA9IG5ldyBFcnJvcignZScsIHsgY2F1c2U6IDcgfSkuY2F1c2UgIT09IDc7XG5cbnZhciBleHBvcnRHbG9iYWxFcnJvckNhdXNlV3JhcHBlciA9IGZ1bmN0aW9uIChFUlJPUl9OQU1FLCB3cmFwcGVyKSB7XG4gIHZhciBPID0ge307XG4gIE9bRVJST1JfTkFNRV0gPSB3cmFwRXJyb3JDb25zdHJ1Y3RvcldpdGhDYXVzZShFUlJPUl9OQU1FLCB3cmFwcGVyLCBGT1JDRUQpO1xuICAkKHsgZ2xvYmFsOiB0cnVlLCBjb25zdHJ1Y3RvcjogdHJ1ZSwgYXJpdHk6IDEsIGZvcmNlZDogRk9SQ0VEIH0sIE8pO1xufTtcblxudmFyIGV4cG9ydFdlYkFzc2VtYmx5RXJyb3JDYXVzZVdyYXBwZXIgPSBmdW5jdGlvbiAoRVJST1JfTkFNRSwgd3JhcHBlcikge1xuICBpZiAoV2ViQXNzZW1ibHkgJiYgV2ViQXNzZW1ibHlbRVJST1JfTkFNRV0pIHtcbiAgICB2YXIgTyA9IHt9O1xuICAgIE9bRVJST1JfTkFNRV0gPSB3cmFwRXJyb3JDb25zdHJ1Y3RvcldpdGhDYXVzZShXRUJfQVNTRU1CTFkgKyAnLicgKyBFUlJPUl9OQU1FLCB3cmFwcGVyLCBGT1JDRUQpO1xuICAgICQoeyB0YXJnZXQ6IFdFQl9BU1NFTUJMWSwgc3RhdDogdHJ1ZSwgY29uc3RydWN0b3I6IHRydWUsIGFyaXR5OiAxLCBmb3JjZWQ6IEZPUkNFRCB9LCBPKTtcbiAgfVxufTtcblxuLy8gaHR0cHM6Ly90YzM5LmVzL2VjbWEyNjIvI3NlYy1uYXRpdmVlcnJvclxuZXhwb3J0R2xvYmFsRXJyb3JDYXVzZVdyYXBwZXIoJ0Vycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIEVycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydEdsb2JhbEVycm9yQ2F1c2VXcmFwcGVyKCdFdmFsRXJyb3InLCBmdW5jdGlvbiAoaW5pdCkge1xuICByZXR1cm4gZnVuY3Rpb24gRXZhbEVycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydEdsb2JhbEVycm9yQ2F1c2VXcmFwcGVyKCdSYW5nZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIFJhbmdlRXJyb3IobWVzc2FnZSkgeyByZXR1cm4gYXBwbHkoaW5pdCwgdGhpcywgYXJndW1lbnRzKTsgfTtcbn0pO1xuZXhwb3J0R2xvYmFsRXJyb3JDYXVzZVdyYXBwZXIoJ1JlZmVyZW5jZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIFJlZmVyZW5jZUVycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydEdsb2JhbEVycm9yQ2F1c2VXcmFwcGVyKCdTeW50YXhFcnJvcicsIGZ1bmN0aW9uIChpbml0KSB7XG4gIHJldHVybiBmdW5jdGlvbiBTeW50YXhFcnJvcihtZXNzYWdlKSB7IHJldHVybiBhcHBseShpbml0LCB0aGlzLCBhcmd1bWVudHMpOyB9O1xufSk7XG5leHBvcnRHbG9iYWxFcnJvckNhdXNlV3JhcHBlcignVHlwZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIFR5cGVFcnJvcihtZXNzYWdlKSB7IHJldHVybiBhcHBseShpbml0LCB0aGlzLCBhcmd1bWVudHMpOyB9O1xufSk7XG5leHBvcnRHbG9iYWxFcnJvckNhdXNlV3JhcHBlcignVVJJRXJyb3InLCBmdW5jdGlvbiAoaW5pdCkge1xuICByZXR1cm4gZnVuY3Rpb24gVVJJRXJyb3IobWVzc2FnZSkgeyByZXR1cm4gYXBwbHkoaW5pdCwgdGhpcywgYXJndW1lbnRzKTsgfTtcbn0pO1xuZXhwb3J0V2ViQXNzZW1ibHlFcnJvckNhdXNlV3JhcHBlcignQ29tcGlsZUVycm9yJywgZnVuY3Rpb24gKGluaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIENvbXBpbGVFcnJvcihtZXNzYWdlKSB7IHJldHVybiBhcHBseShpbml0LCB0aGlzLCBhcmd1bWVudHMpOyB9O1xufSk7XG5leHBvcnRXZWJBc3NlbWJseUVycm9yQ2F1c2VXcmFwcGVyKCdMaW5rRXJyb3InLCBmdW5jdGlvbiAoaW5pdCkge1xuICByZXR1cm4gZnVuY3Rpb24gTGlua0Vycm9yKG1lc3NhZ2UpIHsgcmV0dXJuIGFwcGx5KGluaXQsIHRoaXMsIGFyZ3VtZW50cyk7IH07XG59KTtcbmV4cG9ydFdlYkFzc2VtYmx5RXJyb3JDYXVzZVdyYXBwZXIoJ1J1bnRpbWVFcnJvcicsIGZ1bmN0aW9uIChpbml0KSB7XG4gIHJldHVybiBmdW5jdGlvbiBSdW50aW1lRXJyb3IobWVzc2FnZSkgeyByZXR1cm4gYXBwbHkoaW5pdCwgdGhpcywgYXJndW1lbnRzKTsgfTtcbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyICQgPSByZXF1aXJlKCcuLi9pbnRlcm5hbHMvZXhwb3J0Jyk7XG52YXIgZ2xvYmFsVGhpcyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9nbG9iYWwtdGhpcycpO1xudmFyIGRlZmluZUJ1aWx0SW5BY2Nlc3NvciA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZWZpbmUtYnVpbHQtaW4tYWNjZXNzb3InKTtcbnZhciBERVNDUklQVE9SUyA9IHJlcXVpcmUoJy4uL2ludGVybmFscy9kZXNjcmlwdG9ycycpO1xuXG52YXIgJFR5cGVFcnJvciA9IFR5cGVFcnJvcjtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcy9uby1vYmplY3QtZGVmaW5lcHJvcGVydHkgLS0gc2FmZVxudmFyIGRlZmluZVByb3BlcnR5ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIElOQ09SUkVDVF9WQUxVRSA9IGdsb2JhbFRoaXMuc2VsZiAhPT0gZ2xvYmFsVGhpcztcblxuLy8gYHNlbGZgIGdldHRlclxuLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2Uvd2luZG93LW9iamVjdC5odG1sI2RvbS1zZWxmXG50cnkge1xuICBpZiAoREVTQ1JJUFRPUlMpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXMvbm8tb2JqZWN0LWdldG93bnByb3BlcnR5ZGVzY3JpcHRvciAtLSBzYWZlXG4gICAgdmFyIGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGdsb2JhbFRoaXMsICdzZWxmJyk7XG4gICAgLy8gc29tZSBlbmdpbmVzIGhhdmUgYHNlbGZgLCBidXQgd2l0aCBpbmNvcnJlY3QgZGVzY3JpcHRvclxuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9kZW5vbGFuZC9kZW5vL2lzc3Vlcy8xNTc2NVxuICAgIGlmIChJTkNPUlJFQ1RfVkFMVUUgfHwgIWRlc2NyaXB0b3IgfHwgIWRlc2NyaXB0b3IuZ2V0IHx8ICFkZXNjcmlwdG9yLmVudW1lcmFibGUpIHtcbiAgICAgIGRlZmluZUJ1aWx0SW5BY2Nlc3NvcihnbG9iYWxUaGlzLCAnc2VsZicsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiBzZWxmKCkge1xuICAgICAgICAgIHJldHVybiBnbG9iYWxUaGlzO1xuICAgICAgICB9LFxuICAgICAgICBzZXQ6IGZ1bmN0aW9uIHNlbGYodmFsdWUpIHtcbiAgICAgICAgICBpZiAodGhpcyAhPT0gZ2xvYmFsVGhpcykgdGhyb3cgbmV3ICRUeXBlRXJyb3IoJ0lsbGVnYWwgaW52b2NhdGlvbicpO1xuICAgICAgICAgIGRlZmluZVByb3BlcnR5KGdsb2JhbFRoaXMsICdzZWxmJywge1xuICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9IGVsc2UgJCh7IGdsb2JhbDogdHJ1ZSwgc2ltcGxlOiB0cnVlLCBmb3JjZWQ6IElOQ09SUkVDVF9WQUxVRSB9LCB7XG4gICAgc2VsZjogZ2xvYmFsVGhpc1xuICB9KTtcbn0gY2F0Y2ggKGVycm9yKSB7IC8qIGVtcHR5ICovIH1cbiIsIi8qKlxuICogQ2hlY2tzIGlmIGVycm9yIGhhcyBtZXNzYWdlLlxuICpcbiAqIEBwYXJhbSBlcnJvciBFcnJvciBvYmplY3QuXG4gKiBAcmV0dXJucyBUcnVlIGlmIGVycm9yIGhhcyBtZXNzYWdlLlxuICovXG5mdW5jdGlvbiBpc0Vycm9yV2l0aE1lc3NhZ2UoZXJyb3IpIHtcbiAgICByZXR1cm4gKHR5cGVvZiBlcnJvciA9PT0gJ29iamVjdCdcbiAgICAgICAgJiYgZXJyb3IgIT09IG51bGxcbiAgICAgICAgJiYgJ21lc3NhZ2UnIGluIGVycm9yXG4gICAgICAgICYmIHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSAnc3RyaW5nJyk7XG59XG4vKipcbiAqIENvbnZlcnRzIGVycm9yIHRvIHRoZSBlcnJvciB3aXRoIGEgbWVzc2FnZS5cbiAqXG4gKiBAcGFyYW0gbWF5YmVFcnJvciBQb3NzaWJsZSBlcnJvci5cbiAqIEByZXR1cm5zIEVycm9yIHdpdGggYSBtZXNzYWdlLlxuICovXG5mdW5jdGlvbiB0b0Vycm9yV2l0aE1lc3NhZ2UobWF5YmVFcnJvcikge1xuICAgIGlmIChpc0Vycm9yV2l0aE1lc3NhZ2UobWF5YmVFcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIG1heWJlRXJyb3I7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkobWF5YmVFcnJvcikpO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIC8vIGZhbGxiYWNrIGluIGNhc2UgdGhlcmUncyBhbiBlcnJvciBzdHJpbmdpZnlpbmcgdGhlIG1heWJlRXJyb3JcbiAgICAgICAgLy8gbGlrZSB3aXRoIGNpcmN1bGFyIHJlZmVyZW5jZXMsIGZvciBleGFtcGxlLlxuICAgICAgICByZXR1cm4gbmV3IEVycm9yKFN0cmluZyhtYXliZUVycm9yKSk7XG4gICAgfVxufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBlcnJvciBvYmplY3QgdG8gYW4gZXJyb3Igd2l0aCBhIG1lc3NhZ2UuIFRoaXMgbWV0aG9kIG1pZ2h0IGJlIGhlbHBmdWwgdG8gaGFuZGxlIHRocm93biBlcnJvcnMuXG4gKlxuICogQHBhcmFtIGVycm9yIEVycm9yIG9iamVjdC5cbiAqXG4gKiBAcmV0dXJucyBNZXNzYWdlIG9mIHRoZSBlcnJvci5cbiAqL1xuZnVuY3Rpb24gZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB7XG4gICAgcmV0dXJuIHRvRXJyb3JXaXRoTWVzc2FnZShlcnJvcikubWVzc2FnZTtcbn1cblxuLyoqXG4gKiBQYWRzIGEgbnVtYmVyIHdpdGggbGVhZGluZyB6ZXJvcy5cbiAqIEBwYXJhbSBudW0gVGhlIG51bWJlciB0byBwYWQuXG4gKiBAcGFyYW0gc2l6ZSBUaGUgbnVtYmVyIG9mIGRpZ2l0cyB0byBwYWQgdG8uXG4gKiBAcmV0dXJucyBUaGUgcGFkZGVkIG51bWJlci5cbiAqL1xuY29uc3QgcGFkID0gKG51bSwgc2l6ZSA9IDIpID0+IHtcbiAgICByZXR1cm4gbnVtLnRvU3RyaW5nKCkucGFkU3RhcnQoc2l6ZSwgJzAnKTtcbn07XG4vKipcbiAqIEZvcm1hdHMgYSBkYXRlIGludG8gYW4gSVNPIDg2MDEtbGlrZSBzdHJpbmcgd2l0aCBtaWxsaXNlY29uZHMuXG4gKlxuICogQHBhcmFtIHtEYXRlfG51bWJlcn0gZGF0ZSBUaGUgZGF0ZSBvYmplY3Qgb3IgdGltZXN0YW1wIHRvIGZvcm1hdC5cbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBmb3JtYXR0ZWQgZGF0ZSBzdHJpbmcuXG4gKi9cbmNvbnN0IGZvcm1hdFRpbWUgPSAoZGF0ZSkgPT4ge1xuICAgIGNvbnN0IGQgPSAoZGF0ZSBpbnN0YW5jZW9mIERhdGUpID8gZGF0ZSA6IG5ldyBEYXRlKGRhdGUpO1xuICAgIGNvbnN0IHllYXIgPSBkLmdldEZ1bGxZZWFyKCk7XG4gICAgY29uc3QgbW9udGggPSBwYWQoZC5nZXRNb250aCgpICsgMSk7IC8vIE1vbnRocyBhcmUgMC1iYXNlZFxuICAgIGNvbnN0IGRheSA9IHBhZChkLmdldERhdGUoKSk7XG4gICAgY29uc3QgaG91ciA9IHBhZChkLmdldEhvdXJzKCkpO1xuICAgIGNvbnN0IG1pbnV0ZSA9IHBhZChkLmdldE1pbnV0ZXMoKSk7XG4gICAgY29uc3Qgc2Vjb25kID0gcGFkKGQuZ2V0U2Vjb25kcygpKTtcbiAgICBjb25zdCBtaWxsaXNlY29uZCA9IHBhZChkLmdldE1pbGxpc2Vjb25kcygpLCAzKTsgLy8gTWlsbGlzZWNvbmRzIGFyZSAzIGRpZ2l0c1xuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1UJHtob3VyfToke21pbnV0ZX06JHtzZWNvbmR9OiR7bWlsbGlzZWNvbmR9YDtcbn07XG5cbi8qKlxuICogU3RyaW5nIHByZXNlbnRhdGlvbiBvZiBsb2cgbGV2ZWxzLCBmb3IgY29udmVuaWVudCB1c2VycyB1c2FnZS5cbiAqL1xudmFyIExvZ0xldmVsO1xuKGZ1bmN0aW9uIChMb2dMZXZlbCkge1xuICAgIExvZ0xldmVsW1wiRXJyb3JcIl0gPSBcImVycm9yXCI7XG4gICAgTG9nTGV2ZWxbXCJXYXJuXCJdID0gXCJ3YXJuXCI7XG4gICAgTG9nTGV2ZWxbXCJJbmZvXCJdID0gXCJpbmZvXCI7XG4gICAgTG9nTGV2ZWxbXCJEZWJ1Z1wiXSA9IFwiZGVidWdcIjtcbiAgICBMb2dMZXZlbFtcIlRyYWNlXCJdID0gXCJ0cmFjZVwiO1xufSkoTG9nTGV2ZWwgfHwgKExvZ0xldmVsID0ge30pKTtcbi8qKlxuICogTG9nIGxldmVscyBtYXAsIHdoaWNoIG1hcHMgbnVtYmVyIGxldmVsIHRvIHN0cmluZyBsZXZlbC5cbiAqL1xuY29uc3QgbGV2ZWxNYXBOdW1Ub1N0cmluZyA9IHtcbiAgICBbMSAvKiBMb2dMZXZlbE51bWVyaWMuRXJyb3IgKi9dOiBMb2dMZXZlbC5FcnJvcixcbiAgICBbMiAvKiBMb2dMZXZlbE51bWVyaWMuV2FybiAqL106IExvZ0xldmVsLldhcm4sXG4gICAgWzMgLyogTG9nTGV2ZWxOdW1lcmljLkluZm8gKi9dOiBMb2dMZXZlbC5JbmZvLFxuICAgIFs0IC8qIExvZ0xldmVsTnVtZXJpYy5EZWJ1ZyAqL106IExvZ0xldmVsLkRlYnVnLFxuICAgIFs1IC8qIExvZ0xldmVsTnVtZXJpYy5UcmFjZSAqL106IExvZ0xldmVsLlRyYWNlLFxufTtcbi8qKlxuICogTG9nIGxldmVscyBtYXAsIHdoaWNoIG1hcHMgc3RyaW5nIGxldmVsIHRvIG51bWJlciBsZXZlbC5cbiAqL1xuY29uc3QgbGV2ZWxNYXBTdHJpbmdUb051bSA9IE9iamVjdC5lbnRyaWVzKGxldmVsTWFwTnVtVG9TdHJpbmcpXG4gICAgLnJlZHVjZSgoYWNjLCBba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAvLyBIZXJlLCBrZXkgaXMgb3JpZ2luYWxseSBhIHN0cmluZyBzaW5jZSBPYmplY3QuZW50cmllcygpIHJldHVybnMgW3N0cmluZywgc3RyaW5nXVtdLlxuICAgIC8vIFdlIG5lZWQgdG8gY2FzdCB0aGUga2V5IHRvIExvZ0xldmVsTnVtZXJpYyBjb3JyZWN0bHkgd2l0aG91dCBjYXVzaW5nIHR5cGUgbWlzbWF0Y2hlcy5cbiAgICBjb25zdCBudW1lcmljS2V5ID0gTnVtYmVyKGtleSk7XG4gICAgaWYgKCFOdW1iZXIuaXNOYU4obnVtZXJpY0tleSkpIHtcbiAgICAgICAgYWNjW3ZhbHVlXSA9IG51bWVyaWNLZXk7XG4gICAgfVxuICAgIHJldHVybiBhY2M7XG59LCB7fSk7XG4vKipcbiAqIFNpbXBsZSBsb2dnZXIgd2l0aCBsb2cgbGV2ZWxzLlxuICovXG5jbGFzcyBMb2dnZXIge1xuICAgIGN1cnJlbnRMZXZlbFZhbHVlID0gMyAvKiBMb2dMZXZlbE51bWVyaWMuSW5mbyAqLztcbiAgICB3cml0ZXI7XG4gICAgLyoqXG4gICAgICogQ29uc3RydWN0b3IuXG4gICAgICogQHBhcmFtIHdyaXRlciBXcml0ZXIgb2JqZWN0LlxuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKHdyaXRlciA9IGNvbnNvbGUpIHtcbiAgICAgICAgdGhpcy53cml0ZXIgPSB3cml0ZXI7XG4gICAgICAgIC8vIGJpbmQgdGhlIGxvZ2dpbmcgbWV0aG9kcyB0byBhdm9pZCBsb3NpbmcgY29udGV4dFxuICAgICAgICB0aGlzLmRlYnVnID0gdGhpcy5kZWJ1Zy5iaW5kKHRoaXMpO1xuICAgICAgICB0aGlzLmluZm8gPSB0aGlzLmluZm8uYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy53YXJuID0gdGhpcy53YXJuLmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMuZXJyb3IgPSB0aGlzLmVycm9yLmJpbmQodGhpcyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByaW50IGRlYnVnIG1lc3NhZ2VzLiBVc3VhbGx5IHVzZWQgZm9yIHRlY2huaWNhbCBpbmZvcm1hdGlvbi5cbiAgICAgKiBXaWxsIGJlIHByaW50ZWQgaW4gJ2xvZycgY2hhbm5lbC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcmdzIFByaW50ZWQgYXJndW1lbnRzLlxuICAgICAqL1xuICAgIGRlYnVnKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5wcmludCg0IC8qIExvZ0xldmVsTnVtZXJpYy5EZWJ1ZyAqLywgXCJsb2dcIiAvKiBMb2dNZXRob2QuTG9nICovLCBhcmdzKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHJpbnQgbWVzc2FnZXMgeW91IHdhbnQgdG8gZGlzY2xvc2UgdG8gdXNlcnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYXJncyBQcmludGVkIGFyZ3VtZW50cy5cbiAgICAgKi9cbiAgICBpbmZvKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5wcmludCgzIC8qIExvZ0xldmVsTnVtZXJpYy5JbmZvICovLCBcImluZm9cIiAvKiBMb2dNZXRob2QuSW5mbyAqLywgYXJncyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByaW50IHdhcm4gbWVzc2FnZXMuXG4gICAgICogTk9URTogV2UgZG8gbm90IHVzZSAnd2FybicgY2hhbm5lbCwgc2luY2UgaW4gdGhlIGV4dGVuc2lvbnMgd2FybiBpc1xuICAgICAqIGNvdW50ZWQgYXMgZXJyb3IuIEluc3RlYWQgb2YgdGhpcyB3ZSB1c2UgJ2luZm8nIGNoYW5uZWwuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYXJncyBQcmludGVkIGFyZ3VtZW50cy5cbiAgICAgKi9cbiAgICB3YXJuKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5wcmludCgyIC8qIExvZ0xldmVsTnVtZXJpYy5XYXJuICovLCBcImluZm9cIiAvKiBMb2dNZXRob2QuSW5mbyAqLywgYXJncyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByaW50IGVycm9yIG1lc3NhZ2VzLlxuICAgICAqXG4gICAgICogQHBhcmFtIGFyZ3MgUHJpbnRlZCBhcmd1bWVudHMuXG4gICAgICovXG4gICAgZXJyb3IoLi4uYXJncykge1xuICAgICAgICB0aGlzLnByaW50KDEgLyogTG9nTGV2ZWxOdW1lcmljLkVycm9yICovLCBcImVycm9yXCIgLyogTG9nTWV0aG9kLkVycm9yICovLCBhcmdzKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0dGVyIGZvciBsb2cgbGV2ZWwuXG4gICAgICogQHJldHVybnMgTG9nZ2VyIGxldmVsLlxuICAgICAqL1xuICAgIGdldCBjdXJyZW50TGV2ZWwoKSB7XG4gICAgICAgIHJldHVybiBsZXZlbE1hcE51bVRvU3RyaW5nW3RoaXMuY3VycmVudExldmVsVmFsdWVdO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTZXR0ZXIgZm9yIGxvZyBsZXZlbC4gV2l0aCB0aGlzIG1ldGhvZCBsb2cgbGV2ZWwgY2FuIGJlIHVwZGF0ZWQgZHluYW1pY2FsbHkuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbG9nTGV2ZWwgTG9nZ2VyIGxldmVsLlxuICAgICAqIEB0aHJvd3MgRXJyb3IgaWYgbG9nIGxldmVsIGlzIG5vdCBzdXBwb3J0ZWQuXG4gICAgICovXG4gICAgc2V0IGN1cnJlbnRMZXZlbChsb2dMZXZlbCkge1xuICAgICAgICBjb25zdCBsZXZlbCA9IGxldmVsTWFwU3RyaW5nVG9OdW1bbG9nTGV2ZWxdO1xuICAgICAgICBpZiAobGV2ZWwgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBMb2dnZXIgc3VwcG9ydHMgb25seSB0aGUgZm9sbG93aW5nIGxldmVsczogJHtbT2JqZWN0LnZhbHVlcyhMb2dMZXZlbCkuam9pbignLCAnKV19YCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jdXJyZW50TGV2ZWxWYWx1ZSA9IGxldmVsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0cyBlcnJvciB0byBzdHJpbmcsIGFuZCBhZGRzIHN0YWNrIHRyYWNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIGVycm9yIEVycm9yIHRvIHByaW50LlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQHJldHVybnMgRXJyb3IgbWVzc2FnZS5cbiAgICAgKi9cbiAgICBzdGF0aWMgZXJyb3JUb1N0cmluZyhlcnJvcikge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gZ2V0RXJyb3JNZXNzYWdlKGVycm9yKTtcbiAgICAgICAgcmV0dXJuIGAke21lc3NhZ2V9XFxuU3RhY2sgdHJhY2U6XFxuJHtlcnJvci5zdGFja31gO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBXcmFwcGVyIG92ZXIgbG9nIG1ldGhvZHMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbGV2ZWwgTG9nZ2VyIGxldmVsLlxuICAgICAqIEBwYXJhbSBtZXRob2QgTG9nZ2VyIG1ldGhvZC5cbiAgICAgKiBAcGFyYW0gYXJncyBQcmludGVkIGFyZ3VtZW50cy5cbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIHByaW50KGxldmVsLCBtZXRob2QsIGFyZ3MpIHtcbiAgICAgICAgLy8gc2tpcCB3cml0aW5nIGlmIHRoZSBiYXNpYyBjb25kaXRpb25zIGFyZSBub3QgbWV0XG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnRMZXZlbFZhbHVlIDwgbGV2ZWwpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWFyZ3MgfHwgYXJncy5sZW5ndGggPT09IDAgfHwgIWFyZ3NbMF0pIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmb3JtYXR0ZWRBcmdzID0gYXJncy5tYXAoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgICAgIHJldHVybiBMb2dnZXIuZXJyb3JUb1N0cmluZyh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlLm1lc3NhZ2UgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlLm1lc3NhZ2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZFRpbWUgPSBgJHtmb3JtYXRUaW1lKG5ldyBEYXRlKCkpfTpgO1xuICAgICAgICAvKipcbiAgICAgICAgICogQ29uZGl0aW9ucyBpbiB3aGljaCB0cmFjZSBjYW4gaGFwcGVuOlxuICAgICAgICAgKiAxLiBNZXRob2QgaXMgbm90IGVycm9yIChiZWNhdXNlIGNvbnNvbGUuZXJyb3IgcHJvdmlkZXMgY2FsbCBzdGFjayB0cmFjZSlcbiAgICAgICAgICogMi4gTG9nIGxldmVsIGlzIGVxdWFsIG9yIGhpZ2hlciB0aGF0IGBMb2dMZXZlbC5UcmFjZWAuXG4gICAgICAgICAqIDMuIFdyaXRlciBoYXMgYHRyYWNlYCBtZXRob2QuXG4gICAgICAgICAqL1xuICAgICAgICBpZiAobWV0aG9kID09PSBcImVycm9yXCIgLyogTG9nTWV0aG9kLkVycm9yICovXG4gICAgICAgICAgICB8fCB0aGlzLmN1cnJlbnRMZXZlbFZhbHVlIDwgbGV2ZWxNYXBTdHJpbmdUb051bVtMb2dMZXZlbC5UcmFjZV1cbiAgICAgICAgICAgIHx8ICF0aGlzLndyaXRlci50cmFjZSkge1xuICAgICAgICAgICAgLy8gUHJpbnQgd2l0aCByZWd1bGFyIG1ldGhvZFxuICAgICAgICAgICAgdGhpcy53cml0ZXJbbWV0aG9kXShmb3JtYXR0ZWRUaW1lLCAuLi5mb3JtYXR0ZWRBcmdzKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMud3JpdGVyLmdyb3VwQ29sbGFwc2VkIHx8ICF0aGlzLndyaXRlci5ncm91cEVuZCkge1xuICAgICAgICAgICAgLy8gUHJpbnQgZXhwYW5kZWQgdHJhY2VcbiAgICAgICAgICAgIHRoaXMud3JpdGVyLnRyYWNlKGZvcm1hdHRlZFRpbWUsIC4uLmZvcm1hdHRlZEFyZ3MpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIFByaW50IGNvbGxhcHNlZCB0cmFjZVxuICAgICAgICB0aGlzLndyaXRlci5ncm91cENvbGxhcHNlZChmb3JtYXR0ZWRUaW1lLCAuLi5mb3JtYXR0ZWRBcmdzKTtcbiAgICAgICAgdGhpcy53cml0ZXIudHJhY2UoKTtcbiAgICAgICAgdGhpcy53cml0ZXIuZ3JvdXBFbmQoKTtcbiAgICB9XG59XG5cbmV4cG9ydCB7IExvZ0xldmVsLCBMb2dnZXIgfTtcbiIsImltcG9ydCB7IHVybEFscGhhYmV0IH0gZnJvbSAnLi91cmwtYWxwaGFiZXQvaW5kZXguanMnXG5sZXQgcmFuZG9tID0gYnl0ZXMgPT4gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheShieXRlcykpXG5sZXQgY3VzdG9tUmFuZG9tID0gKGFscGhhYmV0LCBkZWZhdWx0U2l6ZSwgZ2V0UmFuZG9tKSA9PiB7XG4gIGxldCBtYXNrID0gKDIgPDwgKE1hdGgubG9nKGFscGhhYmV0Lmxlbmd0aCAtIDEpIC8gTWF0aC5MTjIpKSAtIDFcbiAgbGV0IHN0ZXAgPSAtfigoMS42ICogbWFzayAqIGRlZmF1bHRTaXplKSAvIGFscGhhYmV0Lmxlbmd0aClcbiAgcmV0dXJuIChzaXplID0gZGVmYXVsdFNpemUpID0+IHtcbiAgICBsZXQgaWQgPSAnJ1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBsZXQgYnl0ZXMgPSBnZXRSYW5kb20oc3RlcClcbiAgICAgIGxldCBqID0gc3RlcFxuICAgICAgd2hpbGUgKGotLSkge1xuICAgICAgICBpZCArPSBhbHBoYWJldFtieXRlc1tqXSAmIG1hc2tdIHx8ICcnXG4gICAgICAgIGlmIChpZC5sZW5ndGggPT09IHNpemUpIHJldHVybiBpZFxuICAgICAgfVxuICAgIH1cbiAgfVxufVxubGV0IGN1c3RvbUFscGhhYmV0ID0gKGFscGhhYmV0LCBzaXplID0gMjEpID0+XG4gIGN1c3RvbVJhbmRvbShhbHBoYWJldCwgc2l6ZSwgcmFuZG9tKVxubGV0IG5hbm9pZCA9IChzaXplID0gMjEpID0+XG4gIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoc2l6ZSkpLnJlZHVjZSgoaWQsIGJ5dGUpID0+IHtcbiAgICBieXRlICY9IDYzXG4gICAgaWYgKGJ5dGUgPCAzNikge1xuICAgICAgaWQgKz0gYnl0ZS50b1N0cmluZygzNilcbiAgICB9IGVsc2UgaWYgKGJ5dGUgPCA2Mikge1xuICAgICAgaWQgKz0gKGJ5dGUgLSAyNikudG9TdHJpbmcoMzYpLnRvVXBwZXJDYXNlKClcbiAgICB9IGVsc2UgaWYgKGJ5dGUgPiA2Mikge1xuICAgICAgaWQgKz0gJy0nXG4gICAgfSBlbHNlIHtcbiAgICAgIGlkICs9ICdfJ1xuICAgIH1cbiAgICByZXR1cm4gaWRcbiAgfSwgJycpXG5leHBvcnQgeyBuYW5vaWQsIGN1c3RvbUFscGhhYmV0LCBjdXN0b21SYW5kb20sIHVybEFscGhhYmV0LCByYW5kb20gfVxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIl9fd2VicGFja19yZXF1aXJlX18uYW1kTyA9IHt9OyIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5nID0gKGZ1bmN0aW9uKCkge1xuXHRpZiAodHlwZW9mIGdsb2JhbFRoaXMgPT09ICdvYmplY3QnKSByZXR1cm4gZ2xvYmFsVGhpcztcblx0dHJ5IHtcblx0XHRyZXR1cm4gdGhpcyB8fCBuZXcgRnVuY3Rpb24oJ3JldHVybiB0aGlzJykoKTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdGlmICh0eXBlb2Ygd2luZG93ID09PSAnb2JqZWN0JykgcmV0dXJuIHdpbmRvdztcblx0fVxufSkoKTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLyoqXG4gKiBAZmlsZVxuICogVGhpcyBmaWxlIGlzIHBhcnQgb2YgQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiAoaHR0cHM6Ly9naXRodWIuY29tL0FkZ3VhcmRUZWFtL0FkZ3VhcmRCcm93c2VyRXh0ZW5zaW9uKS5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGZyZWUgc29mdHdhcmU6IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXG4gKiBidXQgV0lUSE9VVCBBTlkgV0FSUkFOVFk7IHdpdGhvdXQgZXZlbiB0aGUgaW1wbGllZCB3YXJyYW50eSBvZlxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLlxuICogU2VlIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxuICpcbiAqIFlvdSBzaG91bGQgaGF2ZSByZWNlaXZlZCBhIGNvcHkgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBhbG9uZyB3aXRoIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24uIElmIG5vdCwgc2VlIDxodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvPi5cbiAqL1xuXG5pbXBvcnQgeyB0aGFua3lvdSB9IGZyb20gJy4uLy4uL3NyYy9wYWdlcy90aGFua3lvdSc7XG5cbnRoYW5reW91LmluaXQoKTtcbiJdLCJuYW1lcyI6WyJMb2dnZXIiLCJMb2dMZXZlbCIsIkV4dGVuZGVkTG9nZ2VyIiwiaXNWZXJib3NlIiwiY3VycmVudExldmVsIiwiRGVidWciLCJUcmFjZSIsImxvZ2dlciIsIklTX1JFTEVBU0UiLCJJU19CRVRBIiwiSW5mbyIsIk9iamVjdCIsImFzc2lnbiIsInNlbGYiLCJhZGd1YXJkIiwiQVBQX01FU1NBR0VfSEFORExFUl9OQU1FIiwiTWVzc2FnZVR5cGUiLCJicm93c2VyIiwibWVzc2FnZUhhc1R5cGVGaWVsZCIsIm1lc3NhZ2UiLCJtZXNzYWdlSGFzVHlwZUFuZERhdGFGaWVsZHMiLCJNZXNzYWdlSGFuZGxlciIsImluaXQiLCJydW50aW1lIiwib25NZXNzYWdlIiwiYWRkTGlzdGVuZXIiLCJoYW5kbGVNZXNzYWdlIiwidHlwZSIsImxpc3RlbmVyIiwibGlzdGVuZXJzIiwiaGFzIiwiRXJyb3IiLCJzZXQiLCJyZW1vdmVMaXN0ZW5lciIsImRlbGV0ZSIsInJlbW92ZUxpc3RlbmVycyIsImNsZWFyIiwiaXNWYWxpZE1lc3NhZ2VUeXBlIiwiaGFuZGxlck5hbWUiLCJjb25zdHJ1Y3RvciIsIk1hcCIsImJpbmQiLCJzZW5kTWVzc2FnZSIsImUiLCJzZW5kVGFiTWVzc2FnZSIsInRhYklkIiwidGFicyIsIlVBUGFyc2VyIiwiTUlOX1NVUFBPUlRFRF9WRVJTSU9OIiwiVXNlckFnZW50IiwiZ2V0QnJvd3Nlck5hbWUiLCJpc0ZpcmVmb3hNb2JpbGUiLCJwYXJzZXIiLCJnZXRCcm93c2VyIiwibmFtZSIsImdldFN5c3RlbU5hbWUiLCJnZXRPUyIsImdldFN5c3RlbVZlcnNpb24iLCJ2ZXJzaW9uIiwiZ2V0UGxhdGZvcm1WZXJzaW9uIiwicGxhdGZvcm1WZXJzaW9uIiwidWEiLCJuYXZpZ2F0b3IiLCJ1c2VyQWdlbnREYXRhIiwiZ2V0SGlnaEVudHJvcHlWYWx1ZXMiLCJQTEFURk9STV9WRVJTSU9OIiwiZ2V0QWN0dWFsV2luZG93c1ZlcnNpb24iLCJhY3R1YWxWZXJzaW9uIiwicmF3TWFqb3JQbGF0Zm9ybVZlcnNpb24iLCJzcGxpdCIsIm1ham9yUGxhdGZvcm1WZXJzaW9uIiwicGFyc2VJbnQiLCJOdW1iZXIiLCJpc05hTiIsIk1JTl9XSU5ET1dTXzExX1BMQVRGT1JNX1ZFUlNJT04iLCJXSU5ET1dTXzExX09TX1ZFUlNJT04iLCJnZXRBY3R1YWxNYWNvc1ZlcnNpb24iLCJnZXRTeXN0ZW1JbmZvIiwic3lzdGVtSW5mbyIsIm9zTmFtZSIsIm9zVmVyc2lvbiIsImlzV2luZG93cyIsIldJTkRPV1NfMTBfT1NfVkVSU0lPTiIsImlzTWFjT3MiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJpc1RhcmdldEJyb3dzZXIiLCJicm93c2VyTmFtZSIsImlzVGFyZ2V0UGxhdGZvcm0iLCJwbGF0Zm9ybU5hbWUiLCJpc1RhcmdldEVuZ2luZSIsImVuZ2luZU5hbWUiLCJnZXRFbmdpbmUiLCJpc1RhcmdldERldmljZVR5cGUiLCJkZXZpY2VUeXBlIiwiZ2V0RGV2aWNlIiwiZ2V0VmVyc2lvbiIsInZlcnNpb25OdW1iZXIiLCJ1c2VyQWdlbnQiLCJpc0Nocm9tZSIsImlzRmlyZWZveCIsImlzT3BlcmEiLCJpc1lhbmRleCIsImlzRWRnZSIsImlzRWRnZUNocm9taXVtIiwiaXNBbmRyb2lkIiwiaXNDaHJvbWl1bSIsImlzTW9iaWxlRGV2aWNlIiwiaXNTdXBwb3J0ZWRCcm93c2VyIiwiQ0hST01JVU1fTVYyIiwiRURHRV9DSFJPTUlVTSIsIkZJUkVGT1giLCJGSVJFRk9YX01PQklMRSIsIk9QRVJBIiwibmFub2lkIiwiUGFnZSIsIk1lc3NlbmdlciIsImRhdGEiLCJyZXNwb25zZSIsInVwZGF0ZUxpc3RlbmVycyIsIlVwZGF0ZUxpc3RlbmVycyIsImdldE9wdGlvbnNEYXRhIiwiR2V0T3B0aW9uc0RhdGEiLCJjaGFuZ2VVc2VyU2V0dGluZyIsInNldHRpbmdJZCIsInZhbHVlIiwiQ2hhbmdlVXNlclNldHRpbmdzIiwia2V5Iiwib3BlbkV4dGVuc2lvblN0b3JlIiwiT3BlbkV4dGVuc2lvblN0b3JlIiwib3BlbkNvbXBhcmVQYWdlIiwiT3BlbkNvbXBhcmVQYWdlIiwiZW5hYmxlRmlsdGVyIiwiZmlsdGVySWQiLCJBZGRBbmRFbmFibGVGaWx0ZXIiLCJkaXNhYmxlRmlsdGVyIiwiRGlzYWJsZUZpbHRlciIsImFwcGx5U2V0dGluZ3NKc29uIiwianNvbiIsIkFwcGx5U2V0dGluZ3NKc29uIiwib3BlbkZpbHRlcmluZ0xvZyIsIk9wZW5GaWx0ZXJpbmdMb2ciLCJyZXNldFN0YXRpc3RpY3MiLCJSZXNldEJsb2NrZWRBZHNDb3VudCIsInNldEZpbHRlcmluZ0xvZ1dpbmRvd1N0YXRlIiwid2luZG93U3RhdGUiLCJTZXRGaWx0ZXJpbmdMb2dXaW5kb3dTdGF0ZSIsInJlc2V0U2V0dGluZ3MiLCJSZXNldFNldHRpbmdzIiwiZ2V0VXNlclJ1bGVzIiwiR2V0VXNlclJ1bGVzIiwic2F2ZVVzZXJSdWxlcyIsIlNhdmVVc2VyUnVsZXMiLCJvcGVuRnVsbHNjcmVlblVzZXJSdWxlcyIsIk9wZW5GdWxsc2NyZWVuVXNlclJ1bGVzIiwiZ2V0QWxsb3dsaXN0IiwiR2V0QWxsb3dsaXN0RG9tYWlucyIsInNhdmVBbGxvd2xpc3QiLCJTYXZlQWxsb3dsaXN0RG9tYWlucyIsInNldE5vdGlmaWNhdGlvblZpZXdlZCIsIndpdGhEZWxheSIsIlNldE5vdGlmaWNhdGlvblZpZXdlZCIsInVwZGF0ZUZpbHRlcnMiLCJfX0lTX01WM19fIiwiZGVidWciLCJDaGVja0ZpbHRlcnNVcGRhdGUiLCJ1cGRhdGVHcm91cFN0YXR1cyIsImlkIiwiZW5hYmxlZCIsIkVuYWJsZUZpbHRlcnNHcm91cCIsIkRpc2FibGVGaWx0ZXJzR3JvdXAiLCJncm91cElkIiwic2V0Q29uc2VudGVkRmlsdGVycyIsImZpbHRlcklkcyIsIlNldENvbnNlbnRlZEZpbHRlcnMiLCJnZXRJc0NvbnNlbnRlZEZpbHRlciIsIkdldElzQ29uc2VudGVkRmlsdGVyIiwiY2hlY2tDdXN0b21VcmwiLCJ1cmwiLCJMb2FkQ3VzdG9tRmlsdGVySW5mbyIsImFkZEN1c3RvbUZpbHRlciIsImZpbHRlciIsIlN1YnNjcmliZVRvQ3VzdG9tRmlsdGVyIiwicmVtb3ZlQ3VzdG9tRmlsdGVyIiwiUmVtb3ZlQW50aUJhbm5lckZpbHRlciIsImdldElzRW5naW5lU3RhcnRlZCIsIkdldElzRW5naW5lU3RhcnRlZCIsImdldFRhYkluZm9Gb3JQb3B1cCIsIkdldFRhYkluZm9Gb3JQb3B1cCIsImNoYW5nZUFwcGxpY2F0aW9uRmlsdGVyaW5nUGF1c2VkIiwic3RhdGUiLCJDaGFuZ2VBcHBsaWNhdGlvbkZpbHRlcmluZ1BhdXNlZCIsInVwZGF0ZUZ1bGxzY3JlZW5Vc2VyUnVsZXNUaGVtZSIsInRoZW1lIiwiVXBkYXRlRnVsbHNjcmVlblVzZXJSdWxlc1RoZW1lIiwib3BlblJ1bGVzTGltaXRzVGFiIiwiT3BlblJ1bGVzTGltaXRzVGFiIiwib3BlblNldHRpbmdzVGFiIiwiT3BlblNldHRpbmdzVGFiIiwib3BlbkFzc2lzdGFudCIsIk9wZW5Bc3Npc3RhbnQiLCJvcGVuQWJ1c2VTaXRlIiwiZnJvbSIsIk9wZW5BYnVzZVRhYiIsImNoZWNrU2l0ZVNlY3VyaXR5IiwiT3BlblNpdGVSZXBvcnRUYWIiLCJyZXNldFVzZXJSdWxlc0ZvclBhZ2UiLCJjdXJyZW50VGFiIiwicXVlcnkiLCJhY3RpdmUiLCJjdXJyZW50V2luZG93IiwiUmVzZXRVc2VyUnVsZXNGb3JQYWdlIiwicmVtb3ZlQWxsb3dsaXN0RG9tYWluIiwidGFiUmVmcmVzaCIsIlJlbW92ZUFsbG93bGlzdERvbWFpbiIsImFkZEFsbG93bGlzdERvbWFpbiIsIkFkZEFsbG93bGlzdERvbWFpbiIsIm9uT3BlbkZpbHRlcmluZ0xvZ1BhZ2UiLCJPbk9wZW5GaWx0ZXJpbmdMb2dQYWdlIiwiZ2V0RmlsdGVyaW5nTG9nRGF0YSIsIkdldEZpbHRlcmluZ0xvZ0RhdGEiLCJvbkNsb3NlRmlsdGVyaW5nTG9nUGFnZSIsIk9uQ2xvc2VGaWx0ZXJpbmdMb2dQYWdlIiwiZ2V0RmlsdGVyaW5nSW5mb0J5VGFiSWQiLCJHZXRGaWx0ZXJpbmdJbmZvQnlUYWJJZCIsInN5bmNocm9uaXplT3BlblRhYnMiLCJTeW5jaHJvbml6ZU9wZW5UYWJzIiwiY2xlYXJFdmVudHNCeVRhYklkIiwiaWdub3JlUHJlc2VydmVMb2ciLCJDbGVhckV2ZW50c0J5VGFiSWQiLCJyZWZyZXNoUGFnZSIsIlJlZnJlc2hQYWdlIiwiYWRkVXNlclJ1bGUiLCJydWxlVGV4dCIsIkFkZFVzZXJSdWxlIiwicmVtb3ZlVXNlclJ1bGUiLCJSZW1vdmVVc2VyUnVsZSIsInNldFByZXNlcnZlTG9nU3RhdGUiLCJTZXRQcmVzZXJ2ZUxvZ1N0YXRlIiwiZ2V0RWRpdG9yU3RvcmFnZUNvbnRlbnQiLCJHZXRFZGl0b3JTdG9yYWdlQ29udGVudCIsInNldEVkaXRvclN0b3JhZ2VDb250ZW50IiwiY29udGVudCIsIlNldEVkaXRvclN0b3JhZ2VDb250ZW50IiwiZ2V0UnVsZXNMaW1pdHNDb3VudGVycyIsIkdldFJ1bGVzTGltaXRzQ291bnRlcnNNdjMiLCJjYW5FbmFibGVTdGF0aWNGaWx0ZXIiLCJDYW5FbmFibGVTdGF0aWNGaWx0ZXJNdjMiLCJjYW5FbmFibGVTdGF0aWNHcm91cCIsIkNhbkVuYWJsZVN0YXRpY0dyb3VwTXYzIiwiZ2V0Q3VycmVudExpbWl0cyIsIkN1cnJlbnRMaW1pdHNNdjMiLCJjaGVja1JlcXVlc3RGaWx0ZXJSZWFkeSIsIkNoZWNrUmVxdWVzdEZpbHRlclJlYWR5IiwiYWRkVXJsVG9UcnVzdGVkIiwiQWRkVXJsVG9UcnVzdGVkIiwiZ2V0VXNlclJ1bGVzRWRpdG9yRGF0YSIsIkdldFVzZXJSdWxlc0VkaXRvckRhdGEiLCJyZXN0b3JlRmlsdGVyc012MyIsIlJlc3RvcmVGaWx0ZXJzTXYzIiwiY2xlYXJSdWxlc0xpbWl0c1dhcm5pbmdNdjMiLCJDbGVhclJ1bGVzTGltaXRzV2FybmluZ012MyIsImdldEFsbG93bGlzdERvbWFpbnMiLCJsb2FkU2V0dGluZ3NKc29uIiwiTG9hZFNldHRpbmdzSnNvbiIsIm9wZW5UaGFua3lvdVBhZ2UiLCJPcGVuVGhhbmt5b3VQYWdlIiwiaW5pdGlhbGl6ZUZyYW1lU2NyaXB0IiwiSW5pdGlhbGl6ZUZyYW1lU2NyaXB0Iiwib3BlblNhZmVicm93c2luZ1RydXN0ZWQiLCJPcGVuU2FmZWJyb3dzaW5nVHJ1c3RlZCIsImNyZWF0ZUV2ZW50TGlzdGVuZXIiLCJldmVudHMiLCJjYWxsYmFjayIsIm9uVW5sb2FkQ2FsbGJhY2siLCJsaXN0ZW5lcklkIiwiQ3JlYXRlRXZlbnRMaXN0ZW5lciIsIm9uVXBkYXRlTGlzdGVuZXJzIiwidXBkYXRlZFJlc3BvbnNlIiwiZXJyb3IiLCJOb3RpZnlMaXN0ZW5lcnMiLCJjYXN0ZWRNZXNzYWdlIiwiaW5jbHVkZXMiLCJvblVubG9hZCIsIlJlbW92ZUxpc3RlbmVyIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsImNyZWF0ZUxvbmdMaXZlZENvbm5lY3Rpb24iLCJwYWdlIiwicG9ydCIsImZvcmNlRGlzY29ubmVjdGVkIiwiY29ubmVjdCIsInBvc3RNZXNzYWdlIiwiQWRkTG9uZ0xpdmVkQ29ubmVjdGlvbiIsIm9uRGlzY29ubmVjdCIsImxhc3RFcnJvciIsImRpc2Nvbm5lY3QiLCJtZXNzZW5nZXIiLCJQYWdlQ29udHJvbGxlciIsInVzZXJTZXR0aW5ncyIsImVuYWJsZWRGaWx0ZXJzIiwiY29uc3RhbnRzIiwiQW50aUJhbm5lckZpbHRlcnNJZCIsInNhZmVicm93c2luZ0VuYWJsZWRDaGVja2JveCIsInRyYWNraW5nRmlsdGVyRW5hYmxlZENoZWNrYm94Iiwic29jaWFsRmlsdGVyRW5hYmxlZENoZWNrYm94Iiwic2VuZFN0YXRzQ2hlY2tib3giLCJhbGxvd0FjY2VwdGFibGVBZHNDaGVja2JveCIsInNhZmVicm93c2luZ0VuYWJsZWRDaGFuZ2UiLCJjaGVja2JveCIsImN1cnJlbnRUYXJnZXQiLCJuYW1lcyIsIkRpc2FibGVTYWZlYnJvd3NpbmciLCJjaGVja2VkIiwidHJhY2tpbmdGaWx0ZXJFbmFibGVkQ2hhbmdlIiwiVHJhY2tpbmdGaWx0ZXJJZCIsInNvY2lhbEZpbHRlckVuYWJsZWRDaGFuZ2UiLCJTb2NpYWxGaWx0ZXJJZCIsInNlbmRTdGF0c0NoZWNrYm94Q2hhbmdlIiwiRGlzYWJsZUNvbGxlY3RIaXRzIiwiYWxsb3dBY2NlcHRhYmxlQWRzQ2hhbmdlIiwiU2VhcmNoQW5kU2VsZlByb21vRmlsdGVySWQiLCJiaW5kRXZlbnRzIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsIm9wZW5FeHRlbnNpb25TdG9yZUJ0bnMiLCJzbGljZSIsImNhbGwiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZm9yRWFjaCIsIm9wZW5FeHRlbnNpb25TdG9yZUJ0biIsInByZXZlbnREZWZhdWx0Iiwib3BlblNldHRpbmdzQnRucyIsIm9wZW5TZXR0aW5nc0J0biIsInVwZGF0ZUNoZWNrYm94Iiwic2V0QXR0cmlidXRlIiwicmVtb3ZlQXR0cmlidXRlIiwicmVuZGVyIiwidHJhY2tpbmdGaWx0ZXJFbmFibGVkIiwic29jaWFsRmlsdGVyRW5hYmxlZCIsImFsbG93QWNjZXB0YWJsZUFkc0VuYWJsZWQiLCJjb2xsZWN0SGl0c0NvdW50IiwidmFsdWVzIiwic2FmZWJyb3dzaW5nRW5hYmxlZCIsInRpbWVvdXRJZCIsImNvdW50ZXIiLCJNQVhfV0FJVF9SRVRSWSIsIlJFVFJZX1RJTUVPVVRfTVMiLCJjbGVhclRpbWVvdXQiLCJzZXRUaW1lb3V0IiwiY29udHJvbGxlciIsInJlYWR5U3RhdGUiLCJ0aGFua3lvdSIsIldFQl9BQ0NFU1NJQkxFX1JFU09VUkNFU19PVVRQVVQiLCJXRUJfQUNDRVNTSUJMRV9SRVNPVVJDRVNfT1VUUFVUX1JFRElSRUNUUyIsIkJBQ0tHUk9VTkRfT1VUUFVUIiwiT1BUSU9OU19PVVRQVVQiLCJQT1BVUF9PVVRQVVQiLCJGSUxURVJJTkdfTE9HX09VVFBVVCIsIlBPU1RfSU5TVEFMTF9PVVRQVVQiLCJGVUxMU0NSRUVOX1VTRVJfUlVMRVNfT1VUUFVUIiwiU0FGRUJST1dTSU5HX09VVFBVVCIsIkRPQ1VNRU5UX0JMT0NLX09VVFBVVCIsIlNVQlNDUklCRV9PVVRQVVQiLCJDT05URU5UX1NDUklQVF9TVEFSVF9PVVRQVVQiLCJDT05URU5UX1NDUklQVF9FTkRfT1VUUFVUIiwiVEhBTktZT1VfT1VUUFVUIiwiQVNTSVNUQU5UX0lOSkVDVF9PVVRQVVQiLCJHUENfU0NSSVBUX09VVFBVVCIsIkhJREVfRE9DVU1FTlRfUkVGRVJSRVJfT1VUUFVUIiwiREVWVE9PTFNfT1VUUFVUIiwiREVWVE9PTFNfRUxFTUVOVF9TSURFQkFSX09VVFBVVCIsIlNIQVJFRF9FRElUT1JfT1VUUFVUIiwiUkVBQ1RfVkVORE9SX09VVFBVVCIsIk1PQlhfVkVORE9SX09VVFBVVCIsIlhTVEFURV9WRU5ET1JfT1VUUFVUIiwiVFNVUkxGSUxURVJfVkVORE9SX09VVFBVVCIsIkFHVFJFRV9WRU5ET1JfT1VUUFVUIiwiQ1NTX1RPS0VOSVpFUl9WRU5ET1JfT1VUUFVUIiwiVFNXRUJFWFRFTlNJT05fVkVORE9SX09VVFBVVCIsIlRFWFRfRU5DT0RJTkdfUE9MWUZJTExfVkVORE9SX09VVFBVVCIsIlNDUklQVExFVFNfVkVORE9SX09VVFBVVCIsIlJFTU9URV9NRVRBREFUQV9GSUxFX05BTUUiLCJSRU1PVEVfSTE4Tl9NRVRBREFUQV9GSUxFX05BTUUiLCJMT0NBTF9NRVRBREFUQV9GSUxFX05BTUUiLCJMT0NBTF9JMThOX01FVEFEQVRBX0ZJTEVfTkFNRSIsIkFER1VBUkRfRklMVEVSU19JRFMiLCJDSFJPTUlVTV9NVjMiXSwic291cmNlUm9vdCI6IiJ9