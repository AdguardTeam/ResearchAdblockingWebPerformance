/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/common/stealth-helper.js":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/common/stealth-helper.js ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S: () => (/* binding */ StealthHelper)
/* harmony export */ });
// Disable vi coverage for this file, because it will insert
// line comments, and code to count lines covered by tests, for example:
// /* istanbul ignore next */
// cov_uqm40oh03().f[0]++;
// cov_uqm40oh03().s[2]++;
// And we cannot test these strings correctly, because the names of these
// functions with counters are generated at runtime
/* istanbul ignore file */
/**
 * This module applies stealth actions in page context.
 */
class StealthHelper {
    /**
     * Sends a Global Privacy Control DOM signal.
     */
    static setDomSignal() {
        try {
            if ('globalPrivacyControl' in Navigator.prototype) {
                return;
            }
            Object.defineProperty(Navigator.prototype, 'globalPrivacyControl', {
                get: () => true,
                configurable: true,
                enumerable: true,
            });
        }
        catch (ex) {
            // Ignore
        }
    }
    /**
     * Hides document referrer.
     */
    static hideDocumentReferrer() {
        const origDescriptor = Object.getOwnPropertyDescriptor(Document.prototype, 'referrer');
        if (!origDescriptor || !origDescriptor.get || !origDescriptor.configurable) {
            return;
        }
        const returnEmptyReferrerFunc = () => '';
        // Protect getter from native code check
        returnEmptyReferrerFunc.toString = origDescriptor.get.toString.bind(origDescriptor.get);
        Object.defineProperty(Document.prototype, 'referrer', {
            get: returnEmptyReferrerFunc,
        });
    }
}




/***/ }),

/***/ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/gpc.mv3.js":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/gpc.mv3.js ***!
  \**********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _common_stealth_helper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common/stealth-helper.js */ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/common/stealth-helper.js");


/**
 * @typedef {import('../background/services/stealth-service').StealthService} StealthService
 */
/**
 * @file
 * IMPORTANT: This file should be listed inside 'sideEffects' field
 * in the package.json, because it has side effects: we do not export anything
 * from it outside, just evaluate the code (via injection).
 *
 * We will inject this script dynamically via `scripting.registerContentScripts`
 * inside {@link StealthService.setContentScript}.
 */
_common_stealth_helper_js__WEBPACK_IMPORTED_MODULE_0__.S.setDomSignal();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!**************************************!*\
  !*** ./Extension/pages/gpc/index.ts ***!
  \**************************************/
/* harmony import */ var _adguard_tswebextension_mv3_gpc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @adguard/tswebextension/mv3/gpc */ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/gpc.mv3.js");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * We do not inject this scripts manually from extension, because it will be
 * dynamically registered and unregistered by the tswebextension when the
 * stealth option is enabled/disabled.
 */ 

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvZ3BjLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRThCOzs7Ozs7Ozs7Ozs7QUMvQ2tDOztBQUVoRTtBQUNBLGFBQWEsaUVBQWlFO0FBQzlFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLHNDQUFzQztBQUNqRDtBQUNBLHdEQUFhOzs7Ozs7O1VDZGI7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0N0QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQyxHQUVEOzs7O0NBSUMsR0FDd0MiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ2l0aHViLmNvbStBZGd1YXJkVGVhbSt0c3VybGZpbHRlcityYXcrODBmNDM5YWM0NmUyNjM5MWI4ODdiNjgzZDMxYTVjYmI1NWE3MTdlZCtwYWNrYWdlcyt0c3dfdHo0cG5ieDRicnRuZWpvdmhvbWtzZmxqZ20vbm9kZV9tb2R1bGVzL0BhZGd1YXJkL3Rzd2ViZXh0ZW5zaW9uL2Rpc3QvY29tbW9uL3N0ZWFsdGgtaGVscGVyLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzLy5wbnBtL0BnaXRodWIuY29tK0FkZ3VhcmRUZWFtK3RzdXJsZmlsdGVyK3Jhdys4MGY0MzlhYzQ2ZTI2MzkxYjg4N2I2ODNkMzFhNWNiYjU1YTcxN2VkK3BhY2thZ2VzK3Rzd190ejRwbmJ4NGJydG5lam92aG9ta3NmbGpnbS9ub2RlX21vZHVsZXMvQGFkZ3VhcmQvdHN3ZWJleHRlbnNpb24vZGlzdC9ncGMubXYzLmpzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uLy4vRXh0ZW5zaW9uL3BhZ2VzL2dwYy9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBEaXNhYmxlIHZpIGNvdmVyYWdlIGZvciB0aGlzIGZpbGUsIGJlY2F1c2UgaXQgd2lsbCBpbnNlcnRcbi8vIGxpbmUgY29tbWVudHMsIGFuZCBjb2RlIHRvIGNvdW50IGxpbmVzIGNvdmVyZWQgYnkgdGVzdHMsIGZvciBleGFtcGxlOlxuLy8gLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbi8vIGNvdl91cW00MG9oMDMoKS5mWzBdKys7XG4vLyBjb3ZfdXFtNDBvaDAzKCkuc1syXSsrO1xuLy8gQW5kIHdlIGNhbm5vdCB0ZXN0IHRoZXNlIHN0cmluZ3MgY29ycmVjdGx5LCBiZWNhdXNlIHRoZSBuYW1lcyBvZiB0aGVzZVxuLy8gZnVuY3Rpb25zIHdpdGggY291bnRlcnMgYXJlIGdlbmVyYXRlZCBhdCBydW50aW1lXG4vKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyoqXG4gKiBUaGlzIG1vZHVsZSBhcHBsaWVzIHN0ZWFsdGggYWN0aW9ucyBpbiBwYWdlIGNvbnRleHQuXG4gKi9cbmNsYXNzIFN0ZWFsdGhIZWxwZXIge1xuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgR2xvYmFsIFByaXZhY3kgQ29udHJvbCBET00gc2lnbmFsLlxuICAgICAqL1xuICAgIHN0YXRpYyBzZXREb21TaWduYWwoKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoJ2dsb2JhbFByaXZhY3lDb250cm9sJyBpbiBOYXZpZ2F0b3IucHJvdG90eXBlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KE5hdmlnYXRvci5wcm90b3R5cGUsICdnbG9iYWxQcml2YWN5Q29udHJvbCcsIHtcbiAgICAgICAgICAgICAgICBnZXQ6ICgpID0+IHRydWUsXG4gICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIC8vIElnbm9yZVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEhpZGVzIGRvY3VtZW50IHJlZmVycmVyLlxuICAgICAqL1xuICAgIHN0YXRpYyBoaWRlRG9jdW1lbnRSZWZlcnJlcigpIHtcbiAgICAgICAgY29uc3Qgb3JpZ0Rlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKERvY3VtZW50LnByb3RvdHlwZSwgJ3JlZmVycmVyJyk7XG4gICAgICAgIGlmICghb3JpZ0Rlc2NyaXB0b3IgfHwgIW9yaWdEZXNjcmlwdG9yLmdldCB8fCAhb3JpZ0Rlc2NyaXB0b3IuY29uZmlndXJhYmxlKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmV0dXJuRW1wdHlSZWZlcnJlckZ1bmMgPSAoKSA9PiAnJztcbiAgICAgICAgLy8gUHJvdGVjdCBnZXR0ZXIgZnJvbSBuYXRpdmUgY29kZSBjaGVja1xuICAgICAgICByZXR1cm5FbXB0eVJlZmVycmVyRnVuYy50b1N0cmluZyA9IG9yaWdEZXNjcmlwdG9yLmdldC50b1N0cmluZy5iaW5kKG9yaWdEZXNjcmlwdG9yLmdldCk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShEb2N1bWVudC5wcm90b3R5cGUsICdyZWZlcnJlcicsIHtcbiAgICAgICAgICAgIGdldDogcmV0dXJuRW1wdHlSZWZlcnJlckZ1bmMsXG4gICAgICAgIH0pO1xuICAgIH1cbn1cblxuZXhwb3J0IHsgU3RlYWx0aEhlbHBlciBhcyBTIH07XG4iLCJpbXBvcnQgeyBTIGFzIFN0ZWFsdGhIZWxwZXIgfSBmcm9tICcuL2NvbW1vbi9zdGVhbHRoLWhlbHBlci5qcyc7XG5cbi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy9zdGVhbHRoLXNlcnZpY2UnKS5TdGVhbHRoU2VydmljZX0gU3RlYWx0aFNlcnZpY2VcbiAqL1xuLyoqXG4gKiBAZmlsZVxuICogSU1QT1JUQU5UOiBUaGlzIGZpbGUgc2hvdWxkIGJlIGxpc3RlZCBpbnNpZGUgJ3NpZGVFZmZlY3RzJyBmaWVsZFxuICogaW4gdGhlIHBhY2thZ2UuanNvbiwgYmVjYXVzZSBpdCBoYXMgc2lkZSBlZmZlY3RzOiB3ZSBkbyBub3QgZXhwb3J0IGFueXRoaW5nXG4gKiBmcm9tIGl0IG91dHNpZGUsIGp1c3QgZXZhbHVhdGUgdGhlIGNvZGUgKHZpYSBpbmplY3Rpb24pLlxuICpcbiAqIFdlIHdpbGwgaW5qZWN0IHRoaXMgc2NyaXB0IGR5bmFtaWNhbGx5IHZpYSBgc2NyaXB0aW5nLnJlZ2lzdGVyQ29udGVudFNjcmlwdHNgXG4gKiBpbnNpZGUge0BsaW5rIFN0ZWFsdGhTZXJ2aWNlLnNldENvbnRlbnRTY3JpcHR9LlxuICovXG5TdGVhbHRoSGVscGVyLnNldERvbVNpZ25hbCgpO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvKipcbiAqIEBmaWxlXG4gKiBUaGlzIGZpbGUgaXMgcGFydCBvZiBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uIChodHRwczovL2dpdGh1Yi5jb20vQWRndWFyZFRlYW0vQWRndWFyZEJyb3dzZXJFeHRlbnNpb24pLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXG4gKiBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuXG4gKiBTZWUgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogWW91IHNob3VsZCBoYXZlIHJlY2VpdmVkIGEgY29weSBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2VcbiAqIGFsb25nIHdpdGggQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbi4gSWYgbm90LCBzZWUgPGh0dHA6Ly93d3cuZ251Lm9yZy9saWNlbnNlcy8+LlxuICovXG5cbi8qKlxuICogV2UgZG8gbm90IGluamVjdCB0aGlzIHNjcmlwdHMgbWFudWFsbHkgZnJvbSBleHRlbnNpb24sIGJlY2F1c2UgaXQgd2lsbCBiZVxuICogZHluYW1pY2FsbHkgcmVnaXN0ZXJlZCBhbmQgdW5yZWdpc3RlcmVkIGJ5IHRoZSB0c3dlYmV4dGVuc2lvbiB3aGVuIHRoZVxuICogc3RlYWx0aCBvcHRpb24gaXMgZW5hYmxlZC9kaXNhYmxlZC5cbiAqL1xuaW1wb3J0ICdAYWRndWFyZC90c3dlYmV4dGVuc2lvbi9tdjMvZ3BjJztcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==