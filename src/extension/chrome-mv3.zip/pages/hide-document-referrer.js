/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/common/stealth-helper.js":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/common/stealth-helper.js ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S: () => (/* binding */ StealthHelper)
/* harmony export */ });
// Disable vi coverage for this file, because it will insert
// line comments, and code to count lines covered by tests, for example:
// /* istanbul ignore next */
// cov_uqm40oh03().f[0]++;
// cov_uqm40oh03().s[2]++;
// And we cannot test these strings correctly, because the names of these
// functions with counters are generated at runtime
/* istanbul ignore file */
/**
 * This module applies stealth actions in page context.
 */
class StealthHelper {
    /**
     * Sends a Global Privacy Control DOM signal.
     */
    static setDomSignal() {
        try {
            if ('globalPrivacyControl' in Navigator.prototype) {
                return;
            }
            Object.defineProperty(Navigator.prototype, 'globalPrivacyControl', {
                get: () => true,
                configurable: true,
                enumerable: true,
            });
        }
        catch (ex) {
            // Ignore
        }
    }
    /**
     * Hides document referrer.
     */
    static hideDocumentReferrer() {
        const origDescriptor = Object.getOwnPropertyDescriptor(Document.prototype, 'referrer');
        if (!origDescriptor || !origDescriptor.get || !origDescriptor.configurable) {
            return;
        }
        const returnEmptyReferrerFunc = () => '';
        // Protect getter from native code check
        returnEmptyReferrerFunc.toString = origDescriptor.get.toString.bind(origDescriptor.get);
        Object.defineProperty(Document.prototype, 'referrer', {
            get: returnEmptyReferrerFunc,
        });
    }
}




/***/ }),

/***/ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/hide-document-referrer.mv3.js":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/hide-document-referrer.mv3.js ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _common_stealth_helper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common/stealth-helper.js */ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/common/stealth-helper.js");


/**
 * @typedef {import('../background/services/stealth-service').StealthService} StealthService
 */
/**
 * @file
 * IMPORTANT: This file should be listed inside 'sideEffects' field
 * in the package.json, because it has side effects: we do not export anything
 * from it outside, just evaluate the code (via injection).
 *
 * We will inject this script dynamically via `scripting.registerContentScripts`
 * inside {@link StealthService.setContentScript}.
 */
_common_stealth_helper_js__WEBPACK_IMPORTED_MODULE_0__.S.hideDocumentReferrer();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!*********************************************************!*\
  !*** ./Extension/pages/hide-document-referrer/index.ts ***!
  \*********************************************************/
/* harmony import */ var _adguard_tswebextension_mv3_hide_document_referrer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @adguard/tswebextension/mv3/hide-document-referrer */ "./node_modules/.pnpm/@github.com+AdguardTeam+tsurlfilter+raw+80f439ac46e26391b887b683d31a5cbb55a717ed+packages+tsw_tz4pnbx4brtnejovhomksfljgm/node_modules/@adguard/tswebextension/dist/hide-document-referrer.mv3.js");
/**
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * We do not inject this scripts manually from extension, because it will be
 * dynamically registered and unregistered by the tswebextension when the
 * stealth option is enabled/disabled.
 */ 

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaGlkZS1kb2N1bWVudC1yZWZlcnJlci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBOztBQUU4Qjs7Ozs7Ozs7Ozs7O0FDL0NrQzs7QUFFaEU7QUFDQSxhQUFhLGlFQUFpRTtBQUM5RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxzQ0FBc0M7QUFDakQ7QUFDQSx3REFBYTs7Ozs7OztVQ2RiO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7O1dDdEJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FFRDs7OztDQUlDLEdBQzJEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vQGdpdGh1Yi5jb20rQWRndWFyZFRlYW0rdHN1cmxmaWx0ZXIrcmF3KzgwZjQzOWFjNDZlMjYzOTFiODg3YjY4M2QzMWE1Y2JiNTVhNzE3ZWQrcGFja2FnZXMrdHN3X3R6NHBuYng0YnJ0bmVqb3Zob21rc2ZsamdtL25vZGVfbW9kdWxlcy9AYWRndWFyZC90c3dlYmV4dGVuc2lvbi9kaXN0L2NvbW1vbi9zdGVhbHRoLWhlbHBlci5qcyIsIndlYnBhY2s6Ly9icm93c2VyLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ2l0aHViLmNvbStBZGd1YXJkVGVhbSt0c3VybGZpbHRlcityYXcrODBmNDM5YWM0NmUyNjM5MWI4ODdiNjgzZDMxYTVjYmI1NWE3MTdlZCtwYWNrYWdlcyt0c3dfdHo0cG5ieDRicnRuZWpvdmhvbWtzZmxqZ20vbm9kZV9tb2R1bGVzL0BhZGd1YXJkL3Rzd2ViZXh0ZW5zaW9uL2Rpc3QvaGlkZS1kb2N1bWVudC1yZWZlcnJlci5tdjMuanMiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2Jyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vYnJvd3Nlci1leHRlbnNpb24vLi9FeHRlbnNpb24vcGFnZXMvaGlkZS1kb2N1bWVudC1yZWZlcnJlci9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBEaXNhYmxlIHZpIGNvdmVyYWdlIGZvciB0aGlzIGZpbGUsIGJlY2F1c2UgaXQgd2lsbCBpbnNlcnRcbi8vIGxpbmUgY29tbWVudHMsIGFuZCBjb2RlIHRvIGNvdW50IGxpbmVzIGNvdmVyZWQgYnkgdGVzdHMsIGZvciBleGFtcGxlOlxuLy8gLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbi8vIGNvdl91cW00MG9oMDMoKS5mWzBdKys7XG4vLyBjb3ZfdXFtNDBvaDAzKCkuc1syXSsrO1xuLy8gQW5kIHdlIGNhbm5vdCB0ZXN0IHRoZXNlIHN0cmluZ3MgY29ycmVjdGx5LCBiZWNhdXNlIHRoZSBuYW1lcyBvZiB0aGVzZVxuLy8gZnVuY3Rpb25zIHdpdGggY291bnRlcnMgYXJlIGdlbmVyYXRlZCBhdCBydW50aW1lXG4vKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyoqXG4gKiBUaGlzIG1vZHVsZSBhcHBsaWVzIHN0ZWFsdGggYWN0aW9ucyBpbiBwYWdlIGNvbnRleHQuXG4gKi9cbmNsYXNzIFN0ZWFsdGhIZWxwZXIge1xuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgR2xvYmFsIFByaXZhY3kgQ29udHJvbCBET00gc2lnbmFsLlxuICAgICAqL1xuICAgIHN0YXRpYyBzZXREb21TaWduYWwoKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoJ2dsb2JhbFByaXZhY3lDb250cm9sJyBpbiBOYXZpZ2F0b3IucHJvdG90eXBlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KE5hdmlnYXRvci5wcm90b3R5cGUsICdnbG9iYWxQcml2YWN5Q29udHJvbCcsIHtcbiAgICAgICAgICAgICAgICBnZXQ6ICgpID0+IHRydWUsXG4gICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIC8vIElnbm9yZVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEhpZGVzIGRvY3VtZW50IHJlZmVycmVyLlxuICAgICAqL1xuICAgIHN0YXRpYyBoaWRlRG9jdW1lbnRSZWZlcnJlcigpIHtcbiAgICAgICAgY29uc3Qgb3JpZ0Rlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKERvY3VtZW50LnByb3RvdHlwZSwgJ3JlZmVycmVyJyk7XG4gICAgICAgIGlmICghb3JpZ0Rlc2NyaXB0b3IgfHwgIW9yaWdEZXNjcmlwdG9yLmdldCB8fCAhb3JpZ0Rlc2NyaXB0b3IuY29uZmlndXJhYmxlKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmV0dXJuRW1wdHlSZWZlcnJlckZ1bmMgPSAoKSA9PiAnJztcbiAgICAgICAgLy8gUHJvdGVjdCBnZXR0ZXIgZnJvbSBuYXRpdmUgY29kZSBjaGVja1xuICAgICAgICByZXR1cm5FbXB0eVJlZmVycmVyRnVuYy50b1N0cmluZyA9IG9yaWdEZXNjcmlwdG9yLmdldC50b1N0cmluZy5iaW5kKG9yaWdEZXNjcmlwdG9yLmdldCk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShEb2N1bWVudC5wcm90b3R5cGUsICdyZWZlcnJlcicsIHtcbiAgICAgICAgICAgIGdldDogcmV0dXJuRW1wdHlSZWZlcnJlckZ1bmMsXG4gICAgICAgIH0pO1xuICAgIH1cbn1cblxuZXhwb3J0IHsgU3RlYWx0aEhlbHBlciBhcyBTIH07XG4iLCJpbXBvcnQgeyBTIGFzIFN0ZWFsdGhIZWxwZXIgfSBmcm9tICcuL2NvbW1vbi9zdGVhbHRoLWhlbHBlci5qcyc7XG5cbi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnLi4vYmFja2dyb3VuZC9zZXJ2aWNlcy9zdGVhbHRoLXNlcnZpY2UnKS5TdGVhbHRoU2VydmljZX0gU3RlYWx0aFNlcnZpY2VcbiAqL1xuLyoqXG4gKiBAZmlsZVxuICogSU1QT1JUQU5UOiBUaGlzIGZpbGUgc2hvdWxkIGJlIGxpc3RlZCBpbnNpZGUgJ3NpZGVFZmZlY3RzJyBmaWVsZFxuICogaW4gdGhlIHBhY2thZ2UuanNvbiwgYmVjYXVzZSBpdCBoYXMgc2lkZSBlZmZlY3RzOiB3ZSBkbyBub3QgZXhwb3J0IGFueXRoaW5nXG4gKiBmcm9tIGl0IG91dHNpZGUsIGp1c3QgZXZhbHVhdGUgdGhlIGNvZGUgKHZpYSBpbmplY3Rpb24pLlxuICpcbiAqIFdlIHdpbGwgaW5qZWN0IHRoaXMgc2NyaXB0IGR5bmFtaWNhbGx5IHZpYSBgc2NyaXB0aW5nLnJlZ2lzdGVyQ29udGVudFNjcmlwdHNgXG4gKiBpbnNpZGUge0BsaW5rIFN0ZWFsdGhTZXJ2aWNlLnNldENvbnRlbnRTY3JpcHR9LlxuICovXG5TdGVhbHRoSGVscGVyLmhpZGVEb2N1bWVudFJlZmVycmVyKCk7XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8qKlxuICogQGZpbGVcbiAqIFRoaXMgZmlsZSBpcyBwYXJ0IG9mIEFkR3VhcmQgQnJvd3NlciBFeHRlbnNpb24gKGh0dHBzOi8vZ2l0aHViLmNvbS9BZGd1YXJkVGVhbS9BZGd1YXJkQnJvd3NlckV4dGVuc2lvbikuXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBmcmVlIHNvZnR3YXJlOiB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbiwgZWl0aGVyIHZlcnNpb24gMyBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogQWRHdWFyZCBCcm93c2VyIEV4dGVuc2lvbiBpcyBkaXN0cmlidXRlZCBpbiB0aGUgaG9wZSB0aGF0IGl0IHdpbGwgYmUgdXNlZnVsLFxuICogYnV0IFdJVEhPVVQgQU5ZIFdBUlJBTlRZOyB3aXRob3V0IGV2ZW4gdGhlIGltcGxpZWQgd2FycmFudHkgb2ZcbiAqIE1FUkNIQU5UQUJJTElUWSBvciBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRS5cbiAqIFNlZSB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgZm9yIG1vcmUgZGV0YWlscy5cbiAqXG4gKiBZb3Ugc2hvdWxkIGhhdmUgcmVjZWl2ZWQgYSBjb3B5IG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZVxuICogYWxvbmcgd2l0aCBBZEd1YXJkIEJyb3dzZXIgRXh0ZW5zaW9uLiBJZiBub3QsIHNlZSA8aHR0cDovL3d3dy5nbnUub3JnL2xpY2Vuc2VzLz4uXG4gKi9cblxuLyoqXG4gKiBXZSBkbyBub3QgaW5qZWN0IHRoaXMgc2NyaXB0cyBtYW51YWxseSBmcm9tIGV4dGVuc2lvbiwgYmVjYXVzZSBpdCB3aWxsIGJlXG4gKiBkeW5hbWljYWxseSByZWdpc3RlcmVkIGFuZCB1bnJlZ2lzdGVyZWQgYnkgdGhlIHRzd2ViZXh0ZW5zaW9uIHdoZW4gdGhlXG4gKiBzdGVhbHRoIG9wdGlvbiBpcyBlbmFibGVkL2Rpc2FibGVkLlxuICovXG5pbXBvcnQgJ0BhZGd1YXJkL3Rzd2ViZXh0ZW5zaW9uL212My9oaWRlLWRvY3VtZW50LXJlZmVycmVyJztcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==